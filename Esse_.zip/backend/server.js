import app from "./src/app.js";
import { sequelize } from "./src/core/database.js";
import { env } from "./src/core/env.js";

async function start() {
  try {
    await sequelize.authenticate();
    console.log("Database ulanishi muvaffaqiyatli.");

    app.listen(env.port, () => {
      console.log(`Server ${env.port}-portda ishga tushdi.`);
    });
  } catch (error) {
    console.error("Serverni ishga tushirishda xatolik:", error);
    process.exit(1);
  }
}

start();
