import express from "express";
import cors from "cors";
import helmet from "helmet";
import path from "path";
import { env } from "./core/env.js";
import { sequelize } from "./core/database.js";
import userRoutes from "./modules/user/user.routes.js";
import essayRoutes from "./modules/essay/essay.routes.js";
import evaluationRoutes from "./modules/evaluation/evaluation.routes.js";
import paymentRoutes from "./modules/payment/payment.routes.js";
import meRoutes from "./modules/me/me.routes.js";
import topicRoutes from "./modules/topic/topic.routes.js";
import articleRoutes from "./modules/article/article.routes.js";
import competitionRoutes from "./modules/competition/competition.routes.js";
import channelRoutes from "./modules/channel/channel.routes.js";
import adminRoutes from "./modules/admin/admin.routes.js";
import settingRoutes from "./modules/setting/setting.routes.js";
import feedbackRoutes from "./modules/feedback/feedback.routes.js";
import { errorHandler } from "./middleware/errorHandler.js";
import { rateLimit } from "./middleware/rateLimit.js";
import { startPaymentExpirySweeper } from "./modules/payment/payment.service.js";

const app = express();

// Tunnel/reverse-proxy orqasida ishlaganda haqiqiy mijoz IP'sini olish uchun
// (rate limiter va loglar to'g'ri IP ko'rishi uchun).
app.set("trust proxy", 1);

// Rasm/fayl statik xizmati (maqola muqovalari) helmet CORP siyosatini
// bo'shashtiramiz, aks holda frontend boshqa origindan rasmni yuklay olmaydi
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));

// CORS: agar CORS_ORIGINS o'rnatilgan bo'lsa (vergul bilan ajratilgan ro'yxat)
// - faqat shu originlarga ruxsat beriladi (production uchun tavsiya etiladi).
// O'rnatilmasa - hamma originga ruxsat (eski xatti-harakat, lekin ogohlantirish
// beriladi). Eslatma: bot va userbot server tomonidan chaqiradi - ularga CORS
// umuman ta'sir qilmaydi (faqat brauzer so'rovlariga taalluqli).
if (env.corsOrigins.length > 0) {
  app.use(cors({ origin: env.corsOrigins }));
} else {
  if (env.nodeEnv === "production") {
    console.warn(
      "OGOHLANTIRISH: CORS_ORIGINS o'rnatilmagan - barcha originlarga ruxsat " +
        "berilmoqda. Production uchun .env'da CORS_ORIGINS ni belgilang.",
    );
  }
  app.use(cors());
}

// So'rov tanasi hajmini cheklaymiz (esse matni + kvitansiya sig'adi, lekin
// suiiste'mol/DoS uchun katta yuk yuborib bo'lmaydi).
app.use(express.json({ limit: "1mb" }));
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

// Qimmat (model chaqiradigan) va suiiste'molga moyil endpointlar uchun
// cheklovlar. Kalit foydalanuvchi (telegramId/initData) bo'yicha - shuning
// uchun bitta foydalanuvchi boshqalarni bloklab qo'ymaydi.
const evaluationLimiter = rateLimit({ windowMs: 60 * 1000, max: 10 });
const essayLimiter = rateLimit({ windowMs: 60 * 1000, max: 15 });
const meLimiter = rateLimit({ windowMs: 60 * 1000, max: 40 });

app.use("/api/users", userRoutes);
app.use("/api/essays", essayLimiter, essayRoutes);
app.use("/api/evaluations", evaluationLimiter, evaluationRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/me", meLimiter, meRoutes);
app.use("/api/topics", topicRoutes);
app.use("/api/articles", articleRoutes);
app.use("/api/competitions", competitionRoutes);
app.use("/api/channels", channelRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/settings", settingRoutes);
app.use("/api/feedback", feedbackRoutes);

app.use(errorHandler);

async function start() {
  try {
    await sequelize.authenticate();
    console.log("Database ulanishi muvaffaqiyatli.");

    // Eslatma: bu faqat yangi jadval yaratish uchun.
    // Mavjud jadvalga ustun qo'shish/o'zgartirish kerak bo'lsa,
    // Varaq'dagidek manual SQL migratsiya yoziladi (sync() buni qilmaydi).
    await sequelize.sync();
    console.log("Modellar sinxronlandi.");

    // Muddati o'tgan pending to'lovlarni muntazam (60s) "expired"ga o'tkazadi
    // va foydalanuvchilarga muddat tugagani haqida xabar yuboradi. Trafik
    // bo'lmasa ham aynan ishlaydi.
    startPaymentExpirySweeper();
    console.log("To'lov muddati kuzatuvchisi ishga tushdi.");

    app.listen(env.port, () => {
      console.log(`Server ${env.port}-portda ishga tushdi.`);
    });
  } catch (error) {
    console.error("Serverni ishga tushirishda xatolik:", error);
    process.exit(1);
  }
}

start();
