import dotenv from "dotenv";

dotenv.config();

const required = [
  "DATABASE_URL",
  "OPENAI_API_KEY",
  "ADMIN_API_KEY",
  "BOT_TOKEN",
];

for (const key of required) {
  if (!process.env[key]) {
    throw new Error(`Majburiy environment o'zgaruvchi topilmadi: ${key}`);
  }
}

// Umumiy (fallback) model - funksiyaga xos model o'rnatilmasa shu ishlatiladi.
const defaultOpenaiModel = process.env.OPENAI_MODEL || "gpt-4o";

// reasoning_effort qiymatini .env'dan o'qiydi.
//   - o'rnatilmagan bo'lsa -> fallback (default) ishlatiladi
//   - bo'sh yoki "off" bo'lsa -> null (chaqiruvга UMUMAN qo'shilmaydi)
function reasoningEffort(key, fallback) {
  const value = process.env[key];
  if (value === undefined) return fallback;
  const normalized = value.trim().toLowerCase();
  if (normalized === "" || normalized === "off") return null;
  return normalized;
}

export const env = {
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || "development",
  databaseUrl: process.env.DATABASE_URL,
  // CORS uchun ruxsat etilgan originlar (vergul bilan ajratilgan). Bo'sh bo'lsa
  // barcha originlarga ruxsat beriladi. Masalan:
  //   CORS_ORIGINS=https://esse.example.com,https://admin.example.com
  corsOrigins: (process.env.CORS_ORIGINS || "")
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean),
  openaiApiKey: process.env.OPENAI_API_KEY,
  // GPT so'rovi shuncha ms ichida tugamasa uziladi va (vaqtinchalik xato deb)
  // qayta uriladi. Default 90s - osilib qolgan ulanishni tez uzadi.
  openaiTimeoutMs: parseInt(process.env.OPENAI_TIMEOUT_MS || "90000", 10),
  // Vaqtinchalik xatoda (tarmoq/429/5xx) necha marta qayta urinadi. SDK
  // Idempotency-Key qo'shgani uchun ikki marta to'lov ketmaydi.
  openaiMaxRetries: parseInt(process.env.OPENAI_MAX_RETRIES || "3", 10),
  // Eslatma: OpenAI model nomlari va narxlari tez-tez o'zgaradi.
  // Joriy mavjud modellarni platform.openai.com/docs dan tekshirib, kerakli
  // model nomini .env faylida OPENAI_MODEL orqali belgilang.
  //
  // OPENAI_MODEL - UMUMIY (fallback) model. Har bir funksiya uchun ALOHIDA
  // model ishlatmoqchi bo'lsangiz, quyidagilardan foydalaning (o'rnatilmasa
  // shu umumiy modelga qaytadi):
  //   OPENAI_MODEL_EVALUATION   - esse tahlili (baholash)
  //   OPENAI_MODEL_OCR          - rasmdan matn o'qish
  //   OPENAI_MODEL_QUIZ         - viktorina
  //   OPENAI_MODEL_AI_ANALYSIS  - AI xato tahlili
  //   OPENAI_MODEL_COMPARISON   - musobaqada juftma-juft solishtirish
  openaiModel: defaultOpenaiModel,
  openaiModels: {
    evaluation: process.env.OPENAI_MODEL_EVALUATION || defaultOpenaiModel,
    ocr: process.env.OPENAI_MODEL_OCR || defaultOpenaiModel,
    quiz: process.env.OPENAI_MODEL_QUIZ || defaultOpenaiModel,
    aiAnalysis: process.env.OPENAI_MODEL_AI_ANALYSIS || defaultOpenaiModel,
    comparison: process.env.OPENAI_MODEL_COMPARISON || defaultOpenaiModel,
  },
  // Har bir funksiya uchun reasoning_effort (gpt-5.x kabi reasoning modellari
  // uchun: none/low/medium/high/xhigh). Reasoning'ni QO'LLAMAYDIGAN modelga
  // (masalan gpt-4o) o'tsangiz, mos .env'ni "off" (yoki bo'sh) qiling - shunda
  // reasoning_effort umuman yuborilmaydi va xato chiqmaydi.
  //   OPENAI_REASONING_EVALUATION / _OCR / _QUIZ / _AI_ANALYSIS / _COMPARISON
  openaiReasoning: {
    evaluation: reasoningEffort("OPENAI_REASONING_EVALUATION", "low"),
    ocr: reasoningEffort("OPENAI_REASONING_OCR", "none"),
    quiz: reasoningEffort("OPENAI_REASONING_QUIZ", "low"),
    aiAnalysis: reasoningEffort("OPENAI_REASONING_AI_ANALYSIS", "low"),
    comparison: reasoningEffort("OPENAI_REASONING_COMPARISON", "low"),
  },
  // Admin endpointlarni himoyalash uchun oddiy kalit (hozircha to'liq
  // admin-auth tizimi yo'q, faqat shu kalitni biluvchi so'rov yuborolishi mumkin).
  adminApiKey: process.env.ADMIN_API_KEY,
  // Paketsiz (bir martalik) esse tekshiruvi narxi (so'm). Bepul urinish tugagan
  // va faol paket krediti bo'lmaganda balansdan shu summa yechiladi.
  essaySingleCheckPrice: parseInt(
    process.env.ESSAY_SINGLE_CHECK_PRICE || "7000",
    10,
  ),
  // Rasm (qo'lyozma) orqali yuborishda HAR BIR varaq uchun OCR narxi (so'm).
  // To'lov OCR'dan OLDIN balansdan yechiladi.
  essayImagePagePrice: parseInt(
    process.env.ESSAY_IMAGE_PAGE_PRICE || "1000",
    10,
  ),
  // Rasm orqali yuborishda bir martada qabul qilinadigan MAKSIMAL varaq soni.
  // Qo'lda o'zgartiriladi (.env orqali).
  essayImageMaxPages: parseInt(process.env.ESSAY_IMAGE_MAX_PAGES || "2", 10),
  // Sotib olingan paket necha kun amal qiladi. Muddati tugagan kreditlar
  // avtomatik "kuyadi" (hisobga olinmaydi). Default 30 kun.
  packageValidityDays: parseInt(process.env.PACKAGE_VALIDITY_DAYS || "30", 10),
  // OCR kvitansiyasini (rasm to'lovi oldindan olinganini) imzolash kaliti.
  // O'rnatilmasa ADMIN_API_KEY'dan foydalaniladi.
  ocrReceiptSecret: process.env.OCR_RECEIPT_SECRET || process.env.ADMIN_API_KEY,
  // Har bir funksiya uchun GPT javobining MAKSIMAL token chegarasi - bexuda
  // katta token sarfini oldini oladi. .env orqali sozlanadi.
  openaiMaxTokens: {
    evaluation: parseInt(
      process.env.OPENAI_MAX_TOKENS_EVALUATION || "5000",
      10,
    ),
    ocr: parseInt(process.env.OPENAI_MAX_TOKENS_OCR || "4000", 10),
    quiz: parseInt(process.env.OPENAI_MAX_TOKENS_QUIZ || "3500", 10),
    aiAnalysis: parseInt(
      process.env.OPENAI_MAX_TOKENS_AI_ANALYSIS || "2500",
      10,
    ),
    comparison: parseInt(
      process.env.OPENAI_MAX_TOKENS_COMPARISON || "1500",
      10,
    ),
  },
  // Baholashga yuboriladigan esse matnining maksimal uzunligi (belgi). Undan
  // uzun matn GPT'ga yuborilmaydi - bexuda token sarfini cheklaydi.
  essayMaxChars: parseInt(process.env.ESSAY_MAX_CHARS || "12000", 10),
  // Haftalik bepul urinishdan tashqari AI xato tahlili narxi (so'm).
  aiAnalysisPrice: parseInt(process.env.AI_ANALYSIS_PRICE || "3000", 10),
  // Haftalik bepul urinishdan tashqari AI viktorina narxi (so'm).
  quizPrice: parseInt(process.env.QUIZ_PRICE || "2000", 10),
  // Telegram WebApp initData'ni HMAC orqali tekshirish uchun kerak
  // (bot.py'dagi BOT_TOKEN bilan bir xil bo'lishi shart)
  botToken: process.env.BOT_TOKEN,
  // --- Avtomatik to'lov (karta orqali) sozlamalari ---
  // To'lov tushadigan karta va uning egasi (foydalanuvchiga ko'rsatiladi).
  paymentCardNumber: process.env.PAYMENT_CARD_NUMBER || "",
  paymentCardHolder: process.env.PAYMENT_CARD_HOLDER || "",
  // Minimal to'lov summasi (so'm).
  minTopupAmount: parseInt(process.env.MIN_TOPUP_AMOUNT || "2000", 10),
  // Pending to'lov necha daqiqadan keyin bekor bo'ladi. Default 5 daqiqa
  // (.env orqali o'zgartiriladi). Muddati o'tgan to'lovlar fon vazifasi
  // orqali aniq "expired"ga o'tkaziladi.
  paymentExpiryMinutes: parseInt(process.env.PAYMENT_EXPIRY_MINUTES || "5", 10),
  // --- Musobaqa (adolatli baholash) sozlamalari ---
  // Har esse STAGE-1 (absolyut ball) da necha marta baholanadi. >1 bo'lsa
  // median olinadi (LLM shovqinini kamaytiradi), lekin har o'tish = +1 GPT
  // chaqiruvi HAR bir esse uchun. 1000 esseda passes=2 => 2000 chaqiruv.
  //
  // MUHIM: podium (1-2-3) aniqligini STAGE-2 juftma-juft (Copeland) allaqachon
  // ta'minlaydi va podium pooli (COMPETITION_PODIUM_K=6) sovrin o'rinlaridan
  // kengroq - shuning uchun default 1 yetarli va oddiy pullik tekshiruv bilan
  // bir xil. Ko'proq barqarorlik kerak bo'lsagina 2 qiling (xarajat 2x oshadi).
  competitionScoringPasses: parseInt(
    process.env.COMPETITION_SCORING_PASSES || "1",
    10,
  ),
  // Podium (1-2-3) uchun juftma-juft solishtiriladigan yuqori esselar soni.
  competitionPodiumK: parseInt(process.env.COMPETITION_PODIUM_K || "6", 10),
  // Partiyaviy baholashda bir vaqtda nechta GPT so'rovi ketadi (rate-limitni
  // bosib qo'ymaslik uchun cheklanadi).
  competitionEvalConcurrency: parseInt(
    process.env.COMPETITION_EVAL_CONCURRENCY || "4",
    10,
  ),
};

// GPT chaqiruviga qo'shiladigan model parametrlarini quradi: tanlangan model va
// (agar o'rnatilgan bo'lsa) reasoning_effort. reasoning_effort faqat kerak
// bo'lganda qo'shiladi - shunda reasoning'siz modellar (gpt-4o kabi) buzilmaydi.
//
// Ishlatilishi:
//   openai.chat.completions.create({ ...modelParams("ocr"), messages: [...] })
export function modelParams(feature) {
  const model = env.openaiModels[feature] || env.openaiModel;
  const effort = env.openaiReasoning[feature];
  const maxTokens = env.openaiMaxTokens[feature];
  // max_completion_tokens - reasoning (gpt-5.x) va oddiy (gpt-4o) modellarning
  // ikkalasida ham ishlaydi; bexuda katta token sarfini cheklaydi.
  const params = maxTokens
    ? { model, max_completion_tokens: maxTokens }
    : { model };
  return effort ? { ...params, reasoning_effort: effort } : params;
}
