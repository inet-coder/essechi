import crypto from "crypto";
import { env } from "./env.js";

// Telegram'ning rasmiy algoritmi: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
// 1. "hash" maydonini ajratib, qolganlarini alifbo tartibida key=value\n... ko'rinishida birlashtirish
// 2. secret_key = HMAC_SHA256(key="WebAppData", data=BOT_TOKEN)
// 3. hash = HMAC_SHA256(key=secret_key, data=dataCheckString) (hex)
// 4. natijani Telegram yuborgan hash bilan timing-safe solishtirish
const MAX_AGE_SECONDS = 24 * 60 * 60; // 24 soat - bundan eski initData rad etiladi

export function verifyTelegramInitData(initData) {
  if (!initData) return null;

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return null;

  params.delete("hash");

  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");

  const secretKey = crypto
    .createHmac("sha256", "WebAppData")
    .update(env.botToken)
    .digest();
  const computedHash = crypto
    .createHmac("sha256", secretKey)
    .update(dataCheckString)
    .digest("hex");

  const computedBuffer = Buffer.from(computedHash, "hex");
  const receivedBuffer = Buffer.from(hash, "hex");

  if (computedBuffer.length !== receivedBuffer.length) {
    return null;
  }
  if (!crypto.timingSafeEqual(computedBuffer, receivedBuffer)) {
    return null;
  }

  const authDate = Number(params.get("auth_date"));
  if (!authDate || Date.now() / 1000 - authDate > MAX_AGE_SECONDS) {
    return null; // eskirgan initData
  }

  const userRaw = params.get("user");
  if (!userRaw) return null;

  try {
    return JSON.parse(userRaw); // { id, first_name, username, ... }
  } catch {
    return null;
  }
}
