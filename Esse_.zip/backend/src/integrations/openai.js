import OpenAI from "openai";
import { env } from "../core/env.js";

// ===========================================================================
// YAGONA (markazlashgan) OpenAI mijozi.
//
// Nega markazlashgan: avval har modulda alohida `new OpenAI(...)` bor edi va
// hech birida timeout/qayta urinish sozlanmagandi. Tarmoq uzilishida (masalan
// "network chiqdi") so'rov osilib qolar yoki uzilar, foydalanuvchi qaytadan
// yuborishga majbur bo'lar - va bu QAYTA to'liq GPT chaqiruvi = qo'shimcha
// bekorga sarflangan token edi.
//
// Yechim: OpenAI SDK vaqtinchalik xatolarni (tarmoq uzilishi, 408/409/429/5xx)
// AVTOMATIK qayta uriladi - va qayta urinishlarga Idempotency-Key qo'shadi,
// shuning uchun so'rov serverga yetib borgan bo'lsa OpenAI uni takror
// hisoblamaydi (ikki marta to'lov ketmaydi). Bu yerda faqat shu xatti-harakatni
// oqilona timeout va urinishlar soni bilan sozlaymiz.
//
// MUHIM: bu FAQAT vaqtinchalik (transient) xatolarni qaytaradi. Muvaffaqiyatli
// javob kelib, keyin uni qayta ishlashda xato bo'lsa (masalan javob token
// chegarasiga yetib chala JSON), SDK uni QAYTA URINMAYDI - bu to'g'ri, chunki
// aks holda har safar bir xil xato takrorlanib token bekorga sarflanardi.
// ===========================================================================
export const openai = new OpenAI({
  apiKey: env.openaiApiKey,
  // So'rov shuncha ms ichida tugamasa uziladi (keyin SDK qayta uriladi).
  // Juda uzun default (10 daqiqa) o'rniga qisqa, aniq chegara: osilib qolgan
  // ulanish tez uziladi va toza qayta urinish bo'ladi.
  timeout: env.openaiTimeoutMs,
  // Vaqtinchalik xatoda necha marta qayta urinadi (eksponensial backoff bilan).
  maxRetries: env.openaiMaxRetries,
});
