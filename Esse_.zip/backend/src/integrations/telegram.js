import { env } from "../core/env.js";

// Esse boti tokeni orqali foydalanuvchiga to'g'ridan-to'g'ri xabar yuboradi.
// Userbot va aiogram bot alohida jarayonlar bo'lgani uchun, to'lov
// tasdiqlangach xabarni shu yerdan (backenddan) yuborish eng qulay yo'l.
export async function sendTelegramMessage(chatId, text) {
  const url = `https://api.telegram.org/bot${env.botToken}/sendMessage`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" }),
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(
      `Telegram sendMessage xatosi (${response.status}): ${detail}`,
    );
  }

  return response.json();
}
