export function errorHandler(err, req, res, next) {
  console.error(err);

  // err.status mavjud bo'lsa (masalan httpError orqali tashlangan) - bu kutilgan
  // xatolik, xabarini foydalanuvchiga ko'rsatamiz. Aks holda ichki xato sifatida
  // umumiy xabar qaytaramiz (server tafsilotlarini oshkor qilmaslik uchun).
  const status = err.status || 500;
  const message = err.status ? err.message : "Server xatosi yuz berdi";

  res.status(status).json({ error: message });
}
