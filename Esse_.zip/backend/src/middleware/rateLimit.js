// Oddiy, dependency'siz, xotiradagi (in-memory) rate limiter. Bitta Node
// jarayoni uchun mo'ljallangan - qimmat (model chaqiradigan) endpointlarni
// suiiste'moldan himoyalash uchun yetarli. Bir nechta instansiya (klaster)
// bo'lsa, Redis asosidagi limiter kerak bo'ladi.
//
// Kalit: admin kaliti bilan keladigan so'rovlar (bot) uchun - telegramId;
// initData bilan keladigan mini-app so'rovlari uchun - telegram foydalanuvchi
// id'si; aks holda IP. Shu bilan bitta foydalanuvchi (bot orqali ham, web
// orqali ham) alohida cheklanadi.

const buckets = new Map();

// Vaqti o'tgan yozuvlarni davriy tozalab, xotira o'smasligini ta'minlaymiz.
const CLEANUP_INTERVAL_MS = 10 * 60 * 1000;
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of buckets) {
    if (entry.resetAt <= now) buckets.delete(key);
  }
}, CLEANUP_INTERVAL_MS).unref();

function resolveKey(req) {
  // Mini-app: initData tasdiqlangach req.telegramUser to'ladi.
  if (req.telegramUser?.id) return `tg:${req.telegramUser.id}`;
  // Bot: telegramId so'rov tanasida/parametrida keladi.
  const bodyTgId = req.body?.telegramId;
  const paramTgId = req.params?.telegramId;
  if (bodyTgId) return `tg:${bodyTgId}`;
  if (paramTgId) return `tg:${paramTgId}`;
  // Aks holda - IP (proxy orqasida bo'lsa app'da "trust proxy" yoqilgan bo'lsin).
  return `ip:${req.ip}`;
}

// windowMs oralig'ida maksimal `max` so'rovga ruxsat beradi.
export function rateLimit({ windowMs, max, message } = {}) {
  const limitMessage =
    message ||
    "Juda ko'p so'rov yuborildi. Iltimos, birozdan so'ng qayta urinib ko'ring.";

  return function rateLimitMiddleware(req, res, next) {
    const key = `${req.baseUrl}${req.path}|${resolveKey(req)}`;
    const now = Date.now();
    const entry = buckets.get(key);

    if (!entry || entry.resetAt <= now) {
      buckets.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }

    if (entry.count >= max) {
      const retryAfter = Math.ceil((entry.resetAt - now) / 1000);
      res.set("Retry-After", String(retryAfter));
      return res.status(429).json({ error: limitMessage });
    }

    entry.count += 1;
    next();
  };
}
