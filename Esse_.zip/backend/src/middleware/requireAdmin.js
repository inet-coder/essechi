import { env } from "../core/env.js";
import { httpError } from "../core/httpError.js";

export function requireAdmin(req, res, next) {
  const adminKey = req.headers["x-admin-key"];

  if (!adminKey || adminKey !== env.adminApiKey) {
    return next(httpError(401, "Admin huquqi talab qilinadi"));
  }

  next();
}
