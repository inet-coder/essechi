import { verifyTelegramInitData } from "../core/telegramAuth.js";
import { httpError } from "../core/httpError.js";

export function requireTelegramAuth(req, res, next) {
  const initData = req.headers["x-telegram-init-data"];
  const telegramUser = verifyTelegramInitData(initData);

  if (!telegramUser) {
    return next(httpError(401, "Telegram autentifikatsiyasi muvaffaqiyatsiz"));
  }

  req.telegramUser = telegramUser;
  next();
}
