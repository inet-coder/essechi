-- Avtomatik to'lov (karta orqali) uchun payments jadvaliga ustunlar qo'shish.
-- sequelize.sync() mavjud jadvalga ustun qo'shmaydi, shuning uchun bu SQL'ni
-- deploydan OLDIN qo'lda ishga tushiring:
--   psql "$DATABASE_URL" -f src/migrations/001_payment_auto_topup.sql

ALTER TABLE payments
  ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS "requestedAmount" INTEGER,
  ADD COLUMN IF NOT EXISTS provider VARCHAR(50),
  ADD COLUMN IF NOT EXISTS "cardNumber" VARCHAR(30),
  ADD COLUMN IF NOT EXISTS "expiresAt" TIMESTAMPTZ;

-- Migratsiyagacha mavjud barcha to'lovlar allaqachon tasdiqlangan
-- (balans qo'shilgan) top-up'lar - ularni 'confirmed' deb belgilaymiz.
UPDATE payments SET status = 'confirmed' WHERE "expiresAt" IS NULL;

-- Bir vaqtning o'zida ikki foydalanuvchi bir xil pending summani olib
-- qo'ymasligi uchun partial unique index (faqat pending yozuvlar uchun).
CREATE UNIQUE INDEX IF NOT EXISTS uniq_pending_payment_amount
  ON payments (amount) WHERE status = 'pending';