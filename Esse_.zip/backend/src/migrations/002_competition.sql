-- Musobaqa bo'limi uchun jadvallar. sequelize.sync() mavjud jadvalga tegmaydi
-- va ENUM/constraint'larni to'liq yaratmasligi mumkin, shuning uchun bu SQL'ni
-- deploydan OLDIN qo'lda ishga tushiring:
--   psql "$DATABASE_URL" -f src/migrations/002_competition.sql

CREATE TABLE IF NOT EXISTS competitions (
  id            SERIAL PRIMARY KEY,
  title         VARCHAR(255) NOT NULL,
  description   TEXT,
  topic         TEXT NOT NULL,
  "entryFee"    INTEGER NOT NULL DEFAULT 0,
  status        VARCHAR(20) NOT NULL DEFAULT 'draft',
  prizes        JSONB NOT NULL DEFAULT '[]'::jsonb,
  "essaysPublic" BOOLEAN NOT NULL DEFAULT true,
  "startsAt"    TIMESTAMPTZ,
  "endsAt"      TIMESTAMPTZ,
  "evalProgress" JSONB,
  "podiumAudit" JSONB,
  "createdAt"   TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updatedAt"   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS competition_entries (
  id              SERIAL PRIMARY KEY,
  "competitionId" INTEGER NOT NULL REFERENCES competitions(id) ON DELETE CASCADE,
  "userId"        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  "essayId"       INTEGER REFERENCES essays(id) ON DELETE SET NULL,
  rank            INTEGER,
  "scaledScore"   REAL,
  "awardedPrize"  JSONB,
  "createdAt"     TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updatedAt"     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Bir foydalanuvchi bir musobaqada bir marta qatnashadi.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_competition_entry_user
  ON competition_entries ("competitionId", "userId");

-- Reyting/ro'yxat so'rovlari uchun.
CREATE INDEX IF NOT EXISTS idx_competition_entries_competition
  ON competition_entries ("competitionId");
