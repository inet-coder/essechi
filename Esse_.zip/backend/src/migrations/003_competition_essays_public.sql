-- Ishtirokchilar bir-birining esselarini ko'ra olishi sozlamasi.
-- Avval 002_competition.sql ishga tushirilgan bo'lsa, shu ALTER'ni qo'shing:
--   psql "$DATABASE_URL" -f src/migrations/003_competition_essays_public.sql

ALTER TABLE competitions
  ADD COLUMN IF NOT EXISTS "essaysPublic" BOOLEAN NOT NULL DEFAULT true;
