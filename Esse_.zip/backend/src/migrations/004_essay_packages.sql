-- Esse tekshiruv paketlari (30 kunlik kredit), bir martalik bepul tekshiruv,
-- paketsiz bir martalik to'lov va rasm/OCR orqali OLDINDAN to'lov tizimi.
--
-- sequelize.sync() mavjud jadvalga ustun QO'SHMAYDI (faqat yangi jadval
-- yaratadi), shuning uchun bu SQL'ni deploydan OLDIN qo'lda ishga tushiring:
--   psql "$DATABASE_URL" -f src/migrations/004_essay_packages.sql

-- 1) To'lov turi + paket krediti (balans to'lovi vs paket to'lovi).
ALTER TABLE payments
  ADD COLUMN IF NOT EXISTS kind VARCHAR(20) NOT NULL DEFAULT 'balance',
  ADD COLUMN IF NOT EXISTS "essayCredits" INTEGER;
UPDATE payments SET kind = 'balance' WHERE kind IS NULL;

-- 2) Foydalanuvchida bir martalik (umr bo'yi) bepul esse tekshiruvi belgisi.
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS "freeEssayUsed" BOOLEAN NOT NULL DEFAULT false;

-- Eski (endi ishlatilmaydigan) integer kredit ustunini olib tashlaymiz -
-- kreditlar endi essay_credit_grants jadvalida, HAR BIRI 30 kunlik muddat
-- bilan yuritiladi (pastga qarang).
ALTER TABLE users
  DROP COLUMN IF EXISTS "essayCredits";

-- 3) Rasm/OCR orqali yuborilgan esse uchun tekshiruv to'lovi OLDINDAN olingan
--    bo'ladi - shu belgi baholashda qayta pul olishni to'xtatadi. ocrReceiptId
--    UNIQUE - bitta kvitansiya faqat BIR marta ishlatiladi (NULL'lar ko'p
--    bo'lishi mumkin, shuning uchun partial unique index).
ALTER TABLE essays
  ADD COLUMN IF NOT EXISTS "prepaidCheck" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS "ocrReceiptId" VARCHAR(255);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_essay_ocr_receipt
  ON essays ("ocrReceiptId") WHERE "ocrReceiptId" IS NOT NULL;

-- 4) Esse tekshiruv kreditlari "partiya" (grant) sifatida. Har paket bir grant:
--    `remaining` qolgan kredit, `expiresAt` 30 kunlik muddat. Amaldagi kreditlar
--    HAR DOIM `remaining>0 AND expiresAt>now()` orqali hisoblanadi - shuning
--    uchun muddat AYNAN, alohida "kuydirish" vazifasisiz ishlaydi.
--    (sync() ham yangi jadval sifatida yaratadi; bu yerda idempotent zaxira.)
CREATE TABLE IF NOT EXISTS essay_credit_grants (
  id          SERIAL PRIMARY KEY,
  "userId"    INTEGER NOT NULL,
  credits     INTEGER NOT NULL,
  remaining   INTEGER NOT NULL,
  source      VARCHAR(50) NOT NULL DEFAULT 'package',
  "paymentId" INTEGER,
  "expiresAt" TIMESTAMPTZ NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_credit_grants_user_active
  ON essay_credit_grants ("userId", remaining, "expiresAt");
