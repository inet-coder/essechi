-- Musobaqa: "upcoming" (belgilangan sanada boshlanadigan) holati va oldindan
-- ro'yxatdan o'tish. Ishtirokchi ikki bosqichda bo'ladi:
--   1) ro'yxatdan o'tgan (paid=false) - joyni band qildi, hali to'lamagan
--   2) to'liq ishtirokchi (paid=true)  - kirish to'lovini to'lagan, esse yubora oladi
-- Kirish to'lovi 0 bo'lsa, ro'yxatdan o'tish darhol to'liq ishtirokchi qiladi
-- (paid=true).
--
-- sequelize.sync() mavjud jadvalga ustun QO'SHMAYDI, shuning uchun bu SQL'ni
-- deploydan OLDIN qo'lda ishga tushiring:
--   psql "$DATABASE_URL" -f src/migrations/005_competition_prereg.sql

-- status ustuni 002-migratsiyada VARCHAR(20) sifatida yaratilgan, shuning uchun
-- yangi "upcoming" qiymatini qo'shish uchun ENUM o'zgartirish shart emas.

-- Ishtirokchi kirish to'lovini to'laganmi (to'liq ishtirokchi).
ALTER TABLE competition_entries
  ADD COLUMN IF NOT EXISTS paid BOOLEAN NOT NULL DEFAULT false;

-- Mavjud (eski) yozuvlar allaqachon to'lov qilib qatnashgan edi - ularni
-- to'langan deb belgilaymiz (eski oqimda faqat to'lovdan keyin entry yaratilardi).
UPDATE competition_entries SET paid = true WHERE paid = false;
