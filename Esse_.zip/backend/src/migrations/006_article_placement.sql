-- Maqolalarni to'liq boshqarish: joylashuv (tartib), qadab qo'yish (pinned) va
-- bo'lim (category). Bular admin veb-panelida boshqariladi.
--   - pinned    : maqolani yuqoriga qadab qo'yish (ro'yxat boshida ko'rinadi;
--                 birinchi maqola "Tavsiya etilgan" bloki bo'ladi)
--   - sortOrder : qo'lda tartiblash (kichik = yuqorida). Admin yuqori/pastga
--                 surib joylashuvni o'zgartiradi.
--   - category  : ixtiyoriy bo'lim/teg (masalan "Grammatika", "Writing")
--
-- sequelize.sync() mavjud jadvalga ustun QO'SHMAYDI, shuning uchun bu SQL'ni
-- deploydan OLDIN qo'lda ishga tushiring:
--   psql "$DATABASE_URL" -f src/migrations/006_article_placement.sql

ALTER TABLE articles
  ADD COLUMN IF NOT EXISTS pinned BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE articles
  ADD COLUMN IF NOT EXISTS "sortOrder" INTEGER NOT NULL DEFAULT 0;

ALTER TABLE articles
  ADD COLUMN IF NOT EXISTS category VARCHAR(64);

-- Mavjud maqolalarga boshlang'ich tartib: eng yangisi yuqorida bo'lsin.
-- (sortOrder = yangilik bo'yicha o'sish tartibida raqamlanadi)
WITH ordered AS (
  SELECT id, ROW_NUMBER() OVER (ORDER BY "createdAt" DESC) - 1 AS rn
  FROM articles
)
UPDATE articles a
SET "sortOrder" = ordered.rn
FROM ordered
WHERE a.id = ordered.id;

-- Tartib bo'yicha tez saralash uchun indeks.
CREATE INDEX IF NOT EXISTS idx_articles_placement
  ON articles (pinned DESC, "sortOrder" ASC, "createdAt" DESC);
