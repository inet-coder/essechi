-- Bepul esse tekshiruvi: bitta (boolean) o'rniga sozlanadigan SON.
--   - users.freeEssaysUsed : foydalanuvchi nechta bepul tekshiruv ishlatgani
--   - settings.free_essay_limit : har bir foydalanuvchiga beriladigan bepul
--     tekshiruvlar soni (admin panel orqali o'zgartiriladi)
-- Bepul mavjud: freeEssaysUsed < free_essay_limit.
--
-- sequelize.sync() yangi jadval (settings) yaratadi, lekin mavjud jadvalga
-- (users) ustun QO'SHMAYDI - shuning uchun bu SQL'ni deploydan OLDIN ishga
-- tushiring:
--   psql "$DATABASE_URL" -f src/migrations/007_free_essay_count.sql

-- Sozlamalar jadvali (sync() ham yaratadi, lekin idempotent bo'lsin).
CREATE TABLE IF NOT EXISTS settings (
  key         VARCHAR(255) PRIMARY KEY,
  value       VARCHAR(255) NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Foydalanuvchi ishlatgan bepul tekshiruvlar soni.
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS "freeEssaysUsed" INTEGER NOT NULL DEFAULT 0;

-- Eski boolean holatni ko'chiramiz: bepulni ishlatганlar -> 1 ta ishlatgan.
UPDATE users SET "freeEssaysUsed" = 1
  WHERE "freeEssayUsed" = true AND "freeEssaysUsed" = 0;

-- Standart limit (avval har kim 1 ta bepul olardi).
INSERT INTO settings (key, value, "createdAt", "updatedAt")
VALUES ('free_essay_limit', '1', now(), now())
ON CONFLICT (key) DO NOTHING;
