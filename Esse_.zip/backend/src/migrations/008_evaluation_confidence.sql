-- Baholash ishonch darajasi (0-100). Model o'z qo'ygan ballaridan qanchalik
-- qat'iy ishonganini bildiradi (essening balli EMAS). Faqat GPT baholagan
-- (completed) natijalarda to'ladi; precheck orqali rad etilganda null qoladi.
--
-- sequelize.sync() mavjud jadvalga ustun QO'SHMAYDI - shuning uchun bu SQL'ni
-- deploydan OLDIN ishga tushiring:
--   psql "$DATABASE_URL" -f src/migrations/008_evaluation_confidence.sql

ALTER TABLE evaluation_results
  ADD COLUMN IF NOT EXISTS confidence INTEGER;
