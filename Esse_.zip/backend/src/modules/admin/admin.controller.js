import {
  getDashboardStats,
  listUsers,
  getUserDetail,
  listPayments,
  listEssays,
  getEssayDetailForAdmin,
  adminGrantCredits,
  getFreeEssayStats,
  updateFreeEssayLimit,
} from "./admin.service.js";

export async function stats(req, res, next) {
  try {
    res.status(200).json(await getDashboardStats());
  } catch (error) {
    next(error);
  }
}

export async function users(req, res, next) {
  try {
    const { query, page, limit } = req.query;
    res.status(200).json(await listUsers({ query, page, limit }));
  } catch (error) {
    next(error);
  }
}

export async function userDetail(req, res, next) {
  try {
    res.status(200).json(await getUserDetail(req.params.telegramId));
  } catch (error) {
    next(error);
  }
}

export async function payments(req, res, next) {
  try {
    const { status, kind, page, limit } = req.query;
    res.status(200).json(await listPayments({ status, kind, page, limit }));
  } catch (error) {
    next(error);
  }
}

export async function essays(req, res, next) {
  try {
    const { status, page, limit } = req.query;
    res.status(200).json(await listEssays({ status, page, limit }));
  } catch (error) {
    next(error);
  }
}

export async function essayDetail(req, res, next) {
  try {
    res.status(200).json(await getEssayDetailForAdmin(req.params.essayId));
  } catch (error) {
    next(error);
  }
}

export async function grantCredits(req, res, next) {
  try {
    const { telegramId, credits } = req.body;
    if (!telegramId || credits === undefined) {
      return res.status(400).json({ error: "telegramId va credits majburiy" });
    }
    res.status(200).json(await adminGrantCredits({ telegramId, credits }));
  } catch (error) {
    next(error);
  }
}

// Bepul esse tekshiruvi: joriy limit + foydalanish statistikasi.
export async function freeEssay(req, res, next) {
  try {
    res.status(200).json(await getFreeEssayStats());
  } catch (error) {
    next(error);
  }
}

// Bepul esse tekshiruvi limitini o'zgartirish.
export async function setFreeEssay(req, res, next) {
  try {
    const { limit } = req.body;
    if (limit === undefined) {
      return res.status(400).json({ error: "limit majburiy" });
    }
    res.status(200).json(await updateFreeEssayLimit(limit));
  } catch (error) {
    next(error);
  }
}
