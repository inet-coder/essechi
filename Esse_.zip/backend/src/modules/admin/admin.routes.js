import { Router } from "express";

import { requireAdmin } from "../../middleware/requireAdmin.js";
import {
  stats,
  users,
  userDetail,
  payments,
  essays,
  essayDetail,
  grantCredits,
  freeEssay,
  setFreeEssay,
} from "./admin.controller.js";

const router = Router();

// Butun admin modul admin kaliti bilan himoyalangan.
router.use(requireAdmin);

router.get("/stats", stats);
router.get("/users", users);
router.get("/users/:telegramId", userDetail);
router.get("/payments", payments);
router.get("/essays", essays);
router.get("/essays/:essayId", essayDetail);
router.post("/grant-credits", grantCredits);
// Bepul esse tekshiruvi limiti (kuzatish va o'zgartirish).
router.get("/free-essay", freeEssay);
router.patch("/free-essay", setFreeEssay);

export default router;
