import { Op, fn, col } from "sequelize";

import { httpError } from "../../core/httpError.js";
import { User } from "../user/user.model.js";
import { Essay } from "../essay/essay.model.js";
import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { Payment } from "../payment/payment.model.js";
import { EssayCreditGrant } from "../credit/credit.model.js";
import { getAvailableCredits, grantCredits } from "../credit/credit.service.js";
import {
  getFreeEssayLimit,
  setFreeEssayLimit,
} from "../setting/setting.service.js";

// ---------------------------------------------------------------------------
// Dashboard statistikasi: bosh sahifadagi umumiy ko'rsatkichlar.
// Barcha og'ir sanoqlar parallel bajariladi (Promise.all) - tez javob uchun.
// ---------------------------------------------------------------------------
export async function getDashboardStats() {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const [
    userCount,
    usersToday,
    essayCount,
    checkedCount,
    essaysToday,
    pendingPayments,
    revenueAgg,
    scoreAgg,
  ] = await Promise.all([
    User.count(),
    User.count({ where: { createdAt: { [Op.gte]: startOfToday } } }),
    Essay.count(),
    EvaluationResult.count({ where: { status: "completed" } }),
    Essay.count({ where: { createdAt: { [Op.gte]: startOfToday } } }),
    Payment.count({ where: { status: "pending" } }),
    // Jami tushum: faqat foydalanuvchi to'lovlaridan (requestedAmount to'lgan) -
    // admin qo'lda qo'shgan mablag'lar "tushum"ga kirmaydi.
    Payment.findOne({
      where: { status: "confirmed", requestedAmount: { [Op.ne]: null } },
      attributes: [
        [fn("COALESCE", fn("SUM", col("amount")), 0), "revenue"],
        [fn("COUNT", col("id")), "cnt"],
      ],
      raw: true,
    }),
    EvaluationResult.findOne({
      where: { status: "completed" },
      // scaledScore VIRTUAL (bazada ustun emas) - shuning uchun real ustun
      // bo'lgan totalScore bo'yicha o'rtacha olib, keyin shkalaga o'giramiz.
      attributes: [[fn("AVG", col("totalScore")), "avgTotal"]],
      raw: true,
    }),
  ]);

  const avgTotal = scoreAgg?.avgTotal != null ? Number(scoreAgg.avgTotal) : null;
  // convertToStandardScale formulasi (totalScore*2+27), lekin dashboard uchun
  // 1 kasrgacha aniqlik bilan (0 bo'lsa 0).
  const avgScaledScore =
    avgTotal == null ? null : avgTotal === 0 ? 0 : Math.round((avgTotal * 2 + 27) * 10) / 10;

  return {
    userCount,
    usersToday,
    essayCount,
    checkedCount,
    essaysToday,
    pendingPayments,
    revenue: Number(revenueAgg?.revenue || 0),
    paidPaymentsCount: Number(revenueAgg?.cnt || 0),
    avgScaledScore: avgScaledScore,
  };
}

// ---------------------------------------------------------------------------
// Bepul esse tekshiruvi: joriy limit + foydalanish statistikasi (admin kuzatuvi).
// ---------------------------------------------------------------------------
export async function getFreeEssayStats() {
  const limit = await getFreeEssayLimit();

  const [totalUsedAgg, usersUsedAny, usersUsedUp, userCount] = await Promise.all([
    // Jami sarflangan bepul tekshiruvlar (barcha foydalanuvchilar bo'yicha).
    User.findOne({
      attributes: [[fn("COALESCE", fn("SUM", col("freeEssaysUsed")), 0), "total"]],
      raw: true,
    }),
    // Kamida bitta bepul tekshiruvdan foydalangan foydalanuvchilar.
    User.count({ where: { freeEssaysUsed: { [Op.gt]: 0 } } }),
    // Bepul limitini to'liq ishlatib bo'lgan foydalanuvchilar.
    User.count({ where: { freeEssaysUsed: { [Op.gte]: limit } } }),
    User.count(),
  ]);

  const totalUsed = Number(totalUsedAgg?.total || 0);
  // limit 0 bo'lsa hech kimda "qolgan" yo'q; aks holda limitga yetmaganlar.
  const usersWithRemaining = limit <= 0 ? 0 : userCount - usersUsedUp;

  return {
    limit,
    totalUsed,
    usersUsedAny,
    usersUsedUp,
    usersWithRemaining,
    userCount,
  };
}

// Bepul tekshiruv limitini o'zgartiradi (admin). Manfiy bo'lmagan butun son.
export async function updateFreeEssayLimit(limit) {
  const value = Number(limit);
  if (!Number.isFinite(value) || value < 0 || !Number.isInteger(value)) {
    throw httpError(400, "limit manfiy bo'lmagan butun son bo'lishi kerak");
  }
  await setFreeEssayLimit(value);
  return getFreeEssayStats();
}

// ---------------------------------------------------------------------------
// Foydalanuvchilar ro'yxati: qidiruv (ism/username/telegramId) + sahifalash.
// Har bir foydalanuvchi uchun balans, amaldagi kredit va esse soni qaytadi.
// ---------------------------------------------------------------------------
export async function listUsers({ query = "", page = 1, limit = 20 }) {
  const safeLimit = Math.min(Math.max(Number(limit) || 20, 1), 100);
  const safePage = Math.max(Number(page) || 1, 1);
  const offset = (safePage - 1) * safeLimit;

  const where = {};
  const q = String(query || "").trim();
  if (q) {
    const or = [
      { firstName: { [Op.iLike]: `%${q}%` } },
      { username: { [Op.iLike]: `%${q}%` } },
    ];
    if (/^\d+$/.test(q)) or.push({ telegramId: q });
    where[Op.or] = or;
  }

  const { rows, count } = await User.findAndCountAll({
    where,
    order: [["createdAt", "DESC"]],
    limit: safeLimit,
    offset,
  });

  const userIds = rows.map((u) => u.id);

  // Har bir foydalanuvchining esse soni (bitta so'rovda, guruhlab).
  const essayCounts = userIds.length
    ? await Essay.findAll({
        where: { userId: { [Op.in]: userIds } },
        attributes: ["userId", [fn("COUNT", col("id")), "cnt"]],
        group: ["userId"],
        raw: true,
      })
    : [];
  const countMap = new Map(essayCounts.map((e) => [e.userId, Number(e.cnt)]));

  // Amaldagi kreditlar (muddati o'tmagan) - har biri uchun alohida.
  const credits = await Promise.all(userIds.map((id) => getAvailableCredits(id)));
  const creditMap = new Map(userIds.map((id, i) => [id, credits[i]]));

  return {
    users: rows.map((u) => ({
      id: u.id,
      telegramId: String(u.telegramId),
      firstName: u.firstName,
      username: u.username,
      balance: u.balance,
      essayCredits: creditMap.get(u.id) || 0,
      essayCount: countMap.get(u.id) || 0,
      createdAt: u.createdAt,
    })),
    total: count,
    page: safePage,
    limit: safeLimit,
    hasMore: offset + rows.length < count,
  };
}

function serializePayment(p) {
  return {
    id: p.id,
    amount: p.amount,
    requestedAmount: p.requestedAmount,
    status: p.status,
    kind: p.kind,
    essayCredits: p.essayCredits,
    provider: p.provider,
    note: p.note,
    createdAt: p.createdAt,
  };
}

// ---------------------------------------------------------------------------
// Bitta foydalanuvchining to'liq kartochkasi: profil, balans/kredit, to'lovlar
// tarixi, kredit partiyalari va esselari (baholari bilan). Admin istalgan
// foydalanuvchini shu orqali chuqur tekshira oladi.
// ---------------------------------------------------------------------------
export async function getUserDetail(telegramId) {
  const user = await User.findOne({ where: { telegramId } });
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const [payments, grants, essays, essayCredits] = await Promise.all([
    Payment.findAll({
      where: { userId: user.id },
      order: [["createdAt", "DESC"]],
      limit: 100,
    }),
    EssayCreditGrant.findAll({
      where: { userId: user.id },
      order: [["createdAt", "DESC"]],
      limit: 50,
    }),
    Essay.findAll({
      where: { userId: user.id },
      include: [
        {
          model: EvaluationResult,
          as: "evaluationResult",
          attributes: ["status", "totalScore"],
        },
      ],
      order: [["createdAt", "DESC"]],
      limit: 100,
    }),
    getAvailableCredits(user.id),
  ]);

  const now = new Date();

  return {
    user: {
      id: user.id,
      telegramId: String(user.telegramId),
      firstName: user.firstName,
      username: user.username,
      balance: user.balance,
      essayCredits,
      totalAttemptsUsed: user.totalAttemptsUsed,
      freeEssayUsed: user.freeEssayUsed,
      freeEssaysUsed: user.freeEssaysUsed,
      createdAt: user.createdAt,
    },
    payments: payments.map(serializePayment),
    grants: grants.map((g) => ({
      id: g.id,
      credits: g.credits,
      remaining: g.remaining,
      source: g.source,
      expiresAt: g.expiresAt,
      active: g.remaining > 0 && new Date(g.expiresAt) > now,
      createdAt: g.createdAt,
    })),
    essays: essays.map((e) => {
      const ev = e.evaluationResult;
      return {
        id: e.id,
        topic: e.topic,
        sourceType: e.sourceType,
        status: e.status,
        wordCount: e.wordCount,
        createdAt: e.createdAt,
        evaluationResult: ev
          ? {
              status: ev.status,
              totalScore: ev.totalScore,
              scaledScore: ev.scaledScore,
            }
          : null,
      };
    }),
  };
}

// ---------------------------------------------------------------------------
// Global to'lovlar jurnali: barcha to'lovlar (status bo'yicha filtrlanadi) +
// foydalanuvchi ma'lumoti bilan, sahifalab.
// ---------------------------------------------------------------------------
export async function listPayments({ status = "", kind = "", page = 1, limit = 30 }) {
  const safeLimit = Math.min(Math.max(Number(limit) || 30, 1), 100);
  const safePage = Math.max(Number(page) || 1, 1);
  const offset = (safePage - 1) * safeLimit;

  const where = {};
  if (status) where.status = status;
  if (kind) where.kind = kind;

  const { rows, count } = await Payment.findAndCountAll({
    where,
    include: [
      {
        model: User,
        as: "user",
        attributes: ["telegramId", "firstName", "username"],
      },
    ],
    order: [["createdAt", "DESC"]],
    limit: safeLimit,
    offset,
  });

  return {
    payments: rows.map((p) => ({
      ...serializePayment(p),
      user: p.user
        ? {
            telegramId: String(p.user.telegramId),
            firstName: p.user.firstName,
            username: p.user.username,
          }
        : null,
    })),
    total: count,
    page: safePage,
    limit: safeLimit,
    hasMore: offset + rows.length < count,
  };
}

// ---------------------------------------------------------------------------
// So'nggi esse tekshiruvlari (barcha foydalanuvchilar bo'yicha) - admin
// tekshiruvlar oqimini kuzatishi uchun. Muallif ismi bilan, sahifalab.
// ---------------------------------------------------------------------------
export async function listEssays({ status = "", page = 1, limit = 30 }) {
  const safeLimit = Math.min(Math.max(Number(limit) || 30, 1), 100);
  const safePage = Math.max(Number(page) || 1, 1);
  const offset = (safePage - 1) * safeLimit;

  const where = {};
  if (status) where.status = status;

  const { rows, count } = await Essay.findAndCountAll({
    where,
    include: [
      { model: User, as: "user", attributes: ["telegramId", "firstName"] },
      {
        model: EvaluationResult,
        as: "evaluationResult",
        attributes: ["status", "totalScore"],
      },
    ],
    order: [["createdAt", "DESC"]],
    limit: safeLimit,
    offset,
  });

  return {
    essays: rows.map((e) => ({
      id: e.id,
      topic: e.topic,
      sourceType: e.sourceType,
      status: e.status,
      wordCount: e.wordCount,
      createdAt: e.createdAt,
      author: e.user
        ? { telegramId: String(e.user.telegramId), firstName: e.user.firstName }
        : null,
      evaluationResult: e.evaluationResult
        ? {
            status: e.evaluationResult.status,
            totalScore: e.evaluationResult.totalScore,
            scaledScore: e.evaluationResult.scaledScore,
          }
        : null,
    })),
    total: count,
    page: safePage,
    limit: safeLimit,
    hasMore: offset + rows.length < count,
  };
}

// ---------------------------------------------------------------------------
// Bitta essening TO'LIQ tahlili (admin ko'rinishi): matn, band natijalari,
// tavsiyalar va muallif. Web paneldan esse tekshiruvini to'liq ko'rish uchun.
// ---------------------------------------------------------------------------
export async function getEssayDetailForAdmin(essayId) {
  const essay = await Essay.findByPk(essayId, {
    include: [
      { model: User, as: "user", attributes: ["telegramId", "firstName", "username"] },
      { model: EvaluationResult, as: "evaluationResult" },
    ],
  });
  if (!essay) throw httpError(404, "Esse topilmadi");

  const json = essay.toJSON();
  const ev = json.evaluationResult;

  return {
    id: json.id,
    topic: json.topic,
    sourceType: json.sourceType,
    rawText: json.rawText,
    wordCount: json.wordCount,
    language: json.language,
    status: json.status,
    createdAt: json.createdAt,
    author: json.user
      ? {
          telegramId: String(json.user.telegramId),
          firstName: json.user.firstName,
          username: json.user.username,
        }
      : null,
    evaluationResult: ev
      ? {
          status: ev.status,
          totalScore: ev.totalScore,
          scaledScore: ev.scaledScore,
          bandResults: ev.bandResults || [],
          recommendations: ev.recommendations || [],
          rejectionReason: ev.rejectionReason,
        }
      : null,
  };
}

// ---------------------------------------------------------------------------
// Admin foydalanuvchiga qo'lda esse tekshiruv krediti beradi (30 kunlik
// partiya, source="admin"). Sovg'a/kompensatsiya uchun qulay.
// ---------------------------------------------------------------------------
export async function adminGrantCredits({ telegramId, credits }) {
  const user = await User.findOne({ where: { telegramId } });
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const n = Math.trunc(Number(credits));
  if (!n || n <= 0) {
    throw httpError(400, "credits musbat butun son bo'lishi kerak");
  }

  await grantCredits({ userId: user.id, credits: n, source: "admin" });
  const available = await getAvailableCredits(user.id);

  return {
    telegramId: String(user.telegramId),
    firstName: user.firstName,
    essayCredits: available,
    granted: n,
  };
}
