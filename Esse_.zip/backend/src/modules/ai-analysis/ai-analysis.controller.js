import {
  getAiAnalysisStatus,
  generateMyAiAnalysis,
  listMyAnalyses,
  getMyAnalysis,
} from "./ai-analysis.service.js";
import { getUserByTelegramId } from "../user/user.service.js";
import { httpError } from "../../core/httpError.js";

async function resolveUserId(req) {
  const user = await getUserByTelegramId(req.telegramUser.id);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");
  return user.id;
}

export async function getStatus(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const status = await getAiAnalysisStatus(userId);
    res.status(200).json(status);
  } catch (error) {
    next(error);
  }
}

export async function generate(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const result = await generateMyAiAnalysis(userId);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
}

export async function history(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const analyses = await listMyAnalyses(userId);
    res.status(200).json(analyses);
  } catch (error) {
    next(error);
  }
}

export async function getOne(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const analysis = await getMyAnalysis(userId, Number(req.params.id));
    res.status(200).json(analysis);
  } catch (error) {
    next(error);
  }
}
