import { modelParams } from "../../core/env.js";
import { openai } from "../../integrations/openai.js";
import { SYSTEM_PROMPT, RESPONSE_SCHEMA } from "./ai-analysis.prompt.js";

export async function generateAiAnalysis(essaysData) {
  const completion = await openai.chat.completions.create({
    // Model va reasoning_effort .env orqali (funksiyaga xos) tanlanadi.
    ...modelParams("aiAnalysis"),
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content:
          `Talabgorning so'nggi ${essaysData.length} ta tekshirilgan essesi natijalari ` +
          `(JSON, eng yangisi birinchi):\n${JSON.stringify(essaysData)}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "ai_error_analysis",
        strict: true,
        schema: RESPONSE_SCHEMA,
      },
    },
  });

  const rawContent = completion.choices[0]?.message?.content;
  if (!rawContent) {
    throw new Error("GPT bo'sh javob qaytardi");
  }
  return JSON.parse(rawContent);
}
