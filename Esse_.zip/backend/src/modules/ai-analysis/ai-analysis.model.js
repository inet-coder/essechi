import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

export const AiAnalysis = sequelize.define(
  "AiAnalysis",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    content: {
      type: DataTypes.JSONB,
      allowNull: false,
    },
    // Haftalik bepul urinish sifatida ishlatilganmi yoki balansdan
    // to'langanmi - statistika/audit uchun saqlanadi.
    wasFree: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    tableName: "ai_analyses",
    timestamps: true,
  },
);
