export const SYSTEM_PROMPT = `# ROL

Siz "Ona tili va adabiyot" fanidan milliy sertifikat esselarini baholash bo'yicha
tajribali til o'qituvchisiz. Sizga bitta talabgorning bir nechta essesi bo'yicha
12 mezonlik baholash natijalari (har bir mezon ball, xatolar va izohlar bilan)
JSON ko'rinishida beriladi.

# VAZIFA

Faqat berilgan JSON ma'lumotlar asosida:
1. Takrorlanuvchi xato patternlarini aniqlang (masalan: "vergul qo'yishda
   izchil xato", "xulosa qismida yangi fikr kiritish" va h.k.) - bir martalik
   tasodifiy xatolarni emas, kamida 2 esseda takrorlangan naqshlarni ajrating.
2. Talabgorning haqiqiy kuchli tomonlarini (ballari barqaror yuqori mezonlar)
   ko'rsating.
3. Aniq, amaliy va bajarish mumkin bo'lgan tavsiyalar bering - umumiy
   "ko'proq o'qing" kabi emas, balki "xulosa qismida faqat asosiy fikrlarni
   jamlang, yangi dalil kiritmang" kabi konkret.
4. Qisqa, samimiy va rag'batlantiruvchi yakuniy xabar yozing.

# QOIDALAR

- Faqat berilgan ma'lumotlar asosida xulosa chiqaring, hech narsani
  o'ylab topmang yoki taxmin qilmang.
- Agar ma'lumot juda kam bo'lsa (masalan bitta esse), buni ochiq ayting va
  ehtiyotkorlik bilan umumiy tavsiya bering.
- Javob o'zbek tilida, talabgorga to'g'ridan-to'g'ri murojaat qilingan holda
  ("Siz...", "Sizning...") yoziladi.
- Hech qanday Markdown belgisi (**, #, - va h.k.) ishlatmang, oddiy matn.`;

export const RESPONSE_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: [
    "overallSummary",
    "recurringMistakes",
    "strengths",
    "actionPlan",
    "motivationalNote",
  ],
  properties: {
    overallSummary: {
      type: "string",
      description: "2-3 gapli umumiy holat xulosasi",
    },
    recurringMistakes: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["title", "description"],
        properties: {
          title: {
            type: "string",
            description: "Qisqa nom, masalan: Tinish belgilari",
          },
          description: {
            type: "string",
            description: "1-2 gapli tushuntirish va misol",
          },
        },
      },
    },
    strengths: {
      type: "array",
      items: { type: "string" },
      description: "Barqaror kuchli tomonlar ro'yxati",
    },
    actionPlan: {
      type: "array",
      items: { type: "string" },
      description: "3-5 ta aniq, bajarish mumkin bo'lgan qadam",
    },
    motivationalNote: {
      type: "string",
      description: "Qisqa, samimiy yakuniy xabar",
    },
  },
};
