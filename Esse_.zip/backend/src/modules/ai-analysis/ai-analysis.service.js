import { getUserById, deductBalanceIfEnough, addBalance } from "../user/user.service.js";
import { Essay } from "../essay/essay.model.js";
import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { AiAnalysis } from "./ai-analysis.model.js";
import { generateAiAnalysis } from "./ai-analysis.gpt.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

const MAX_ESSAYS_FOR_ANALYSIS = 10;

export async function getAiAnalysisStatus(userId) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const lastAnalysis = await AiAnalysis.findOne({
    where: { userId },
    order: [["createdAt", "DESC"]],
  });

  return {
    // AI tahlil endi FAQAT pullik (haftalik bepul urinish olib tashlandi).
    isFree: false,
    nextFreeAt: null,
    price: env.aiAnalysisPrice,
    balance: user.balance,
    lastAnalysis: lastAnalysis
      ? {
          id: lastAnalysis.id,
          content: lastAnalysis.content,
          wasFree: lastAnalysis.wasFree,
          createdAt: lastAnalysis.createdAt,
        }
      : null,
  };
}

export async function generateMyAiAnalysis(userId) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const essays = await Essay.findAll({
    where: { userId },
    include: [{ model: EvaluationResult, as: "evaluationResult" }],
    order: [["createdAt", "DESC"]],
    limit: MAX_ESSAYS_FOR_ANALYSIS,
  });

  const completed = essays.filter(
    (e) => e.evaluationResult?.status === "completed",
  );

  if (completed.length === 0) {
    throw httpError(
      400,
      "AI tahlil qilish uchun kamida bitta muvaffaqiyatli tekshirilgan esse kerak.",
    );
  }

  // AI tahlil - FAQAT pullik. To'lovni GPT chaqiruvidan OLDIN atomik yechamiz
  // (parallel so'rovlar balansni minusга tushirmasligi uchun). Xato bo'lsa
  // qaytaramiz.
  const paid = await deductBalanceIfEnough(userId, env.aiAnalysisPrice);
  if (!paid) {
    throw httpError(
      402,
      `AI tahlil narxi ${env.aiAnalysisPrice} so'm. Balansingizda mablag' ` +
        `yetarli emas. Botdagi "💰 Balansni to'ldirish" bo'limidan ` +
        `hisobingizni to'ldiring.`,
    );
  }

  const essaysData = completed.map((e) => ({
    topic: e.topic,
    totalScore: e.evaluationResult.totalScore,
    bandResults: e.evaluationResult.bandResults,
  }));

  let content;
  try {
    content = await generateAiAnalysis(essaysData);
  } catch (error) {
    // GPT texnik xatosi - yechilgan to'lovni qaytaramiz va tushunarli
    // "texnik nosozlik" xabarini beramiz (ichki xato oshkor qilinmaydi).
    console.error("AI tahlil GPT xatosi:", error?.status, error?.message);
    await addBalance(userId, env.aiAnalysisPrice);
    throw httpError(
      502,
      "Texnik nosozlik yuz berdi. Balansingizdan hech narsa yechilmadi. " +
        "Iltimos, birozdan so'ng qayta urinib ko'ring.",
    );
  }

  const analysis = await AiAnalysis.create({
    userId,
    content,
    wasFree: false,
  });

  return {
    id: analysis.id,
    content: analysis.content,
    wasFree: analysis.wasFree,
    createdAt: analysis.createdAt,
  };
}

function toPublicAnalysis(a) {
  return {
    id: a.id,
    content: a.content,
    wasFree: a.wasFree,
    createdAt: a.createdAt,
  };
}

export async function listMyAnalyses(userId) {
  const analyses = await AiAnalysis.findAll({
    where: { userId },
    order: [["createdAt", "DESC"]],
  });
  return analyses.map(toPublicAnalysis);
}

export async function getMyAnalysis(userId, id) {
  const analysis = await AiAnalysis.findOne({ where: { id, userId } });
  if (!analysis) throw httpError(404, "Tahlil topilmadi");
  return toPublicAnalysis(analysis);
}
