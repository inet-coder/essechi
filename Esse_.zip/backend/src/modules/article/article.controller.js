import {
  createArticle,
  getPublishedArticles,
  getPublishedArticleById,
  getPublishedCategories,
  getAllArticles,
  getArticleById,
  updateArticle,
  reorderArticles,
  deleteArticle,
  estimateReadingMinutesFromBody,
} from "./article.service.js";

function coverImagePath(file) {
  return file ? `/uploads/articles/${file.filename}` : undefined;
}

// "true"/"false" (FormData matn) yoki boolean -> boolean.
function parseBool(value) {
  if (value === undefined) return undefined;
  return value === "true" || value === true;
}

// --- Public (foydalanuvchi) ---

export async function listPublishedArticles(req, res, next) {
  try {
    const articles = await getPublishedArticles();
    res.status(200).json(articles);
  } catch (error) {
    next(error);
  }
}

export async function listPublishedCategories(req, res, next) {
  try {
    const categories = await getPublishedCategories();
    res.status(200).json(categories);
  } catch (error) {
    next(error);
  }
}

export async function getPublishedArticle(req, res, next) {
  try {
    const { id } = req.params;
    const article = await getPublishedArticleById(id);

    if (!article) {
      return res.status(404).json({ error: "Maqola topilmadi" });
    }

    res.status(200).json({
      ...article.toJSON(),
      readingMinutes: estimateReadingMinutesFromBody(article.body),
    });
  } catch (error) {
    next(error);
  }
}

// --- Admin ---

export async function adminListArticles(req, res, next) {
  try {
    const articles = await getAllArticles();
    res.status(200).json(articles);
  } catch (error) {
    next(error);
  }
}

export async function adminGetArticle(req, res, next) {
  try {
    const { id } = req.params;
    const article = await getArticleById(id);

    if (!article) {
      return res.status(404).json({ error: "Maqola topilmadi" });
    }

    res.status(200).json(article);
  } catch (error) {
    next(error);
  }
}

export async function adminCreateArticle(req, res, next) {
  try {
    const { title, body, isPublished, pinned, category } = req.body;

    if (!title || !title.trim() || !body || !body.trim()) {
      return res.status(400).json({ error: "title va body majburiy" });
    }

    const article = await createArticle({
      title: title.trim(),
      body: body.trim(),
      coverImage: coverImagePath(req.file),
      isPublished: isPublished === undefined ? true : parseBool(isPublished),
      pinned: parseBool(pinned) ?? false,
      category,
    });

    res.status(201).json(article);
  } catch (error) {
    next(error);
  }
}

// Joylashuvni qayta tartiblash: { ids: [3, 1, 2] } - ro'yxatdagi tartib.
export async function adminReorderArticles(req, res, next) {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids)) {
      return res.status(400).json({ error: "ids massiv bo'lishi kerak" });
    }
    await reorderArticles(ids);
    const articles = await getAllArticles();
    res.status(200).json(articles);
  } catch (error) {
    next(error);
  }
}

export async function adminUpdateArticle(req, res, next) {
  try {
    const { id } = req.params;
    const { title, body, isPublished, pinned, category } = req.body;

    const article = await updateArticle(id, {
      title: title !== undefined ? title.trim() : undefined,
      body: body !== undefined ? body.trim() : undefined,
      coverImage: coverImagePath(req.file),
      isPublished: parseBool(isPublished),
      pinned: parseBool(pinned),
      category,
    });

    if (!article) {
      return res.status(404).json({ error: "Maqola topilmadi" });
    }

    res.status(200).json(article);
  } catch (error) {
    next(error);
  }
}

export async function adminDeleteArticle(req, res, next) {
  try {
    const { id } = req.params;
    const article = await deleteArticle(id);

    if (!article) {
      return res.status(404).json({ error: "Maqola topilmadi" });
    }

    res.status(200).json({ success: true });
  } catch (error) {
    next(error);
  }
}
