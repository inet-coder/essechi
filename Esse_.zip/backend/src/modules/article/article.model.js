import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

export const Article = sequelize.define(
  "Article",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    coverImage: {
      type: DataTypes.STRING,
      allowNull: true, // "/uploads/articles/<file>" - Multer orqali yuklanadi
    },
    body: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    // Admin qoralama sifatida saqlab, keyin e'lon qilishi mumkin
    isPublished: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
    // Yuqoriga qadab qo'yish - qadalgan maqolalar ro'yxat boshida turadi va
    // birinchisi "Tavsiya etilgan" bloki bo'ladi.
    pinned: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    // Qo'lda tartiblash (joylashuv). Kichik qiymat - yuqorida.
    sortOrder: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    // Ixtiyoriy bo'lim/teg (masalan "Grammatika", "Writing").
    category: {
      type: DataTypes.STRING(64),
      allowNull: true,
    },
  },
  {
    tableName: "articles",
    timestamps: true,
  },
);
