import { Router } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { requireAdmin } from "../../middleware/requireAdmin.js";
import {
  listPublishedArticles,
  listPublishedCategories,
  getPublishedArticle,
  adminListArticles,
  adminGetArticle,
  adminCreateArticle,
  adminUpdateArticle,
  adminReorderArticles,
  adminDeleteArticle,
} from "./article.controller.js";

const uploadsDir = path.join(process.cwd(), "uploads", "articles");
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || ".jpg";
    cb(null, `${randomUUID()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("Faqat rasm fayli qabul qilinadi"));
    }
    cb(null, true);
  },
});

const router = Router();

// Admin ro'yxati (qoralamalar bilan) - "/:id" dan oldin bo'lishi shart
router.get("/admin", requireAdmin, adminListArticles);
router.get("/admin/:id", requireAdmin, adminGetArticle);
router.post("/admin", requireAdmin, upload.single("cover"), adminCreateArticle);
// Joylashuvni qayta tartiblash (JSON: { ids: [...] }) - "/admin/:id" dan oldin.
router.patch("/admin/reorder", requireAdmin, adminReorderArticles);
router.patch(
  "/admin/:id",
  requireAdmin,
  upload.single("cover"),
  adminUpdateArticle,
);
router.delete("/admin/:id", requireAdmin, adminDeleteArticle);

// Public (faqat e'lon qilinganlar)
router.get("/", listPublishedArticles);
router.get("/categories", listPublishedCategories);
router.get("/:id", getPublishedArticle);

export default router;
