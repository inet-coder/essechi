import { fn, col } from "sequelize";
import { Article } from "./article.model.js";

// Joylashuv tartibi: avval qadalganlar (pinned), so'ng qo'lda tartib
// (sortOrder), so'ng yangilik bo'yicha. Ham public, ham admin ro'yxatida bir xil.
const PLACEMENT_ORDER = [
  ["pinned", "DESC"],
  ["sortOrder", "ASC"],
  ["createdAt", "DESC"],
];

function normalizeCategory(value) {
  if (value === undefined) return undefined;
  if (value === null) return null;
  const trimmed = String(value).trim();
  return trimmed ? trimmed.slice(0, 64) : null;
}

export async function createArticle({
  title,
  body,
  coverImage,
  isPublished,
  pinned,
  category,
}) {
  // Yangi maqola ro'yxat oxiriga qo'yiladi (mavjud joylashuvni buzmaydi).
  const maxOrder = await Article.max("sortOrder");
  const nextOrder = Number.isFinite(maxOrder) ? maxOrder + 1 : 0;

  return Article.create({
    title,
    body,
    coverImage: coverImage ?? null,
    isPublished: isPublished ?? true,
    pinned: pinned ?? false,
    category: normalizeCategory(category) ?? null,
    sortOrder: nextOrder,
  });
}

const WORDS_PER_MINUTE = 180;
const EXCERPT_LENGTH = 140;

function estimateReadingMinutes(body) {
  const words = body.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / WORDS_PER_MINUTE));
}

function buildExcerpt(body) {
  const flat = body.trim().replace(/\s+/g, " ");
  if (flat.length <= EXCERPT_LENGTH) return flat;
  return `${flat.slice(0, EXCERPT_LENGTH).trimEnd()}…`;
}

// Foydalanuvchilarga faqat e'lon qilingan maqolalar ko'rsatiladi. Ro'yxat
// yengil bo'lishi uchun to'liq matn (body) qaytarilmaydi - faqat undan
// hisoblangan o'qish vaqti (daqiqa) va qisqa parcha (excerpt) beriladi.
export async function getPublishedArticles() {
  const articles = await Article.findAll({
    where: { isPublished: true },
    order: PLACEMENT_ORDER,
    attributes: ["id", "title", "coverImage", "body", "category", "createdAt"],
  });

  return articles.map((article) => ({
    id: article.id,
    title: article.title,
    coverImage: article.coverImage,
    category: article.category,
    createdAt: article.createdAt,
    readingMinutes: estimateReadingMinutes(article.body),
    excerpt: buildExcerpt(article.body),
  }));
}

export function estimateReadingMinutesFromBody(body) {
  return estimateReadingMinutes(body);
}

export async function getPublishedArticleById(id) {
  return Article.findOne({ where: { id, isPublished: true } });
}

// Admin panel - qoralamalar ham shu yerda ko'rinadi (joylashuv tartibida).
export async function getAllArticles() {
  return Article.findAll({ order: PLACEMENT_ORDER });
}

// Public bo'limlar (kategoriyalar) ro'yxati - filtr uchun. Bo'sh bo'lmaganlari.
export async function getPublishedCategories() {
  const rows = await Article.findAll({
    where: { isPublished: true },
    attributes: [[fn("DISTINCT", col("category")), "category"]],
    raw: true,
  });
  return rows
    .map((r) => r.category)
    .filter((c) => c && c.trim())
    .sort((a, b) => a.localeCompare(b));
}

export async function getArticleById(id) {
  return Article.findByPk(id);
}

export async function updateArticle(
  id,
  { title, body, coverImage, isPublished, pinned, category },
) {
  const article = await Article.findByPk(id);
  if (!article) return null;

  if (title !== undefined) article.title = title;
  if (body !== undefined) article.body = body;
  if (coverImage !== undefined) article.coverImage = coverImage;
  if (isPublished !== undefined) article.isPublished = isPublished;
  if (pinned !== undefined) article.pinned = pinned;
  const normalizedCategory = normalizeCategory(category);
  if (normalizedCategory !== undefined) article.category = normalizedCategory;

  await article.save();
  return article;
}

// Joylashuvni qayta tartiblash: berilgan ID tartibiga qarab sortOrder = indeks.
// Faqat mavjud (haqiqiy) ID'lar yoziladi. Noma'lum ID'lar e'tiborsiz qoldiriladi.
export async function reorderArticles(ids) {
  if (!Array.isArray(ids) || ids.length === 0) return;

  const known = await Article.findAll({ attributes: ["id"] });
  const knownIds = new Set(known.map((a) => a.id));

  let order = 0;
  for (const rawId of ids) {
    const id = Number(rawId);
    if (!knownIds.has(id)) continue;
    await Article.update({ sortOrder: order }, { where: { id } });
    order += 1;
  }
}

export async function deleteArticle(id) {
  const article = await Article.findByPk(id);
  if (!article) return null;
  await article.destroy();
  return article;
}
