import {
  getActiveChannels,
  getAllChannelsAdmin,
  addChannel,
  updateChannelStatus,
  deactivateChannel,
  activateChannel,
} from "./channel.service.js";

// Ochiq endpoint - bot majburiy obunani tekshirish uchun ishlatadi.
export async function listActiveChannels(req, res, next) {
  try {
    const channels = await getActiveChannels();
    res.status(200).json(channels);
  } catch (error) {
    next(error);
  }
}

export async function adminListChannels(req, res, next) {
  try {
    const channels = await getAllChannelsAdmin();
    res.status(200).json(channels);
  } catch (error) {
    next(error);
  }
}

export async function adminAddChannel(req, res, next) {
  try {
    const { chatId, username, title, inviteLink, status } = req.body;

    if (!chatId) {
      return res.status(400).json({ error: "chatId majburiy" });
    }
    if (!title || !title.trim()) {
      return res.status(400).json({ error: "title majburiy" });
    }

    const channel = await addChannel({
      chatId,
      username,
      title: title.trim(),
      inviteLink,
      status,
    });
    res.status(201).json(channel);
  } catch (error) {
    if (error.name === "SequelizeUniqueConstraintError") {
      return res.status(409).json({ error: "Bu kanal allaqachon qo'shilgan" });
    }
    next(error);
  }
}

export async function adminUpdateStatus(req, res, next) {
  try {
    const { id } = req.params;
    const { status, inviteLink, title, username } = req.body;

    if (status && !["pending", "active"].includes(status)) {
      return res.status(400).json({ error: "status noto'g'ri" });
    }

    const channel = await updateChannelStatus(id, { status, inviteLink, title, username });
    if (!channel) {
      return res.status(404).json({ error: "Kanal topilmadi" });
    }
    res.status(200).json(channel);
  } catch (error) {
    next(error);
  }
}

export async function removeChannel(req, res, next) {
  try {
    const { id } = req.params;
    const channel = await deactivateChannel(id);
    if (!channel) {
      return res.status(404).json({ error: "Kanal topilmadi" });
    }
    res.status(200).json(channel);
  } catch (error) {
    next(error);
  }
}

export async function restoreChannel(req, res, next) {
  try {
    const { id } = req.params;
    const channel = await activateChannel(id);
    if (!channel) {
      return res.status(404).json({ error: "Kanal topilmadi" });
    }
    res.status(200).json(channel);
  } catch (error) {
    next(error);
  }
}
