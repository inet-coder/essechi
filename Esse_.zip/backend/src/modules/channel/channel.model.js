import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

// Majburiy obuna kanallari. Admin panel orqali qo'shiladi - foydalanuvchi
// botdan foydalanishdan oldin shu yerdagi FAOL (isActive=true, status=active)
// kanallarga obuna bo'lgan bo'lishi shart.
//
// status:
//   "pending" - kanal qo'shildi, lekin bot hali u yerda admin/a'zo emas
//               (obuna tekshiruvi ISHLAMAYDI - Telegram Bot API kanalda
//               a'zo bo'lmagan botga getChatMember qaytarmaydi). Admin
//               botni kanalga admin qilib qo'shishi kerak.
//   "active"  - bot kanalda admin/a'zo ekanligi tasdiqlangan, obuna
//               tekshiruvi shu kanal uchun ishlaydi.
export const RequiredChannel = sequelize.define(
  "RequiredChannel",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    // Telegram chat id (masalan -1001234567890). Har bir kanal bittadan.
    chatId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      unique: true,
    },
    // Ochiq kanal bo'lsa @username (@ belgisisiz). Yopiq kanalda null.
    username: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    // Yopiq kanallar uchun taklif havolasi (t.me/+xxxx). Ochiq kanalda
    // odatda kerak emas - @username orqali havola tuziladi.
    inviteLink: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    status: {
      type: DataTypes.ENUM("pending", "active"),
      allowNull: false,
      defaultValue: "pending",
    },
    // Admin ro'yxatdan vaqtincha (butunlay o'chirmasdan) olib tashlashi
    // uchun - topic/category'dagi kabi soft-deactivate.
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    tableName: "required_channels",
    timestamps: true,
  },
);
