import { Router } from "express";
import { requireAdmin } from "../../middleware/requireAdmin.js";
import {
  listActiveChannels,
  adminListChannels,
  adminAddChannel,
  adminUpdateStatus,
  removeChannel,
  restoreChannel,
} from "./channel.controller.js";

const router = Router();

// Ochiq - bot majburiy obunani tekshirishda shu ro'yxatni ishlatadi
// (faqat status=active va isActive=true kanallar qaytadi).
router.get("/", listActiveChannels);

// Admin boshqaruv paneli uchun to'liq ro'yxat (pending + active, faol + nofaol).
router.get("/admin", requireAdmin, adminListChannels);

router.post("/", requireAdmin, adminAddChannel);
router.post("/:id/status", requireAdmin, adminUpdateStatus);
router.post("/:id/deactivate", requireAdmin, removeChannel);
router.post("/:id/activate", requireAdmin, restoreChannel);

export default router;
