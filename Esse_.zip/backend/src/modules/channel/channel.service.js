import { RequiredChannel } from "./channel.model.js";

// Botga (obuna tekshiruvi uchun) va foydalanuvchiga ko'rsatiladigan ro'yxam -
// faqat bot allaqachon a'zo/admin bo'lgan (status=active) va faol
// (isActive=true) kanallar.
export async function getActiveChannels() {
  return RequiredChannel.findAll({
    where: { isActive: true, status: "active" },
    order: [["createdAt", "ASC"]],
  });
}

// Admin boshqaruv paneli uchun - barcha kanallar (pending, active, faol,
// nofaol - hammasi ko'rinsin).
export async function getAllChannelsAdmin() {
  return RequiredChannel.findAll({ order: [["createdAt", "DESC"]] });
}

export async function findByChatId(chatId) {
  return RequiredChannel.findOne({ where: { chatId } });
}

// Kanal qo'shish. Agar shu chatId bilan avval (masalan o'chirilgan holda)
// qo'shilgan bo'lsa - qayta yaratmasdan, mavjud yozuvni yangilab qayta
// faollashtiramiz (unique constraint xatosi o'rniga tabiiy xatti-harakat).
export async function addChannel({ chatId, username, title, inviteLink, status }) {
  const existing = await findByChatId(chatId);

  if (existing) {
    existing.username = username ?? existing.username;
    existing.title = title ?? existing.title;
    existing.inviteLink = inviteLink ?? existing.inviteLink;
    existing.status = status ?? existing.status;
    existing.isActive = true;
    await existing.save();
    return existing;
  }

  return RequiredChannel.create({
    chatId,
    username: username || null,
    title,
    inviteLink: inviteLink || null,
    status: status || "pending",
  });
}

// Bot kanalga admin sifatida qo'shilgach (yoki holati o'zgarganda) holatni
// yangilash uchun.
export async function updateChannelStatus(id, { status, inviteLink, title, username }) {
  const channel = await RequiredChannel.findByPk(id);
  if (!channel) return null;

  if (status) channel.status = status;
  if (inviteLink !== undefined) channel.inviteLink = inviteLink;
  if (title) channel.title = title;
  if (username !== undefined) channel.username = username;

  await channel.save();
  return channel;
}

export async function deactivateChannel(id) {
  const channel = await RequiredChannel.findByPk(id);
  if (!channel) return null;
  channel.isActive = false;
  await channel.save();
  return channel;
}

export async function activateChannel(id) {
  const channel = await RequiredChannel.findByPk(id);
  if (!channel) return null;
  channel.isActive = true;
  await channel.save();
  return channel;
}
