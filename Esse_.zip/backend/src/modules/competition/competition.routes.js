import { Router } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { requireTelegramAuth } from "../../middleware/telegramAuth.js";
import { requireAdmin } from "../../middleware/requireAdmin.js";
import { env } from "../../core/env.js";
import {
  listCompetitions,
  getCompetition,
  register,
  pay,
  submitTextEssay,
  submitPdfEssay,
  extractCompetitionImageText,
  results,
  entryEssay,
  adminList,
  adminGet,
  adminCreate,
  adminUpdate,
  adminSetStatus,
  adminSetVisibility,
  adminFinish,
} from "./competition.controller.js";

const uploadsDir = path.join(process.cwd(), "uploads", "essays");
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => cb(null, `${randomUUID()}.pdf`),
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype !== "application/pdf") {
      return cb(new Error("Faqat PDF fayl qabul qilinadi"));
    }
    cb(null, true);
  },
});

// Qo'lyozma rasmlar diskka saqlanmaydi - faqat OCR uchun xotirada saqlanadi.
const MAX_IMAGE_PAGES = env.essayImageMaxPages;
const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: MAX_IMAGE_PAGES }, // 5MB/dona
  fileFilter: (req, file, cb) => {
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.mimetype)) {
      return cb(new Error("Faqat JPEG, PNG yoki WEBP rasm qabul qilinadi"));
    }
    cb(null, true);
  },
});

const router = Router();

// --- Admin ("/:id" dan oldin bo'lishi shart) ---
router.get("/admin", requireAdmin, adminList);
router.get("/admin/:id", requireAdmin, adminGet);
router.post("/admin", requireAdmin, adminCreate);
router.patch("/admin/:id", requireAdmin, adminUpdate);
router.post("/admin/:id/status", requireAdmin, adminSetStatus);
router.post("/admin/:id/visibility", requireAdmin, adminSetVisibility);
router.post("/admin/:id/finish", requireAdmin, adminFinish);

// --- Public (Telegram initData bilan) ---
router.use(requireTelegramAuth);
router.get("/", listCompetitions);
router.get("/:id", getCompetition);
router.get("/:id/results", results);
router.get("/:id/entries/:userId/essay", entryEssay);
// Oldindan ro'yxatdan o'tish (tekin) va kirish to'lovini to'lash (ishtirokchi).
router.post("/:id/register", register);
router.post("/:id/pay", pay);
router.post("/:id/essays/text", submitTextEssay);
router.post("/:id/essays/pdf", upload.single("file"), submitPdfEssay);
// Rasmdan matn o'qish - musobaqada TEKIN.
router.post(
  "/:id/essays/extract-image-text",
  imageUpload.array("files", MAX_IMAGE_PAGES),
  extractCompetitionImageText,
);

export default router;
