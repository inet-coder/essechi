import { Op, fn, col, literal } from "sequelize";
import { sequelize } from "../../core/database.js";
import { httpError } from "../../core/httpError.js";
import { Competition, CompetitionEntry } from "./competition.model.js";
import { User } from "../user/user.model.js";
import { Essay } from "../essay/essay.model.js";
import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { addBalance } from "../user/user.service.js";
import { runCompetitionEvaluation } from "./competition.evaluator.js";

// Foydalanuvchiga ko'rinadigan statuslar (draft yashirin). "upcoming" -
// belgilangan sanada boshlanadigan, oldindan ro'yxat ochiq musobaqa.
const PUBLIC_STATUSES = ["upcoming", "open", "closed", "evaluating", "finished"];

// Bir nechta musobaqa uchun ro'yxatdan o'tganlar va (to'lagan) ishtirokchilar
// sonini bitta so'rovda hisoblaydi. { registeredCount, participantCount }.
async function entryCountsFor(competitionIds) {
  const map = new Map();
  if (competitionIds.length === 0) return map;
  const rows = await CompetitionEntry.findAll({
    attributes: [
      "competitionId",
      [fn("COUNT", col("id")), "registered"],
      [fn("SUM", literal("CASE WHEN paid THEN 1 ELSE 0 END")), "participants"],
    ],
    where: { competitionId: { [Op.in]: competitionIds } },
    group: ["competitionId"],
    raw: true,
  });
  for (const r of rows) {
    map.set(Number(r.competitionId), {
      registeredCount: Number(r.registered) || 0,
      participantCount: Number(r.participants) || 0,
    });
  }
  return map;
}

// --- Public ---

export async function listPublicCompetitions() {
  const competitions = await Competition.findAll({
    where: { status: { [Op.in]: PUBLIC_STATUSES } },
    order: [["createdAt", "DESC"]],
  });
  const counts = await entryCountsFor(competitions.map((c) => c.id));
  return competitions.map((c) => ({
    ...c.toJSON(),
    registeredCount: counts.get(c.id)?.registeredCount ?? 0,
    participantCount: counts.get(c.id)?.participantCount ?? 0,
  }));
}

// Musobaqa tafsiloti + shu foydalanuvchining holati (ro'yxatdan o'tganmi,
// to'lab to'liq ishtirokchi bo'lganmi, esse yuborganmi) + umumiy sonlar.
export async function getCompetitionForUser(competitionId, userId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.status === "draft") {
    throw httpError(404, "Musobaqa topilmadi");
  }

  const entry = await CompetitionEntry.findOne({
    where: { competitionId, userId },
  });
  const counts = (await entryCountsFor([competition.id])).get(competition.id);

  return {
    competition,
    joined: Boolean(entry), // ro'yxatdan o'tganmi (to'lagan yoki to'lamagan)
    paid: Boolean(entry?.paid), // kirish to'lovini to'laganmi (to'liq ishtirokchi)
    hasEssay: Boolean(entry?.essayId),
    entryEssayId: entry?.essayId ?? null,
    registeredCount: counts?.registeredCount ?? 0,
    participantCount: counts?.participantCount ?? 0,
  };
}

// Oldindan ro'yxatdan o'tish (to'lovsiz - joyni band qilish). "upcoming" yoki
// "open" holatda ishlaydi. Kirish to'lovi 0 bo'lsa darhol to'liq ishtirokchi
// qiladi (paid=true) - to'laydigan narsa yo'q. Allaqachon yozuvi bo'lsa mavjud
// yozuvni qaytaradi (idempotent). Kirish to'lovini keyin payEntryFee bilan
// to'lab to'liq ishtirokchi bo'ladi.
export async function registerForCompetition(competitionId, userId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.status === "draft") {
    throw httpError(404, "Musobaqa topilmadi");
  }
  if (!["upcoming", "open"].includes(competition.status)) {
    throw httpError(409, "Ro'yxatdan o'tish hozir ochiq emas");
  }

  // findOrCreate - ikki parallel so'rov (ikki marta bosildi) unique indeks
  // orqali xavfsiz: faqat bittasi yaratadi, ikkinchisi mavjudini oladi.
  // Kirish to'lovi bo'lmasa ro'yxatdan o'tish = to'liq ishtirokchi.
  const [entry] = await CompetitionEntry.findOrCreate({
    where: { competitionId, userId },
    defaults: { competitionId, userId, paid: competition.entryFee <= 0 },
  });
  return entry;
}

// Kirish to'lovini to'lab to'liq ishtirokchiga aylanish: to'lovni balansdan
// atomik yechadi, entry'ni paid=true qiladi. "upcoming" yoki "open" holatda
// ishlaydi - oldindan (musobaqa boshlanmasidan) ham to'lab qo'yish mumkin.
// Allaqachon to'lagan bo'lsa qayta yechilmaydi (idempotent). Ro'yxatdan
// o'tmagan bo'lsa ham to'lab darhol to'liq ishtirokchi bo'ladi.
export async function payEntryFee(competitionId, userId) {
  return sequelize.transaction(async (t) => {
    const competition = await Competition.findByPk(competitionId, {
      lock: t.LOCK.UPDATE,
      transaction: t,
    });
    if (!competition || competition.status === "draft") {
      throw httpError(404, "Musobaqa topilmadi");
    }
    if (!["upcoming", "open"].includes(competition.status)) {
      throw httpError(409, "Musobaqa hozir qabul qilmayapti");
    }

    const existing = await CompetitionEntry.findOne({
      where: { competitionId, userId },
      transaction: t,
    });
    if (existing?.paid) return existing; // allaqachon to'liq ishtirokchi

    if (competition.entryFee > 0) {
      const user = await User.findByPk(userId, {
        lock: t.LOCK.UPDATE,
        transaction: t,
      });
      if (!user) throw httpError(404, "Foydalanuvchi topilmadi");
      if (user.balance < competition.entryFee) {
        throw httpError(
          402,
          `Balans yetarli emas. Kirish to'lovi: ${competition.entryFee} so'm`,
        );
      }
      user.balance -= competition.entryFee;
      await user.save({ transaction: t });
    }

    if (existing) {
      existing.paid = true;
      await existing.save({ transaction: t });
      return existing;
    }
    return CompetitionEntry.create(
      { competitionId, userId, paid: true },
      { transaction: t },
    );
  });
}

// Yuborilgan esseni entry'ga bog'laydi (deadline'gacha almashtirilishi mumkin).
// Esse yozuvi chaqiruvchi (controller) tomonidan oldindan yaratiladi. Faqat
// to'liq ishtirokchi (paid=true) esse yubora oladi.
export async function attachEssayToEntry(competitionId, userId, essayId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.status === "draft") {
    throw httpError(404, "Musobaqa topilmadi");
  }
  if (competition.status !== "open") {
    throw httpError(409, "Musobaqa yopilgan, esse qabul qilinmaydi");
  }

  const entry = await CompetitionEntry.findOne({
    where: { competitionId, userId },
  });
  if (!entry) {
    throw httpError(403, "Avval musobaqaga ro'yxatdan o'ting");
  }
  if (!entry.paid) {
    throw httpError(403, "Avval kirish to'lovini to'lab ishtirokchi bo'ling");
  }

  entry.essayId = essayId;
  await entry.save();
  return entry;
}

// Yakuniy natijalar: to'liq reyting + so'rovchining o'z tahlili. Faqat
// "finished" holatda ochiladi.
export async function getResults(competitionId, userId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.status === "draft") {
    throw httpError(404, "Musobaqa topilmadi");
  }
  if (competition.status !== "finished") {
    throw httpError(409, "Natijalar hali e'lon qilinmagan");
  }

  const entries = await CompetitionEntry.findAll({
    where: { competitionId },
    include: [
      { model: User, as: "user", attributes: ["id", "firstName"] },
      {
        model: Essay,
        as: "essay",
        include: [
          { model: EvaluationResult, as: "evaluationResult" },
        ],
      },
    ],
    order: [["rank", "ASC"]],
  });

  const ranking = entries
    .filter((e) => e.rank != null)
    .map((e) => ({
      rank: e.rank,
      userId: e.userId,
      firstName: e.user?.firstName || "Noma'lum",
      scaledScore: e.scaledScore,
      status: e.essay?.evaluationResult?.status || "failed",
      prize: e.awardedPrize || null,
      isMe: e.userId === userId,
    }));

  // So'rovchining o'z essesi tahlili (band natijalari, tavsiyalar).
  const myEntry = entries.find((e) => e.userId === userId);
  const myResult = myEntry?.essay?.evaluationResult || null;

  return {
    competition: {
      id: competition.id,
      title: competition.title,
      topic: competition.topic,
      prizes: competition.prizes,
      essaysPublic: competition.essaysPublic,
    },
    ranking,
    myResult: myResult
      ? {
          rank: myEntry.rank,
          scaledScore: myEntry.scaledScore,
          status: myResult.status,
          bandResults: myResult.bandResults,
          recommendations: myResult.recommendations,
          rejectionReason: myResult.rejectionReason,
          prize: myEntry.awardedPrize || null,
        }
      : null,
  };
}

// Bitta ishtirokchining essesi va tahlili. O'z essesini har kim ko'radi;
// boshqalarnikini faqat musobaqa essaysPublic bo'lsa. Faqat "finished" holatda.
export async function getEntryEssay(competitionId, viewerId, targetUserId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.status === "draft") {
    throw httpError(404, "Musobaqa topilmadi");
  }
  if (competition.status !== "finished") {
    throw httpError(409, "Natijalar hali e'lon qilinmagan");
  }

  const isOwn = viewerId === Number(targetUserId);
  if (!isOwn && !competition.essaysPublic) {
    throw httpError(403, "Ishtirokchilar esselari yopiq");
  }

  const entry = await CompetitionEntry.findOne({
    where: { competitionId, userId: targetUserId },
    include: [
      { model: User, as: "user", attributes: ["firstName"] },
      {
        model: Essay,
        as: "essay",
        include: [{ model: EvaluationResult, as: "evaluationResult" }],
      },
    ],
  });

  if (!entry || !entry.essay) {
    throw httpError(404, "Esse topilmadi");
  }

  const result = entry.essay.evaluationResult;
  return {
    rank: entry.rank,
    firstName: entry.user?.firstName || "Ishtirokchi",
    scaledScore: entry.scaledScore,
    status: result?.status || "failed",
    rawText: entry.essay.rawText,
    bandResults: result?.bandResults || [],
    isMe: isOwn,
  };
}

// --- Admin ---

export async function listAllCompetitions() {
  return Competition.findAll({ order: [["createdAt", "DESC"]] });
}

export async function getCompetitionAdmin(competitionId) {
  const competition = await Competition.findByPk(competitionId, {
    include: [
      {
        model: CompetitionEntry,
        as: "entries",
        include: [{ model: User, as: "user", attributes: ["firstName"] }],
      },
    ],
    order: [[{ model: CompetitionEntry, as: "entries" }, "rank", "ASC"]],
  });
  if (!competition) throw httpError(404, "Musobaqa topilmadi");

  const entries = competition.entries ?? [];
  return {
    ...competition.toJSON(),
    registeredCount: entries.length,
    participantCount: entries.filter((e) => e.paid).length,
  };
}

// Yutuqlarni bir xil, erkin shaklga keltiradi: [{ place, reward }].
// reward - ERKIN matn (naqd pul, jismoniy sovg'a, sertifikat va h.k.). Pul
// mukofoti AVTO tushirilmaydi - admin qo'lda beradi. Bo'sh yutuqlar tushiriladi.
// Eski ({place,title,rewardAmount}) formatdan ham o'qiy oladi (title -> reward).
function normalizePrizes(prizes) {
  if (!Array.isArray(prizes)) return [];
  return prizes
    .map((p, i) => {
      const legacyAmount =
        p && p.rewardAmount ? ` — ${p.rewardAmount} so'm` : "";
      const reward = String(
        p?.reward ?? (p?.title ? p.title + legacyAmount : ""),
      ).trim();
      return {
        place: Number.isInteger(p?.place) ? p.place : i + 1,
        reward,
      };
    })
    .filter((p) => p.reward.length > 0);
}

export async function createCompetition(data) {
  const { title, topic, description, entryFee, prizes, startsAt, endsAt } =
    data;
  if (!title || !title.trim() || !topic || !topic.trim()) {
    throw httpError(400, "title va topic majburiy");
  }
  return Competition.create({
    title: title.trim(),
    topic: topic.trim(),
    description: description || null,
    entryFee: Number.isInteger(entryFee) ? entryFee : 0,
    prizes: normalizePrizes(prizes),
    startsAt: startsAt || null,
    endsAt: endsAt || null,
    status: "draft",
  });
}

// Tahrirlash faqat draft/upcoming/open holatda (baholash boshlangach
// o'zgartirilmaydi).
export async function updateCompetition(competitionId, data) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition) throw httpError(404, "Musobaqa topilmadi");
  if (!["draft", "upcoming", "open"].includes(competition.status)) {
    throw httpError(409, "Bu holatda musobaqani tahrirlab bo'lmaydi");
  }

  const fields = [
    "title",
    "topic",
    "description",
    "entryFee",
    "prizes",
    "essaysPublic",
    "startsAt",
    "endsAt",
  ];
  for (const field of fields) {
    if (data[field] !== undefined) {
      competition[field] =
        field === "prizes" ? normalizePrizes(data[field]) : data[field];
    }
  }
  await competition.save();
  return competition;
}

// Ruxsat etilgan qo'lda status o'tishlari (admin panel tugmalari).
const ALLOWED_TRANSITIONS = {
  upcoming: ["draft"], // -> upcoming (e'lon qilish, oldindan ro'yxat ochish)
  open: ["draft", "upcoming", "closed"], // -> open (qabulni boshlash)
  closed: ["open"], // -> closed
  cancelled: ["draft", "upcoming", "open", "closed"], // -> cancelled
};

export async function setCompetitionStatus(competitionId, nextStatus) {
  const allowedFrom = ALLOWED_TRANSITIONS[nextStatus];
  if (!allowedFrom) {
    throw httpError(400, "Noto'g'ri status o'tishi");
  }

  const competition = await Competition.findByPk(competitionId);
  if (!competition) throw httpError(404, "Musobaqa topilmadi");
  if (!allowedFrom.includes(competition.status)) {
    throw httpError(
      409,
      `"${competition.status}" holatidan "${nextStatus}"ga o'tib bo'lmaydi`,
    );
  }

  if (nextStatus === "cancelled") {
    await refundAllEntries(competition.id);
  }

  competition.status = nextStatus;
  await competition.save();
  return competition;
}

// Bekor qilinganda kirish to'lovini FAQAT to'lagan (paid) ishtirokchilarga
// qaytaramiz. Ro'yxatdan o'tib to'lamaganlarga qaytariladigan narsa yo'q.
async function refundAllEntries(competitionId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.entryFee <= 0) return;

  const entries = await CompetitionEntry.findAll({
    where: { competitionId, paid: true },
  });
  for (const entry of entries) {
    await addBalance(entry.userId, competition.entryFee);
  }
}

// Esselar ko'rinishini alohida yoqish/o'chirish - istalgan holatda ishlaydi
// (ayniqsa "finished"dan keyin admin qaror o'zgartira olishi uchun).
export async function setEssaysVisibility(competitionId, essaysPublic) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition) throw httpError(404, "Musobaqa topilmadi");
  competition.essaysPublic = Boolean(essaysPublic);
  await competition.save();
  return competition;
}

// Yopilgan musobaqani baholab yakunlaydi. Status "evaluating"ga o'tkaziladi va
// og'ir partiya fon rejimida ishga tushadi (HTTP so'rov darhol qaytadi). Xato
// bo'lsa admin qayta urina olishi uchun "closed"ga qaytariladi.
export async function startEvaluation(competitionId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition) throw httpError(404, "Musobaqa topilmadi");
  if (competition.status !== "closed") {
    throw httpError(409, "Baholash uchun avval musobaqani yoping");
  }

  competition.status = "evaluating";
  competition.evalProgress = { done: 0, total: 0 };
  await competition.save();

  // Fon rejimida (await qilinmaydi).
  runCompetitionEvaluation(competitionId).catch(async (error) => {
    console.error("Musobaqa baholashda xatolik:", error);
    await Competition.update(
      { status: "closed" },
      { where: { id: competitionId } },
    );
  });

  return competition;
}
