import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

// Esse tekshiruv kreditlari "partiya" (grant) sifatida saqlanadi. Har bir
// paket sotib olinganda bitta grant yoziladi: `credits` - dastlabki soni,
// `remaining` - qolgan soni, `expiresAt` - amal muddati (30 kun).
//
// Nega jadval? Chunki kreditlar 30 kunlik va foydalanuvchi turli vaqtlarda
// bir nechta paket olishi mumkin. Har partiyaning o'z muddati bo'ladi. Mavjud
// (amal qilayotgan) kreditlar HAR DOIM `remaining>0 AND expiresAt>now()`
// so'rovi orqali hisoblanadi - shuning uchun muddat AYNAN, kechikishsiz
// ishlaydi (alohida "kuydirish" vazifasi shart emas).
export const EssayCreditGrant = sequelize.define(
  "EssayCreditGrant",
  {
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    credits: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    remaining: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    // "package" - sotib olingan paket, "admin" - admin qo'lda bergan.
    source: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: "package",
    },
    // Grant qaysi to'lovdan yaratilgani (audit uchun, ixtiyoriy).
    paymentId: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    expiresAt: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    tableName: "essay_credit_grants",
    indexes: [{ fields: ["userId", "remaining", "expiresAt"] }],
  },
);
