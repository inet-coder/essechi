import { Op } from "sequelize";

import { sequelize } from "../../core/database.js";
import { env } from "../../core/env.js";
import { EssayCreditGrant } from "./credit.model.js";

// Yangi kredit partiyasini yaratadi (paket sotib olinganda yoki admin bergan).
// 30 kunlik amal muddati bilan. Ixtiyoriy tranzaksiya ichida bajariladi.
export async function grantCredits(
  { userId, credits, source = "package", paymentId = null },
  transaction = null,
) {
  const expiresAt = new Date(
    Date.now() + env.packageValidityDays * 24 * 60 * 60 * 1000,
  );
  return EssayCreditGrant.create(
    {
      userId,
      credits,
      remaining: credits,
      source,
      paymentId,
      expiresAt,
    },
    { transaction },
  );
}

// Foydalanuvchining AYNI DAMDA amal qilayotgan (muddati o'tmagan) kreditlari.
export async function getAvailableCredits(userId) {
  const sum = await EssayCreditGrant.sum("remaining", {
    where: {
      userId,
      remaining: { [Op.gt]: 0 },
      expiresAt: { [Op.gt]: new Date() },
    },
  });
  return sum || 0;
}

// ATOMIK: eng tez muddati tugaydigan (soonest-expiring) amaldagi partiyadan
// 1 kredit yechadi. Qatorni FOR UPDATE bilan bloklaymiz - shu bilan ikki
// parallel tekshiruv bitta kreditni ikki marta yeb yubormaydi. Muvaffaqiyatli
// bo'lsa {ok:true, grantId}, kredit bo'lmasa {ok:false} qaytaradi.
export async function consumeEssayCredit(userId) {
  return sequelize.transaction(async (t) => {
    const grant = await EssayCreditGrant.findOne({
      where: {
        userId,
        remaining: { [Op.gt]: 0 },
        expiresAt: { [Op.gt]: new Date() },
      },
      order: [["expiresAt", "ASC"]], // avval muddati yaqinini sarflaymiz
      lock: t.LOCK.UPDATE,
      transaction: t,
    });

    if (!grant) return { ok: false };

    grant.remaining -= 1;
    await grant.save({ transaction: t });
    return { ok: true, grantId: grant.id };
  });
}

// Band qilingan kreditni o'sha partiyaga qaytaradi (baholash texnik xato
// bersa yoki natija dublikat bo'lsa).
export async function refundEssayCredit(grantId) {
  if (!grantId) return;
  await EssayCreditGrant.increment(
    { remaining: 1 },
    { where: { id: grantId } },
  );
}
