import {
  getUserByTelegramId,
  deductBalanceIfEnough,
  addBalance,
} from "../user/user.service.js";
import {
  createEssayFromText,
  createEssayFromPdf,
  getEssayById,
} from "./essay.service.js";
import { extractTextFromImages } from "./essay.imageExtractor.js";
import { signOcrReceipt } from "./essay.ocrReceipt.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

export async function submitTextEssay(req, res, next) {
  try {
    const { telegramId, topic, text, ocrReceipt } = req.body;

    if (!telegramId || !topic || !text) {
      return res
        .status(400)
        .json({ error: "telegramId, topic va text majburiy" });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    // ocrReceipt bo'lsa (rasm orqali kelgan, OCR bosqichida oldindan
    // to'langan) - esse "prepaidCheck" bo'lib yaratiladi, baholashda qayta
    // pul/kredit olinmaydi.
    const essay = await createEssayFromText({
      userId: user.id,
      topic,
      text,
      ocrReceipt,
    });
    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

export async function submitPdfEssay(req, res, next) {
  try {
    const { telegramId, topic } = req.body;

    if (!telegramId || !topic) {
      return res.status(400).json({ error: "telegramId va topic majburiy" });
    }
    if (!req.file) {
      return res.status(400).json({ error: "PDF fayl yuborilmadi" });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    let essay;
    try {
      essay = await createEssayFromPdf({
        userId: user.id,
        topic,
        filePath: req.file.path,
      });
    } catch (pdfError) {
      // pdf-parse buzilgan/himoyalangan/noto'g'ri formatdagi PDF fayllarda
      // xato tashlaydi (masalan "bad XRef entry"). Bu foydalanuvchi
      // tushunadigan, aniq xabar bilan qaytariladi - ichki stack trace emas.
      return res.status(400).json({
        error:
          "PDF faylni o'qib bo'lmadi. Fayl buzilgan, himoyalangan yoki " +
          "noto'g'ri formatda bo'lishi mumkin. Boshqa PDF bilan urinib " +
          "ko'ring yoki matn ko'rinishida yuboring.",
      });
    }

    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

export async function getEssay(req, res, next) {
  try {
    const { id } = req.params;
    const essay = await getEssayById(id);

    if (!essay) {
      return res.status(404).json({ error: "Esse topilmadi" });
    }

    res.status(200).json(essay);
  } catch (error) {
    next(error);
  }
}

// Bu endpoint Essay yozuvi YARATMAYDI - u rasm(lar)dagi qo'lyozma matnni o'qib
// beradi. RASM orqali tekshiruv to'lovi SHU YERDA, OLDINDAN olinadi (har varaq
// uchun env.essayImagePagePrice so'm, balansdan). Muvaffaqiyatli o'qilsa
// imzolangan (HMAC) kvitansiya qaytariladi - foydalanuvchi matnni tasdiqlagach
// /text endpointiga shu kvitansiya bilan yuboriladi va esse "prepaidCheck"
// bo'ladi (baholashda qayta pul/kredit OLINMAYDI). OCR texnik xato bersa yoki
// matn topilmasa - olingan to'lov TO'LIQ qaytariladi.
export async function extractImageText(req, res, next) {
  try {
    const { telegramId } = req.body;
    if (!telegramId) {
      throw httpError(400, "telegramId majburiy");
    }
    if (!req.files || req.files.length === 0) {
      throw httpError(400, "Kamida bitta rasm yuborilishi kerak");
    }

    const pages = req.files.length;
    if (pages > env.essayImageMaxPages) {
      throw httpError(
        400,
        `Bir martada eng ko'pi ${env.essayImageMaxPages} ta varaq yuborish mumkin.`,
      );
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }

    const cost = pages * env.essayImagePagePrice;

    // To'lov OCR (GPT) chaqiruvidan OLDIN, atomik yechiladi - shu bilan bexuda
    // vision-token sarflanmaydi va parallel so'rov ikki marta yechmaydi.
    const paid = await deductBalanceIfEnough(user.id, cost);
    if (!paid) {
      throw httpError(
        402,
        `Rasm orqali tekshirishda ${pages} ta varaq × ${env.essayImagePagePrice} = ` +
          `${cost} so'm balansdan oldindan yechiladi. Balansingiz yetarli emas. ` +
          `Botdagi "💰 Balansni to'ldirish" bo'limidan hisobingizni to'ldiring.`,
      );
    }

    const imageFiles = req.files.map((f) => ({
      buffer: f.buffer,
      mimeType: f.mimetype,
    }));

    let text;
    try {
      text = await extractTextFromImages(imageFiles);
    } catch (gptError) {
      console.error("OCR xatosi:", gptError?.status, gptError?.message, gptError);
      await addBalance(user.id, cost); // texnik nosozlik - to'lov qaytariladi
      throw httpError(
        502,
        "Rasmni o'qishda texnik nosozlik yuz berdi. Hisobingizdan yechilgan " +
          "mablag' qaytarildi. Iltimos, birozdan so'ng qayta urinib ko'ring.",
      );
    }

    // Model matn topa olmaganda "XATOLIK: ..." bilan boshlaydi.
    if (/^\s*xatolik/i.test(text)) {
      await addBalance(user.id, cost); // matn topilmadi - to'lov qaytariladi
      throw httpError(
        422,
        "Qo'lyozmani tanib bo'lmadi. Hisobingizdan yechilgan mablag' " +
          "qaytarildi. Iltimos, yorug'roq va aniqroq surat bilan qayta urinib ko'ring.",
      );
    }

    // To'lov muvaffaqiyatli - bir martalik, imzolangan kvitansiya beramiz.
    const ocrReceipt = signOcrReceipt({ userId: user.id, pages });
    res.status(200).json({ text, ocrReceipt, pages, charged: cost });
  } catch (error) {
    next(error);
  }
}
