import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

// pdfjs-dist - Mozilla'ning rasmiy, faol qo'llab-quvvatlanadigan PDF
// kutubxonasi. Eski "pdf-parse" paketidan (2017-yilga oid pdf.js asosida)
// farqli o'laroq, zamonaviy dasturlar (Google Docs, Word eksporti va h.)
// yaratgan PDF fayllarning turli strukturalarini to'g'ri o'qiy oladi.
export async function extractTextFromPdf(buffer) {
  const loadingTask = getDocument({
    data: new Uint8Array(buffer),
    // Node.js muhitida shrift/worker ogohlantirishlarini kamaytirish uchun
    useSystemFonts: true,
  });

  const pdfDocument = await loadingTask.promise;
  const pageTexts = [];

  for (
    let pageNumber = 1;
    pageNumber <= pdfDocument.numPages;
    pageNumber += 1
  ) {
    const page = await pdfDocument.getPage(pageNumber);
    const content = await page.getTextContent();
    const pageText = content.items.map((item) => item.str).join(" ");
    pageTexts.push(pageText);
  }

  if (typeof pdfDocument.cleanup === "function") {
    await pdfDocument.cleanup();
  }

  return pageTexts.join("\n\n");
}

export function countWords(text) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

// Belgi-asosli til aniqlash heuristikasi.
// 'kirill'   - deyarli to'liq kirillcha (lotin harf nolga yaqin) -> precheckda 0 ball
// 'aralash'  - ikkala alifbo ham uchraydi -> GPT bosqichida imlo xatosi sifatida baholanadi
// 'lotin'    - asosan lotin alifbosida
export function detectScript(text) {
  const cyrillicCount = (text.match(/[\u0400-\u04FF]/g) || []).length;
  const latinCount = (text.match(/[A-Za-zʻʼ]/g) || []).length;
  const total = cyrillicCount + latinCount;

  if (total === 0) return "aniqlanmadi";

  const cyrillicRatio = cyrillicCount / total;

  if (cyrillicRatio > 0.95) return "kirill";
  if (cyrillicCount > 0) return "aralash";
  return "lotin";
}
