import { modelParams } from "../../core/env.js";
import { openai } from "../../integrations/openai.js";

const SYSTEM_PROMPT = `# ROL

Siz qog'ozga qo'lda yozilgan matnlarni raqamli matnga aylantiruvchi OCR
(qo'lyozma tanish) tizimisiz.

# VAZIFA

Sizga bir yoki bir nechta rasm beriladi - ularda qog'ozga qo'lda yozilgan
o'zbek tilidagi matn (esse) bor. Har bir rasmdagi matnni ANIQ, so'zma-so'z
transkripsiya qiling.

# QOIDALAR

- Matnni AYNAN yozilganidek qaytaring - imlo xatolarini TUZATMANG, uslubni
  O'ZGARTIRMANG, so'z QO'SHMANG yoki OLIB TASHLAMANG. Siz faqat qo'l bilan
  yozilgan belgilarni raqamli matnga o'giryapsiz, muharrir emassiz.
- Agar bir nechta rasm berilgan bo'lsa, ularni varoq tartibida, bitta
  uzluksiz matn sifatida birlashtiring (varoqlar orasida bo'sh qatordan
  foydalaning).
- Faqat qo'lyozma matnning o'zini qaytaring - hech qanday izoh, sarlavha,
  "Mana matn:" kabi kirish so'zlar yozmang.
- Agar biror so'z yoki jumlani umuman o'qib bo'lmasa, o'sha o'ringa
  [o'qib bo'lmadi] deb yozing va davom eting.
- Agar rasm(lar)da umuman qo'lyozma matn topilmasa yoki matn o'qib
  bo'lmaydigan darajada noaniq/loyqa bo'lsa, boshqa hech narsa yozmasdan
  faqat "XATOLIK: matn aniqlanmadi" deb javob qaytaring.`;

function bufferToDataUrl(buffer, mimeType) {
  return `data:${mimeType};base64,${buffer.toString("base64")}`;
}

// imageFiles: [{ buffer: Buffer, mimeType: string }]
export async function extractTextFromImages(imageFiles) {
  const content = [
    {
      type: "text",
      text:
        imageFiles.length > 1
          ? `Quyidagi ${imageFiles.length} ta rasmdagi (varoqlar ketma-ket) qo'lyozma matnni transkripsiya qiling.`
          : "Quyidagi rasmdagi qo'lyozma matnni transkripsiya qiling.",
    },
    ...imageFiles.map((file) => ({
      type: "image_url",
      image_url: {
        url: bufferToDataUrl(file.buffer, file.mimeType),
        detail: "high",
      },
    })),
  ];

  const completion = await openai.chat.completions.create({
    // Model va reasoning_effort .env orqali (funksiyaga xos) tanlanadi.
    ...modelParams("ocr"),
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content },
    ],
  });

  const choice = completion.choices[0];
  const message = choice?.message;

  if (message?.refusal) {
    throw new Error(`Model rasmni o'qishdan bosh tortdi: ${message.refusal}`);
  }

  // Ko'p varoqli qalin qo'lyozma javobni token chegarasidan oshirishi mumkin.
  if (choice?.finish_reason === "length") {
    throw new Error(
      "Matn juda uzun - varoqlar sonini kamaytirib qayta urinib ko'ring",
    );
  }

  const text = message?.content?.trim();
  if (!text) {
    throw new Error("GPT bo'sh javob qaytardi");
  }

  return text;
}
