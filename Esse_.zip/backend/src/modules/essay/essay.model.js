import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";
import { User } from "../user/user.model.js";

export const Essay = sequelize.define(
  "Essay",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    topic: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    sourceType: {
      type: DataTypes.ENUM("text", "pdf"),
      allowNull: false,
    },
    rawText: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    filePath: {
      type: DataTypes.STRING,
      allowNull: true, // faqat sourceType: 'pdf' bo'lganda to'ladi
    },
    wordCount: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    language: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("pending", "checked", "rejected"),
      allowNull: false,
      defaultValue: "pending",
    },
    // Rasm/OCR orqali yuborilgan esse uchun tekshiruv to'lovi OLDINDAN
    // (OCR bosqichida, balansdan) olingan bo'ladi - shunda baholashda
    // qayta pul/kredit olinmaydi.
    prepaidCheck: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    // OCR kvitansiyasining bir martalik identifikatori. UNIQUE - shu bilan
    // bitta kvitansiya bilan bir nechta bepul tekshiruv olib bo'lmaydi.
    ocrReceiptId: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
    },
  },
  {
    tableName: "essays",
    timestamps: true,
  },
);

Essay.belongsTo(User, { foreignKey: "userId", as: "user" });
User.hasMany(Essay, { foreignKey: "userId", as: "essays" });
