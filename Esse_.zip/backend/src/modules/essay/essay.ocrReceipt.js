import crypto from "crypto";
import { env } from "../../core/env.js";

// OCR (rasm->matn) to'lovi OLDINDAN olingani haqidagi "kvitansiya". U HMAC bilan
// imzolanadi - shuning uchun uni soxtalashtirib bo'lmaydi. Bu kvitansiya keyin
// esse yaratishda tekshiriladi va esse "prepaidCheck" deb belgilanadi (baholashda
// qayta pul olinmaydi). ocrReceiptId ustuni UNIQUE bo'lgani uchun bitta
// kvitansiya faqat BIR marta ishlatiladi.

const MAX_AGE_MS = 30 * 60 * 1000; // 30 daqiqa - OCR va tasdiqlash orasidagi vaqt

function sign(payloadB64) {
  return crypto
    .createHmac("sha256", env.ocrReceiptSecret)
    .update(payloadB64)
    .digest("hex");
}

export function signOcrReceipt({ userId, pages }) {
  const payload = {
    receiptId: crypto.randomUUID(),
    userId,
    pages,
    ts: Date.now(),
  };
  const payloadB64 = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${payloadB64}.${sign(payloadB64)}`;
}

// Kvitansiyani tekshiradi. Yaroqli bo'lsa { valid:true, receiptId, pages },
// aks holda { valid:false } qaytaradi. userId mos kelishi shart.
export function verifyOcrReceipt(receipt, userId) {
  if (typeof receipt !== "string" || !receipt.includes(".")) {
    return { valid: false };
  }
  const [payloadB64, signature] = receipt.split(".");
  const expected = sign(payloadB64);

  // Timing-safe taqqoslash.
  const sigBuf = Buffer.from(signature || "", "hex");
  const expBuf = Buffer.from(expected, "hex");
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return { valid: false };
  }

  let payload;
  try {
    payload = JSON.parse(Buffer.from(payloadB64, "base64url").toString("utf8"));
  } catch {
    return { valid: false };
  }

  if (Number(payload.userId) !== Number(userId)) return { valid: false };
  if (Date.now() - payload.ts > MAX_AGE_MS) return { valid: false };

  return { valid: true, receiptId: payload.receiptId, pages: payload.pages };
}
