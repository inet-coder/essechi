import fs from "fs/promises";
import { Essay } from "./essay.model.js";
import { verifyOcrReceipt } from "./essay.ocrReceipt.js";
import {
  extractTextFromPdf,
  countWords,
  detectScript,
} from "./essay.extractor.js";
import { env } from "../../core/env.js";
import { httpError } from "../../core/httpError.js";

// Mavzu (topshiriq matni) ham modelga yuboriladi - haddan tashqari uzun
// bo'lmasligini ta'minlaymiz (bexuda token va suiiste'moldan himoya).
const MAX_TOPIC_CHARS = 2000;

// Esse matni va mavzuni uzunlik bo'yicha tekshiradi. Juda uzun bo'lsa, model
// javobi token chegarasiga urilib "texnik xatolik" berardi - buni oldindan,
// tushunarli xabar bilan to'xtatamiz (foydalanuvchi matnni qisqartiradi).
function assertWithinLimits(topic, text) {
  if (typeof topic === "string" && topic.length > MAX_TOPIC_CHARS) {
    throw httpError(
      400,
      `Mavzu matni juda uzun (${MAX_TOPIC_CHARS} belgidan oshmasligi kerak).`,
    );
  }
  if (typeof text === "string" && text.length > env.essayMaxChars) {
    throw httpError(
      400,
      `Esse matni juda uzun (${env.essayMaxChars} belgidan oshmasligi kerak). ` +
        "Iltimos, matnni qisqartirib qayta yuboring.",
    );
  }
}

export async function createEssayFromText({ userId, topic, text, ocrReceipt }) {
  assertWithinLimits(topic, text);
  const wordCount = countWords(text);
  const language = detectScript(text);

  // Rasm/OCR orqali kelgan matn bo'lsa - to'lov allaqachon OCR bosqichida
  // olingan. Yaroqli kvitansiya bo'lsa esse "prepaidCheck" deb belgilanadi
  // (baholashda qayta pul/kredit olinmaydi). ocrReceiptId UNIQUE bo'lgani
  // uchun kvitansiyani qayta ishlatib bo'lmaydi.
  let prepaidCheck = false;
  let ocrReceiptId = null;
  if (ocrReceipt) {
    const verified = verifyOcrReceipt(ocrReceipt, userId);
    if (verified.valid) {
      prepaidCheck = true;
      ocrReceiptId = verified.receiptId;
    }
  }

  return Essay.create({
    userId,
    topic,
    sourceType: "text",
    rawText: text,
    wordCount,
    language,
    prepaidCheck,
    ocrReceiptId,
  });
}

export async function createEssayFromPdf({ userId, topic, filePath }) {
  const fileBuffer = await fs.readFile(filePath);
  const text = await extractTextFromPdf(fileBuffer);
  assertWithinLimits(topic, text);
  const wordCount = countWords(text);
  const language = detectScript(text);

  return Essay.create({
    userId,
    topic,
    sourceType: "pdf",
    rawText: text,
    filePath,
    wordCount,
    language,
  });
}

export async function getEssayById(id) {
  return Essay.findByPk(id);
}
