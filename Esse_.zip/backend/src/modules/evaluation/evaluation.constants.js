// To'lov tizimi ulanmaguncha shu son bilan ishlaymiz.
// Payment moduli qo'shilganda bu yerga shartli logika (masalan balansga
// qarab limitni oshirish) kiritiladi.
export const FREE_ATTEMPTS_LIMIT = 3;
