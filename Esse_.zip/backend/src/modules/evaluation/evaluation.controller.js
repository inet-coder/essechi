import { requestEvaluation, getUserHistory } from "./evaluation.service.js";
import { EvaluationResult } from "./evaluation.model.js";
import { getUserByTelegramId } from "../user/user.service.js";

export async function submitEvaluation(req, res, next) {
  try {
    const { essayId } = req.body;

    if (!essayId) {
      return res.status(400).json({ error: "essayId majburiy" });
    }

    // Asinxron: agar natija allaqachon tayyor bo'lsa - darhol qaytaramiz;
    // aks holda fon rejimida baholab, 202 "processing" qaytaramiz. Bot keyin
    // GET /by-essay/:essayId orqali natijани navbat bilan so'raydi.
    const outcome = await requestEvaluation(essayId);
    if (outcome.status === "done") {
      return res.status(200).json(outcome.result);
    }
    return res.status(202).json({ essayId, status: "processing" });
  } catch (error) {
    next(error);
  }
}

// Polling endpointi: natija tayyor bo'lsa 200 + natija, aks holda 202
// "processing" qaytaradi. Har chaqiruv qisqa - tunnel timeout'iga tushmaydi.
export async function getResultByEssay(req, res, next) {
  try {
    const { essayId } = req.params;
    const result = await EvaluationResult.findOne({ where: { essayId } });

    if (!result) {
      return res.status(202).json({ essayId, status: "processing" });
    }

    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
}

export async function getHistory(req, res, next) {
  try {
    const { telegramId } = req.params;
    const user = await getUserByTelegramId(telegramId);

    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const essays = await getUserHistory(user.id);
    res.status(200).json(essays);
  } catch (error) {
    next(error);
  }
}
export async function getEvaluation(req, res, next) {
  try {
    const { id } = req.params;
    const result = await EvaluationResult.findByPk(id);

    if (!result) {
      return res.status(404).json({ error: "Natija topilmadi" });
    }

    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
}
