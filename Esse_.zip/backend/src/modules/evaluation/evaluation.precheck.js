// Bu yerda faqat KOD orqali aniqlanadigan, lingvistik tushunish talab qilmaydigan
// holatlar tekshiriladi. Mavzuga moslik, ko'chirilganlik va "faqat kirish qismi"
// holatlari GPT bosqichida tekshiriladi (semantik tushunish kerak).
export function runPrecheck({ rawText, wordCount, language }) {
  const trimmed = rawText.trim();

  if (trimmed.length === 0) {
    return { passed: false, totalScore: 0, rejectionReason: "Esse yozilmagan" };
  }

  if (language === "kirill") {
    return {
      passed: false,
      totalScore: 0,
      rejectionReason: "Esse matni to'liq kirill alifbosida yozilgan",
    };
  }

  if (wordCount < 100) {
    return {
      passed: false,
      totalScore: 2,
      rejectionReason: "Esse hajmi 100 ta so'zdan kam",
    };
  }

  return { passed: true };
}
