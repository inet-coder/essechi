import { Router } from "express";
import {
  submitEvaluation,
  getResultByEssay,
  getEvaluation,
  getHistory,
} from "./evaluation.controller.js";
import { requireAdmin } from "../../middleware/requireAdmin.js";

const router = Router();

// Bu endpointlar FAQAT bot (server) tomonidan chaqiriladi va telegramId'ni
// so'rov tanasidan/parametridan oladi (initData yo'q). Shuning uchun admin
// kaliti bilan yopamiz - aks holda begona odam boshqa foydalanuvchining esse
// tarixini/natijasini o'qishi yoki uning nomidan baholashni (pulini sarflab)
// ishga tushirishi mumkin edi. Mini-app esa initData bilan himoyalangan
// ALOHIDA /api/me/essays/* endpointlaridan foydalanadi.
router.use(requireAdmin);

router.post("/", submitEvaluation);
router.get("/history/:telegramId", getHistory);
// Diqqat: bu /:id dan OLDIN turishi shart, aks holda "by-essay" id deb qabul
// qilinadi.
router.get("/by-essay/:essayId", getResultByEssay);
router.get("/:id", getEvaluation);

export default router;
