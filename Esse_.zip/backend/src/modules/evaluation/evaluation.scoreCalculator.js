const VALID_SCORES = new Set([2, 1.5, 1, 0.5, 0]);

// Validlik bandlaridan kelib chiqib auto-reject holatini aniqlaydi.
// has_only_introduction eng og'ir holat sifatida ustun turadi (0 ball),
// undan keyin mavzuga mos emaslik/ko'chirilganlik tekshiriladi (2 ball).
export function resolveAutoReject(validity) {
  if (validity.has_only_introduction) {
    return {
      totalScore: 0,
      rejectionReason: "Faqat kirish qismi yozilgan (topshiriq bajarilmagan)",
    };
  }

  if (!validity.is_topic_relevant) {
    return { totalScore: 2, rejectionReason: "Esse mavzuga mos emas" };
  }

  if (validity.is_plagiarized) {
    return {
      totalScore: 2,
      rejectionReason: "Esse boshqa manbadan ko'chirilgan",
    };
  }

  return null;
}

// GPT qaytargan bands massivini tekshiradi: aynan 12 ta, band raqamlari
// 1..12 takrorlanmagan holda, har bir ball ruxsat etilgan 5 qiymatdan biri.
// Schema (strict mode) buni allaqachon kafolatlashi kerak, lekin milliy
// sertifikat tizimi uchun ikkinchi marta kod darajasida ham tasdiqlaymiz.
export function validateBands(bands) {
  if (!Array.isArray(bands) || bands.length !== 12) {
    throw new Error(
      `GPT 12 ta band qaytarishi kerak, ${bands?.length ?? 0} ta qaytardi`,
    );
  }

  const seenBands = new Set();

  for (const band of bands) {
    if (seenBands.has(band.band)) {
      throw new Error(`Band ${band.band} GPT javobida takrorlandi`);
    }
    seenBands.add(band.band);

    if (!VALID_SCORES.has(band.score)) {
      throw new Error(
        `Band ${band.band} uchun noto'g'ri ball qiymati: ${band.score}`,
      );
    }
  }

  for (let i = 1; i <= 12; i += 1) {
    if (!seenBands.has(i)) {
      throw new Error(`Band ${i} GPT javobida yo'q`);
    }
  }
}

export function calculateTotalScore(bands) {
  return bands.reduce((sum, band) => sum + band.score, 0);
}

// Milliy sertifikat tizimida yozma ish (esse) 24 balllik mezondan 75 ballik
// standart shkalaga Rasch modeli asosidagi rasmiy jadval orqali aylantiriladi.
// Jadval 0.5 balllik qadamlarda (0.5->28 dan 24->75 gacha) qatiy chiziqli
// (har 0.5 ball uchun +1) ko'tariladi, shuning uchun formula bilan ifodalanadi:
//   75-ballik = (24-ballik ball x 2) + 27
//
// 0 ball ALOHIDA holat: rasmiy jadvalda 0 ko'rsatilmagan, chunki bu "past
// ball" emas, "topshiriq bajarilmagan" (tekshirilmagan) degani - shuning
// uchun formula qo'llanmaydi, to'g'ridan-to'g'ri 0 qaytariladi.
//
// MUHIM CHEKLOV: bu yerda faqat ESSE (yozma ish, ikkinchi bo'lim)ning o'z
// ekvivalenti hisoblanadi. Rasmiy yakuniy sertifikat balli test qismi
// (birinchi bo'lim, bizning tizimdan tashqarida) bilan birgalikda o'rtacha
// arifmetik sifatida hisoblanadi - buni biz hisoblay olmaymiz, chunki test
// qismi natijasi bizda yo'q.
export function convertToStandardScale(totalScore) {
  if (totalScore === 0) return 0;
  return Math.round(totalScore * 2 + 27);
}
