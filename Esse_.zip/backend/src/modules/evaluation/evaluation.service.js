import { Essay } from "../essay/essay.model.js";
import { EvaluationResult } from "./evaluation.model.js";
import { User } from "../user/user.model.js";
import { runPrecheck } from "./evaluation.precheck.js";
import { evaluateWithGpt } from "./evaluation.gpt.js";
import {
  resolveAutoReject,
  validateBands,
  calculateTotalScore,
} from "./evaluation.scoreCalculator.js";
import { getEssayById } from "../essay/essay.service.js";
import {
  getUserById,
  incrementAttemptsUsed,
  claimFreeEssay,
  releaseFreeEssay,
  deductBalanceIfEnough,
  addBalance,
} from "../user/user.service.js";
import {
  consumeEssayCredit,
  refundEssayCredit,
} from "../credit/credit.service.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

// Kredit tugaganda / balans yetmaganda ko'rsatiladigan xabar.
const NO_CREDIT_MESSAGE =
  "Bepul tekshiruvingiz ishlatilgan. Davom etish uchun esse paketi sotib " +
  "oling (botdagi \"💰 Balansni to'ldirish\" → \"📦 Esse paketlari\") yoki " +
  `balansingizda kamida ${env.essaySingleCheckPrice} so'm bo'lsin (paketsiz ` +
  "bir tekshiruv shu narxda).";

// Foydalanuvchi uchun tushunarli, ichki tafsilotni oshkor qilmaydigan xato.
const TECH_FAILURE_MESSAGE =
  "Texnik nosozlik yuz berdi. Bu tekshiruv uchun hisobingizdan hech narsa " +
  "yechilmadi. Iltimos, birozdan so'ng qayta urinib ko'ring.";

// Esse tekshiruvi uchun to'lovni OLDINDAN, atomik band qiladi. Tartib:
//   1) bir martalik bepul (agar ishlatilmagan bo'lsa)
//   2) faol paket krediti (30 kunlik, muddati o'tmagan)
//   3) balansdan bir martalik narx (env.essaySingleCheckPrice)
// prepaidCheck=true bo'lsa (rasm/OCR orqali oldindan to'langan) - hech narsa
// olinmaydi. Band qilingan "rezervatsiya"ni qaytaradi (keyin sarflanadi yoki
// texnik xato/dublikatда ortga qaytariladi).
async function reserveCheckCharge(essay, user) {
  if (essay.prepaidCheck) {
    return { mode: "prepaid" };
  }
  if (await claimFreeEssay(user.id)) {
    return { mode: "free" };
  }
  const credit = await consumeEssayCredit(user.id);
  if (credit.ok) {
    return { mode: "credit", grantId: credit.grantId };
  }
  if (await deductBalanceIfEnough(user.id, env.essaySingleCheckPrice)) {
    return { mode: "balance" };
  }
  return null; // to'lov manbai yo'q
}

// Band qilingan to'lovni ortga qaytaradi (texnik xato yoki dublikat natijada).
async function releaseCheckCharge(user, reservation) {
  if (!reservation) return;
  if (reservation.mode === "free") await releaseFreeEssay(user.id);
  else if (reservation.mode === "credit") await refundEssayCredit(reservation.grantId);
  else if (reservation.mode === "balance")
    await addBalance(user.id, env.essaySingleCheckPrice);
}

// Modelning ishonch foizini xavfsiz 0-100 oralig'iga keltiradi. Yaroqsiz
// (yo'q/son emas) bo'lsa null qaytaradi - natija baribir saqlanadi.
function clampConfidence(value) {
  if (typeof value !== "number" || Number.isNaN(value)) return null;
  return Math.max(0, Math.min(100, Math.round(value)));
}

// DB darajasidagi unique constraint orqali himoyalangan saqlash.
// Agar parallel so'rov sababli bu essayId uchun natija allaqachon yozilgan
// bo'lsa (race condition), xato tashlamasdan mavjud natijani qaytaradi va
// buni "yangi yaratilmadi" deb belgilaydi - shu orqali chaqiruvchi tomon
// ikkinchi marta urinish/balansni hisobga olmaydi.
async function saveResult({
  essayId,
  status,
  totalScore,
  bandResults = [],
  recommendations = [],
  rejectionReason = null,
  confidence = null,
}) {
  try {
    const created = await EvaluationResult.create({
      essayId,
      status,
      totalScore,
      bandResults,
      recommendations,
      rejectionReason,
      confidence,
    });
    return { result: created, isNew: true };
  } catch (error) {
    if (error.name === "SequelizeUniqueConstraintError") {
      const existing = await EvaluationResult.findOne({ where: { essayId } });
      return { result: existing, isNew: false };
    }
    throw error;
  }
}

// Bir nechta GPT o'tishidan "vakil" (median) natijani tanlaydi - Frankenstein
// o'rtacha ball chiqarmasdan, aynan bitta haqiqiy, izchil javobni oladi
// (shuning uchun bandlar validatsiyadan o'tadi va izoh/ballar bir-biriga mos).
//   1) auto-reject ovozi: o'tishlarning ko'pchiligi essени rad etsa - rad.
//      Juft sonli o'tishda durang bo'lsa RAD ETILMAYDI (pullik ishtirokka
//      shubha foydasiga hukm - noto'g'ri rad qilmaslik uchun).
//   2) qolgan (baholangan) o'tishlar orasidan umumiy ball bo'yicha median
//      o'tish tanlanadi.
function aggregatePasses(responses) {
  const rejects = responses
    .map((r) => resolveAutoReject(r.validity))
    .filter(Boolean);

  if (rejects.length > responses.length / 2) {
    return { autoReject: rejects[0] };
  }

  const scored = responses
    .filter((r) => !resolveAutoReject(r.validity))
    .map((r) => ({ response: r, total: calculateTotalScore(r.bands) }))
    .sort((a, b) => a.total - b.total);

  const mid = scored[Math.floor((scored.length - 1) / 2)];

  // Ishonch: bitta o'tishda - modelning o'z-o'zini baholashi. Ko'p o'tishda
  // (musobaqa) - o'tishlar bir-biriga qanchalik mos kelgani ham signal:
  // ballar keng tarqalgan bo'lsa (o'tishlar kelishmasa), self-report ishonchni
  // shu kelishmovchilik darajasida cheklaymiz - shunda ishonch foizi
  // haqqoniyroq bo'ladi.
  let confidence = clampConfidence(mid.response.confidence);
  if (scored.length > 1 && confidence !== null) {
    const spread = scored[scored.length - 1].total - scored[0].total; // xom ball
    const agreementCap = Math.max(0, 100 - Math.round(spread * 8));
    confidence = Math.min(confidence, agreementCap);
  }

  return { scored: mid.response, totalScore: mid.total, confidence };
}

// Baholashning "yadrosi": precheck -> GPT (passes marta, median) -> natijani
// saqlaydi. Balans/urinish hisob-kitobiga TEGMAYDI - shuning uchun ham oddiy
// foydalanuvchi oqimi (evaluateEssay), ham musobaqa partiyasi shuni ishlatadi.
// passes > 1 bo'lsa self-consistency (median) qo'llanadi - musobaqada shovqinni
// yo'qotib, adolatli ball beradi.
export async function evaluateEssayCore(essay, { passes = 1 } = {}) {
  const existing = await EvaluationResult.findOne({
    where: { essayId: essay.id },
  });
  if (existing) return { result: existing, isNew: false };

  // 1-bosqich: lokal precheck (GPTsiz)
  const precheckResult = runPrecheck({
    rawText: essay.rawText,
    wordCount: essay.wordCount,
    language: essay.language,
  });

  if (!precheckResult.passed) {
    return saveResult({
      essayId: essay.id,
      status: "auto_rejected",
      totalScore: precheckResult.totalScore,
      rejectionReason: precheckResult.rejectionReason,
    });
  }

  // 2-bosqich: GPT chaqiruvi passes marta. Struktura talabiga mos kelmagan yoki
  // xato bergan o'tish tashlab yuboriladi; birortasi ham o'tmasa - failed
  // (texnik xatolik, balans/urinish sarflanmaydi).
  const responses = [];
  let lastError = null;
  for (let i = 0; i < passes; i += 1) {
    try {
      const response = await evaluateWithGpt({
        topic: essay.topic,
        essayText: essay.rawText,
      });
      if (!resolveAutoReject(response.validity)) {
        validateBands(response.bands);
      }
      responses.push(response);
    } catch (error) {
      lastError = error;
    }
  }

  if (responses.length === 0) {
    // Ichki (model) xatosi FAQAT logga yoziladi - foydalanuvchiga hech qachon
    // texnik tafsilot (model nomi, token chegarasi va h.k.) ko'rsatilmaydi.
    console.error(
      `Baholash muvaffaqiyatsiz (essayId=${essay.id}):`,
      lastError?.message,
    );
    return saveResult({
      essayId: essay.id,
      status: "failed",
      totalScore: 0,
      // Foydalanuvchiga ko'rinadigan umumiy, xavfsiz xabar.
      rejectionReason:
        "Texnik nosozlik yuz berdi. Hisobingizdan hech narsa yechilmadi.",
    });
  }

  const agg = aggregatePasses(responses);

  if (agg.autoReject) {
    return saveResult({
      essayId: essay.id,
      status: "auto_rejected",
      totalScore: agg.autoReject.totalScore,
      rejectionReason: agg.autoReject.rejectionReason,
    });
  }

  return saveResult({
    essayId: essay.id,
    status: "completed",
    totalScore: agg.totalScore,
    bandResults: agg.scored.bands,
    recommendations: agg.scored.recommendations,
    confidence: agg.confidence,
  });
}

export async function evaluateEssay(essayId) {
  // Tezkor tekshiruv: natija allaqachon mavjud bo'lsa (ikki marta bosildi yoki
  // so'rov qayta yuborildi), GPT chaqirmasdan, urinish sarflamasdan qaytaramiz.
  const existingResult = await EvaluationResult.findOne({ where: { essayId } });
  if (existingResult) {
    return existingResult;
  }

  const essay = await getEssayById(essayId);
  if (!essay) {
    throw httpError(404, "Esse topilmadi");
  }

  const user = await getUserById(essay.userId);
  if (!user) {
    throw httpError(404, "Foydalanuvchi topilmadi");
  }

  // To'lovni OLDINDAN, atomik band qilamiz (parallel so'rovlar bir manbani
  // ikki marta sarflab yubormasligi uchun).
  const reservation = await reserveCheckCharge(essay, user);
  if (!reservation) {
    throw httpError(402, NO_CREDIT_MESSAGE);
  }

  let result;
  let isNew;
  try {
    ({ result, isNew } = await evaluateEssayCore(essay, { passes: 1 }));
  } catch (error) {
    // Kutilmagan (masalan GPT) xato - band qilingan to'lovni qaytaramiz va
    // foydalanuvchiga umumiy "texnik nosozlik" xabarini beramiz.
    console.error(`Baholash xatosi (essayId=${essay.id}):`, error);
    await releaseCheckCharge(user, reservation);
    throw httpError(502, TECH_FAILURE_MESSAGE);
  }

  // To'lov faqat YANGI va texnik xato bo'lmagan natijada sarflanadi:
  //   - dublikat natija (isNew=false) -> qaytariladi
  //   - "failed" (texnik xato) -> qaytariladi
  //   - "completed"/"auto_rejected" -> sarflandi (haqiqiy tekshiruv bo'ldi)
  if (!isNew || result.status === "failed") {
    await releaseCheckCharge(user, reservation);
  } else {
    await incrementAttemptsUsed(user.id);
  }

  return result;
}

// ===========================================================================
// ASINXRON baholash (bot oqimi uchun).
//
// Muammo: sinxron baholashda HTTP so'rov GPT tugaguncha ochiq turadi. Oldindagi
// tunnel (cloudflared) 100 soniyada javob kelmasa 524 HTML qaytaradi -> bot uni
// JSON deb o'qiy olmay "Server javob bermadi" xatosini chiqaradi.
//
// Yechim: so'rov tez validatsiya qilib, GPT ishini FON rejimiga o'tkazadi va
// DARHOL qaytadi (202). Bot natijani GET /by-essay/:essayId orqali navbat bilan
// (poll) so'rab oladi. Har bir so'rov qisqa - 100s limitiga umuman yaqinlashmaydi.
// ===========================================================================
export async function requestEvaluation(essayId) {
  const existingResult = await EvaluationResult.findOne({ where: { essayId } });
  if (existingResult) return { status: "done", result: existingResult };

  const essay = await getEssayById(essayId);
  if (!essay) throw httpError(404, "Esse topilmadi");

  const user = await getUserById(essay.userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  // To'lovni fon ishidan OLDIN, atomik band qilamiz - manba yo'q bo'lsa
  // foydalanuvchi darhol 402 oladi va bekorга GPT chaqirilmaydi.
  const reservation = await reserveCheckCharge(essay, user);
  if (!reservation) throw httpError(402, NO_CREDIT_MESSAGE);

  // Fon rejimida (javob qaytgach) baholanadi - HTTP so'rov shu yerda tugaydi.
  runEvaluationInBackground(essay, user, reservation);
  return { status: "processing" };
}

// Fire-and-forget: baholash yadrosi + hisob-kitob. Javob allaqachon qaytarilgan,
// bu event loop'da mustaqil davom etadi. Kutilmagan xato bo'lsa ham natija
// "failed" deb yoziladi - shunda bot polling cheksiz osilib qolmaydi.
function runEvaluationInBackground(essay, user, reservation) {
  void (async () => {
    try {
      const { result, isNew } = await evaluateEssayCore(essay, { passes: 1 });
      // To'lov faqat YANGI va texnik xato bo'lmagan natijada sarflanadi;
      // aks holda qaytariladi.
      if (!isNew || result.status === "failed") {
        await releaseCheckCharge(user, reservation);
      } else {
        await incrementAttemptsUsed(user.id);
      }
    } catch (error) {
      console.error(`Fon baholash xatosi (essayId=${essay.id}):`, error);
      // Band qilingan to'lovni qaytaramiz - texnik xato uchun pul olinmaydi.
      await releaseCheckCharge(user, reservation);
      try {
        await EvaluationResult.create({
          essayId: essay.id,
          status: "failed",
          totalScore: 0,
          // Foydalanuvchiga ko'rinadigan umumiy xabar - ichki xato oshkor
          // qilinmaydi (asl xato yuqorida log qilindi).
          rejectionReason:
            "Texnik nosozlik yuz berdi. Hisobingizdan hech narsa yechilmadi.",
        });
      } catch (saveError) {
        // Ehtimol natija allaqachon yozilgan (unique constraint) - e'tiborsiz.
        if (saveError?.name !== "SequelizeUniqueConstraintError") {
          console.error("Failed-natijani saqlashda xatolik:", saveError);
        }
      }
    }
  })();
}

// Bot/Web app uchun: foydalanuvchining barcha esselarini, har biriga tegishli
// baholash natijasi (mavjud bo'lsa) bilan birga qaytaradi.
export async function getUserHistory(userId) {
  return Essay.findAll({
    where: { userId },
    include: [{ model: EvaluationResult, as: "evaluationResult" }],
    order: [["createdAt", "DESC"]],
  });
}

// Reytingdagi esseni boshqa foydalanuvchilar ochib ko'rishi uchun ommaviy
// ko'rinish. Faqat TO'LIQ tekshirilgan (completed) esselar qaytariladi -
// shu bilan hali baholanmagan yoki rad etilgan shaxsiy esselar oshkor
// bo'lib qolmaydi. Muallif ismi ham qo'shiladi (kim yozganini ko'rsatish uchun).
export async function getPublicEssayView(essayId) {
  const essay = await Essay.findByPk(essayId, {
    include: [
      { model: EvaluationResult, as: "evaluationResult" },
      { model: User, as: "user", attributes: ["firstName"] },
    ],
  });

  if (!essay) return null;
  if (!essay.evaluationResult || essay.evaluationResult.status !== "completed") {
    return null;
  }

  const json = essay.toJSON();
  return {
    id: json.id,
    topic: json.topic,
    sourceType: json.sourceType,
    rawText: json.rawText,
    wordCount: json.wordCount,
    language: json.language,
    createdAt: json.createdAt,
    evaluationResult: json.evaluationResult,
    authorName: json.user?.firstName || "Noma'lum",
  };
}
