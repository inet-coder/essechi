import {
  logFeedback,
  getUserFeedbackHistory,
} from "./feedback.service.js";

// Bot (server) chaqiradi: har bir yozishma xabarini saqlaydi.
export async function createFeedback(req, res, next) {
  try {
    const { telegramId, direction, message } = req.body;

    if (!telegramId || !direction || !message) {
      return res
        .status(400)
        .json({ error: "telegramId, direction va message majburiy" });
    }
    if (!["incoming", "outgoing"].includes(direction)) {
      return res
        .status(400)
        .json({ error: "direction 'incoming' yoki 'outgoing' bo'lishi kerak" });
    }

    const record = await logFeedback({ telegramId, direction, message });
    res.status(201).json(record);
  } catch (error) {
    next(error);
  }
}

export async function getFeedbackHistory(req, res, next) {
  try {
    const { telegramId } = req.params;
    const items = await getUserFeedbackHistory(telegramId);
    res.status(200).json(items);
  } catch (error) {
    next(error);
  }
}
