import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";
import { User } from "../user/user.model.js";

// Foydalanuvchi va admin o'rtasidagi savol/taklif yozishmasi. Har bir xabar
// (ikkala yo'nalishda ham) tarix/audit uchun saqlanadi. Yozishma "threading"i
// botda inline tugmalar orqali boshqariladi - bu jadval faqat tarix uchun.
export const Feedback = sequelize.define(
  "Feedback",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    // Yozishmadagi FOYDALANUVCHI (admin bo'lmagan tomon).
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    // "incoming" - foydalanuvchidan adminga; "outgoing" - admindan foydalanuvchiga.
    direction: {
      type: DataTypes.ENUM("incoming", "outgoing"),
      allowNull: false,
    },
    message: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    tableName: "feedbacks",
    timestamps: true,
  },
);

Feedback.belongsTo(User, { foreignKey: "userId", as: "user" });
