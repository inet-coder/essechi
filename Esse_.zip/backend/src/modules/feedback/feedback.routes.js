import { Router } from "express";
import {
  createFeedback,
  getFeedbackHistory,
} from "./feedback.controller.js";
import { requireAdmin } from "../../middleware/requireAdmin.js";

const router = Router();

// Faqat bot (server) chaqiradi - admin kaliti bilan yopiladi.
router.post("/", requireAdmin, createFeedback);
router.get("/user/:telegramId", requireAdmin, getFeedbackHistory);

export default router;
