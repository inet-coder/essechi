import { httpError } from "../../core/httpError.js";
import { Feedback } from "./feedback.model.js";
import { User } from "../user/user.model.js";

// Yozishma xabarini saqlaydi (tarix uchun). telegramId bo'yicha foydalanuvchini
// topadi.
export async function logFeedback({ telegramId, direction, message }) {
  const user = await User.findOne({ where: { telegramId } });
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const text = String(message ?? "").trim();
  if (!text) throw httpError(400, "message bo'sh bo'lmasligi kerak");

  return Feedback.create({
    userId: user.id,
    direction,
    message: text,
  });
}

// Admin panel/veb uchun: bitta foydalanuvchining yozishma tarixi.
export async function getUserFeedbackHistory(telegramId) {
  const user = await User.findOne({ where: { telegramId } });
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");
  return Feedback.findAll({
    where: { userId: user.id },
    order: [["createdAt", "ASC"]],
  });
}
