import { getLeaderboard } from "./leaderboard.service.js";

const VALID_PERIODS = new Set(["daily", "weekly", "monthly"]);
const VALID_METRICS = new Set(["score", "count"]);

export async function getLeaderboardHandler(req, res, next) {
  try {
    const { period } = req.query;
    // Tartiblash ko'rsatkichi: "score" (eng yuqori ball) yoki "count" (esselar
    // soni). Berilmasa - "score".
    const metric = req.query.metric ?? "score";

    if (!VALID_PERIODS.has(period)) {
      return res.status(400).json({
        error: "period 'daily', 'weekly' yoki 'monthly' bo'lishi kerak",
      });
    }
    if (!VALID_METRICS.has(metric)) {
      return res.status(400).json({
        error: "metric 'score' yoki 'count' bo'lishi kerak",
      });
    }

    const leaderboard = await getLeaderboard(period, metric);
    res.status(200).json({ period, metric, leaderboard });
  } catch (error) {
    next(error);
  }
}
