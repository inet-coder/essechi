import { Op } from "sequelize";
import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { Essay } from "../essay/essay.model.js";
import { User } from "../user/user.model.js";

const PERIOD_DAYS = {
  daily: 1,
  weekly: 7,
  monthly: 30,
};

const TOP_LIMIT = 20;

function getPeriodStartDate(period) {
  const days = PERIOD_DAYS[period];
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date;
}

// Berilgan davr (kunlik/haftalik/oylik) ichida yaratilgan, to'liq tekshirilgan
// (completed) esselar bo'yicha reyting. Ikki xil tartiblash mavjud:
//   metric = "score" - har foydalanuvchining ENG YUQORI natijasi bo'yicha
//   metric = "count" - tekshirilgan esselar SONI bo'yicha
// Har bir yozuv ikkala ko'rsatkichni ham (scaledScore va essayCount) olib
// yuradi, shuning uchun foydalanuvchi rejimni almashtirganda ma'lumot to'liq.
export async function getLeaderboard(period, metric = "score") {
  const startDate = getPeriodStartDate(period);

  const results = await EvaluationResult.findAll({
    where: {
      status: "completed",
      createdAt: { [Op.gte]: startDate },
    },
    include: [
      {
        model: Essay,
        as: "essay",
        attributes: ["id", "userId"],
        include: [{ model: User, as: "user", attributes: ["firstName"] }],
      },
    ],
    attributes: ["totalScore", "createdAt"],
  });

  // userId -> { firstName, essayCount, scaledScore(eng yuqori), totalScore,
  //             achievedAt, essayId(eng yuqori natijali esse) }
  const byUser = new Map();

  for (const result of results) {
    const userId = result.essay.userId;
    const firstName = result.essay.user?.firstName || "Noma'lum";
    const scaledScore = result.scaledScore;

    const existing = byUser.get(userId);
    if (!existing) {
      byUser.set(userId, {
        userId,
        firstName,
        essayCount: 1,
        scaledScore,
        totalScore: result.totalScore,
        achievedAt: result.createdAt,
        // Eng yuqori natijani bergan esse - boshqalar tahlilini ochib ko'rishi
        // uchun (ommaviy ko'rinish).
        essayId: result.essay.id,
      });
    } else {
      existing.essayCount += 1;
      if (scaledScore > existing.scaledScore) {
        existing.scaledScore = scaledScore;
        existing.totalScore = result.totalScore;
        existing.achievedAt = result.createdAt;
        existing.essayId = result.essay.id;
      }
    }
  }

  // "count" rejimida teng sonlilar eng yuqori ball bilan ajratiladi;
  // "score" rejimida teng ballar ko'proq esse yozgan bilan ajratiladi.
  const sorter =
    metric === "count"
      ? (a, b) => b.essayCount - a.essayCount || b.scaledScore - a.scaledScore
      : (a, b) => b.scaledScore - a.scaledScore || b.essayCount - a.essayCount;

  return [...byUser.values()]
    .sort(sorter)
    .slice(0, TOP_LIMIT)
    .map((entry, index) => ({ rank: index + 1, ...entry }));
}
