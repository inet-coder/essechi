import { getUserByTelegramId, updateUserName } from "../user/user.service.js";
import { getUserHistory } from "../evaluation/evaluation.service.js";
import { getUserBandStats } from "./me.stats.service.js";
import { getUserSummary } from "./me.summary.service.js";
import { getAvailableCredits } from "../credit/credit.service.js";
import { getFreeEssayLimit } from "../setting/setting.service.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

export async function getMyProfile(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }
    // essayCredits - amaldagi (muddati o'tmagan) paket kreditlari. Balansdan
    // ALOHIDA hisoblanadi va grant jadvalidan olinadi.
    const essayCredits = await getAvailableCredits(user.id);
    // Bepul tekshiruv limiti admin tomonidan belgilanadi; qolgan miqdor
    // limitdan ishlatilganini ayirib topiladi.
    const freeEssayLimit = await getFreeEssayLimit();
    const freeEssayRemaining = Math.max(0, freeEssayLimit - user.freeEssaysUsed);
    res.status(200).json({
      ...user.toJSON(),
      essayCredits,
      freeEssayAvailable: freeEssayRemaining > 0,
      // Qolgan bepul tekshiruvlar soni (mini-app ko'rsatishi uchun).
      freeEssayRemaining,
      // Paketsiz (bir martalik) tekshiruv narxi - paket bo'lmaganda mini-app
      // "balansdan N so'mga tekshirasiz" deb ko'rsatishi uchun.
      singleCheckPrice: env.essaySingleCheckPrice,
      // Rasm (qo'lyozma) orqali tekshirishda har varaq narxi va bir martada
      // yuborish mumkin bo'lgan maksimal varaq soni (mini-app ko'rsatishi uchun).
      imagePagePrice: env.essayImagePagePrice,
      imageMaxPages: env.essayImageMaxPages,
    });
  } catch (error) {
    next(error);
  }
}

// Profil ismini o'zgartirish.
export async function updateMyProfile(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }

    const name =
      typeof req.body?.firstName === "string" ? req.body.firstName.trim() : "";
    if (!name) {
      throw httpError(400, "Ism bo'sh bo'lishi mumkin emas");
    }
    if (name.length > 64) {
      throw httpError(400, "Ism 64 belgidan oshmasligi kerak");
    }

    const updated = await updateUserName(user.id, name);
    res.status(200).json(updated);
  } catch (error) {
    next(error);
  }
}

export async function getMyHistory(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }
    const essays = await getUserHistory(user.id);
    res.status(200).json(essays);
  } catch (error) {
    next(error);
  }
}

export async function getMyStats(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }
    const stats = await getUserBandStats(user.id);
    res.status(200).json(stats);
  } catch (error) {
    next(error);
  }
}

export async function getMySummary(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }
    const summary = await getUserSummary(user.id);
    res.status(200).json(summary);
  } catch (error) {
    next(error);
  }
}
