import {
  getUserByTelegramId,
  deductBalanceIfEnough,
  addBalance,
} from "../user/user.service.js";
import {
  createEssayFromText,
  createEssayFromPdf,
  getEssayById,
} from "../essay/essay.service.js";
import { extractTextFromImages } from "../essay/essay.imageExtractor.js";
import { signOcrReceipt } from "../essay/essay.ocrReceipt.js";
import {
  evaluateEssay,
  getPublicEssayView,
} from "../evaluation/evaluation.service.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

// Bot'dagi /api/essays/* endpointlaridan farqli ravishda, bu yerda
// foydalanuvchi so'rov tanasidan (body) emas, balki tekshirilgan Telegram
// initData'dan (req.telegramUser, requireTelegramAuth middleware'i orqali)
// aniqlanadi - shu orqali kimdir boshqa birovning telegramId'sidan
// foydalanib esse yubora olmaydi.
async function resolveUser(req) {
  const user = await getUserByTelegramId(req.telegramUser.id);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");
  return user;
}

export async function submitMyTextEssay(req, res, next) {
  try {
    const { topic, text, ocrReceipt } = req.body;
    if (!topic || !topic.trim() || !text || !text.trim()) {
      throw httpError(400, "topic va text majburiy");
    }

    const user = await resolveUser(req);
    // ocrReceipt bo'lsa (rasm orqali kelgan, OCR bosqichida oldindan
    // to'langan) - esse "prepaidCheck" bo'lib yaratiladi, baholashda qayta
    // pul/kredit olinmaydi.
    const essay = await createEssayFromText({
      userId: user.id,
      topic: topic.trim(),
      text,
      ocrReceipt,
    });
    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

// Rasm(lar)dan qo'lyozma matnni o'qib beradi. Esse tekshiruvida bu PULLIK -
// har varaq uchun env.essayImagePagePrice so'm balansdan OLDINDAN yechiladi.
// Muvaffaqiyatli o'qilsa imzolangan (HMAC) kvitansiya qaytariladi; foydalanuvchi
// matnni tahrirlab, /essays/text ga shu kvitansiya bilan yuboradi va esse
// "prepaidCheck" bo'ladi (baholashda qayta pul OLINMAYDI). OCR texnik xato
// bersa yoki matn topilmasa - olingan to'lov TO'LIQ qaytariladi.
export async function extractMyImageText(req, res, next) {
  try {
    if (!req.files || req.files.length === 0) {
      throw httpError(400, "Kamida bitta rasm yuborilishi kerak");
    }

    const pages = req.files.length;
    if (pages > env.essayImageMaxPages) {
      throw httpError(
        400,
        `Bir martada eng ko'pi ${env.essayImageMaxPages} ta varaq yuborish mumkin.`,
      );
    }

    const user = await resolveUser(req);
    const cost = pages * env.essayImagePagePrice;

    // To'lov OCR (GPT) chaqiruvidan OLDIN, atomik yechiladi - bexuda token
    // sarflanmaydi va parallel so'rov ikki marta yechmaydi.
    const paid = await deductBalanceIfEnough(user.id, cost);
    if (!paid) {
      throw httpError(
        402,
        `Rasm orqali tekshirishda ${pages} ta varaq × ${env.essayImagePagePrice} = ` +
          `${cost} so'm balansdan oldindan yechiladi. Balansingiz yetarli emas. ` +
          `Botdagi "💰 Balansni to'ldirish" bo'limidan hisobingizni to'ldiring.`,
      );
    }

    const imageFiles = req.files.map((f) => ({
      buffer: f.buffer,
      mimeType: f.mimetype,
    }));

    let text;
    try {
      text = await extractTextFromImages(imageFiles);
    } catch (gptError) {
      console.error("OCR xatosi:", gptError?.status, gptError?.message);
      await addBalance(user.id, cost); // texnik nosozlik - to'lov qaytariladi
      throw httpError(
        502,
        "Rasmni o'qishda texnik nosozlik yuz berdi. Hisobingizdan yechilgan " +
          "mablag' qaytarildi. Iltimos, birozdan so'ng qayta urinib ko'ring.",
      );
    }

    if (/^\s*xatolik/i.test(text)) {
      await addBalance(user.id, cost); // matn topilmadi - to'lov qaytariladi
      throw httpError(
        422,
        "Qo'lyozmani tanib bo'lmadi. Hisobingizdan yechilgan mablag' " +
          "qaytarildi. Iltimos, yorug'roq va aniqroq surat bilan qayta urinib ko'ring.",
      );
    }

    const ocrReceipt = signOcrReceipt({ userId: user.id, pages });
    res.status(200).json({ text, ocrReceipt, pages, charged: cost });
  } catch (error) {
    next(error);
  }
}

export async function submitMyPdfEssay(req, res, next) {
  try {
    const { topic } = req.body;
    if (!topic || !topic.trim()) {
      throw httpError(400, "topic majburiy");
    }
    if (!req.file) {
      throw httpError(400, "PDF fayl yuborilmadi");
    }

    const user = await resolveUser(req);

    let essay;
    try {
      essay = await createEssayFromPdf({
        userId: user.id,
        topic: topic.trim(),
        filePath: req.file.path,
      });
    } catch {
      // pdf-parse buzilgan/himoyalangan PDF'larda xato tashlaydi - foydalanuvchiga
      // ichki stack trace o'rniga tushunarli xabar qaytariladi.
      throw httpError(
        400,
        "PDF faylni o'qib bo'lmadi. Fayl buzilgan, himoyalangan yoki noto'g'ri " +
          "formatda bo'lishi mumkin. Boshqa PDF bilan urinib ko'ring yoki matn " +
          "ko'rinishida yuboring.",
      );
    }

    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

// Reytingdagi (yoki boshqa) esseni ochib, uning tahlilini ko'rish. Egalik
// tekshiruvi YO'Q - bu ataylab ommaviy ko'rinish (leaderboard'dagi esselarni
// hamma ko'ra oladi). Xavfsizlik: faqat to'liq tekshirilgan (completed)
// esselar qaytariladi va so'rov requireTelegramAuth orqali himoyalangan.
export async function viewEssayPublic(req, res, next) {
  try {
    const { essayId } = req.params;
    const essay = await getPublicEssayView(essayId);
    if (!essay) {
      throw httpError(404, "Esse topilmadi yoki hali tekshirilmagan");
    }
    res.status(200).json(essay);
  } catch (error) {
    next(error);
  }
}

export async function evaluateMyEssay(req, res, next) {
  try {
    const { essayId } = req.params;
    const user = await resolveUser(req);
    const essay = await getEssayById(essayId);

    if (!essay) throw httpError(404, "Esse topilmadi");
    // Egalik tekshiruvi - boshqa foydalanuvchining essayId'sini taxmin qilib
    // uning balansi/urinishlarini "yeb qo'yish" imkoniyatini yopadi.
    if (essay.userId !== user.id)
      throw httpError(403, "Bu esse sizga tegishli emas");

    const result = await evaluateEssay(essayId);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
}
