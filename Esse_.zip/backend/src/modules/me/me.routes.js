import { Router } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { requireTelegramAuth } from "../../middleware/telegramAuth.js";
import { env } from "../../core/env.js";
import {
  getMyProfile,
  updateMyProfile,
  getMyHistory,
  getMyStats,
  getMySummary,
} from "./me.controller.js";
import {
  submitMyTextEssay,
  submitMyPdfEssay,
  extractMyImageText,
  evaluateMyEssay,
  viewEssayPublic,
} from "./me.essay.controller.js";
import { getLeaderboardHandler } from "../leaderboard/leaderboard.controller.js";
import {
  getStatus as getAiAnalysisStatus,
  generate as generateAiAnalysis,
  history as aiAnalysisHistory,
  getOne as aiAnalysisGetOne,
} from "../ai-analysis/ai-analysis.controller.js";
import {
  getStatus as getQuizStatus,
  generate as generateQuiz,
  submit as submitQuiz,
  history as quizHistory,
  getOne as quizGetOne,
  retake as retakeQuiz,
  random as randomQuiz,
} from "../quiz/quiz.controller.js";

const uploadsDir = path.join(process.cwd(), "uploads", "essays");
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => cb(null, `${randomUUID()}.pdf`),
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype !== "application/pdf") {
      return cb(new Error("Faqat PDF fayl qabul qilinadi"));
    }
    cb(null, true);
  },
});

// Qo'lyozma rasmlar diskka saqlanmaydi - faqat OCR uchun xotirada saqlanadi.
const MAX_IMAGE_PAGES = env.essayImageMaxPages;
const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: MAX_IMAGE_PAGES }, // 5MB/dona
  fileFilter: (req, file, cb) => {
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.mimetype)) {
      return cb(new Error("Faqat JPEG, PNG yoki WEBP rasm qabul qilinadi"));
    }
    cb(null, true);
  },
});

const router = Router();

router.use(requireTelegramAuth);

router.get("/", getMyProfile);
router.patch("/", updateMyProfile);
router.get("/history", getMyHistory);
router.get("/stats", getMyStats);
router.get("/summary", getMySummary);
router.get("/leaderboard", getLeaderboardHandler);

router.post("/essays/text", submitMyTextEssay);
router.post("/essays/pdf", upload.single("file"), submitMyPdfEssay);
// Rasmdan matn o'qish - esse tekshiruvida PULLIK (har varaq uchun oldindan).
router.post(
  "/essays/extract-image-text",
  imageUpload.array("files", MAX_IMAGE_PAGES),
  extractMyImageText,
);
router.post("/essays/:essayId/evaluate", evaluateMyEssay);
// Reytingdagi esseni ochib ko'rish (ommaviy - egalik talab qilinmaydi).
router.get("/essays/:essayId/view", viewEssayPublic);

router.get("/ai-analysis/status", getAiAnalysisStatus);
router.get("/ai-analysis/history", aiAnalysisHistory);
router.post("/ai-analysis", generateAiAnalysis);
router.get("/ai-analysis/:id", aiAnalysisGetOne);

router.get("/quiz/status", getQuizStatus);
router.get("/quiz/history", quizHistory);
router.post("/quiz/generate", generateQuiz);
// Tasodifiy test - statik yo'l, param yo'llardan oldin.
router.post("/quiz/random", randomQuiz);
router.post("/quiz/:quizId/submit", submitQuiz);
router.post("/quiz/:quizId/retake", retakeQuiz);
router.get("/quiz/:quizId", quizGetOne);

export default router;
