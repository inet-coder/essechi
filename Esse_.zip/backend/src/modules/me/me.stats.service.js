import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { Essay } from "../essay/essay.model.js";

const TOTAL_BANDS = 12;

// Foydalanuvchining barcha "completed" baholashlari bo'yicha har bir
// banddagi o'rtacha ballni hisoblaydi. Faqat to'liq tekshirilgan esselar
// hisobga olinadi (auto_rejected/failed band ballariga ega emas).
export async function getUserBandStats(userId) {
  const results = await EvaluationResult.findAll({
    where: { status: "completed" },
    include: [{ model: Essay, as: "essay", where: { userId }, attributes: [] }],
    attributes: ["bandResults"],
  });

  if (results.length === 0) {
    return { essayCount: 0, bands: [] };
  }

  // band raqami -> { sum, count, criterionName }
  const accumulator = new Map();

  for (const result of results) {
    for (const band of result.bandResults || []) {
      const entry = accumulator.get(band.band) || {
        sum: 0,
        count: 0,
        criterionName: band.criterion_name,
      };
      entry.sum += band.score;
      entry.count += 1;
      accumulator.set(band.band, entry);
    }
  }

  const bands = [];
  for (let bandNumber = 1; bandNumber <= TOTAL_BANDS; bandNumber += 1) {
    const entry = accumulator.get(bandNumber);
    if (!entry) continue; // nazariy holat, har doim to'ldirilgan bo'lishi kerak

    bands.push({
      band: bandNumber,
      criterionName: entry.criterionName,
      averageScore: Math.round((entry.sum / entry.count) * 100) / 100,
      essayCount: entry.count,
    });
  }

  // Eng past o'rtacha ball birinchi - foydalanuvchi zaif tomonini darhol ko'radi
  bands.sort((a, b) => a.averageScore - b.averageScore);

  return { essayCount: results.length, bands };
}
