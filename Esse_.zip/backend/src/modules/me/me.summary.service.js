import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { Essay } from "../essay/essay.model.js";
import { getUserBandStats } from "./me.stats.service.js";

// Profilda ko'rsatish uchun: jami/tekshirilgan esselar soni, eng yaxshi va
// o'rtacha natija (scaledScore, 75 ballik shkalada), hamda eng zaif mezon
// (band statistikasidan birinchisi - chunki u allaqachon o'sib boruvchi
// tartibda saralangan).
export async function getUserSummary(userId) {
  const totalEssayCount = await Essay.count({ where: { userId } });

  const completedResults = await EvaluationResult.findAll({
    where: { status: "completed" },
    include: [{ model: Essay, as: "essay", where: { userId }, attributes: [] }],
    attributes: ["totalScore"],
  });

  let bestScaledScore = null;
  let averageScaledScore = null;

  if (completedResults.length > 0) {
    const scaledScores = completedResults.map((r) => r.scaledScore);
    bestScaledScore = Math.max(...scaledScores);
    const sum = scaledScores.reduce((acc, s) => acc + s, 0);
    averageScaledScore = Math.round(sum / scaledScores.length);
  }

  const bandStats = await getUserBandStats(userId);
  const weakestBand = bandStats.bands[0] || null;

  return {
    totalEssayCount,
    checkedEssayCount: completedResults.length,
    bestScaledScore,
    averageScaledScore,
    weakestBand: weakestBand
      ? {
          criterionName: weakestBand.criterionName,
          averageScore: weakestBand.averageScore,
        }
      : null,
  };
}
