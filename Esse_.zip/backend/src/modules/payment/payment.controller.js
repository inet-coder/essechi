import { env } from "../../core/env.js";
import { getUserByTelegramId } from "../user/user.service.js";
import { sendTelegramMessage } from "../../integrations/telegram.js";
import {
  topUpBalance,
  getUserPayments,
  createPendingPayment,
  confirmPaymentByAmount,
  getUserBalanceInfo,
  adminAdjustBalance,
  getPaymentStatus,
} from "./payment.service.js";
import { ESSAY_PACKAGES, getPackageById } from "./payment.packages.js";

// Esse tekshiruv paketlari ro'yxati (bot/web shu orqali oladi).
export async function listPackages(req, res, next) {
  try {
    res.status(200).json(ESSAY_PACKAGES);
  } catch (error) {
    next(error);
  }
}

// Admin panel: telegramId bo'yicha foydalanuvchi balansi/kreditini ko'rish.
export async function getUserForAdmin(req, res, next) {
  try {
    const info = await getUserBalanceInfo(req.params.telegramId);
    res.status(200).json(info);
  } catch (error) {
    next(error);
  }
}

// Admin panel: telegramId bo'yicha balansga qo'lda mablag' qo'shish (amount>0)
// yoki olib tashlash (amount<0).
export async function adjustBalance(req, res, next) {
  try {
    const { telegramId, amount, note } = req.body;
    if (!telegramId || amount === undefined) {
      return res
        .status(400)
        .json({ error: "telegramId va amount majburiy" });
    }
    if (typeof amount !== "number" || !Number.isFinite(amount)) {
      return res.status(400).json({ error: "amount son bo'lishi kerak" });
    }
    const result = await adminAdjustBalance({ telegramId, amount, note });
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
}

export async function createTopUp(req, res, next) {
  try {
    const { telegramId, amount, note } = req.body;

    if (!telegramId || !amount) {
      return res.status(400).json({ error: "telegramId va amount majburiy" });
    }
    if (typeof amount !== "number" || amount <= 0) {
      return res
        .status(400)
        .json({ error: "amount musbat son bo'lishi kerak" });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const payment = await topUpBalance({ userId: user.id, amount, note });
    res.status(201).json(payment);
  } catch (error) {
    next(error);
  }
}

// Avtomatik to'lov uchun pending yozuv yaratadi va foydalanuvchiga
// ko'rsatiladigan to'lov ma'lumotlarini (ID, unikal summa, karta) qaytaradi.
export async function createPendingTopUp(req, res, next) {
  try {
    const { telegramId, amount, provider } = req.body;

    if (!telegramId || !amount) {
      return res.status(400).json({ error: "telegramId va amount majburiy" });
    }
    if (!Number.isInteger(amount) || amount < env.minTopupAmount) {
      return res.status(400).json({
        error: `Minimal to'lov summasi ${env.minTopupAmount} so'm`,
      });
    }

    if (!env.paymentCardNumber || !env.paymentCardHolder) {
      return res.status(500).json({
        error:
          "To'lov kartasi sozlanmagan (PAYMENT_CARD_NUMBER / PAYMENT_CARD_HOLDER)",
      });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const payment = await createPendingPayment({
      userId: user.id,
      requestedAmount: amount,
      provider: provider || null,
      cardNumber: env.paymentCardNumber,
      expiryMinutes: env.paymentExpiryMinutes,
    });

    res.status(201).json({
      id: payment.id,
      kind: payment.kind,
      amount: payment.amount,
      requestedAmount: payment.requestedAmount,
      cardNumber: env.paymentCardNumber,
      cardHolder: env.paymentCardHolder,
      provider: payment.provider,
      expiresAt: payment.expiresAt,
      expiryMinutes: env.paymentExpiryMinutes,
    });
  } catch (error) {
    next(error);
  }
}

// Esse tekshiruv PAKETI uchun pending yozuv yaratadi. Balans to'ldirishdan
// farqi: summa foydalanuvchi kiritmaydi - tanlangan paket narxidan olinadi va
// tasdiqlangach balans emas, esse tekshiruv krediti qo'shiladi.
export async function createPackagePending(req, res, next) {
  try {
    const { telegramId, packageId, provider } = req.body;

    if (!telegramId || packageId === undefined) {
      return res
        .status(400)
        .json({ error: "telegramId va packageId majburiy" });
    }

    const pkg = getPackageById(packageId);
    if (!pkg) {
      return res.status(400).json({ error: "Noto'g'ri paket tanlandi" });
    }

    if (!env.paymentCardNumber || !env.paymentCardHolder) {
      return res.status(500).json({
        error:
          "To'lov kartasi sozlanmagan (PAYMENT_CARD_NUMBER / PAYMENT_CARD_HOLDER)",
      });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const payment = await createPendingPayment({
      userId: user.id,
      requestedAmount: pkg.price,
      provider: provider || null,
      cardNumber: env.paymentCardNumber,
      expiryMinutes: env.paymentExpiryMinutes,
      kind: "package",
      essayCredits: pkg.credits,
    });

    res.status(201).json({
      id: payment.id,
      kind: payment.kind,
      amount: payment.amount,
      requestedAmount: payment.requestedAmount,
      essayCredits: payment.essayCredits,
      cardNumber: env.paymentCardNumber,
      cardHolder: env.paymentCardHolder,
      provider: payment.provider,
      expiresAt: payment.expiresAt,
      expiryMinutes: env.paymentExpiryMinutes,
    });
  } catch (error) {
    next(error);
  }
}

// Userbot bank/karta xabaridan olingan summani yuboradi; mos pending to'lov
// topilsa - tasdiqlanadi, balans qo'shiladi va foydalanuvchiga xabar beriladi.
export async function confirmByAmount(req, res, next) {
  try {
    const { amount } = req.body;

    if (!Number.isInteger(amount) || amount <= 0) {
      return res
        .status(400)
        .json({ error: "amount butun musbat son bo'lishi kerak" });
    }

    const result = await confirmPaymentByAmount(amount);
    if (!result) {
      // Mos pending to'lov yo'q - userbot buni "unmatched" deb log qiladi
      // (masalan begona o'tkazma yoki summa mos kelmadi).
      return res.status(200).json({ matched: false });
    }

    const { payment, user, availableCredits } = result;

    // Balans/kredit allaqachon qo'shildi; xabar yuborish xatosi tasdiqlashni
    // bekor qilmasligi kerak.
    const confirmMessage =
      payment.kind === "package"
        ? "✅ <b>To'lovingiz qabul qilindi!</b>\n\n" +
          `📦 <b>${payment.essayCredits}</b> ta esse tekshiruvi hisobingizga qo'shildi.\n` +
          `🧮 Amaldagi esse tekshiruv qoldig'i: <b>${availableCredits}</b> ta\n` +
          `⏳ Diqqat: paket <b>30 kun</b> amal qiladi.`
        : "✅ <b>To'lovingiz qabul qilindi!</b>\n\n" +
          `💵 <b>${payment.amount}</b> so'm balansingizga qo'shildi.\n` +
          `💰 Joriy balans: <b>${user.balance}</b> so'm`;

    try {
      await sendTelegramMessage(user.telegramId, confirmMessage);
    } catch (error) {
      console.error(
        "To'lov tasdiqlash xabarini yuborishda xatolik:",
        error.message,
      );
    }

    res.status(200).json({
      matched: true,
      paymentId: payment.id,
      telegramId: user.telegramId,
      kind: payment.kind,
      amount: payment.amount,
      availableCredits,
      balance: user.balance,
    });
  } catch (error) {
    next(error);
  }
}

export async function listPaymentsByTelegramId(req, res, next) {
  try {
    const { telegramId } = req.params;
    const user = await getUserByTelegramId(telegramId);

    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const payments = await getUserPayments(user.id);
    res.status(200).json(payments);
  } catch (error) {
    next(error);
  }
}

// Bitta pending to'lovning holati va qolgan vaqti (bot "Qolgan vaqtni
// tekshirish" tugmasi shu orqali ishlaydi).
export async function getPaymentStatusHandler(req, res, next) {
  try {
    const { id } = req.params;
    const status = await getPaymentStatus(id);
    if (!status) {
      return res.status(404).json({ error: "To'lov topilmadi" });
    }
    res.status(200).json(status);
  } catch (error) {
    next(error);
  }
}
