import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";
import { User } from "../user/user.model.js";

export const Payment = sequelize.define(
  "Payment",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    // To'lash uchun aniq summa (so'm). Pending to'lovlar uchun bu UNIKAL
    // qilib beriladi (foydalanuvchi kiritgan summaga 0..99 qo'shiladi) -
    // shunda userbot bank SMS'idagi summani aynan shu to'lovga bog'lay oladi.
    amount: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    // Foydalanuvchi kiritgan asl summa (unikallik uchun qo'shilgan qoldiqsiz).
    requestedAmount: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    // "pending" | "confirmed" | "expired"
    status: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: "pending",
    },
    // To'lov turi: "balance" - balansni to'ldirish (so'm qo'shiladi),
    // "package" - esse tekshiruv paketi (essayCredits qo'shiladi).
    kind: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: "balance",
    },
    // Paket to'lovi uchun beriladigan esse tekshiruv krediti soni
    // (kind = "package" bo'lganda to'ldiriladi, balans to'lovida null).
    essayCredits: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    // Tanlangan to'lov tizimi kodi (masalan "payme", "click", "any").
    provider: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    // To'lov tushishi kerak bo'lgan karta - userbot SMS'ni shu karta bo'yicha
    // ham solishtiradi.
    cardNumber: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    // Pending to'lov shu vaqtdan keyin "expired" bo'ladi.
    expiresAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    // Admin uchun ixtiyoriy izoh (masalan "Click orqali", "Naqd")
    note: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    tableName: "payments",
    timestamps: true,
  },
);

Payment.belongsTo(User, { foreignKey: "userId", as: "user" });
User.hasMany(Payment, { foreignKey: "userId", as: "payments" });
