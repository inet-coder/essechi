// Esse tekshiruv paketlari - YAGONA MANBA (bot, web va backend shu ro'yxatga
// tayanadi). Har bir paket `credits` ta esse tekshiruvini `price` so'mga beradi.
// Narx/kredit o'zgarsa - faqat shu yerni tahrirlash kifoya.
export const ESSAY_PACKAGES = [
  { id: 1, credits: 10, price: 50000 },
  { id: 2, credits: 20, price: 90000 },
  { id: 3, credits: 30, price: 130000 },
  { id: 4, credits: 40, price: 180000 },
  { id: 5, credits: 50, price: 220000 },
];

export function getPackageById(id) {
  const numericId = Number(id);
  return ESSAY_PACKAGES.find((p) => p.id === numericId) || null;
}
