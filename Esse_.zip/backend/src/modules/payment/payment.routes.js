import { Router } from "express";
import {
  createTopUp,
  createPendingTopUp,
  createPackagePending,
  listPackages,
  confirmByAmount,
  listPaymentsByTelegramId,
  getUserForAdmin,
  adjustBalance,
  getPaymentStatusHandler,
} from "./payment.controller.js";
import { requireAdmin } from "../../middleware/requireAdmin.js";

const router = Router();

router.get("/packages", listPackages);
router.post("/topup", requireAdmin, createTopUp);
router.post("/pending", requireAdmin, createPendingTopUp);
router.post("/package-pending", requireAdmin, createPackagePending);
router.post("/confirm-by-amount", requireAdmin, confirmByAmount);
// Admin panel: qo'lda balans boshqaruvi (telegramId bo'yicha).
router.get("/admin/user/:telegramId", requireAdmin, getUserForAdmin);
router.post("/admin/adjust-balance", requireAdmin, adjustBalance);
// Bitta to'lov holati/qolgan vaqti (bot chaqiradi).
router.get("/:id/status", requireAdmin, getPaymentStatusHandler);
// Bot (server) chaqiradi - foydalanuvchining to'lov tarixi begonaga
// ko'rinmasligi uchun admin kaliti bilan yopamiz.
router.get("/user/:telegramId", requireAdmin, listPaymentsByTelegramId);

export default router;
