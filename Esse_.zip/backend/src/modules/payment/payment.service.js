import { Op } from "sequelize";

import { httpError } from "../../core/httpError.js";
import { sequelize } from "../../core/database.js";
import { env } from "../../core/env.js";
import { sendTelegramMessage } from "../../integrations/telegram.js";
import { Payment } from "./payment.model.js";
import { User } from "../user/user.model.js";
import { addBalance, deductBalanceIfEnough } from "../user/user.service.js";
import { grantCredits, getAvailableCredits } from "../credit/credit.service.js";

// Foydalanuvchi kiritgan summaga qo'shiladigan qoldiq oralig'i (0..99).
// Bir vaqtda ko'p pending to'lov bo'lganda ham summalar unikal bo'lib turadi.
const UNIQUE_OFFSET_RANGE = 100;

export async function topUpBalance({ userId, amount, note }) {
  await addBalance(userId, amount);
  return Payment.create({ userId, amount, note, status: "confirmed" });
}

// Admin panel uchun: telegramId bo'yicha foydalanuvchi balansi/krediti.
export async function getUserBalanceInfo(telegramId) {
  const user = await User.findOne({ where: { telegramId } });
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");
  const essayCredits = await getAvailableCredits(user.id);
  return {
    telegramId: String(user.telegramId),
    firstName: user.firstName,
    balance: user.balance,
    essayCredits,
  };
}

// Admin ISTALGAN foydalanuvchi balansiga qo'lda mablag' QO'SHADI (amount>0) yoki
// OLIB TASHLAYDI (amount<0). Balans manfiy bo'lib qolmaydi. Qo'shishда tarixда
// ko'rinishi uchun Payment yozuvi yaratiladi; olib tashlashda esa faqat balans
// to'g'rilanadi (bu "to'lov" emas - tuzatish).
export async function adminAdjustBalance({ telegramId, amount, note }) {
  const user = await User.findOne({ where: { telegramId } });
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const delta = Math.trunc(Number(amount));
  if (!delta) throw httpError(400, "amount 0 bo'lmasligi kerak");

  if (delta < 0) {
    if (user.balance + delta < 0) {
      throw httpError(
        400,
        `Balans manfiy bo'lib qoladi. Joriy balans: ${user.balance} so'm.`,
      );
    }
    // atomik, shartli yechish (poyga holatida ham minusga tushmaydi)
    const ok = await deductBalanceIfEnough(user.id, -delta);
    if (!ok) {
      throw httpError(400, `Balans yetarli emas. Joriy: ${user.balance} so'm.`);
    }
  } else {
    await addBalance(user.id, delta);
    await Payment.create({
      userId: user.id,
      amount: delta,
      note: note || "Admin qo'lda qo'shdi",
      status: "confirmed",
      kind: "balance",
    });
  }

  const fresh = await User.findByPk(user.id);
  return {
    telegramId: String(fresh.telegramId),
    firstName: fresh.firstName,
    balance: fresh.balance,
    applied: delta,
  };
}

// "To'lovlarim" ro'yxatiga faqat haqiqatan amalga oshgan to'lovlar tushishi
// kerak - pending/expired yozuvlar bu yerga chiqmaydi.
export async function getUserPayments(userId) {
  return Payment.findAll({
    where: { userId, status: "confirmed" },
    order: [["createdAt", "DESC"]],
  });
}

// Muddati o'tgan pending to'lovlarni "expired"ga o'tkazamiz va HAR BIR
// foydalanuvchiga muddat tugagani haqida xabar yuboramiz.
//   - returning:true bilan AYNAN shu chaqiruvda "expired"ga o'tgan qatorlar
//     olinadi (poyga xavfsiz: shu orada tasdiqlangan to'lov bu yerga tushmaydi,
//     shuning uchun noto'g'ri "muddat tugadi" xabari yuborilmaydi).
//   - Xabar yuborish "best-effort": bittasi xato bersa ham qolganlarga ta'sir
//     qilmaydi va expire jarayoni to'xtamaydi.
async function expireStalePayments() {
  const [count, rows] = await Payment.update(
    { status: "expired" },
    {
      where: { status: "pending", expiresAt: { [Op.lt]: new Date() } },
      returning: true,
    },
  );

  if (!count || !rows?.length) return;

  const userIds = [...new Set(rows.map((r) => r.userId))];
  const users = await User.findAll({
    where: { id: { [Op.in]: userIds } },
    attributes: ["id", "telegramId"],
  });
  const telegramIdByUserId = new Map(users.map((u) => [u.id, u.telegramId]));

  await Promise.allSettled(
    rows.map((payment) => {
      const telegramId = telegramIdByUserId.get(payment.userId);
      if (!telegramId) return Promise.resolve();
      return sendTelegramMessage(
        String(telegramId),
        buildExpiredMessage(payment),
      ).catch((error) =>
        console.error(
          "Muddat tugash xabarini yuborishda xatolik:",
          error.message,
        ),
      );
    }),
  );
}

// Muddati tugagan to'lov uchun foydalanuvchiga ko'rsatiladigan xabar.
function buildExpiredMessage(payment) {
  const what =
    payment.kind === "package"
      ? `📦 <b>${payment.essayCredits}</b> ta esse tekshiruvi paketi uchun to'lov`
      : `💵 <b>${payment.amount}</b> so'mlik to'lov`;
  return (
    "⏰ <b>To'lov muddati tugadi</b>\n\n" +
    `${what} amalga oshmadi (belgilangan ${env.paymentExpiryMinutes} daqiqa ` +
    "ichida to'lov qabul qilinmadi).\n\n" +
    "Qayta urinish uchun <b>«💰 Balansni to'ldirish»</b> " +
    "tugmasini bosib, yangi to'lov yarating."
  );
}

// Bitta pending to'lovni MUDDATSIZ tekshirish uchun (bot "Qolgan vaqtni
// tekshirish" tugmasi). O'zi hech narsani o'zgartirmaydi (read-only): DB'dagi
// "expired"ga o'tkazish va push-xabarni sweeper bajaradi. Muddati o'tgan
// pending'ni foydalanuvchiga "expired" deb ko'rsatadi.
export async function getPaymentStatus(id) {
  const payment = await Payment.findByPk(id);
  if (!payment) return null;

  const now = Date.now();
  const expiresMs = new Date(payment.expiresAt).getTime();
  const effectiveStatus =
    payment.status === "pending" && expiresMs < now
      ? "expired"
      : payment.status;
  const secondsLeft =
    effectiveStatus === "pending"
      ? Math.max(0, Math.ceil((expiresMs - now) / 1000))
      : 0;

  return {
    id: payment.id,
    status: effectiveStatus,
    kind: payment.kind,
    amount: payment.amount,
    essayCredits: payment.essayCredits,
    expiresAt: payment.expiresAt,
    secondsLeft,
  };
}

// Muddati o'tgan pending to'lovlarni MUNTAZAM (default 60 soniyada) "expired"ga
// o'tkazadi. Shu bilan 5 daqiqalik muddat trafik bo'lmasa ham AYNAN ishlaydi:
// band qilingan unikal summalar bo'shaydi va parallel-himoya (bitta ochiq
// to'lov) bloki ochiladi. app.js ishga tushganda bir marta chaqiriladi.
let sweeperStarted = false;
export function startPaymentExpirySweeper(intervalMs = 60 * 1000) {
  if (sweeperStarted) return;
  sweeperStarted = true;
  setInterval(() => {
    expireStalePayments().catch((error) =>
      console.error("Pending to'lovlarni expire qilishda xatolik:", error),
    );
  }, intervalMs).unref?.();
}

// Foydalanuvchining hozir kuchda turgan (muddati o'tmagan) pending to'lovi
// bo'lsa - qaytaradi. Parallel/takroriy to'lovlarni oldini olish uchun
// ishlatiladi (bitta vaqtda faqat bitta ochiq to'lov).
async function findActivePendingPayment(userId) {
  return Payment.findOne({
    where: {
      userId,
      status: "pending",
      expiresAt: { [Op.gt]: new Date() },
    },
    order: [["createdAt", "DESC"]],
  });
}

// Yangi pending to'lov yaratadi. Balans/kredit HALI qo'shilmaydi - userbot
// bank SMS'ini solishtirib tasdiqlagandan keyin qo'shiladi.
//   kind          - "balance" (balans to'ldirish) yoki "package" (esse paketi)
//   essayCredits  - paket to'lovida beriladigan kredit soni (balansda null)
//
// PARALLEL TO'LOVLARNI OLDINI OLISH: agar foydalanuvchida allaqachon ochiq
// (muddati o'tmagan) pending to'lov bo'lsa, yangisi yaratilmaydi - shu bilan
// bir odam bir vaqtda bir nechta unikal summani band qilib, bittasini to'lab,
// qolganlarini "osilib qolgan" holatda qoldirib ketolmaydi.
export async function createPendingPayment({
  userId,
  requestedAmount,
  provider,
  cardNumber,
  expiryMinutes,
  kind = "balance",
  essayCredits = null,
}) {
  await expireStalePayments();

  const active = await findActivePendingPayment(userId);
  if (active) {
    const err = httpError(
      409,
      "Sizda hali tugallanmagan to'lov mavjud. Avval uni to'lang yoki " +
        "amal qilish muddati tugashini kuting, so'ng qayta urinib ko'ring.",
    );
    err.activePayment = active;
    throw err;
  }

  const expiresAt = new Date(Date.now() + expiryMinutes * 60 * 1000);

  // requestedAmount dan boshlab band bo'lmagan birinchi unikal summani
  // topamiz. DB'dagi partial unique index (status='pending') poyga holatidan
  // himoya qiladi - agar create shu sababdan xato bersa, keyingi offsetni
  // sinaymiz.
  for (let offset = 0; offset < UNIQUE_OFFSET_RANGE; offset++) {
    const amount = requestedAmount + offset;

    const busy = await Payment.findOne({
      where: { amount, status: "pending" },
    });
    if (busy) continue;

    try {
      return await Payment.create({
        userId,
        amount,
        requestedAmount,
        provider,
        cardNumber,
        status: "pending",
        expiresAt,
        kind,
        essayCredits,
      });
    } catch (error) {
      if (error.name === "SequelizeUniqueConstraintError") continue;
      throw error;
    }
  }

  throw httpError(
    409,
    "Ayni damda bo'sh to'lov summasi topilmadi. Birozdan so'ng qayta urinib ko'ring.",
  );
}

// Bank/karta xabaridan kelgan summa bo'yicha mos pending to'lovni topib
// tasdiqlaydi va balansni qo'shadi. Butun amal bitta tranzaksiyada, qator
// bloklab (FOR UPDATE) bajariladi - shunda bir vaqtda ikki xabar kelsa ham
// balans ikki marta qo'shilib ketmaydi. Mos to'lov bo'lmasa null qaytaradi.
export async function confirmPaymentByAmount(amount) {
  await expireStalePayments();

  const outcome = await sequelize.transaction(async (t) => {
    const payment = await Payment.findOne({
      // Muddati o'tmagan (expiresAt>now) pending to'lovnigina tasdiqlaymiz -
      // expired to'lov hech qachon tasdiqlanmaydi.
      where: {
        amount,
        status: "pending",
        expiresAt: { [Op.gt]: new Date() },
      },
      order: [["createdAt", "ASC"]],
      lock: t.LOCK.UPDATE,
      transaction: t,
    });
    if (!payment) return null;

    const user = await User.findByPk(payment.userId, {
      lock: t.LOCK.UPDATE,
      transaction: t,
    });
    if (!user) return null;

    if (payment.kind === "package") {
      // Paket to'lovi - 30 kunlik kredit partiyasi yaratiladi (balansga
      // TEGMAYDI). Kreditlar credit.service orqali alohida yuritiladi.
      await grantCredits(
        {
          userId: user.id,
          credits: payment.essayCredits || 0,
          source: "package",
          paymentId: payment.id,
        },
        t,
      );
    } else {
      user.balance += payment.amount;
      await user.save({ transaction: t });
    }

    payment.status = "confirmed";
    await payment.save({ transaction: t });

    return { payment, user };
  });

  if (!outcome) return null;

  // Paket bo'lsa - yangilangan (amaldagi) kredit sonini qaytaramiz (xabar uchun).
  const availableCredits =
    outcome.payment.kind === "package"
      ? await getAvailableCredits(outcome.user.id)
      : null;

  return { ...outcome, availableCredits };
}
