import { modelParams } from "../../core/env.js";
import { openai } from "../../integrations/openai.js";
import {
  SYSTEM_PROMPT,
  RESPONSE_SCHEMA,
  QUESTION_COUNT,
} from "./quiz.prompt.js";

export async function generateQuizQuestions(weakBands) {
  const completion = await openai.chat.completions.create({
    // Model va reasoning_effort .env orqali (funksiyaga xos) tanlanadi.
    ...modelParams("quiz"),
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content:
          `Talabgorning eng past ball olgan mezonlari (JSON, eng zaifi ` +
          `birinchi):\n${JSON.stringify(weakBands)}\n\n` +
          `Roppa-rosa ${QUESTION_COUNT} ta savol tuzing.`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "essay_quiz",
        strict: true,
        schema: RESPONSE_SCHEMA,
      },
    },
  });

  const rawContent = completion.choices[0]?.message?.content;
  if (!rawContent) {
    throw new Error("GPT bo'sh javob qaytardi");
  }

  const parsed = JSON.parse(rawContent);
  return parsed.questions;
}
