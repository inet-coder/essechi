import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

export const Quiz = sequelize.define(
  "Quiz",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    // [{ id, criterionName, question, options: [4 ta string], correctIndex, explanation }]
    questions: {
      type: DataTypes.JSONB,
      allowNull: false,
    },
    // Topshirilgach to'ladi: [{ questionId, selectedIndex }]
    answers: {
      type: DataTypes.JSONB,
      allowNull: true,
    },
    // To'g'ri javoblar soni (0-10). Topshirilmagan bo'lsa null.
    score: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    // Haftalik bepul urinish sifatida ishlatilganmi yoki balansdan
    // to'langanmi - statistika/audit uchun saqlanadi.
    wasFree: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
    completedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: "quizzes",
    timestamps: true,
  },
);
