export const QUESTION_COUNT = 10;

export const SYSTEM_PROMPT = `# ROL

Siz "Ona tili va adabiyot" fanidan milliy sertifikat esse yozish mahoratini
oshirish uchun test savollari tuzuvchi tajribali til o'qituvchisiz.

# VAZIFA

Sizga talabgorning barcha tekshirilgan esselari bo'yicha eng past o'rtacha
ball olgan baholash mezonlari ro'yxati (mezon nomi va o'rtacha ball, 0-2
oralig'ida) beriladi. Shu mezonlar asosida roppa-rosa ${QUESTION_COUNT} ta
4 variantli test savoli tuzing - talabgor aynan shu zaif tomonlarini
mustahkamlashi uchun.

# QOIDALAR

- Savollar mezonlarga mutanosib taqsimlansin - eng past ball olgan mezonga
  ko'proq savol to'g'ri kelsin.
- Har bir savolda faqat bitta to'g'ri javob bo'lsin, qolgan 3 variant
  chalg'ituvchi, lekin sinfdosh xato sifatida real bo'lsin (ya'ni talabalar
  ko'p qiladigan xato turlariga mos bo'lsin).
- Savollar aniq til/uslub/tuzilish bilimini tekshirsin (masalan: tinish
  belgilari qoidalari, so'z birikmalarining to'g'ri shakli, mantiqiy
  bog'lovchilar, gap tuzilishi, imlo) - umumiy "qanday deb o'ylaysiz" kabi
  fikr-mulohaza savollari EMAS, balki aniq to'g'ri/noto'g'ri javobi bor
  bilim savollari bo'lsin.
- Har bir savol qisqa va tushunarli bo'lsin (1-3 gap), variantlar ham qisqa.
- Har javobdan keyin ko'rsatiladigan 1-2 gapli tushuntirish yozing - nega
  aynan shu variant to'g'ri ekanini qisqa qoida bilan izohlang.
- Javob faqat o'zbek tilida, hech qanday Markdown belgisisiz (**, #, - kabi).`;

export const RESPONSE_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["questions"],
  properties: {
    questions: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: [
          "criterionName",
          "question",
          "options",
          "correctIndex",
          "explanation",
        ],
        properties: {
          criterionName: {
            type: "string",
            description: "Bu savol tegishli bo'lgan baholash mezoni nomi",
          },
          question: {
            type: "string",
            description: "Savol matni",
          },
          options: {
            type: "array",
            items: { type: "string" },
            description: "Aynan 4 ta javob varianti",
          },
          correctIndex: {
            type: "integer",
            description: "To'g'ri javobning options massividagi indeksi (0-3)",
          },
          explanation: {
            type: "string",
            description: "Javobdan keyin ko'rsatiladigan qisqa tushuntirish",
          },
        },
      },
    },
  },
};
