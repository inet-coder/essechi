import { Op } from "sequelize";

import { getUserById, deductBalanceIfEnough, addBalance } from "../user/user.service.js";
import { getUserBandStats } from "../me/me.stats.service.js";
import { Quiz } from "./quiz.model.js";
import { generateQuizQuestions } from "./quiz.gpt.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

// Savollarni juda ko'p mezonga sochib yubormaslik uchun faqat eng zaif
// bir nechta mezon asosida savol tuziladi (10 ta savol shular orasida
// mutanosib taqsimlanadi).
const MAX_WEAK_CRITERIA = 4;

// Tasodifiy (random) test uchun eng kam savollar soni.
const MIN_RANDOM_QUESTIONS = 10;

// Fisher-Yates aralashtirish (asl massivга tegmaydi).
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Savolni matni bo'yicha noyoblashtirish kaliti (hovuzda takror bo'lmasligi uchun).
function questionKey(q) {
  return (q?.question || "").trim().toLowerCase();
}

// Foydalanuvchining BARCHA viktorinalaridagi savollardan takrorlanmas hovuz
// yig'adi. Qayta ishlangan/tasodifiy testlardagi nusxa savollar bir xil matnга
// ega bo'lgani uchun avtomatik chiqib ketadi - hovuz faqat noyob savollardan
// iborat bo'ladi. HECH QANDAY AI chaqirilmaydi.
async function getUserQuestionPool(userId) {
  const quizzes = await Quiz.findAll({
    where: { userId },
    attributes: ["questions"],
  });

  const seen = new Set();
  const pool = [];
  for (const quiz of quizzes) {
    for (const q of quiz.questions || []) {
      const key = questionKey(q);
      if (!key || seen.has(key)) continue;
      seen.add(key);
      pool.push(q);
    }
  }
  return pool;
}

function toPublicQuiz(quiz) {
  return {
    id: quiz.id,
    questions: quiz.questions,
    answers: quiz.answers,
    score: quiz.score,
    wasFree: quiz.wasFree,
    completedAt: quiz.completedAt,
    createdAt: quiz.createdAt,
  };
}

export async function getQuizStatus(userId) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const lastQuiz = await Quiz.findOne({
    where: { userId },
    order: [["createdAt", "DESC"]],
  });

  // Tasodifiy test uchun mavjud noyob savollar hovuzi (AI'siz qayta ishlash).
  const pool = await getUserQuestionPool(userId);

  return {
    // AI viktorina endi FAQAT pullik (haftalik bepul urinish olib tashlandi).
    // Eski frontend moslashuvi uchun maydonlar saqlangan.
    isFree: false,
    nextFreeAt: null,
    price: env.quizPrice,
    balance: user.balance,
    lastQuiz: lastQuiz ? toPublicQuiz(lastQuiz) : null,
    // Frontend "tasodifiy test" bo'limini shu asosda ko'rsatadi:
    //   randomAvailable - hovuzda kamida MIN_RANDOM_QUESTIONS ta savol bormi
    //   poolSize        - jami noyob savollar (max shu qiymat)
    //   min / max       - foydalanuvchi tanlashi mumkin bo'lgan oraliq
    random: {
      available: pool.length >= MIN_RANDOM_QUESTIONS,
      poolSize: pool.length,
      min: MIN_RANDOM_QUESTIONS,
      max: pool.length,
    },
  };
}

export async function generateMyQuiz(userId) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const { essayCount, bands } = await getUserBandStats(userId);

  if (essayCount === 0) {
    throw httpError(
      400,
      "Viktorina tuzish uchun kamida bitta muvaffaqiyatli tekshirilgan esse kerak.",
    );
  }

  // AI viktorina - FAQAT pullik. To'lovni GPT chaqiruvidan OLDIN atomik yechamiz
  // (parallel so'rovlar balansni minusга tushirmasligi uchun). Xato bo'lsa
  // qaytaramiz.
  const paid = await deductBalanceIfEnough(userId, env.quizPrice);
  if (!paid) {
    throw httpError(
      402,
      `AI viktorina narxi ${env.quizPrice} so'm. Balansingizda mablag' ` +
        `yetarli emas. Botdagi "💰 Balansni to'ldirish" bo'limidan ` +
        `hisobingizni to'ldiring.`,
    );
  }

  const weakBands = bands.slice(0, MAX_WEAK_CRITERIA).map((b) => ({
    criterionName: b.criterionName,
    averageScore: b.averageScore,
  }));

  let generated;
  try {
    generated = await generateQuizQuestions(weakBands);
  } catch (error) {
    // GPT texnik xatosi - yechilgan to'lovni qaytaramiz va foydalanuvchiga
    // tushunarli "texnik nosozlik" xabarini beramiz (ichki xato oshkor emas).
    console.error("Viktorina GPT xatosi:", error?.status, error?.message);
    await addBalance(userId, env.quizPrice);
    throw httpError(
      502,
      "Texnik nosozlik yuz berdi. Balansingizdan hech narsa yechilmadi. " +
        "Iltimos, birozdan so'ng qayta urinib ko'ring.",
    );
  }

  const questions = generated.map((q, i) => ({ id: i + 1, ...q }));

  const quiz = await Quiz.create({
    userId,
    questions,
    wasFree: false,
  });

  return toPublicQuiz(quiz);
}

export async function submitMyQuizAnswers(userId, quizId, answers) {
  const quiz = await Quiz.findOne({ where: { id: quizId, userId } });
  if (!quiz) throw httpError(404, "Viktorina topilmadi");
  if (quiz.completedAt)
    throw httpError(400, "Bu viktorina allaqachon topshirilgan");

  if (!Array.isArray(answers) || answers.length !== quiz.questions.length) {
    throw httpError(400, "Barcha savollarga javob berilishi kerak");
  }

  const correctByQuestionId = new Map(
    quiz.questions.map((q) => [q.id, q.correctIndex]),
  );

  let score = 0;
  for (const answer of answers) {
    const correctIndex = correctByQuestionId.get(answer.questionId);
    if (correctIndex !== undefined && correctIndex === answer.selectedIndex) {
      score += 1;
    }
  }

  quiz.answers = answers;
  quiz.score = score;
  quiz.completedAt = new Date();
  await quiz.save();

  return toPublicQuiz(quiz);
}

// QAYTA ISHLASH: mavjud viktorinani aynan o'sha savollar bilan yangi urinish
// sifatida ochadi. AI CHAQIRILMAYDI -> bepul. Savollar tartibi aralashtiriladi
// (har safar biroz boshqacha bo'lishi uchun); har bir savolning variantlari va
// to'g'ri javobi o'zgarmaydi.
export async function retakeMyQuiz(userId, quizId) {
  const source = await Quiz.findOne({ where: { id: quizId, userId } });
  if (!source) throw httpError(404, "Viktorina topilmadi");

  const questions = shuffle(source.questions).map((q, i) => ({
    ...q,
    id: i + 1,
  }));

  const quiz = await Quiz.create({
    userId,
    questions,
    wasFree: true, // AI ishlatilmadi
  });

  return toPublicQuiz(quiz);
}

// TASODIFIY TEST: foydalanuvchining barcha tuzilgan savollari hovuzidan tasodifiy
// `count` ta savol tanlab yangi test yasaydi. AI CHAQIRILMAYDI -> bepul.
// `count` [MIN_RANDOM_QUESTIONS .. hovuz hajmi] oralig'iga moslanadi (min 10,
// max - mavjud boricha). Hovuzda 10 tadan kam savol bo'lsa - xatolik.
export async function generateRandomQuiz(userId, count) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const pool = await getUserQuestionPool(userId);

  if (pool.length < MIN_RANDOM_QUESTIONS) {
    throw httpError(
      400,
      `Tasodifiy test uchun kamida ${MIN_RANDOM_QUESTIONS} ta tuzilgan savol ` +
        `kerak. Hozircha ${pool.length} ta bor - avval AI viktorina tuzing.`,
    );
  }

  let n = Number.parseInt(count, 10);
  if (!Number.isFinite(n)) n = MIN_RANDOM_QUESTIONS;
  // [10 .. hovuz hajmi] oralig'iga moslash.
  n = Math.max(MIN_RANDOM_QUESTIONS, Math.min(n, pool.length));

  const questions = shuffle(pool)
    .slice(0, n)
    .map((q, i) => ({ ...q, id: i + 1 }));

  const quiz = await Quiz.create({
    userId,
    questions,
    wasFree: true, // AI ishlatilmadi
  });

  return toPublicQuiz(quiz);
}

export async function listMyQuizzes(userId) {
  const quizzes = await Quiz.findAll({
    where: { userId, completedAt: { [Op.ne]: null } },
    order: [["createdAt", "DESC"]],
  });
  return quizzes.map(toPublicQuiz);
}

export async function getMyQuiz(userId, quizId) {
  const quiz = await Quiz.findOne({ where: { id: quizId, userId } });
  if (!quiz) throw httpError(404, "Viktorina topilmadi");
  return toPublicQuiz(quiz);
}
