import {
  getGuide,
  setGuideVideo,
  setGuideDescription,
} from "./setting.service.js";

// Ochiq: foydalanuvchi "📖 Qo'llanma" bosganda bot shu ma'lumotni oladi.
export async function getGuideHandler(req, res, next) {
  try {
    const guide = await getGuide();
    res.status(200).json(guide);
  } catch (error) {
    next(error);
  }
}

// Admin (bot orqali): qo'llanma videosi file_id'sini o'rnatadi/o'zgartiradi.
export async function setGuideVideoHandler(req, res, next) {
  try {
    const { videoFileId } = req.body;
    if (!videoFileId) {
      return res.status(400).json({ error: "videoFileId majburiy" });
    }
    const guide = await setGuideVideo(videoFileId);
    res.status(200).json(guide);
  } catch (error) {
    next(error);
  }
}

// Admin (bot orqali): qo'llanma tavsifini o'rnatadi/o'zgartiradi.
export async function setGuideDescriptionHandler(req, res, next) {
  try {
    const { description } = req.body;
    const guide = await setGuideDescription(description ?? "");
    res.status(200).json(guide);
  } catch (error) {
    next(error);
  }
}
