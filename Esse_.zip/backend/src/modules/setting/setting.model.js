import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

// Oddiy kalit-qiymat sozlamalar jadvali. Admin panel orqali o'zgartiriladigan,
// deploysiz sozlanadigan qiymatlar shu yerda saqlanadi (masalan, bepul esse
// tekshiruvi limiti).
export const Setting = sequelize.define(
  "Setting",
  {
    key: {
      type: DataTypes.STRING,
      primaryKey: true,
    },
    value: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    tableName: "settings",
    timestamps: true,
  },
);
