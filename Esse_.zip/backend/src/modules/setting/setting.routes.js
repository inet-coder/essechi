import { Router } from "express";
import {
  getGuideHandler,
  setGuideVideoHandler,
  setGuideDescriptionHandler,
} from "./setting.controller.js";
import { requireAdmin } from "../../middleware/requireAdmin.js";

const router = Router();

// Ochiq (bot foydalanuvchi uchun qo'llanmani oladi).
router.get("/guide", getGuideHandler);

// Admin (bot orqali - x-admin-key bilan).
router.post("/guide/video", requireAdmin, setGuideVideoHandler);
router.post("/guide/description", requireAdmin, setGuideDescriptionHandler);

export default router;
