import { Setting } from "./setting.model.js";

// Har bir foydalanuvchiga beriladigan bepul esse tekshiruvlari soni (umr bo'yi).
// Admin panel orqali o'zgartiriladi. 0 - bepul tekshiruv umuman berilmaydi.
const FREE_ESSAY_LIMIT_KEY = "free_essay_limit";
const DEFAULT_FREE_ESSAY_LIMIT = 1;

// Xotira keshi - har bir tekshiruvda DBga bormaslik uchun (qiymat kam
// o'zgaradi). setFreeEssayLimit chaqirilganda yangilanadi.
let cachedLimit = null;

export async function getFreeEssayLimit() {
  if (cachedLimit !== null) return cachedLimit;
  const row = await Setting.findByPk(FREE_ESSAY_LIMIT_KEY);
  const parsed = row ? parseInt(row.value, 10) : DEFAULT_FREE_ESSAY_LIMIT;
  cachedLimit =
    Number.isFinite(parsed) && parsed >= 0 ? parsed : DEFAULT_FREE_ESSAY_LIMIT;
  return cachedLimit;
}

export async function setFreeEssayLimit(limit) {
  const n = Math.max(0, Math.trunc(Number(limit)));
  await Setting.upsert({ key: FREE_ESSAY_LIMIT_KEY, value: String(n) });
  cachedLimit = n;
  return n;
}

// ===========================================================================
// Qo'llanma (bot ichidagi video + tavsif). Admin bot orqali videoni yuklaydi -
// Telegram file_id va tavsif shu yerda (deploysiz) saqlanadi. Foydalanuvchi
// "📖 Qo'llanma" tugmasini bosganda bot shu file_id orqali videoni yuboradi.
// ===========================================================================
const GUIDE_VIDEO_KEY = "guide_video_file_id";
const GUIDE_DESC_KEY = "guide_video_description";

export async function getGuide() {
  const [video, desc] = await Promise.all([
    Setting.findByPk(GUIDE_VIDEO_KEY),
    Setting.findByPk(GUIDE_DESC_KEY),
  ]);
  return {
    videoFileId: video?.value || null,
    description: desc?.value || null,
  };
}

export async function setGuideVideo(fileId) {
  const value = String(fileId || "").trim();
  if (!value) return getGuide();
  await Setting.upsert({ key: GUIDE_VIDEO_KEY, value });
  return getGuide();
}

export async function setGuideDescription(description) {
  // Bo'sh tavsifga ham ruxsat (tavsifsiz video). Uzunlikni cheklaymiz -
  // Telegram caption chegarasi (~1024 belgi).
  const value = String(description ?? "").slice(0, 1024);
  await Setting.upsert({ key: GUIDE_DESC_KEY, value });
  return getGuide();
}
