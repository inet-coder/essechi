import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

// Mavzular kategoriyalari (admin tomonidan boshqariladi). Mavzu qo'shilganda
// admin mavjud kategoriyani tanlaydi yoki yangisini kiritadi.
export const Category = sequelize.define(
  "Category",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    // Topic'dagi kabi soft-deactivate.
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    tableName: "categories",
    timestamps: true,
  },
);
