import { Op } from "sequelize";
import { Category } from "./category.model.js";

export async function getActiveCategories() {
  return Category.findAll({
    where: { isActive: true },
    order: [["name", "ASC"]],
  });
}

export async function createCategory(name) {
  const trimmed = name.trim();

  // Avval o'chirilgan (nofaol) kategoriya bo'lsa, unique constraint xatosi
  // o'rniga uni qayta faollashtiramiz - admin uchun tabiiyroq xatti-harakat.
  const existingInactive = await Category.findOne({
    where: { name: { [Op.iLike]: trimmed }, isActive: false },
  });
  if (existingInactive) {
    existingInactive.isActive = true;
    await existingInactive.save();
    return existingInactive;
  }

  return Category.create({ name: trimmed });
}

// Admin uchun: faol va nofaol barcha kategoriyalar (boshqaruv sahifasida
// ko'rsatish uchun - o'chirilgan kategoriya ham ro'yxatda ko'rinsin).
export async function getAllCategoriesAdmin() {
  return Category.findAll({ order: [["name", "ASC"]] });
}

// Topic'dagi kabi soft-deactivate - kategoriya butunlay o'chirilmaydi,
// chunki unga bog'langan mavzular (topicId->categoryId) bo'lishi mumkin.
export async function deactivateCategory(id) {
  const category = await Category.findByPk(id);
  if (!category) return null;
  category.isActive = false;
  await category.save();
  return category;
}

export async function activateCategory(id) {
  const category = await Category.findByPk(id);
  if (!category) return null;
  category.isActive = true;
  await category.save();
  return category;
}

// Nom bo'yicha (katta-kichik harfsiz) topadi, bo'lmasa yaratadi. Admin yangi
// mavzu qo'shganda "yangi kategoriya" kiritsa, takroriy yozuv yaratmaslik uchun.
export async function findOrCreateCategory(name) {
  const trimmed = name.trim();
  const existing = await Category.findOne({
    where: { name: { [Op.iLike]: trimmed } },
  });
  if (existing) {
    // Avval o'chirilgan (nofaol) kategoriya bo'lsa, qayta ishlatilganda
    // avtomatik qayta faollashtiramiz - aks holda mavzu "ko'rinmas"
    // kategoriyaga bog'lanib qolardi.
    if (!existing.isActive) {
      existing.isActive = true;
      await existing.save();
    }
    return existing;
  }
  return Category.create({ name: trimmed });
}
