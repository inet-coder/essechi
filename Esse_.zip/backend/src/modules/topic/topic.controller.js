import {
  createTopic,
  getActiveTopics,
  getAllTopicsAdmin,
  deactivateTopic,
} from "./topic.service.js";
import {
  getActiveCategories,
  getAllCategoriesAdmin,
  createCategory,
  deactivateCategory,
} from "./category.service.js";

export async function addTopic(req, res, next) {
  try {
    const { text, categoryId, newCategoryName } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ error: "text majburiy" });
    }

    const topic = await createTopic({ text, categoryId, newCategoryName });
    res.status(201).json(topic);
  } catch (error) {
    next(error);
  }
}

export async function listCategories(req, res, next) {
  try {
    const categories = await getActiveCategories();
    res.status(200).json(categories);
  } catch (error) {
    next(error);
  }
}

export async function addCategory(req, res, next) {
  try {
    const { name } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ error: "name majburiy" });
    }
    const category = await createCategory(name);
    res.status(201).json(category);
  } catch (error) {
    // Bir xil nomli kategoriya (unique) - tushunarli xabar.
    if (error.name === "SequelizeUniqueConstraintError") {
      return res
        .status(409)
        .json({ error: "Bunday kategoriya allaqachon mavjud" });
    }
    next(error);
  }
}

export async function listTopics(req, res, next) {
  try {
    const topics = await getActiveTopics();
    res.status(200).json(topics);
  } catch (error) {
    next(error);
  }
}

export async function removeTopic(req, res, next) {
  try {
    const { id } = req.params;
    const topic = await deactivateTopic(id);

    if (!topic) {
      return res.status(404).json({ error: "Mavzu topilmadi" });
    }

    res.status(200).json(topic);
  } catch (error) {
    next(error);
  }
}

// --- Admin (web-admin panel uchun to'liq boshqaruv) ---

export async function adminListTopics(req, res, next) {
  try {
    const topics = await getAllTopicsAdmin();
    res.status(200).json(topics);
  } catch (error) {
    next(error);
  }
}

export async function adminListCategories(req, res, next) {
  try {
    const categories = await getAllCategoriesAdmin();
    res.status(200).json(categories);
  } catch (error) {
    next(error);
  }
}

export async function removeCategory(req, res, next) {
  try {
    const { id } = req.params;
    const category = await deactivateCategory(id);

    if (!category) {
      return res.status(404).json({ error: "Kategoriya topilmadi" });
    }

    res.status(200).json(category);
  } catch (error) {
    next(error);
  }
}
