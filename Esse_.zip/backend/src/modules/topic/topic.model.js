import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";
import { Category } from "./category.model.js";

export const Topic = sequelize.define(
  "Topic",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    text: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    // Mavzu qaysi kategoriyaga tegishli (ixtiyoriy - kategoriyasiz ham bo'lishi mumkin).
    categoryId: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    // Admin mavzuni o'chirib tashlamasdan, faollikdan chiqarishi mumkin
    // (eski/foydalanilmaydigan mavzularni ro'yxatdan olib tashlash uchun)
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    tableName: "topics",
    timestamps: true,
  },
);

Category.hasMany(Topic, { foreignKey: "categoryId", as: "topics" });
Topic.belongsTo(Category, { foreignKey: "categoryId", as: "category" });
