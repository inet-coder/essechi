import { Router } from "express";
import { requireAdmin } from "../../middleware/requireAdmin.js";
import {
  addTopic,
  listTopics,
  removeTopic,
  listCategories,
  addCategory,
  adminListTopics,
  adminListCategories,
  removeCategory,
} from "./topic.controller.js";

const router = Router();

// --- Kategoriyalar ---
// Ochiq (bot/web foydalanuvchi tomonidan mavzu tanlashda kategoriya
// ro'yxatini olish uchun ishlatiladi) - faqat faol kategoriyalar.
router.get("/categories", listCategories);
router.post("/categories", requireAdmin, addCategory);
router.post("/categories/:id/deactivate", requireAdmin, removeCategory);

// Admin boshqaruv paneli uchun to'liq (faol+nofaol) ro'yxatlar.
router.get("/admin/categories", requireAdmin, adminListCategories);
router.get("/admin", requireAdmin, adminListTopics);

// --- Mavzular ---
router.get("/", listTopics);
router.post("/", requireAdmin, addTopic);
router.post("/:id/deactivate", requireAdmin, removeTopic);

export default router;
