import { Topic } from "./topic.model.js";
import { Category } from "./category.model.js";
import { findOrCreateCategory } from "./category.service.js";

// Mavzu yaratish. Admin mavjud kategoriyani (categoryId) tanlaydi YOKI yangi
// kategoriya nomini (newCategoryName) kiritadi - ikkinchi holda kategoriya
// topiladi/yaratiladi. Ikkalasi ham berilmasa - kategoriyasiz mavzu.
export async function createTopic({
  text,
  categoryId = null,
  newCategoryName = null,
}) {
  let finalCategoryId = categoryId ? Number(categoryId) : null;

  if (!finalCategoryId && newCategoryName && newCategoryName.trim()) {
    const category = await findOrCreateCategory(newCategoryName);
    finalCategoryId = category.id;
  }

  const topic = await Topic.create({
    text: text.trim(),
    categoryId: finalCategoryId,
  });
  // Kategoriya ma'lumoti bilan qaytaramiz (frontend uchun qulay).
  return Topic.findByPk(topic.id, {
    include: [{ model: Category, as: "category", attributes: ["id", "name"] }],
  });
}

export async function getActiveTopics() {
  return Topic.findAll({
    where: { isActive: true },
    include: [{ model: Category, as: "category", attributes: ["id", "name"] }],
    order: [["createdAt", "DESC"]],
  });
}

// Admin uchun: faol va nofaol barcha mavzular (boshqaruv sahifasida to'liq
// ro'yxatni ko'rsatish uchun).
export async function getAllTopicsAdmin() {
  return Topic.findAll({
    include: [{ model: Category, as: "category", attributes: ["id", "name"] }],
    order: [["createdAt", "DESC"]],
  });
}

// "O'chirish" aslida soft-delete - hard delete qilinmaydi, chunki esselar
// topicId orqali bog'langan bo'lishi mumkin (reyting/tarix uchun kerak).
// Faollikdan chiqarilgan mavzu endi yangi esselarda ko'rsatilmaydi.
export async function deactivateTopic(id) {
  const topic = await Topic.findByPk(id);
  if (!topic) return null;
  topic.isActive = false;
  await topic.save();
  return topic;
}
