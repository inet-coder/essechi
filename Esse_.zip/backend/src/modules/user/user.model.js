import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

export const User = sequelize.define(
  "User",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    telegramId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      unique: true,
    },
    firstName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    username: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    totalAttemptsUsed: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    balance: {
      type: DataTypes.INTEGER, // so'm, butun son
      allowNull: false,
      defaultValue: 0,
    },
    // Bir martalik (umumiy) bepul esse tekshiruvi ishlatilganmi. ESKI maydon -
    // endi freeEssaysUsed (son) ishlatiladi, lekin muvofiqlik uchun saqlanadi.
    freeEssayUsed: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    // Foydalanuvchi ishlatgan bepul tekshiruvlar SONI. Bepul mavjud, agar bu
    // son admin belgilagan limitdan (settings.free_essay_limit) kichik bo'lsa.
    freeEssaysUsed: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    // AI xato tahlili xizmatidan oxirgi marta BEPUL foydalangan vaqti.
    // Haftalik bepul limitni hisoblash uchun ishlatiladi (pullik urinishlar
    // bu maydonni yangilamaydi).
    lastAiAnalysisAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    // AI viktorinadan oxirgi marta BEPUL foydalangan vaqti - xuddi
    // lastAiAnalysisAt kabi, haftalik bepul limit hisoblash uchun.
    lastQuizAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: "users",
    timestamps: true,
  },
);
