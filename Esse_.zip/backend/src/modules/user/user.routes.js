import { Router } from "express";
import {
  registerUser,
  getUser,
  getUserSummaryByTelegramId,
  listAllTelegramIds,
} from "./user.controller.js";
import { requireAdmin } from "../../middleware/requireAdmin.js";

const router = Router();

router.post("/", registerUser);
router.get("/telegram-ids", requireAdmin, listAllTelegramIds);
router.get("/:telegramId/summary", getUserSummaryByTelegramId);
router.get("/:telegramId", getUser);

export default router;
