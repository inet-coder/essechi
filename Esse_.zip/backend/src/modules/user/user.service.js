import { Op, literal } from "sequelize";

import { User } from "./user.model.js";
import { getFreeEssayLimit } from "../setting/setting.service.js";

export async function findOrCreateUser({ telegramId, firstName, username }) {
  const [user] = await User.findOrCreate({
    where: { telegramId },
    defaults: { firstName, username },
  });
  return user;
}

export async function getUserByTelegramId(telegramId) {
  return User.findOne({ where: { telegramId } });
}

export async function getUserById(id) {
  return User.findByPk(id);
}

// Faqat broadcast (admin xabar yuborishi) uchun - minimal ma'lumot, butun
// User obyektini emas, faqat telegramId ro'yxatini qaytaradi.
export async function getAllTelegramIds() {
  const users = await User.findAll({ attributes: ["telegramId"] });
  return users.map((u) => u.telegramId);
}

// ATOMIK: parallel baholashlar hisoblagichni yo'qotmasligi uchun bitta UPDATE.
export async function incrementAttemptsUsed(userId) {
  await User.update(
    { totalAttemptsUsed: literal(`"totalAttemptsUsed" + 1`) },
    { where: { id: userId } },
  );
}

// ATOMIK: bitta SQL UPDATE ichida balansni oshiradi. Read-modify-write
// (findByPk -> +amount -> save) o'rniga shuni ishlatamiz, aks holda ikki
// parallel qaytarish/qo'shish bir-birining ustiga yozib, mablag' yo'qolishi
// mumkin edi.
export async function addBalance(userId, amount) {
  const value = Math.trunc(Number(amount));
  const [affected] = await User.update(
    { balance: literal(`"balance" + ${value}`) },
    { where: { id: userId } },
  );
  return affected === 1;
}

export async function updateUserName(userId, firstName) {
  const user = await User.findByPk(userId);
  if (!user) return null;
  user.firstName = firstName;
  await user.save();
  return user;
}

// ATOMIK (shartsiz) yechish. Balans yetarli ekanini tekshirib yechish kerak
// bo'lsa deductBalanceIfEnough ishlatiladi.
export async function deductBalance(userId, amount) {
  const value = Math.trunc(Number(amount));
  const [affected] = await User.update(
    { balance: literal(`"balance" - ${value}`) },
    { where: { id: userId } },
  );
  return affected === 1;
}

// ATOMIK: balansda yetarli mablag' bo'lsagina yechadi. Bitta SQL UPDATE ichida
// shart (balance >= amount) tekshirilib yechilgani uchun, ikki parallel so'rov
// bir mablag'ni ikki marta sarflab, balansni minusга tushirib yubormaydi.
// Yechilsa true, mablag' yetmasa (yoki poyga natijasida) false qaytaradi.
export async function deductBalanceIfEnough(userId, amount) {
  const value = Math.trunc(Number(amount));
  const [affected] = await User.update(
    { balance: literal(`"balance" - ${value}`) },
    { where: { id: userId, balance: { [Op.gte]: value } } },
  );
  return affected === 1;
}

// ATOMIK: foydalanuvchining bepul tekshiruvini "band qiladi". Limit admin
// tomonidan belgilanadi (settings.free_essay_limit). UPDATE ... WHERE
// freeEssaysUsed < limit bo'lgani uchun ikki parallel so'rov bir vaqtda
// limitdan oshirib yubormaydi (ortiqchasi kredit/balansga o'tadi). Band
// qilinsa true, limit tugagan bo'lsa (yoki limit 0) false qaytaradi.
export async function claimFreeEssay(userId) {
  const limit = await getFreeEssayLimit();
  if (limit <= 0) return false;
  const [affected] = await User.update(
    { freeEssaysUsed: literal(`"freeEssaysUsed" + 1`) },
    { where: { id: userId, freeEssaysUsed: { [Op.lt]: limit } } },
  );
  return affected === 1;
}

// Bepul tekshiruvni qaytaradi (baholash texnik xato bersa yoki dublikat bo'lsa).
export async function releaseFreeEssay(userId) {
  await User.update(
    { freeEssaysUsed: literal(`"freeEssaysUsed" - 1`) },
    { where: { id: userId, freeEssaysUsed: { [Op.gt]: 0 } } },
  );
}
