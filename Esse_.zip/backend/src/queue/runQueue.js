// Konkurentligi cheklangan navbat ishlovchisi. Ko'p esseni bir vaqtda GPT'ga
// yubormasdan (rate-limitni bosib qo'ymasdan), `concurrency` ta ishlovchi
// bilan parallel bajaradi. Bitta element xato bersa butun partiya to'xtamaydi
// - xato natija sifatida qaytariladi (worker o'zi ushlamasa `runQueue` uni
// { error } ga o'raydi).
export async function processWithConcurrency(
  items,
  worker,
  { concurrency = 4, onProgress } = {},
) {
  const results = new Array(items.length);
  let nextIndex = 0;
  let completed = 0;

  async function runLane() {
    while (nextIndex < items.length) {
      const current = nextIndex;
      nextIndex += 1;
      try {
        results[current] = await worker(items[current], current);
      } catch (error) {
        results[current] = { error };
      }
      completed += 1;
      if (onProgress) {
        // Progress yozish (masalan DB) xato bersa ham partiya davom etsin.
        try {
          await onProgress(completed, items.length);
        } catch {
          /* noop */
        }
      }
    }
  }

  const laneCount = Math.min(Math.max(1, concurrency), items.length || 1);
  await Promise.all(Array.from({ length: laneCount }, runLane));

  return results;
}

// Vaqtincha xatolarga (rate-limit, tarmoq uzilishi) qarshi eksponensial
// backoff bilan qayta urinish.
export async function withRetry(fn, { retries = 2, baseDelayMs = 1000 } = {}) {
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (attempt < retries) {
        await new Promise((resolve) =>
          setTimeout(resolve, baseDelayMs * 2 ** attempt),
        );
      }
    }
  }
  throw lastError;
}
