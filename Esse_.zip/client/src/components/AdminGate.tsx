import { type ReactNode, useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { adminApi, setAdminKey, clearAdminKey } from "@/lib/api";

type Status = "checking" | "ok" | "invalid";

export function AdminGate({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const [status, setStatus] = useState<Status>("checking");

  useEffect(() => {
    let cancelled = false;

    // Bot ichidagi "Web App" tugmasi admin kalitni ?key= orqali yuboradi -
    // shu bo'lsa, qo'lda kiritmasdan avtomatik saqlab, manzildan tozalaymiz.
    const params = new URLSearchParams(window.location.search);
    const urlKey = params.get("key");
    if (urlKey) {
      setAdminKey(urlKey);
      params.delete("key");
      const cleanUrl =
        window.location.pathname + (params.toString() ? `?${params.toString()}` : "");
      window.history.replaceState({}, "", cleanUrl);
    }

    if (!adminApi.hasKey()) {
      navigate({ to: "/admin/login" });
      return;
    }
    adminApi
      .listArticles()
      .then(() => {
        if (!cancelled) setStatus("ok");
      })
      .catch(() => {
        if (!cancelled) {
          clearAdminKey();
          setStatus("invalid");
          navigate({ to: "/admin/login" });
        }
      });
    return () => {
      cancelled = true;
    };
  }, [navigate]);

  if (status !== "ok") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-sm text-muted-foreground">Tekshirilmoqda…</p>
      </div>
    );
  }

  return <>{children}</>;
}
