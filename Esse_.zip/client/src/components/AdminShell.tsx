import type { ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  CreditCard,
  FileText,
  LayoutDashboard,
  ListTodo,
  Trophy,
  Users,
  Wallet,
} from "lucide-react";
import { adminApi } from "@/lib/api";

const NAV = [
  { to: "/admin", label: "Boshqaruv", icon: LayoutDashboard, exact: true },
  { to: "/admin/users", label: "Foydalanuvchilar", icon: Users },
  { to: "/admin/payments", label: "To'lovlar", icon: CreditCard },
  { to: "/admin/articles", label: "Maqolalar", icon: FileText },
  { to: "/admin/competitions", label: "Musobaqalar", icon: Trophy },
  { to: "/admin/topics", label: "Mavzular", icon: ListTodo },
  { to: "/admin/balance", label: "Balans", icon: Wallet },
];

export function AdminShell({
  title,
  actions,
  children,
}: {
  title: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 border-b border-border bg-background/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-[900px] items-center justify-between px-4 py-3.5">
          <Link to="/admin" className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground">
              A
            </span>
            <span className="text-sm font-semibold text-foreground">Admin panel</span>
          </Link>
          <button
            type="button"
            onClick={() => {
              adminApi.logout();
              navigate({ to: "/admin/login" });
            }}
            className="text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Chiqish
          </button>
        </div>
        <div className="mx-auto max-w-[900px] px-4">
          <div className="flex gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {NAV.map((item) => {
              const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className="flex shrink-0 items-center gap-1.5 whitespace-nowrap border-b-2 px-3 py-2.5 text-[13px] font-medium transition-colors"
                  style={{
                    borderColor: active ? "var(--primary)" : "transparent",
                    color: active ? "var(--primary)" : "var(--muted-foreground)",
                  }}
                >
                  <item.icon className="h-4 w-4 shrink-0" strokeWidth={2} />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[900px] px-4 pb-14 pt-6">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <h1 className="text-xl font-bold text-foreground">{title}</h1>
          {actions}
        </div>
        {children}
      </div>
    </div>
  );
}
