import { useMemo } from "react";
import type { BandResult, ErrorItem } from "@/lib/api";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface FlatError extends ErrorItem {
  criterionName: string;
}

interface Match {
  start: number;
  end: number;
  error: FlatError;
}

interface Segment {
  text: string;
  error?: FlatError;
}

function findMatches(text: string, errors: FlatError[]): Match[] {
  const candidates: Match[] = [];

  for (const error of errors) {
    if (!error.original) continue;
    const idx = text.indexOf(error.original);
    if (idx === -1) continue; // GPT original matnni aynan qaytarmagan - o'tkazib yuboramiz
    candidates.push({ start: idx, end: idx + error.original.length, error });
  }

  // Uzunroq (demak ko'proq aniq) moslikka ustunlik beramiz, shunda qisqa
  // moslik uzunroq moslikni "yeb qo'ymaydi"
  candidates.sort((a, b) => b.end - b.start - (a.end - a.start));

  const accepted: Match[] = [];
  for (const candidate of candidates) {
    const overlaps = accepted.some((m) => candidate.start < m.end && candidate.end > m.start);
    if (!overlaps) accepted.push(candidate);
  }

  return accepted.sort((a, b) => a.start - b.start);
}

function buildSegments(text: string, matches: Match[]): Segment[] {
  const segments: Segment[] = [];
  let cursor = 0;

  for (const match of matches) {
    if (match.start > cursor) {
      segments.push({ text: text.slice(cursor, match.start) });
    }
    segments.push({ text: text.slice(match.start, match.end), error: match.error });
    cursor = match.end;
  }

  if (cursor < text.length) {
    segments.push({ text: text.slice(cursor) });
  }

  return segments;
}

export function AnnotatedEssayText({
  text,
  bandResults,
}: {
  text: string;
  bandResults: BandResult[];
}) {
  const segments = useMemo(() => {
    const flatErrors: FlatError[] = bandResults.flatMap((band) =>
      band.errors.map((err) => ({ ...err, criterionName: band.criterion_name })),
    );
    const matches = findMatches(text, flatErrors);
    return buildSegments(text, matches);
  }, [text, bandResults]);

  return (
    <p className="whitespace-pre-wrap text-[15px] leading-relaxed text-foreground">
      {segments.map((seg, i) =>
        seg.error ? (
          <Popover key={i}>
            <PopoverTrigger asChild>
              <button
                type="button"
                className="rounded-sm px-0.5 underline decoration-wavy decoration-2 underline-offset-2 transition-opacity hover:opacity-80"
                style={{
                  backgroundColor: "var(--tone-weak-soft)",
                  textDecorationColor: "var(--tone-bad)",
                }}
              >
                {seg.text}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-72">
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                {seg.error.criterionName}
              </div>
              <div
                className="mt-2 text-sm font-semibold"
                style={{ color: "var(--tone-excellent)" }}
              >
                {seg.error.suggestion}
              </div>
              {seg.error.explanation && (
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                  {seg.error.explanation}
                </p>
              )}
            </PopoverContent>
          </Popover>
        ) : (
          <span key={i}>{seg.text}</span>
        ),
      )}
    </p>
  );
}
