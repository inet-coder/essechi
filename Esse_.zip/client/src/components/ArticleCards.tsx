import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { BookOpen, ChevronRight, Clock, FileText } from "lucide-react";
import { resolveAssetUrl, type Article } from "@/lib/api";
import { formatDate } from "@/lib/format";

/** Rasm yuklanguncha yumshoq pulse fon, yuklangach fade-in bilan chiqadi. */
function ArticleCoverImage({ src, className }: { src: string; className?: string }) {
  const [loaded, setLoaded] = useState(false);
  return (
    <>
      {!loaded && <div className="absolute inset-0 animate-pulse bg-muted" />}
      <img
        src={src}
        alt=""
        loading="lazy"
        onLoad={() => setLoaded(true)}
        className={`${className ?? ""} transition-opacity duration-500 ${
          loaded ? "opacity-100" : "opacity-0"
        }`}
      />
    </>
  );
}

export function FeaturedArticleCard({
  article,
  wide = false,
}: {
  article: Article;
  wide?: boolean;
}) {
  const cover = resolveAssetUrl(article.coverImage);
  return (
    <Link
      to="/articles/$id"
      params={{ id: String(article.id) }}
      className={`group block shrink-0 overflow-hidden rounded-2xl bg-card shadow-elevated transition-transform active:scale-[0.98] ${
        wide ? "w-full" : "w-[260px]"
      }`}
    >
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-muted">
        {cover ? (
          <ArticleCoverImage
            src={cover}
            className="h-full w-full object-cover transition-transform duration-300 group-active:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            <BookOpen className="h-10 w-10" strokeWidth={1.5} />
          </div>
        )}
        <div
          className="absolute inset-x-0 bottom-0 h-2/3"
          style={{
            background: "linear-gradient(to top, oklch(0.15 0.03 255 / 0.85), transparent)",
          }}
        />
        <div className="absolute inset-x-0 bottom-0 p-4">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-2 py-0.5 text-[10px] font-semibold text-white backdrop-blur-sm">
              <BookOpen className="h-3 w-3" strokeWidth={2} />
              {article.readingMinutes} daq. o'qish
            </span>
            {article.category && (
              <span className="inline-flex items-center rounded-full bg-white/15 px-2 py-0.5 text-[10px] font-semibold text-white backdrop-blur-sm">
                {article.category}
              </span>
            )}
          </div>
          <h3 className="mt-2 line-clamp-2 text-[16px] font-bold leading-snug text-white">
            {article.title}
          </h3>
          {article.excerpt && (
            <p className="mt-1 line-clamp-2 text-[12px] leading-snug text-white/80">
              {article.excerpt}
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}

export function ArticleGridCard({ article }: { article: Article }) {
  const cover = resolveAssetUrl(article.coverImage);
  return (
    <Link
      to="/articles/$id"
      params={{ id: String(article.id) }}
      className="group block overflow-hidden rounded-2xl bg-card shadow-card transition-transform active:scale-[0.97]"
    >
      <div className="relative aspect-square w-full overflow-hidden bg-muted">
        {cover ? (
          <ArticleCoverImage
            src={cover}
            className="h-full w-full object-cover transition-transform duration-300 group-active:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            <FileText className="h-8 w-8" strokeWidth={1.5} />
          </div>
        )}
        <span className="absolute bottom-1.5 left-1.5 inline-flex items-center gap-0.5 rounded-full bg-black/45 px-1.5 py-0.5 text-[9.5px] font-medium text-white backdrop-blur-sm">
          <Clock className="h-2.5 w-2.5" strokeWidth={2} />
          {article.readingMinutes} daq.
        </span>
      </div>
      <div className="p-3">
        {article.category && (
          <span
            className="mb-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold"
            style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
          >
            {article.category}
          </span>
        )}
        <h3 className="line-clamp-2 text-[13px] font-semibold leading-snug text-foreground">
          {article.title}
        </h3>
      </div>
    </Link>
  );
}

export function ArticleListCard({ article }: { article: Article }) {
  const cover = resolveAssetUrl(article.coverImage);
  return (
    <Link
      to="/articles/$id"
      params={{ id: String(article.id) }}
      className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-card transition-transform active:scale-[0.99]"
    >
      <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-muted">
        {cover ? (
          <ArticleCoverImage src={cover} className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            <FileText className="h-5 w-5" strokeWidth={1.5} />
          </div>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <h3 className="line-clamp-2 text-[14px] font-semibold leading-snug text-foreground">
          {article.title}
        </h3>
        {article.excerpt && (
          <p className="mt-1 line-clamp-2 text-[12px] leading-snug text-muted-foreground">
            {article.excerpt}
          </p>
        )}
        <div className="mt-1.5 flex items-center gap-2 text-[11px] text-muted-foreground">
          <span>{formatDate(article.createdAt)}</span>
          <span className="opacity-40">•</span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" strokeWidth={2} />
            {article.readingMinutes} daq.
          </span>
        </div>
      </div>
      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={2} />
    </Link>
  );
}
