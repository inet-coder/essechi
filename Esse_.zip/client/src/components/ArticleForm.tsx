import { useRef, useState } from "react";
import { resolveAssetUrl } from "@/lib/api";

export interface ArticleFormValues {
  title: string;
  body: string;
  isPublished: boolean;
  pinned: boolean;
  category: string;
  cover: File | null;
}

// Tez tanlash uchun tavsiya etilgan bo'limlar (ixtiyoriy - admin o'zi ham yozadi).
const CATEGORY_SUGGESTIONS = ["Grammatika", "Writing", "Lug'at", "Maslahatlar", "Namunalar"];

export function ArticleForm({
  initial,
  submitLabel,
  onSubmit,
  submitting,
}: {
  initial?: {
    title: string;
    body: string;
    isPublished: boolean;
    pinned: boolean;
    category: string | null;
    coverImage: string | null;
  };
  submitLabel: string;
  onSubmit: (values: ArticleFormValues) => void;
  submitting: boolean;
}) {
  const [title, setTitle] = useState(initial?.title ?? "");
  const [body, setBody] = useState(initial?.body ?? "");
  const [isPublished, setIsPublished] = useState(initial?.isPublished ?? true);
  const [pinned, setPinned] = useState(initial?.pinned ?? false);
  const [category, setCategory] = useState(initial?.category ?? "");
  const [cover, setCover] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | undefined>(resolveAssetUrl(initial?.coverImage));
  const fileInputRef = useRef<HTMLInputElement>(null);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] ?? null;
    setCover(file);
    if (file) setPreview(URL.createObjectURL(file));
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({ title, body, isPublished, pinned, category: category.trim(), cover });
      }}
      className="space-y-5"
    >
      <div className="rounded-2xl bg-card p-5 shadow-card">
        <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Muqova rasm
        </label>
        <div className="mt-3 flex items-center gap-4">
          <div
            className="flex h-24 w-24 shrink-0 cursor-pointer items-center justify-center overflow-hidden rounded-xl bg-muted text-muted-foreground"
            onClick={() => fileInputRef.current?.click()}
          >
            {preview ? (
              <img src={preview} alt="" className="h-full w-full object-cover" />
            ) : (
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                className="h-8 w-8"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <path d="M21 15l-5-5L5 21" />
              </svg>
            )}
          </div>
          <div>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="rounded-lg border border-input bg-background px-3.5 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted"
            >
              Rasm tanlash
            </button>
            <p className="mt-1.5 text-xs text-muted-foreground">JPG, PNG — 5MB gacha</p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>
      </div>

      <div className="rounded-2xl bg-card p-5 shadow-card">
        <label
          htmlFor="title"
          className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
        >
          Sarlavha
        </label>
        <input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Maqola sarlavhasi"
          required
          className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      <div className="rounded-2xl bg-card p-5 shadow-card">
        <label
          htmlFor="body"
          className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
        >
          Matn
        </label>
        <textarea
          id="body"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Maqola matnini shu yerga yozing…"
          required
          rows={14}
          className="mt-2 w-full resize-y rounded-xl border border-input bg-background px-4 py-3 text-sm leading-relaxed text-foreground outline-none focus:ring-2 focus:ring-ring"
        />
        <p className="mt-1.5 text-xs text-muted-foreground">
          Paragraflarni ajratish uchun bo'sh qator qoldiring.
        </p>
      </div>

      <div className="rounded-2xl bg-card p-5 shadow-card">
        <label
          htmlFor="category"
          className="text-xs font-semibold uppercase tracking-wide text-muted-foreground"
        >
          Bo'lim (ixtiyoriy)
        </label>
        <input
          id="category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          placeholder="Masalan: Grammatika"
          maxLength={64}
          className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
        />
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {CATEGORY_SUGGESTIONS.map((c) => {
            const active = category.trim().toLowerCase() === c.toLowerCase();
            return (
              <button
                key={c}
                type="button"
                onClick={() => setCategory(active ? "" : c)}
                className="rounded-full px-3 py-1 text-[12px] font-medium transition-colors"
                style={{
                  backgroundColor: active ? "var(--primary)" : "var(--muted)",
                  color: active ? "var(--primary-foreground)" : "var(--muted-foreground)",
                }}
              >
                {c}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex items-center justify-between rounded-2xl bg-card p-5 shadow-card">
        <div>
          <p className="text-sm font-medium text-foreground">Yuqoriga qadash</p>
          <p className="text-xs text-muted-foreground">
            Qadalgan maqola roʻyxat boshida va "Tavsiya etilgan" blokida koʻrinadi.
          </p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={pinned}
          onClick={() => setPinned((v) => !v)}
          className="relative h-6 w-11 shrink-0 rounded-full transition-colors"
          style={{ backgroundColor: pinned ? "var(--primary)" : "var(--muted)" }}
        >
          <span
            className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform"
            style={{ transform: pinned ? "translateX(22px)" : "translateX(2px)" }}
          />
        </button>
      </div>

      <div className="flex items-center justify-between rounded-2xl bg-card p-5 shadow-card">
        <div>
          <p className="text-sm font-medium text-foreground">Eʼlon qilish</p>
          <p className="text-xs text-muted-foreground">
            Yoqilgan boʻlsa, maqola foydalanuvchilarga darhol koʻrinadi.
          </p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={isPublished}
          onClick={() => setIsPublished((v) => !v)}
          className="relative h-6 w-11 shrink-0 rounded-full transition-colors"
          style={{ backgroundColor: isPublished ? "var(--primary)" : "var(--muted)" }}
        >
          <span
            className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform"
            style={{ transform: isPublished ? "translateX(22px)" : "translateX(2px)" }}
          />
        </button>
      </div>

      <button
        type="submit"
        disabled={submitting || !title.trim() || !body.trim()}
        className="w-full rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
      >
        {submitting ? "Saqlanmoqda…" : submitLabel}
      </button>
    </form>
  );
}
