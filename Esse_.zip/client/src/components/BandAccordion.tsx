import { useState } from "react";
import { ArrowRight } from "lucide-react";
import type { BandResult } from "@/lib/api";
import { ScoreBadge } from "./ScoreBadge";

export function BandAccordion({ band }: { band: BandResult }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="overflow-hidden rounded-xl bg-card shadow-card">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-3 px-4 py-3.5 text-left transition-colors hover:bg-muted/50"
      >
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-semibold text-secondary-foreground tabular-nums">
          {band.band}
        </span>
        <span className="flex-1 text-sm font-medium text-foreground">{band.criterion_name}</span>
        <ScoreBadge score={band.score} />
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${
            open ? "rotate-180" : ""
          }`}
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      {open && (
        <div className="border-t border-border px-4 py-4">
          {band.comment && (
            <p className="text-sm leading-relaxed text-foreground/90">{band.comment}</p>
          )}

          {band.errors.length > 0 && (
            <div className="mt-4 space-y-3">
              {band.errors.map((err, i) => (
                <div key={i} className="rounded-lg border border-border bg-muted/40 p-3">
                  <div className="flex flex-wrap items-baseline gap-2">
                    <span
                      className="text-sm font-medium line-through decoration-2"
                      style={{ color: "var(--tone-bad)" }}
                    >
                      {err.original}
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={2} />
                    <span
                      className="text-sm font-semibold"
                      style={{ color: "var(--tone-excellent)" }}
                    >
                      {err.suggestion}
                    </span>
                  </div>
                  {err.explanation && (
                    <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                      {err.explanation}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
