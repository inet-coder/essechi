import { Link, useRouterState } from "@tanstack/react-router";
import { House, Library, PenLine, Trophy, User } from "lucide-react";
import type { LucideIcon } from "lucide-react";

function isActivePath(current: string, target: string) {
  if (target === "/") return current === "/";
  return current === target || current.startsWith(`${target}/`);
}

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/95 backdrop-blur-md"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="relative mx-auto grid max-w-[560px] grid-cols-5 items-center px-1">
        <TabLink to="/" label="Bosh sahifa" icon={House} active={isActivePath(pathname, "/")} />
        <TabLink
          to="/articles"
          label="Maqolalar"
          icon={Library}
          active={isActivePath(pathname, "/articles")}
        />

        {/* Center FAB - write essay (opens in-app chat) */}
        <div className="flex items-center justify-center">
          <Link
            to="/write"
            search={{ topic: undefined }}
            aria-label="Esse yozish"
            className="relative -top-4 flex h-14 w-14 items-center justify-center rounded-2xl text-white shadow-elevated ring-4 ring-background transition-transform active:scale-95"
            style={{ background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))" }}
          >
            <PenLine className="h-6 w-6" strokeWidth={2} />
          </Link>
        </div>

        <TabLink
          to="/leaderboard"
          label="Reyting"
          icon={Trophy}
          active={isActivePath(pathname, "/leaderboard")}
        />
        <TabLink
          to="/profile"
          label="Profil"
          icon={User}
          active={isActivePath(pathname, "/profile")}
        />
      </div>
    </nav>
  );
}

function TabLink({
  to,
  label,
  icon: Icon,
  active,
}: {
  to: string;
  label: string;
  icon: LucideIcon;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className="flex flex-col items-center gap-1 py-2.5 text-[10.5px] font-medium transition-colors"
      style={{ color: active ? "var(--primary)" : "var(--muted-foreground)" }}
    >
      <Icon className="h-5 w-5" strokeWidth={active ? 2.4 : 2} />
      <span>{label}</span>
    </Link>
  );
}