import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import type { CompetitionInput, CompetitionPrize } from "@/lib/api";

const DEFAULT_PRIZES: CompetitionPrize[] = [
  { place: 1, reward: "" },
  { place: 2, reward: "" },
  { place: 3, reward: "" },
];

// datetime-local uchun: ISO -> "YYYY-MM-DDTHH:mm" (lokal)
function toLocalInput(iso: string | null | undefined): string {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours(),
  )}:${pad(d.getMinutes())}`;
}

function fromLocalInput(value: string): string | null {
  return value ? new Date(value).toISOString() : null;
}

const labelClass = "text-xs font-semibold uppercase tracking-wide text-muted-foreground";
const inputClass =
  "mt-2 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring";

export function CompetitionForm({
  initial,
  submitLabel,
  onSubmit,
  submitting,
}: {
  initial?: Partial<CompetitionInput>;
  submitLabel: string;
  onSubmit: (values: CompetitionInput) => void;
  submitting: boolean;
}) {
  const [title, setTitle] = useState(initial?.title ?? "");
  const [topic, setTopic] = useState(initial?.topic ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [entryFee, setEntryFee] = useState(String(initial?.entryFee ?? 0));
  const [prizes, setPrizes] = useState<CompetitionPrize[]>(
    initial?.prizes && initial.prizes.length > 0 ? initial.prizes : DEFAULT_PRIZES,
  );
  const [startsAt, setStartsAt] = useState(toLocalInput(initial?.startsAt));
  const [endsAt, setEndsAt] = useState(toLocalInput(initial?.endsAt));

  function updatePrize(index: number, patch: Partial<CompetitionPrize>) {
    setPrizes((prev) => prev.map((p, i) => (i === index ? { ...p, ...patch } : p)));
  }

  function addPrize() {
    setPrizes((prev) => [...prev, { place: prev.length + 1, reward: "" }]);
  }

  function removePrize(index: number) {
    setPrizes((prev) => prev.filter((_, i) => i !== index).map((p, i) => ({ ...p, place: i + 1 })));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onSubmit({
      title: title.trim(),
      topic: topic.trim(),
      description: description.trim() || null,
      entryFee: parseInt(entryFee, 10) || 0,
      prizes: prizes
        .map((p, i) => ({ place: i + 1, reward: p.reward.trim() }))
        .filter((p) => p.reward.length > 0),
      startsAt: fromLocalInput(startsAt),
      endsAt: fromLocalInput(endsAt),
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="rounded-2xl bg-card p-5 shadow-card">
        <label htmlFor="title" className={labelClass}>
          Sarlavha
        </label>
        <input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Masalan: Yanvar oyi esse musobaqasi"
          required
          className={inputClass}
        />
      </div>

      <div className="rounded-2xl bg-card p-5 shadow-card">
        <label htmlFor="topic" className={labelClass}>
          Esse mavzusi (hamma uchun bir xil)
        </label>
        <textarea
          id="topic"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="Talabgorlar shu mavzuda esse yozadi…"
          required
          rows={3}
          className={`${inputClass} resize-y leading-relaxed`}
        />
      </div>

      <div className="rounded-2xl bg-card p-5 shadow-card">
        <label htmlFor="description" className={labelClass}>
          Tavsif / qoidalar (ixtiyoriy)
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Musobaqa haqida qisqacha…"
          rows={3}
          className={`${inputClass} resize-y leading-relaxed`}
        />
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
        <div className="rounded-2xl bg-card p-5 shadow-card">
          <label htmlFor="entryFee" className={labelClass}>
            Kirish to'lovi (so'm)
          </label>
          <input
            id="entryFee"
            type="number"
            min={0}
            value={entryFee}
            onChange={(e) => setEntryFee(e.target.value)}
            className={inputClass}
          />
        </div>
        <div className="rounded-2xl bg-card p-5 shadow-card">
          <label htmlFor="startsAt" className={labelClass}>
            Boshlanish (ixtiyoriy)
          </label>
          <input
            id="startsAt"
            type="datetime-local"
            value={startsAt}
            onChange={(e) => setStartsAt(e.target.value)}
            className={inputClass}
          />
        </div>
        <div className="rounded-2xl bg-card p-5 shadow-card">
          <label htmlFor="endsAt" className={labelClass}>
            Tugash (ixtiyoriy)
          </label>
          <input
            id="endsAt"
            type="datetime-local"
            value={endsAt}
            onChange={(e) => setEndsAt(e.target.value)}
            className={inputClass}
          />
        </div>
      </div>

      <div className="rounded-2xl bg-card p-5 shadow-card">
        <div className="flex items-center justify-between">
          <label className={labelClass}>Yutuqlar</label>
          <button
            type="button"
            onClick={addPrize}
            className="inline-flex items-center gap-1 rounded-lg bg-secondary px-2.5 py-1.5 text-xs font-semibold text-secondary-foreground transition-colors hover:opacity-80"
          >
            <Plus className="h-3.5 w-3.5" strokeWidth={2.5} />
            O'rin qo'shish
          </button>
        </div>

        <div className="mt-3 space-y-2.5">
          {prizes.map((prize, i) => (
            <div key={i} className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary-soft text-sm font-bold text-primary">
                {prize.place}
              </span>
              <input
                value={prize.reward}
                onChange={(e) => updatePrize(i, { reward: e.target.value })}
                placeholder="Masalan: 100 000 so'm yoki Planshet, Sertifikat"
                className="min-w-0 flex-1 rounded-xl border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
              />
              <button
                type="button"
                onClick={() => removePrize(i)}
                className="shrink-0 rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted"
                style={{ color: "var(--tone-bad)" }}
                aria-label="O'chirish"
              >
                <Trash2 className="h-4 w-4" strokeWidth={2} />
              </button>
            </div>
          ))}
        </div>
        <p className="mt-2.5 text-xs text-muted-foreground">
          Har o'rin uchun naqd pul yoki istalgan sovg'ani erkin yozing. Pul
          mukofoti avtomatik tushmaydi — g'oliblarga admin qo'lda beradi.
        </p>
      </div>

      <button
        type="submit"
        disabled={submitting || !title.trim() || !topic.trim()}
        className="w-full rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
      >
        {submitting ? "Saqlanmoqda…" : submitLabel}
      </button>
    </form>
  );
}
