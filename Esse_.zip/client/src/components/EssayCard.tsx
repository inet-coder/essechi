import { Link } from "@tanstack/react-router";
import { Check, Clock, TriangleAlert, X } from "lucide-react";
import type { Essay } from "@/lib/api";
import { formatDate, totalTone } from "@/lib/format";

function StatusPill({ essay }: { essay: Essay }) {
  const ev = essay.evaluationResult;
  if (!ev) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
        <Clock className="h-3 w-3" strokeWidth={2} />
        Tekshirilmagan
      </span>
    );
  }
  if (ev.status === "completed") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium"
        style={{
          backgroundColor: "var(--tone-excellent-soft)",
          color: "var(--tone-excellent)",
        }}
      >
        <Check className="h-3 w-3" strokeWidth={2.5} />
        Tekshirildi
      </span>
    );
  }
  if (ev.status === "auto_rejected") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium"
        style={{
          backgroundColor: "var(--tone-weak-soft)",
          color: "var(--tone-weak)",
        }}
      >
        <TriangleAlert className="h-3 w-3" strokeWidth={2} />
        Rad etildi
      </span>
    );
  }
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium"
      style={{
        backgroundColor: "var(--tone-bad-soft)",
        color: "var(--tone-bad)",
      }}
    >
      <X className="h-3 w-3" strokeWidth={2.5} />
      Xatolik
    </span>
  );
}

export function EssayCard({ essay }: { essay: Essay }) {
  const ev = essay.evaluationResult;
  const showScore = ev && (ev.status === "completed" || ev.status === "auto_rejected");
  const tone = showScore ? totalTone(ev.totalScore) : "ok";

  return (
    <Link
      to="/essay/$id"
      params={{ id: String(essay.id) }}
      className="block rounded-2xl bg-card p-4 shadow-card transition-transform active:scale-[0.99]"
    >
      <div className="flex items-start gap-4">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="tabular-nums">{formatDate(essay.createdAt)}</span>
            <span className="opacity-40">•</span>
            <span>{essay.wordCount} soʻz</span>
          </div>
          <p className="mt-1.5 line-clamp-2 text-sm font-medium leading-snug text-foreground">
            {essay.topic}
          </p>
          <div className="mt-2.5">
            <StatusPill essay={essay} />
          </div>
        </div>

        {showScore && (
          <div
            className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-xl text-center"
            style={{
              backgroundColor: `var(--tone-${tone}-soft)`,
              color: `var(--tone-${tone})`,
            }}
          >
            <span className="text-xl font-bold leading-none tabular-nums">{ev!.scaledScore}</span>
            <span className="mt-0.5 text-[10px] opacity-80">/ 75</span>
          </div>
        )}
      </div>
    </Link>
  );
}
