import { useRef, useState } from "react";
import {
  ArrowRight,
  Check,
  ImagePlus,
  Loader2,
  ScanText,
  Sparkles,
  Trash2,
  X,
  XCircle,
} from "lucide-react";
import { ApiError, type ImageOcrResult } from "@/lib/api";
import { formatSum } from "@/lib/format";

function countWords(s: string): number {
  const t = s.trim();
  return t ? t.split(/\s+/).filter(Boolean).length : 0;
}

// Rasm(lar)dan matn o'qish oqimi: rasm tanlash -> OCR -> tahrirlanadigan matn ->
// tasdiqlash. Ham esse tekshiruvida (pullik), ham musobaqada (tekin) ishlatiladi.
// pagePrice berilsa "pullik" ogohlantirishi, berilmasa "tekin" ko'rsatiladi.
export function ImageOcrPanel({
  extract,
  onConfirm,
  confirmLabel,
  confirming,
  minWords,
  maxPages,
  pagePrice,
}: {
  extract: (files: File[]) => Promise<ImageOcrResult>;
  onConfirm: (text: string, ocrReceipt?: string) => void;
  confirmLabel: string;
  confirming: boolean;
  minWords: number;
  maxPages: number;
  pagePrice?: number;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [reading, setReading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // OCR muvaffaqiyatli bo'lgach: tahrirlanadigan matn + (pullik oqimda) kvitansiya.
  const [text, setText] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<string | undefined>(undefined);

  const paid = typeof pagePrice === "number" && pagePrice > 0;

  function addFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const picked = Array.from(e.target.files ?? []);
    e.target.value = "";
    if (picked.length === 0) return;
    setError(null);
    setFiles((prev) => [...prev, ...picked].slice(0, maxPages));
  }

  function removeFile(index: number) {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  }

  async function runExtract() {
    if (files.length === 0) return;
    setReading(true);
    setError(null);
    try {
      const result = await extract(files);
      setText(result.text);
      setReceipt(result.ocrReceipt);
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : "Rasmni o'qishda xatolik. Qayta urinib ko'ring.",
      );
    } finally {
      setReading(false);
    }
  }

  function reset() {
    setFiles([]);
    setText(null);
    setReceipt(undefined);
    setError(null);
  }

  // 3-bosqich: o'qilgan matnni tahrirlash + tasdiqlash.
  if (text !== null) {
    const words = countWords(text);
    const enough = words >= minWords;
    return (
      <div className="flex flex-1 flex-col overflow-hidden">
        <div
          className="mt-3 flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-[12.5px] font-medium"
          style={{ backgroundColor: "var(--tone-good-soft)", color: "var(--tone-good)" }}
        >
          <ScanText className="h-4 w-4 shrink-0" strokeWidth={2} />
          Matn o'qildi — tekshirib, kerak bo'lsa tuzating.
        </div>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="mt-3 min-h-[220px] flex-1 resize-none rounded-2xl border border-border bg-card p-4 text-[14px] leading-relaxed text-foreground shadow-card outline-none placeholder:text-muted-foreground focus:border-primary/40"
        />

        <div className="mt-3 flex shrink-0 items-center gap-2.5">
          <button
            type="button"
            onClick={reset}
            className="flex h-11 shrink-0 items-center gap-1.5 rounded-2xl border border-border bg-card px-3.5 text-[13px] font-semibold text-foreground transition-colors hover:bg-muted"
          >
            <ImagePlus className="h-4 w-4" strokeWidth={2} />
            Boshqa rasm
          </button>
          <div className="min-w-0 flex-1 text-right">
            {enough ? (
              <p
                className="flex items-center justify-end gap-1 text-[12.5px] font-semibold"
                style={{ color: "var(--tone-good)" }}
              >
                <Check className="h-3.5 w-3.5 shrink-0" strokeWidth={2.5} />
                {words} so'z
              </p>
            ) : (
              <p className="text-[12.5px] font-medium text-muted-foreground">
                Yana <span className="font-bold text-foreground">{minWords - words}</span> so'z
                kerak
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={() => onConfirm(text, receipt)}
            disabled={!enough || confirming}
            className="flex h-11 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-2xl bg-primary px-5 text-[14px] font-semibold text-primary-foreground shadow-card transition-all hover:opacity-90 disabled:opacity-40"
          >
            {confirming ? (
              <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2} />
            ) : (
              <ArrowRight className="h-4 w-4 shrink-0" strokeWidth={2.2} />
            )}
            {confirmLabel}
          </button>
        </div>
      </div>
    );
  }

  // 1-2 bosqich: rasm tanlash + o'qishga yuborish.
  const cost = paid ? files.length * (pagePrice as number) : 0;
  return (
    <div className="mt-3 flex flex-1 flex-col">
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        multiple
        onChange={addFiles}
        className="hidden"
      />

      {files.length === 0 ? (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="flex min-h-[200px] flex-1 flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border bg-card p-8 text-center transition-colors hover:border-primary/50 hover:bg-primary-soft/30"
        >
          <span
            className="flex h-14 w-14 items-center justify-center rounded-2xl"
            style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
          >
            <ImagePlus className="h-6 w-6" strokeWidth={2} />
          </span>
          <span>
            <span className="block text-[15px] font-semibold text-foreground">
              Qo'lyozma suratini tanlang
            </span>
            <span className="mt-1 block text-[12.5px] text-muted-foreground">
              Yorug', aniq surat oling — matn to'g'ri o'qiladi
            </span>
          </span>
          <span className="mt-1 rounded-xl bg-primary px-4 py-2 text-[13px] font-semibold text-primary-foreground">
            Rasm tanlash
          </span>
        </button>
      ) : (
        <div className="flex flex-1 flex-col">
          <div className="space-y-2">
            {files.map((f, i) => (
              <div
                key={i}
                className="flex items-center gap-2.5 rounded-xl border border-border bg-card px-3 py-2.5 shadow-card"
              >
                <span
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-[11px] font-bold"
                  style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
                >
                  {i + 1}
                </span>
                <span className="min-w-0 flex-1 truncate text-[13px] text-foreground">
                  {f.name}
                </span>
                <button
                  type="button"
                  onClick={() => removeFile(i)}
                  className="shrink-0 rounded-lg p-1.5 transition-colors hover:bg-muted"
                  style={{ color: "var(--tone-bad)" }}
                  aria-label="O'chirish"
                >
                  <Trash2 className="h-4 w-4" strokeWidth={2} />
                </button>
              </div>
            ))}
          </div>

          {files.length < maxPages && (
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="mt-2 flex items-center justify-center gap-1.5 rounded-xl border border-dashed border-border py-2.5 text-[13px] font-semibold text-muted-foreground transition-colors hover:bg-muted"
            >
              <ImagePlus className="h-4 w-4" strokeWidth={2} />
              Yana varaq qo'shish
            </button>
          )}
        </div>
      )}

      {error && (
        <div
          className="mt-3 flex shrink-0 items-start gap-2 whitespace-pre-wrap rounded-2xl px-3.5 py-3 text-[13px] leading-relaxed"
          style={{ backgroundColor: "var(--tone-bad-soft)", color: "var(--tone-bad)" }}
        >
          <XCircle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2} aria-hidden />
          <span>{error}</span>
        </div>
      )}

      {files.length > 0 && (
        <div className="mt-3 shrink-0">
          <div
            className="flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-center text-[12px] font-medium"
            style={{
              backgroundColor: paid ? "var(--tone-weak-soft)" : "var(--tone-excellent-soft)",
              color: paid ? "var(--tone-weak)" : "var(--tone-excellent)",
            }}
          >
            {paid ? (
              <>
                <Sparkles className="h-3.5 w-3.5 shrink-0" strokeWidth={2} />
                {files.length} varaq × {formatSum(pagePrice as number)} ={" "}
                <span className="font-bold">{formatSum(cost)}</span> balansdan yechiladi
              </>
            ) : (
              <>
                <Sparkles className="h-3.5 w-3.5 shrink-0" strokeWidth={2} />
                Rasmdan matn o'qish — bepul
              </>
            )}
          </div>

          <div className="mt-3 flex items-center gap-2">
            <button
              type="button"
              onClick={reset}
              className="flex h-11 shrink-0 items-center justify-center rounded-2xl border border-border bg-card px-3.5 text-muted-foreground transition-colors hover:bg-muted"
              aria-label="Bekor qilish"
              disabled={reading}
            >
              <X className="h-4 w-4" strokeWidth={2} />
            </button>
            <button
              type="button"
              onClick={runExtract}
              disabled={reading}
              className="flex h-11 flex-1 items-center justify-center gap-1.5 rounded-2xl bg-primary text-[14px] font-semibold text-primary-foreground shadow-card transition-all hover:opacity-90 disabled:opacity-50"
            >
              {reading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2} />
                  O'qilmoqda…
                </>
              ) : (
                <>
                  <ScanText className="h-4 w-4" strokeWidth={2} />
                  Matnni o'qish
                </>
              )}
            </button>
          </div>
        </div>
      )}

      <p className="mt-3 shrink-0 text-center text-[11.5px] text-muted-foreground">
        JPEG, PNG yoki WEBP · eng ko'pi {maxPages} varaq · kamida {minWords} so'z
      </p>
    </div>
  );
}
