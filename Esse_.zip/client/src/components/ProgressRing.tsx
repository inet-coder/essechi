interface Props {
  value: number;
  max: number;
  size?: number;
  stroke?: number;
  tone: "excellent" | "good" | "ok" | "weak" | "bad";
  centerLabel: string;
  subLabel?: string;
}

export function ProgressRing({
  value,
  max,
  size = 128,
  stroke = 11,
  tone,
  centerLabel,
  subLabel,
}: Props) {
  const pct = Math.max(0, Math.min(1, max > 0 ? value / max : 0));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = c * pct;

  return (
    <div
      className="relative inline-flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={`var(--tone-${tone}-soft)`}
          strokeWidth={stroke}
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={`var(--tone-${tone})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${dash} ${c - dash}`}
          style={{ transition: "stroke-dasharray 600ms ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-2xl font-bold tabular-nums text-foreground">{centerLabel}</div>
        {subLabel && <div className="mt-0.5 text-[11px] text-muted-foreground">{subLabel}</div>}
      </div>
    </div>
  );
}
