import { scoreTone } from "@/lib/format";

export function ScoreBadge({ score, max = 2 }: { score: number; max?: number }) {
  const tone = scoreTone(score);
  return (
    <span
      className="inline-flex min-w-[2.75rem] items-center justify-center rounded-full px-2.5 py-1 text-xs font-semibold tabular-nums"
      style={{
        backgroundColor: `var(--tone-${tone}-soft)`,
        color: `var(--tone-${tone})`,
      }}
    >
      {Number.isInteger(score) ? score : score.toFixed(1)}/{max}
    </span>
  );
}
