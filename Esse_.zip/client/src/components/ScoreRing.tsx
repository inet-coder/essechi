import { totalTone } from "@/lib/format";

interface Props {
  totalScore: number;
  scaledScore: number;
  size?: number;
}

export function ScoreRing({ totalScore, scaledScore, size = 140 }: Props) {
  const tone = totalTone(totalScore);
  const pct = Math.max(0, Math.min(1, totalScore / 24));

  const stroke = 10; // Biroq ingichka va zamonaviyroq
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = c * pct;

  return (
    <div
      className="relative flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} className="rotate-[-90deg]">
        {/* Fon halqasi */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="currentColor"
          strokeWidth={stroke}
          fill="none"
          className="text-muted/20"
        />
        {/* Asosiy progress halqasi */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={`var(--tone-${tone})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${dash} ${c}`}
          className="transition-all duration-700 ease-out"
          style={{ filter: "drop-shadow(0 0 4px var(--tone-base))" }}
        />
      </svg>

      {/* Markaziy qism */}
      <div className="absolute flex flex-col items-center justify-center">
        <span className="text-4xl font-extrabold tracking-tight text-foreground">
          {scaledScore}
        </span>
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
          {totalScore} / 24 ball
        </span>
      </div>
    </div>
  );
}
