import { Link } from "@tanstack/react-router";
import type { LucideIcon } from "lucide-react";

const TONE_STYLES: Record<string, { bg: string; fg: string }> = {
  primary: { bg: "var(--primary-soft)", fg: "var(--primary)" },
  excellent: { bg: "var(--tone-excellent-soft)", fg: "var(--tone-excellent)" },
  good: { bg: "var(--tone-good-soft)", fg: "var(--tone-good)" },
  ok: { bg: "var(--tone-ok-soft)", fg: "var(--tone-ok)" },
  weak: { bg: "var(--tone-weak-soft)", fg: "var(--tone-weak)" },
};

export function SectionHeader({
  icon: Icon,
  title,
  subtitle,
  linkTo,
  linkLabel = "Hammasi",
  tone = "primary",
}: {
  icon?: LucideIcon;
  title: string;
  subtitle?: string;
  linkTo?: string;
  linkLabel?: string;
  tone?: keyof typeof TONE_STYLES;
}) {
  const style = TONE_STYLES[tone];
  return (
    <div className="mb-3 flex items-end justify-between px-1">
      <div className="flex items-center gap-2.5">
        {Icon && (
          <span
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl"
            style={{ backgroundColor: style.bg, color: style.fg }}
            aria-hidden
          >
            <Icon className="h-4 w-4" strokeWidth={2} />
          </span>
        )}
        <div>
          <h2 className="text-[17px] font-bold leading-tight text-foreground">{title}</h2>
          {subtitle && <p className="mt-0.5 text-[12.5px] text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
      {linkTo && (
        <Link
          to={linkTo}
          className="shrink-0 text-[13px] font-semibold text-primary transition-opacity hover:opacity-70"
        >
          {linkLabel}
        </Link>
      )}
    </div>
  );
}
