export function Skeleton({ className = "" }: { className?: string }) {
  return (
    <div
      className={`animate-pulse rounded-lg bg-muted ${className}`}
      style={{
        backgroundImage: "linear-gradient(90deg, var(--muted), var(--secondary), var(--muted))",
        backgroundSize: "200% 100%",
      }}
    />
  );
}
