import type { ReactNode } from "react";
import { isInTelegram } from "@/lib/telegram";

export function TelegramGate({ children }: { children: ReactNode }) {
  // In SSR there is no window — render children optimistically; the API client
  // will block requests until initData is present, and the client re-renders
  // after hydration when window.Telegram becomes available.
  if (typeof window === "undefined") return <>{children}</>;
  if (isInTelegram()) return <>{children}</>;

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-6">
      <div className="w-full max-w-sm rounded-2xl bg-card p-8 text-center shadow-card">
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-primary-soft text-primary">
          <svg viewBox="0 0 24 24" fill="currentColor" className="h-7 w-7">
            <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z" />
          </svg>
        </div>
        <h1 className="text-lg font-semibold text-foreground">
          Bu ilova faqat Telegram orqali ishlaydi
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">Iltimos, botdagi tugma orqali oching.</p>
      </div>
    </div>
  );
}
