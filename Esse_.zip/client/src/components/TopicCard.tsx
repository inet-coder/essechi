import { Link } from "@tanstack/react-router";
import { PenLine } from "lucide-react";
import type { Topic } from "@/lib/api";

export function TopicCard({ topic }: { topic: Topic }) {
  return (
    <div className="flex w-[248px] shrink-0 flex-col justify-between rounded-2xl bg-card p-4 shadow-card">
      <div>
        <span
          className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold"
          style={{ backgroundColor: "var(--tone-ok-soft)", color: "var(--tone-ok)" }}
        >
          <PenLine className="h-3 w-3" strokeWidth={2} />
          Esse mavzusi
        </span>
        <p className="mt-2.5 line-clamp-4 text-[14px] font-medium leading-snug text-foreground">
          {topic.text}
        </p>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="h-3.5 w-3.5"
          >
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          ~40 daqiqa
        </span>
        <Link
          to="/write"
          search={{ topic: topic.text }}
          className="rounded-lg bg-primary px-3 py-1.5 text-[12px] font-semibold text-primary-foreground transition-opacity hover:opacity-90 active:scale-95"
        >
          Yozishni boshlash
        </Link>
      </div>
    </div>
  );
}
