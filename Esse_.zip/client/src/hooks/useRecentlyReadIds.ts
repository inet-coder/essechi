import { useEffect, useState } from "react";
import { getRecentlyReadIds } from "@/lib/recentlyRead";

/**
 * Sahifa mount bo'lganda localStorage'dan "so'nggi o'qilgan" maqola
 * ID'larini o'qiydi. SSR paytida bo'sh massiv qaytaradi, keyin
 * hydratsiyadan so'ng client'da to'ldiriladi.
 */
export function useRecentlyReadIds(): number[] {
  const [ids, setIds] = useState<number[]>([]);

  useEffect(() => {
    setIds(getRecentlyReadIds());
  }, []);

  return ids;
}
