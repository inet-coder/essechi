import { useCallback, useEffect, useState } from "react";
import { getTelegram } from "@/lib/telegram";

export type Theme = "light" | "dark";

const STORAGE_KEY = "esse-theme";

function systemPrefersDark(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
}

function resolveInitialTheme(): Theme {
  if (typeof window === "undefined") return "light";

  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored === "light" || stored === "dark") return stored;

  const tgScheme = getTelegram()?.colorScheme;
  if (tgScheme === "light" || tgScheme === "dark") return tgScheme;

  return systemPrefersDark() ? "dark" : "light";
}

function applyTheme(theme: Theme) {
  document.documentElement.classList.toggle("dark", theme === "dark");
}

/**
 * Ilova mavzusini (light/dark) boshqaradi.
 * Ustuvorlik: foydalanuvchi qo'lda tanlagan tanlov (localStorage)
 * > Telegram klientining o'z mavzusi > tizim mavzusi.
 */
export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(() => resolveInitialTheme());

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  // Foydalanuvchi hali qo'lda tanlamagan bo'lsa, Telegram mavzusi
  // o'zgarganda (masalan tizim mavzusi almashsa) avtomatik moslashtiramiz.
  useEffect(() => {
    if (window.localStorage.getItem(STORAGE_KEY)) return;

    const tg = getTelegram();
    if (!tg) return;

    const handleThemeChanged = () => {
      const scheme = tg.colorScheme;
      if (scheme === "light" || scheme === "dark") setThemeState(scheme);
    };

    (
      tg as unknown as {
        onEvent?: (event: string, cb: () => void) => void;
        offEvent?: (event: string, cb: () => void) => void;
      }
    ).onEvent?.("themeChanged", handleThemeChanged);

    return () => {
      (tg as unknown as { offEvent?: (event: string, cb: () => void) => void }).offEvent?.(
        "themeChanged",
        handleThemeChanged,
      );
    };
  }, []);

  const setTheme = useCallback((next: Theme) => {
    window.localStorage.setItem(STORAGE_KEY, next);
    setThemeState(next);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(theme === "dark" ? "light" : "dark");
  }, [theme, setTheme]);

  return { theme, setTheme, toggleTheme };
}
