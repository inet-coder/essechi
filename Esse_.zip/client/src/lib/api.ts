import { getInitData } from "./telegram";

const BASE_URL =
  (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, "") ?? "";

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

async function request<T>(path: string): Promise<T> {
  const initData = getInitData();
  if (!initData) throw new ApiError(0, "no_telegram");
  if (!BASE_URL) throw new ApiError(0, "VITE_API_BASE_URL sozlanmagan");

  let res: Response;
  try {
    res = await fetch(`${BASE_URL}${path}`, {
      headers: { "x-telegram-init-data": initData },
    });
  } catch {
    throw new ApiError(0, "network");
  }
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) msg = data.error;
    } catch {
      /* noop */
    }
    throw new ApiError(res.status, msg);
  }
  return (await res.json()) as T;
}

// Telegram initData bilan tasdiqlangan POST so'rov (matn/JSON yoki fayl
// yuklash uchun FormData). Esse yuborish va tekshirish shu orqali ishlaydi.
async function authPost<T>(path: string, body: Record<string, unknown> | FormData): Promise<T> {
  const initData = getInitData();
  if (!initData) throw new ApiError(0, "no_telegram");
  if (!BASE_URL) throw new ApiError(0, "VITE_API_BASE_URL sozlanmagan");

  const isFormData = body instanceof FormData;

  let res: Response;
  try {
    res = await fetch(`${BASE_URL}${path}`, {
      method: "POST",
      headers: isFormData
        ? { "x-telegram-init-data": initData }
        : { "x-telegram-init-data": initData, "Content-Type": "application/json" },
      body: isFormData ? body : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, "network");
  }
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) msg = data.error;
    } catch {
      /* noop */
    }
    throw new ApiError(res.status, msg);
  }
  return (await res.json()) as T;
}

// Telegram initData bilan tasdiqlangan PATCH so'rov (JSON). Profilni yangilash
// (masalan ism o'zgartirish) shu orqali ishlaydi.
async function authPatch<T>(path: string, body: Record<string, unknown>): Promise<T> {
  const initData = getInitData();
  if (!initData) throw new ApiError(0, "no_telegram");
  if (!BASE_URL) throw new ApiError(0, "VITE_API_BASE_URL sozlanmagan");

  let res: Response;
  try {
    res = await fetch(`${BASE_URL}${path}`, {
      method: "PATCH",
      headers: { "x-telegram-init-data": initData, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, "network");
  }
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) msg = data.error;
    } catch {
      /* noop */
    }
    throw new ApiError(res.status, msg);
  }
  return (await res.json()) as T;
}

// Telegram initData'dan mustaqil, oddiy so'rov (masalan public maqolalar uchun)
async function publicRequest<T>(path: string): Promise<T> {
  if (!BASE_URL) throw new ApiError(0, "VITE_API_BASE_URL sozlanmagan");

  let res: Response;
  try {
    res = await fetch(`${BASE_URL}${path}`);
  } catch {
    throw new ApiError(0, "network");
  }
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) msg = data.error;
    } catch {
      /* noop */
    }
    throw new ApiError(res.status, msg);
  }
  return (await res.json()) as T;
}

// --- Admin ---

const ADMIN_KEY_STORAGE = "esse_admin_key";

export function getAdminKey(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(ADMIN_KEY_STORAGE);
}

export function setAdminKey(key: string) {
  if (typeof window === "undefined") return;
  localStorage.setItem(ADMIN_KEY_STORAGE, key);
}

export function clearAdminKey() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(ADMIN_KEY_STORAGE);
}

async function adminRequest<T>(
  path: string,
  options: { method?: string; body?: FormData; json?: unknown } = {},
): Promise<T> {
  if (!BASE_URL) throw new ApiError(0, "VITE_API_BASE_URL sozlanmagan");
  const adminKey = getAdminKey();
  if (!adminKey) throw new ApiError(401, "admin_key_missing");

  const headers: Record<string, string> = { "x-admin-key": adminKey };
  let body: BodyInit | undefined = options.body;
  if (options.json !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(options.json);
  }

  let res: Response;
  try {
    res = await fetch(`${BASE_URL}${path}`, {
      method: options.method ?? "GET",
      headers,
      body,
    });
  } catch {
    throw new ApiError(0, "network");
  }
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const data = (await res.json()) as { error?: string };
      if (data?.error) msg = data.error;
    } catch {
      /* noop */
    }
    throw new ApiError(res.status, msg);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export interface Me {
  id: number;
  telegramId: string;
  firstName: string;
  username?: string;
  totalAttemptsUsed: number;
  balance: number;
  // Esse tekshiruv krediti - paketlar orqali olinadi, balansdan ALOHIDA.
  essayCredits: number;
  // Bir martalik (umr bo'yi) bepul tekshiruv hali mavjudmi.
  freeEssayAvailable: boolean;
  // Qolgan bepul tekshiruvlar soni.
  freeEssayRemaining: number;
  // Paketsiz (bir martalik) tekshiruv narxi (so'm) - balansdan yechiladi.
  singleCheckPrice: number;
  // Rasm orqali tekshirishda har varaq narxi (so'm) va maksimal varaq soni.
  imagePagePrice: number;
  imageMaxPages: number;
  createdAt: string;
  updatedAt: string;
}

export interface EssayPackage {
  id: number;
  credits: number;
  price: number;
}

export interface ErrorItem {
  original: string;
  suggestion: string;
  explanation: string;
}

export interface BandResult {
  band: number;
  criterion_name: string;
  score: number;
  errors: ErrorItem[];
  comment: string;
}

export type EvaluationStatus = "completed" | "auto_rejected" | "failed";

export interface EvaluationResult {
  id: number;
  status: EvaluationStatus;
  totalScore: number;
  scaledScore: number;
  bandResults: BandResult[];
  recommendations: string[];
  rejectionReason: string | null;
}

export interface Essay {
  id: number;
  topic: string;
  sourceType: string;
  rawText: string;
  wordCount: number;
  language: string;
  createdAt: string;
  evaluationResult: EvaluationResult | null;
}

// Reytingdagi boshqa foydalanuvchining essesini ochib ko'rish - muallif ismi
// bilan (o'z essemizdan farqli ravishda "kim yozgani" ko'rsatiladi).
export interface PublicEssay extends Essay {
  authorName: string;
}

export interface BandStat {
  band: number;
  criterionName: string;
  averageScore: number;
  essayCount: number;
}

export interface MyStats {
  essayCount: number;
  bands: BandStat[];
}

export type LeaderboardPeriod = "daily" | "weekly" | "monthly";
// Tartiblash ko'rsatkichi: "score" - eng yuqori ball, "count" - esselar soni.
export type LeaderboardMetric = "score" | "count";

export interface LeaderboardEntry {
  rank: number;
  userId: number;
  firstName: string;
  scaledScore: number;
  totalScore: number;
  // Davr ichida tekshirilgan esselar soni.
  essayCount: number;
  achievedAt: string;
  // Ushbu natijani bergan esse - bosilganda tahlilini ochib ko'rish uchun.
  essayId: number;
}

export interface Leaderboard {
  period: LeaderboardPeriod;
  metric: LeaderboardMetric;
  leaderboard: LeaderboardEntry[];
}

export interface WeakestBand {
  criterionName: string;
  averageScore: number;
}

export interface MySummary {
  totalEssayCount: number;
  checkedEssayCount: number;
  bestScaledScore: number | null;
  averageScaledScore: number | null;
  weakestBand: WeakestBand | null;
}

export interface AiRecurringMistake {
  title: string;
  description: string;
}

export interface AiAnalysisContent {
  overallSummary: string;
  recurringMistakes: AiRecurringMistake[];
  strengths: string[];
  actionPlan: string[];
  motivationalNote: string;
}

export interface AiAnalysisRecord {
  id: number;
  content: AiAnalysisContent;
  wasFree: boolean;
  createdAt: string;
}

export interface AiAnalysisStatus {
  isFree: boolean;
  nextFreeAt: string | null;
  price: number;
  balance: number;
  lastAnalysis: AiAnalysisRecord | null;
}

export interface QuizQuestion {
  id: number;
  criterionName: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizAnswer {
  questionId: number;
  selectedIndex: number;
}

export interface QuizRecord {
  id: number;
  questions: QuizQuestion[];
  answers: QuizAnswer[] | null;
  score: number | null;
  wasFree: boolean;
  completedAt: string | null;
  createdAt: string;
}

export interface QuizStatus {
  isFree: boolean;
  nextFreeAt: string | null;
  price: number;
  balance: number;
  lastQuiz: QuizRecord | null;
  random: {
    available: boolean;
    poolSize: number;
    min: number;
    max: number;
  };
}

export interface Topic {
  id: number;
  text: string;
  isActive: boolean;
  createdAt: string;
  category: { id: number; name: string } | null;
}

export interface Category {
  id: number;
  name: string;
  isActive: boolean;
  createdAt: string;
}

export interface Article {
  id: number;
  title: string;
  coverImage: string | null;
  category: string | null;
  createdAt: string;
  readingMinutes: number;
  excerpt: string;
}

export interface ArticleDetail extends Article {
  body: string;
  isPublished: boolean;
  pinned: boolean;
  sortOrder: number;
  updatedAt: string;
}

export interface CreatedEssay {
  id: number;
  topic: string;
  sourceType: string;
  wordCount: number;
}

export type CompetitionStatus =
  "draft" | "upcoming" | "open" | "closed" | "evaluating" | "finished" | "cancelled";

export interface CompetitionPrize {
  place: number;
  // Erkin matn: naqd pul yoki istalgan sovg'a (masalan "100 000 so'm",
  // "Planshet", "Sertifikat"). Pul mukofoti avtomatik tushmaydi - admin beradi.
  reward: string;
}

export interface AdminUserBalance {
  telegramId: string;
  firstName: string | null;
  balance: number;
  essayCredits: number;
}

export interface AdminBalanceResult {
  telegramId: string;
  firstName: string | null;
  balance: number;
  applied: number;
}

export interface AdminStats {
  userCount: number;
  usersToday: number;
  essayCount: number;
  checkedCount: number;
  essaysToday: number;
  pendingPayments: number;
  revenue: number;
  paidPaymentsCount: number;
  avgScaledScore: number | null;
}

export interface AdminFreeEssaySettings {
  // Har bir foydalanuvchiga beriladigan bepul tekshiruvlar soni.
  limit: number;
  // Jami sarflangan bepul tekshiruvlar.
  totalUsed: number;
  // Kamida bitta bepuldan foydalangan foydalanuvchilar.
  usersUsedAny: number;
  // Limitni to'liq ishlatib bo'lganlar.
  usersUsedUp: number;
  // Hali bepul qolgan foydalanuvchilar.
  usersWithRemaining: number;
  userCount: number;
}

export interface AdminUserListItem {
  id: number;
  telegramId: string;
  firstName: string | null;
  username: string | null;
  balance: number;
  essayCredits: number;
  essayCount: number;
  createdAt: string;
}

export interface AdminUserList {
  users: AdminUserListItem[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}

export interface AdminPayment {
  id: number;
  amount: number;
  requestedAmount: number | null;
  status: string;
  kind: string;
  essayCredits: number | null;
  provider: string | null;
  note: string | null;
  createdAt: string;
}

export interface AdminPaymentWithUser extends AdminPayment {
  user: { telegramId: string; firstName: string | null; username: string | null } | null;
}

export interface AdminPaymentList {
  payments: AdminPaymentWithUser[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}

export interface AdminCreditGrant {
  id: number;
  credits: number;
  remaining: number;
  source: string;
  expiresAt: string;
  active: boolean;
  createdAt: string;
}

export interface AdminUserEssay {
  id: number;
  topic: string;
  sourceType: string;
  status: string;
  wordCount: number;
  createdAt: string;
  evaluationResult: {
    status: string;
    totalScore: number;
    scaledScore: number;
  } | null;
}

export interface AdminUserDetail {
  user: {
    id: number;
    telegramId: string;
    firstName: string | null;
    username: string | null;
    balance: number;
    essayCredits: number;
    totalAttemptsUsed: number;
    freeEssayUsed: boolean;
    freeEssaysUsed: number;
    createdAt: string;
  };
  payments: AdminPayment[];
  grants: AdminCreditGrant[];
  essays: AdminUserEssay[];
}

export interface AdminEssayListItem {
  id: number;
  topic: string;
  sourceType: string;
  status: string;
  wordCount: number;
  createdAt: string;
  author: { telegramId: string; firstName: string | null } | null;
  evaluationResult: {
    status: string;
    totalScore: number;
    scaledScore: number;
  } | null;
}

export interface AdminEssayList {
  essays: AdminEssayListItem[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}

export interface AdminEssayDetail {
  id: number;
  topic: string;
  sourceType: string;
  rawText: string;
  wordCount: number;
  language: string;
  status: string;
  createdAt: string;
  author: { telegramId: string; firstName: string | null; username: string | null } | null;
  evaluationResult: {
    status: EvaluationStatus;
    totalScore: number;
    scaledScore: number;
    bandResults: BandResult[];
    recommendations: string[];
    rejectionReason: string | null;
  } | null;
}

export interface Competition {
  id: number;
  title: string;
  description: string | null;
  topic: string;
  entryFee: number;
  status: CompetitionStatus;
  prizes: CompetitionPrize[];
  essaysPublic: boolean;
  startsAt: string | null;
  endsAt: string | null;
  createdAt: string;
  updatedAt: string;
  // Ro'yxatdan o'tganlar va (kirish to'lovini to'lagan) ishtirokchilar soni.
  registeredCount?: number;
  participantCount?: number;
}

export interface CompetitionDetail {
  competition: Competition;
  // Ro'yxatdan o'tganmi (to'lagan yoki faqat band qilgan).
  joined: boolean;
  // Kirish to'lovini to'lab to'liq ishtirokchi bo'lganmi (esse yubora oladi).
  paid: boolean;
  hasEssay: boolean;
  entryEssayId: number | null;
  registeredCount: number;
  participantCount: number;
}

// Rasmdan matn o'qish natijasi. ocrReceipt faqat pullik (esse tekshiruvi)
// oqimida qaytadi - musobaqada OCR tekin bo'lgani uchun kvitansiya yo'q.
export interface ImageOcrResult {
  text: string;
  pages: number;
  ocrReceipt?: string;
  charged?: number;
}

export interface CompetitionRankingEntry {
  rank: number;
  userId: number;
  firstName: string;
  scaledScore: number | null;
  status: EvaluationStatus;
  prize: CompetitionPrize | null;
  isMe: boolean;
}

export interface CompetitionMyResult {
  rank: number;
  scaledScore: number | null;
  status: EvaluationStatus;
  bandResults: BandResult[];
  recommendations: string[];
  rejectionReason: string | null;
  prize: CompetitionPrize | null;
}

export interface CompetitionResults {
  competition: {
    id: number;
    title: string;
    topic: string;
    prizes: CompetitionPrize[];
    essaysPublic: boolean;
  };
  ranking: CompetitionRankingEntry[];
  myResult: CompetitionMyResult | null;
}

export interface CompetitionEntryEssay {
  rank: number;
  firstName: string;
  scaledScore: number | null;
  status: EvaluationStatus;
  rawText: string;
  bandResults: BandResult[];
  isMe: boolean;
}

export interface CompetitionEntryAdmin {
  id: number;
  userId: number;
  paid: boolean;
  essayId: number | null;
  rank: number | null;
  scaledScore: number | null;
  awardedPrize: CompetitionPrize | null;
  user?: { firstName: string };
}

export interface CompetitionAdmin extends Competition {
  evalProgress: { done: number; total: number } | null;
  entries?: CompetitionEntryAdmin[];
  registeredCount: number;
  participantCount: number;
}

export interface CompetitionInput {
  title: string;
  topic: string;
  description?: string | null;
  entryFee: number;
  prizes: CompetitionPrize[];
  startsAt?: string | null;
  endsAt?: string | null;
}

export const api = {
  me: () => request<Me>("/api/me"),
  packages: () => publicRequest<EssayPackage[]>("/api/payments/packages"),
  updateProfile: (firstName: string) => authPatch<Me>("/api/me", { firstName }),
  history: () => request<Essay[]>("/api/me/history"),
  // Reytingdagi esseni ochib ko'rish (ommaviy - istalgan foydalanuvchi).
  publicEssay: (id: string | number) => request<PublicEssay>(`/api/me/essays/${id}/view`),
  stats: () => request<MyStats>("/api/me/stats"),
  summary: () => request<MySummary>("/api/me/summary"),
  leaderboard: (period: LeaderboardPeriod, metric: LeaderboardMetric = "score") =>
    request<Leaderboard>(`/api/me/leaderboard?period=${period}&metric=${metric}`),
  articles: () => publicRequest<Article[]>("/api/articles"),
  articleCategories: () => publicRequest<string[]>("/api/articles/categories"),
  article: (id: string | number) => publicRequest<ArticleDetail>(`/api/articles/${id}`),
  topics: () => publicRequest<Topic[]>("/api/topics"),
  submitTextEssay: (topic: string, text: string, ocrReceipt?: string) =>
    authPost<CreatedEssay>("/api/me/essays/text", { topic, text, ocrReceipt }),
  submitPdfEssay: (topic: string, file: File) => {
    const form = new FormData();
    form.append("topic", topic);
    form.append("file", file);
    return authPost<CreatedEssay>("/api/me/essays/pdf", form);
  },
  // Rasmdan matn o'qish (esse tekshiruvi) - PULLIK. Kvitansiya bilan qaytaradi.
  extractEssayImageText: (files: File[]) => {
    const form = new FormData();
    for (const f of files) form.append("files", f);
    return authPost<ImageOcrResult>("/api/me/essays/extract-image-text", form);
  },
  evaluateEssay: (essayId: number) =>
    authPost<EvaluationResult>(`/api/me/essays/${essayId}/evaluate`, {}),
  aiAnalysisStatus: () => request<AiAnalysisStatus>("/api/me/ai-analysis/status"),
  aiAnalysisHistory: () => request<AiAnalysisRecord[]>("/api/me/ai-analysis/history"),
  aiAnalysis: (id: number) => request<AiAnalysisRecord>(`/api/me/ai-analysis/${id}`),
  generateAiAnalysis: () => authPost<AiAnalysisRecord>("/api/me/ai-analysis", {}),
  quizStatus: () => request<QuizStatus>("/api/me/quiz/status"),
  quizHistory: () => request<QuizRecord[]>("/api/me/quiz/history"),
  quiz: (id: number) => request<QuizRecord>(`/api/me/quiz/${id}`),
  generateQuiz: () => authPost<QuizRecord>("/api/me/quiz/generate", {}),
  submitQuiz: (quizId: number, answers: QuizAnswer[]) =>
    authPost<QuizRecord>(`/api/me/quiz/${quizId}/submit`, { answers }),
  retakeQuiz: (quizId: number) => authPost<QuizRecord>(`/api/me/quiz/${quizId}/retake`, {}),
  randomQuiz: (count: number) => authPost<QuizRecord>("/api/me/quiz/random", { count }),
  competitions: () => request<Competition[]>("/api/competitions"),
  competition: (id: string | number) => request<CompetitionDetail>(`/api/competitions/${id}`),
  competitionResults: (id: string | number) =>
    request<CompetitionResults>(`/api/competitions/${id}/results`),
  competitionEntryEssay: (id: string | number, userId: number) =>
    request<CompetitionEntryEssay>(`/api/competitions/${id}/entries/${userId}/essay`),
  // Oldindan ro'yxatdan o'tish (tekin - joyni band qilish).
  registerCompetition: (id: string | number) =>
    authPost<{ id: number }>(`/api/competitions/${id}/register`, {}),
  // Kirish to'lovini to'lab to'liq ishtirokchiga aylanish.
  payCompetition: (id: string | number) =>
    authPost<{ id: number }>(`/api/competitions/${id}/pay`, {}),
  submitCompetitionText: (id: string | number, text: string) =>
    authPost<CreatedEssay>(`/api/competitions/${id}/essays/text`, { text }),
  submitCompetitionPdf: (id: string | number, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return authPost<CreatedEssay>(`/api/competitions/${id}/essays/pdf`, form);
  },
  // Rasmdan matn o'qish (musobaqa) - TEKIN. Kvitansiya qaytmaydi.
  extractCompetitionImageText: (id: string | number, files: File[]) => {
    const form = new FormData();
    for (const f of files) form.append("files", f);
    return authPost<ImageOcrResult>(`/api/competitions/${id}/essays/extract-image-text`, form);
  },
};

export function resolveAssetUrl(path: string | null | undefined): string | undefined {
  if (!path) return undefined;
  if (/^https?:\/\//.test(path)) return path;
  return `${BASE_URL}${path}`;
}

export const adminApi = {
  login: (key: string) => {
    setAdminKey(key);
    return adminRequest<ArticleDetail[]>("/api/articles/admin");
  },
  logout: () => clearAdminKey(),
  hasKey: () => Boolean(getAdminKey()),
  listArticles: () => adminRequest<ArticleDetail[]>("/api/articles/admin"),
  getArticle: (id: string | number) => adminRequest<ArticleDetail>(`/api/articles/admin/${id}`),
  createArticle: (data: {
    title: string;
    body: string;
    isPublished: boolean;
    pinned?: boolean;
    category?: string | null;
    cover?: File | null;
  }) => {
    const form = new FormData();
    form.append("title", data.title);
    form.append("body", data.body);
    form.append("isPublished", String(data.isPublished));
    if (data.pinned !== undefined) form.append("pinned", String(data.pinned));
    if (data.category !== undefined && data.category !== null)
      form.append("category", data.category);
    if (data.cover) form.append("cover", data.cover);
    return adminRequest<ArticleDetail>("/api/articles/admin", { method: "POST", body: form });
  },
  updateArticle: (
    id: string | number,
    data: {
      title?: string;
      body?: string;
      isPublished?: boolean;
      pinned?: boolean;
      category?: string | null;
      cover?: File | null;
    },
  ) => {
    const form = new FormData();
    if (data.title !== undefined) form.append("title", data.title);
    if (data.body !== undefined) form.append("body", data.body);
    if (data.isPublished !== undefined) form.append("isPublished", String(data.isPublished));
    if (data.pinned !== undefined) form.append("pinned", String(data.pinned));
    // Bo'lim bo'shatilsa ham yuboramiz (null -> "" -> backend null qiladi).
    if (data.category !== undefined) form.append("category", data.category ?? "");
    if (data.cover) form.append("cover", data.cover);
    return adminRequest<ArticleDetail>(`/api/articles/admin/${id}`, {
      method: "PATCH",
      body: form,
    });
  },
  reorderArticles: (ids: number[]) =>
    adminRequest<ArticleDetail[]>("/api/articles/admin/reorder", {
      method: "PATCH",
      json: { ids },
    }),
  deleteArticle: (id: string | number) =>
    adminRequest<{ success: boolean }>(`/api/articles/admin/${id}`, { method: "DELETE" }),
  listCompetitions: () => adminRequest<CompetitionAdmin[]>("/api/competitions/admin"),
  getCompetition: (id: string | number) =>
    adminRequest<CompetitionAdmin>(`/api/competitions/admin/${id}`),
  createCompetition: (data: CompetitionInput) =>
    adminRequest<CompetitionAdmin>("/api/competitions/admin", {
      method: "POST",
      json: data,
    }),
  updateCompetition: (id: string | number, data: Partial<CompetitionInput>) =>
    adminRequest<CompetitionAdmin>(`/api/competitions/admin/${id}`, {
      method: "PATCH",
      json: data,
    }),
  setCompetitionStatus: (id: string | number, status: CompetitionStatus) =>
    adminRequest<CompetitionAdmin>(`/api/competitions/admin/${id}/status`, {
      method: "POST",
      json: { status },
    }),
  setCompetitionVisibility: (id: string | number, essaysPublic: boolean) =>
    adminRequest<CompetitionAdmin>(`/api/competitions/admin/${id}/visibility`, {
      method: "POST",
      json: { essaysPublic },
    }),
  finishCompetition: (id: string | number) =>
    adminRequest<CompetitionAdmin>(`/api/competitions/admin/${id}/finish`, {
      method: "POST",
    }),
  listTopicsAdmin: () => adminRequest<Topic[]>("/api/topics/admin"),
  listCategoriesAdmin: () => adminRequest<Category[]>("/api/topics/admin/categories"),
  createCategory: (name: string) =>
    adminRequest<Category>("/api/topics/categories", { method: "POST", json: { name } }),
  deleteCategory: (id: string | number) =>
    adminRequest<Category>(`/api/topics/categories/${id}/deactivate`, { method: "POST" }),
  createTopic: (data: {
    text: string;
    categoryId?: number | null;
    newCategoryName?: string | null;
  }) => adminRequest<Topic>("/api/topics", { method: "POST", json: data }),
  deleteTopic: (id: string | number) =>
    adminRequest<Topic>(`/api/topics/${id}/deactivate`, { method: "POST" }),
  // Balans boshqaruvi: telegramId bo'yicha ko'rish va qo'lda +/- qilish.
  lookupUserBalance: (telegramId: string) =>
    adminRequest<AdminUserBalance>(`/api/payments/admin/user/${telegramId.trim()}`),
  adjustBalance: (telegramId: string, amount: number, note?: string) =>
    adminRequest<AdminBalanceResult>("/api/payments/admin/adjust-balance", {
      method: "POST",
      json: { telegramId: telegramId.trim(), amount, note },
    }),

  // --- Kengaytirilgan admin panel: dashboard, foydalanuvchilar, to'lovlar ---
  stats: () => adminRequest<AdminStats>("/api/admin/stats"),
  freeEssay: () => adminRequest<AdminFreeEssaySettings>("/api/admin/free-essay"),
  setFreeEssayLimit: (limit: number) =>
    adminRequest<AdminFreeEssaySettings>("/api/admin/free-essay", {
      method: "PATCH",
      json: { limit },
    }),
  listUsers: (params: { query?: string; page?: number; limit?: number } = {}) => {
    const sp = new URLSearchParams();
    if (params.query) sp.set("query", params.query);
    if (params.page) sp.set("page", String(params.page));
    if (params.limit) sp.set("limit", String(params.limit));
    const qs = sp.toString();
    return adminRequest<AdminUserList>(`/api/admin/users${qs ? `?${qs}` : ""}`);
  },
  getUserDetail: (telegramId: string) =>
    adminRequest<AdminUserDetail>(`/api/admin/users/${telegramId.trim()}`),
  listPayments: (
    params: { status?: string; kind?: string; page?: number; limit?: number } = {},
  ) => {
    const sp = new URLSearchParams();
    if (params.status) sp.set("status", params.status);
    if (params.kind) sp.set("kind", params.kind);
    if (params.page) sp.set("page", String(params.page));
    if (params.limit) sp.set("limit", String(params.limit));
    const qs = sp.toString();
    return adminRequest<AdminPaymentList>(`/api/admin/payments${qs ? `?${qs}` : ""}`);
  },
  listEssays: (params: { status?: string; page?: number; limit?: number } = {}) => {
    const sp = new URLSearchParams();
    if (params.status) sp.set("status", params.status);
    if (params.page) sp.set("page", String(params.page));
    if (params.limit) sp.set("limit", String(params.limit));
    const qs = sp.toString();
    return adminRequest<AdminEssayList>(`/api/admin/essays${qs ? `?${qs}` : ""}`);
  },
  getEssay: (essayId: string | number) =>
    adminRequest<AdminEssayDetail>(`/api/admin/essays/${essayId}`),
  grantCredits: (telegramId: string, credits: number) =>
    adminRequest<{
      telegramId: string;
      firstName: string | null;
      essayCredits: number;
      granted: number;
    }>("/api/admin/grant-credits", {
      method: "POST",
      json: { telegramId: telegramId.trim(), credits },
    }),
};
