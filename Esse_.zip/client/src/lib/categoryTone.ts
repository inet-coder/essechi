// Kategoriyalarga barqaror rang (tone) beruvchi umumiy yordamchi. Mavzular
// sahifasi va Esse yozish sahifasida bir xil rang sxemasi ishlatiladi, shunda
// bitta kategoriya ilovaning hamma joyida bir xil rangda ko'rinadi.

export interface Tone {
  fg: string;
  soft: string;
}

const TONES: Tone[] = [
  { fg: "var(--primary)", soft: "var(--primary-soft)" },
  { fg: "var(--tone-excellent)", soft: "var(--tone-excellent-soft)" },
  { fg: "var(--tone-ok)", soft: "var(--tone-ok-soft)" },
  { fg: "var(--tone-weak)", soft: "var(--tone-weak-soft)" },
  { fg: "var(--tone-good)", soft: "var(--tone-good-soft)" },
];

const NEUTRAL: Tone = { fg: "var(--muted-foreground)", soft: "var(--muted)" };

// null (kategoriyasiz) uchun neytral rang, aks holda id bo'yicha barqaror rang.
export function toneFor(categoryId: number | null): Tone {
  if (categoryId === null) return NEUTRAL;
  return TONES[categoryId % TONES.length];
}
