import type { CompetitionStatus } from "./api";

// Status uchun yorliq, rang tokeni va qisqa tavsif - mini-app va admin panelda
// bir xil ishlatiladi (bir joyda saqlanadi).
export const COMPETITION_STATUS_META: Record<
  CompetitionStatus,
  { label: string; tone: string; hint: string }
> = {
  draft: { label: "Qoralama", tone: "muted", hint: "Hali e'lon qilinmagan" },
  upcoming: {
    label: "Tez orada",
    tone: "ok",
    hint: "Belgilangan sanada boshlanadi, ro'yxat ochiq",
  },
  open: { label: "Ochiq", tone: "excellent", hint: "Qatnashish ochiq" },
  closed: {
    label: "Yopilgan",
    tone: "weak",
    hint: "Qabul tugadi, natija kutilmoqda",
  },
  evaluating: {
    label: "Baholanmoqda",
    tone: "ok",
    hint: "AI esselarni tekshirmoqda",
  },
  finished: { label: "Yakunlandi", tone: "primary", hint: "Natijalar tayyor" },
  cancelled: { label: "Bekor qilindi", tone: "bad", hint: "To'lov qaytarildi" },
};

const MEDAL_COLORS: Record<number, string> = {
  1: "#F5B700",
  2: "#AEB6C2",
  3: "#C97C3D",
};

export function medalColor(rank: number): string | null {
  return MEDAL_COLORS[rank] ?? null;
}

export function formatDeadline(iso: string | null): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(
    d.getHours(),
  )}:${pad(d.getMinutes())}`;
}

// Boshlanish sanasi (formatDeadline bilan bir xil format - "starts on" uchun).
export const formatStartDate = formatDeadline;
