export function formatDate(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;
}

export function formatSum(value: number): string {
  return `${value.toLocaleString("ru-RU").replace(/,/g, " ")} soʻm`;
}

export function scoreTone(score: number): "excellent" | "good" | "ok" | "weak" | "bad" {
  if (score >= 2) return "excellent";
  if (score >= 1.5) return "good";
  if (score >= 1) return "ok";
  if (score >= 0.5) return "weak";
  return "bad";
}

export function totalTone(total: number): "excellent" | "good" | "ok" | "bad" {
  if (total >= 19) return "excellent";
  if (total >= 13) return "good";
  if (total >= 7) return "ok";
  return "bad";
}

// totalTone kabi, lekin 75 ballik (scaledScore) shkala uchun - xuddi shu
// nisbatlarga proporsional chegaralar (19/13/7 dan 24 ballik shkalada)
export function scaledTone(scaled: number): "excellent" | "good" | "ok" | "bad" {
  if (scaled >= 59) return "excellent";
  if (scaled >= 41) return "good";
  if (scaled >= 22) return "ok";
  return "bad";
}

export function totalLabel(total: number): string {
  const t = totalTone(total);
  if (t === "excellent") return "Aʼlo natija";
  if (t === "good") return "Yaxshi natija";
  if (t === "ok") return "Qoniqarli natija";
  return "Past natija";
}

const WORDS_PER_MINUTE = 180;

export function estimateReadingMinutes(text: string): number {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / WORDS_PER_MINUTE));
}

export function greeting(hour = new Date().getHours()): string {
  if (hour < 6) return "Xayrli tun";
  if (hour < 11) return "Xayrli tong";
  if (hour < 17) return "Xayrli kun";
  return "Xayrli kech";
}
