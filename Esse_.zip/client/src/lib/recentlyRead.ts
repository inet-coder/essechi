// "So'nggi o'qilgan" maqolalarni brauzer xotirasida (localStorage) saqlaydi.
// Backend'da alohida jadval kerak emas - foydalanuvchi shu qurilmada
// o'qigan maqolalarini ko'radi.

const STORAGE_KEY = "esse-recently-read";
const MAX_ITEMS = 10;

export function getRecentlyReadIds(): number[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((v): v is number => typeof v === "number") : [];
  } catch {
    return [];
  }
}

export function addRecentlyRead(articleId: number) {
  if (typeof window === "undefined") return;
  try {
    const withoutCurrent = getRecentlyReadIds().filter((id) => id !== articleId);
    const next = [articleId, ...withoutCurrent].slice(0, MAX_ITEMS);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    /* noop */
  }
}
