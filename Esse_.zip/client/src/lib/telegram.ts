// Minimal Telegram WebApp helpers.
declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        ready: () => void;
        expand: () => void;
        close: () => void;
        initData: string;
        themeParams?: Record<string, string>;
        colorScheme?: "light" | "dark";
        BackButton?: {
          show: () => void;
          hide: () => void;
          onClick: (cb: () => void) => void;
          offClick: (cb: () => void) => void;
        };
      };
    };
  }
}

export function getTelegram() {
  if (typeof window === "undefined") return undefined;
  return window.Telegram?.WebApp;
}

export function getInitData(): string | undefined {
  const tg = getTelegram();
  return tg?.initData && tg.initData.length > 0 ? tg.initData : undefined;
}

export function isInTelegram(): boolean {
  return Boolean(getInitData());
}

export function initTelegram() {
  const tg = getTelegram();
  if (!tg) return;
  try {
    tg.ready();
    tg.expand();
  } catch {
    /* noop */
  }
}

// Esse yozish botning o'zida (matn/PDF yuborish orqali) amalga oshiriladi -
// mavzu tanlangach WebApp'ni yopib, foydalanuvchini chatga qaytaramiz.
export function closeTelegramWebApp() {
  const tg = getTelegram();
  if (tg) {
    try {
      tg.close();
      return;
    } catch {
      /* noop */
    }
  }
  if (typeof window !== "undefined") window.history.back();
}
