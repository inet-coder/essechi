export const LEARNING_TIPS: string[] = [
  "Kirish qismida mavzuni qayta ifodalab, o'z pozitsiyangizni aniq bildiring — bahoловчи buni birinchi mezon sifatida baholaydi.",
  "Har bir asosiy fikringizni kamida bitta aniq misol yoki dalil bilan mustahkamlang — umumiy gaplar ball keltirmaydi.",
  "Xulosa qismida yangi fikr kiritmang — faqat asosiy g'oyalarni qisqa jamlab, mavzuga yakun yasang.",
  "Bir xil so'zlarni takrorlash o'rniga sinonimlardan foydalaning — bu leksik boylik mezoni bo'yicha ballingizni oshiradi.",
  "Yozishdan oldin 2-3 daqiqa reja tuzing — bu esse tuzilishini ancha izchil qiladi.",
  "Uzun va qisqa gaplarni almashtirib qo'llang — bu matningizni o'qishga yengil va tabiiy qiladi.",
  "Tinish belgilariga, ayniqsa vergul va nuqtali vergulga alohida e'tibor bering — mayda xatolar jamlanib ballni pasaytiradi.",
  "Har bir paragraf faqat bitta asosiy fikrga bag'ishlansin — aralash fikrlar mantiqiy izchillikni buzadi.",
];

export function todaysTip(): string {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86_400_000,
  );
  return LEARNING_TIPS[dayOfYear % LEARNING_TIPS.length];
}
