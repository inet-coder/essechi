import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { adminApi } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { ArticleForm, type ArticleFormValues } from "@/components/ArticleForm";
import { Skeleton } from "@/components/Skeleton";

export const Route = createFileRoute("/admin/articles/$id")({
  head: () => ({ meta: [{ title: "Admin — Maqolani tahrirlash" }] }),
  component: () => (
    <AdminGate>
      <EditArticlePage />
    </AdminGate>
  ),
});

function EditArticlePage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const articleQ = useQuery({
    queryKey: ["admin-article", id],
    queryFn: () => adminApi.getArticle(id),
  });

  const updateMutation = useMutation({
    mutationFn: (values: ArticleFormValues) =>
      adminApi.updateArticle(id, {
        title: values.title,
        body: values.body,
        isPublished: values.isPublished,
        pinned: values.pinned,
        category: values.category || null,
        cover: values.cover,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-articles"] });
      queryClient.invalidateQueries({ queryKey: ["admin-article", id] });
      navigate({ to: "/admin/articles" });
    },
  });

  return (
    <AdminShell title="Maqolani tahrirlash">
      {articleQ.isLoading && (
        <div className="space-y-4">
          <Skeleton className="h-32 rounded-2xl" />
          <Skeleton className="h-16 rounded-2xl" />
          <Skeleton className="h-64 rounded-2xl" />
        </div>
      )}

      {articleQ.data && (
        <ArticleForm
          initial={{
            title: articleQ.data.title,
            body: articleQ.data.body,
            isPublished: articleQ.data.isPublished,
            pinned: articleQ.data.pinned,
            category: articleQ.data.category,
            coverImage: articleQ.data.coverImage,
          }}
          submitLabel="Oʻzgarishlarni saqlash"
          submitting={updateMutation.isPending}
          onSubmit={(values) => updateMutation.mutate(values)}
        />
      )}

      {updateMutation.isError && (
        <p className="mt-3 text-sm font-medium" style={{ color: "var(--tone-bad)" }}>
          Saqlashda xatolik yuz berdi. Qayta urinib koʻring.
        </p>
      )}
    </AdminShell>
  );
}
