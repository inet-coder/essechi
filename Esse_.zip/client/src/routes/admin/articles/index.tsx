import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, FileText, Pencil, Pin, PinOff, Plus, Trash2 } from "lucide-react";
import { adminApi, resolveAssetUrl, type ArticleDetail } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { Skeleton } from "@/components/Skeleton";
import { formatDate } from "@/lib/format";

export const Route = createFileRoute("/admin/articles/")({
  head: () => ({ meta: [{ title: "Admin — Maqolalar" }] }),
  component: () => (
    <AdminGate>
      <AdminArticlesPage />
    </AdminGate>
  ),
});

function AdminArticlesPage() {
  const queryClient = useQueryClient();
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const articlesQ = useQuery({ queryKey: ["admin-articles"], queryFn: adminApi.listArticles });

  const setList = (list: ArticleDetail[]) => queryClient.setQueryData(["admin-articles"], list);

  const toggleMutation = useMutation({
    mutationFn: (article: ArticleDetail) =>
      adminApi.updateArticle(article.id, { isPublished: !article.isPublished }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-articles"] }),
  });

  const pinMutation = useMutation({
    mutationFn: (article: ArticleDetail) =>
      adminApi.updateArticle(article.id, { pinned: !article.pinned }),
    // Qadash ro'yxat tartibini o'zgartiradi - to'g'ri tartibni qayta olamiz.
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-articles"] }),
  });

  const reorderMutation = useMutation({
    mutationFn: (ids: number[]) => adminApi.reorderArticles(ids),
    onSuccess: (data) => setList(data),
    onError: () => queryClient.invalidateQueries({ queryKey: ["admin-articles"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => adminApi.deleteArticle(id),
    onSuccess: () => {
      setDeletingId(null);
      queryClient.invalidateQueries({ queryKey: ["admin-articles"] });
    },
  });

  const list = articlesQ.data ?? [];

  // Yuqori/pastga surish: joriy ro'yxatda o'rin almashtirib, yangi tartibni
  // serverga yuboramiz (optimistik yangilanish bilan darhol ko'rinadi).
  function move(index: number, dir: "up" | "down") {
    const target = dir === "up" ? index - 1 : index + 1;
    if (target < 0 || target >= list.length) return;
    const next = [...list];
    [next[index], next[target]] = [next[target], next[index]];
    setList(next);
    reorderMutation.mutate(next.map((a) => a.id));
  }

  const busyReorder = reorderMutation.isPending;

  return (
    <AdminShell
      title="Maqolalar"
      actions={
        <Link
          to="/admin/articles/new"
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
        >
          <Plus className="h-4 w-4" strokeWidth={2.2} />
          Yangi maqola
        </Link>
      }
    >
      {articlesQ.isLoading && (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-[76px] rounded-2xl" />
          ))}
        </div>
      )}

      {list.length === 0 && !articlesQ.isLoading && (
        <div className="rounded-2xl bg-card p-10 text-center shadow-card">
          <p className="text-sm text-muted-foreground">Hali maqola qoʻshilmagan.</p>
        </div>
      )}

      {list.length > 0 && (
        <>
          <p className="mb-2.5 px-1 text-xs text-muted-foreground">
            Joylashuvni oʻzgartirish uchun oʻq tugmalaridan foydalaning. Eng yuqoridagi maqola
            foydalanuvchilarga "Tavsiya etilgan" boʻlib koʻrinadi.
          </p>
          <div className="space-y-2.5">
            {list.map((article, index) => {
              const cover = resolveAssetUrl(article.coverImage);
              return (
                <div
                  key={article.id}
                  className="flex items-center gap-2.5 rounded-2xl bg-card p-3 shadow-card sm:gap-3 sm:p-4"
                >
                  {/* Joylashuv o'qlari */}
                  <div className="flex shrink-0 flex-col">
                    <button
                      type="button"
                      onClick={() => move(index, "up")}
                      disabled={index === 0 || busyReorder}
                      className="rounded-md p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:opacity-30"
                      aria-label="Yuqoriga"
                    >
                      <ArrowUp className="h-4 w-4" strokeWidth={2.2} />
                    </button>
                    <button
                      type="button"
                      onClick={() => move(index, "down")}
                      disabled={index === list.length - 1 || busyReorder}
                      className="rounded-md p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:opacity-30"
                      aria-label="Pastga"
                    >
                      <ArrowDown className="h-4 w-4" strokeWidth={2.2} />
                    </button>
                  </div>

                  <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-muted sm:h-16 sm:w-16">
                    {cover ? (
                      <img src={cover} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                        <FileText className="h-6 w-6" strokeWidth={1.5} />
                      </div>
                    )}
                    {article.pinned && (
                      <span
                        className="absolute left-1 top-1 flex h-5 w-5 items-center justify-center rounded-full text-primary-foreground"
                        style={{ backgroundColor: "var(--primary)" }}
                        title="Qadalgan"
                      >
                        <Pin className="h-3 w-3" strokeWidth={2.4} />
                      </span>
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-foreground">
                      {article.title}
                    </p>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5">
                      {article.category && (
                        <span
                          className="rounded-full px-2 py-0.5 text-[10.5px] font-semibold"
                          style={{
                            backgroundColor: "var(--primary-soft)",
                            color: "var(--primary)",
                          }}
                        >
                          {article.category}
                        </span>
                      )}
                      <span className="text-xs text-muted-foreground">
                        {formatDate(article.createdAt)}
                      </span>
                    </div>
                  </div>

                  {/* Qadash */}
                  <button
                    type="button"
                    onClick={() => pinMutation.mutate(article)}
                    disabled={pinMutation.isPending}
                    className="shrink-0 rounded-lg p-2 transition-colors hover:bg-muted"
                    style={{ color: article.pinned ? "var(--primary)" : "var(--muted-foreground)" }}
                    aria-label={article.pinned ? "Qadashni olib tashlash" : "Yuqoriga qadash"}
                    title={article.pinned ? "Qadalgan" : "Qadash"}
                  >
                    {article.pinned ? (
                      <PinOff className="h-4 w-4" strokeWidth={2} />
                    ) : (
                      <Pin className="h-4 w-4" strokeWidth={2} />
                    )}
                  </button>

                  {/* E'lon holati */}
                  <button
                    type="button"
                    onClick={() => toggleMutation.mutate(article)}
                    disabled={toggleMutation.isPending}
                    className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold"
                    style={{
                      backgroundColor: article.isPublished
                        ? "var(--tone-excellent-soft)"
                        : "var(--tone-weak-soft)",
                      color: article.isPublished ? "var(--tone-excellent)" : "var(--tone-weak)",
                    }}
                  >
                    {article.isPublished ? "Eʼlon qilingan" : "Qoralama"}
                  </button>

                  <Link
                    to="/admin/articles/$id"
                    params={{ id: String(article.id) }}
                    className="shrink-0 rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                    aria-label="Tahrirlash"
                  >
                    <Pencil className="h-4 w-4" strokeWidth={2} />
                  </Link>

                  {deletingId === article.id ? (
                    <div className="flex shrink-0 items-center gap-1">
                      <button
                        type="button"
                        onClick={() => deleteMutation.mutate(article.id)}
                        disabled={deleteMutation.isPending}
                        className="rounded-lg px-2 py-1.5 text-xs font-semibold text-primary-foreground"
                        style={{ backgroundColor: "var(--tone-bad)" }}
                      >
                        Oʻchirish
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeletingId(null)}
                        className="rounded-lg px-2 py-1.5 text-xs font-medium text-muted-foreground hover:bg-muted"
                      >
                        Bekor
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setDeletingId(article.id)}
                      className="shrink-0 rounded-lg p-2 transition-colors hover:bg-muted"
                      style={{ color: "var(--tone-bad)" }}
                      aria-label="Oʻchirish"
                    >
                      <Trash2 className="h-4 w-4" strokeWidth={2} />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}
    </AdminShell>
  );
}
