import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { adminApi } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { ArticleForm, type ArticleFormValues } from "@/components/ArticleForm";

export const Route = createFileRoute("/admin/articles/new")({
  head: () => ({ meta: [{ title: "Admin — Yangi maqola" }] }),
  component: () => (
    <AdminGate>
      <NewArticlePage />
    </AdminGate>
  ),
});

function NewArticlePage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (values: ArticleFormValues) =>
      adminApi.createArticle({
        title: values.title,
        body: values.body,
        isPublished: values.isPublished,
        pinned: values.pinned,
        category: values.category || null,
        cover: values.cover,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-articles"] });
      navigate({ to: "/admin/articles" });
    },
  });

  return (
    <AdminShell title="Yangi maqola">
      <ArticleForm
        submitLabel="Nashr qilish"
        submitting={createMutation.isPending}
        onSubmit={(values) => createMutation.mutate(values)}
      />
      {createMutation.isError && (
        <p className="mt-3 text-sm font-medium" style={{ color: "var(--tone-bad)" }}>
          Saqlashda xatolik yuz berdi. Qayta urinib koʻring.
        </p>
      )}
    </AdminShell>
  );
}
