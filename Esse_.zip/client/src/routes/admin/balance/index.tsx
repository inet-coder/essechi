import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { Minus, Plus, Search, Ticket, Wallet } from "lucide-react";
import { adminApi, ApiError, type AdminUserBalance } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { formatSum } from "@/lib/format";

export const Route = createFileRoute("/admin/balance/")({
  head: () => ({ meta: [{ title: "Admin — Balans" }] }),
  component: () => (
    <AdminGate>
      <AdminBalancePage />
    </AdminGate>
  ),
});

const inputClass =
  "mt-2 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring";
const labelClass = "text-xs font-semibold uppercase tracking-wide text-muted-foreground";

function AdminBalancePage() {
  const [telegramId, setTelegramId] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [user, setUser] = useState<AdminUserBalance | null>(null);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const lookup = useMutation({
    mutationFn: () => adminApi.lookupUserBalance(telegramId),
    onSuccess: (data) => {
      setUser(data);
      setMessage(null);
    },
    onError: (error: ApiError) => {
      setUser(null);
      setMessage({ ok: false, text: error.message || "Foydalanuvchi topilmadi" });
    },
  });

  const adjust = useMutation({
    mutationFn: (signedAmount: number) =>
      adminApi.adjustBalance(telegramId, signedAmount, note.trim() || undefined),
    onSuccess: (res) => {
      setUser((prev) => (prev ? { ...prev, balance: res.balance } : prev));
      const sign = res.applied > 0 ? "+" : "−";
      setMessage({
        ok: true,
        text: `${sign}${formatSum(Math.abs(res.applied))} so'm qo'llandi. Yangi balans: ${formatSum(res.balance)} so'm`,
      });
      setAmount("");
      setNote("");
    },
    onError: (error: ApiError) => {
      setMessage({ ok: false, text: error.message || "Xatolik yuz berdi" });
    },
  });

  const amountNum = Math.trunc(Number(amount));
  const validAmount = Number.isFinite(amountNum) && amountNum > 0;
  const canAdjust = Boolean(user) && validAmount && !adjust.isPending;

  return (
    <AdminShell title="Balans boshqaruvi">
      <div className="mx-auto max-w-[560px]">
        <p className="text-sm text-muted-foreground">
          Telegram ID bo'yicha foydalanuvchi balansini qo'lda to'ldiring yoki kamaytiring. Mablag'
          darhol qo'llanadi (avto emas). Kredit/paket bu yerdan berilmaydi — faqat balans (so'm).
        </p>

        {/* Telegram ID + ko'rish */}
        <div className="mt-5 rounded-2xl border border-border bg-card p-4">
          <label className={labelClass}>Telegram ID</label>
          <div className="mt-2 flex items-stretch gap-2">
            <input
              className="min-w-0 flex-1 rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
              value={telegramId}
              inputMode="numeric"
              placeholder="Masalan: 123456789"
              onChange={(e) => setTelegramId(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && telegramId.trim()) lookup.mutate();
              }}
            />
            <button
              type="button"
              disabled={!telegramId.trim() || lookup.isPending}
              onClick={() => lookup.mutate()}
              className="flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl px-4 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
              style={{ backgroundColor: "var(--primary)" }}
            >
              <Search className="h-4 w-4 shrink-0" strokeWidth={2} />
              {lookup.isPending ? "..." : "Ko'rish"}
            </button>
          </div>

          {user && (
            <div className="mt-4 rounded-xl bg-muted/50 p-3">
              <p className="text-sm font-semibold text-foreground">
                {user.firstName || "(ismsiz)"}{" "}
                <span className="font-normal text-muted-foreground">· ID {user.telegramId}</span>
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-background px-2.5 py-1 text-sm font-medium text-foreground">
                  <Wallet className="h-3.5 w-3.5" strokeWidth={2} />
                  {formatSum(user.balance)} so'm
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-background px-2.5 py-1 text-sm font-medium text-foreground">
                  <Ticket className="h-3.5 w-3.5" strokeWidth={2} />
                  {user.essayCredits} ta kredit
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Summa + qo'shish/ayirish */}
        <div
          className="mt-4 rounded-2xl border border-border bg-card p-4"
          style={{ opacity: user ? 1 : 0.55 }}
        >
          <label className={labelClass}>Summa (so'm)</label>
          <input
            className={inputClass}
            value={amount}
            inputMode="numeric"
            placeholder="Masalan: 50000"
            disabled={!user}
            onChange={(e) => setAmount(e.target.value.replace(/[^0-9]/g, ""))}
          />

          <label className={`${labelClass} mt-4 block`}>Izoh (ixtiyoriy)</label>
          <input
            className={inputClass}
            value={note}
            placeholder="Masalan: Musobaqa 1-o'rin mukofoti"
            disabled={!user}
            onChange={(e) => setNote(e.target.value)}
          />

          <div className="mt-4 grid grid-cols-2 gap-3">
            <button
              type="button"
              disabled={!canAdjust}
              onClick={() => adjust.mutate(amountNum)}
              className="flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
              style={{ backgroundColor: "var(--tone-excellent)" }}
            >
              <Plus className="h-4 w-4" strokeWidth={2.5} />
              Qo'shish
            </button>
            <button
              type="button"
              disabled={!canAdjust}
              onClick={() => adjust.mutate(-amountNum)}
              className="flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
              style={{ backgroundColor: "var(--tone-bad)" }}
            >
              <Minus className="h-4 w-4" strokeWidth={2.5} />
              Ayirish
            </button>
          </div>
        </div>

        {message && (
          <p
            className="mt-4 rounded-xl px-4 py-3 text-sm font-medium"
            style={{
              backgroundColor: message.ok
                ? "color-mix(in oklch, var(--tone-excellent) 15%, transparent)"
                : "color-mix(in oklch, var(--tone-bad) 15%, transparent)",
              color: message.ok ? "var(--tone-excellent)" : "var(--tone-bad)",
            }}
          >
            {message.text}
          </p>
        )}
      </div>
    </AdminShell>
  );
}
