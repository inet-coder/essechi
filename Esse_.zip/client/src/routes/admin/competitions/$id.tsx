import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CalendarClock,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Play,
  Sparkles,
  Users,
  XCircle,
} from "lucide-react";
import {
  adminApi,
  type CompetitionAdmin,
  type CompetitionStatus,
  type CompetitionInput,
  type CompetitionEntryAdmin,
} from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { CompetitionForm } from "@/components/CompetitionForm";
import { Skeleton } from "@/components/Skeleton";
import { formatSum } from "@/lib/format";
import { COMPETITION_STATUS_META } from "@/lib/competition";

export const Route = createFileRoute("/admin/competitions/$id")({
  head: () => ({ meta: [{ title: "Admin — Musobaqa" }] }),
  component: () => (
    <AdminGate>
      <ManageCompetitionPage />
    </AdminGate>
  ),
});

function ManageCompetitionPage() {
  const { id } = Route.useParams();
  const queryClient = useQueryClient();

  const compQ = useQuery({
    queryKey: ["admin-competition", id],
    queryFn: () => adminApi.getCompetition(id),
    // Baholash davomida progressni yangilab turish uchun.
    refetchInterval: (query) => (query.state.data?.status === "evaluating" ? 3000 : false),
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["admin-competition", id] });
    queryClient.invalidateQueries({ queryKey: ["admin-competitions"] });
  };

  const statusMutation = useMutation({
    mutationFn: (status: CompetitionStatus) => adminApi.setCompetitionStatus(id, status),
    onSuccess: invalidate,
  });
  const finishMutation = useMutation({
    mutationFn: () => adminApi.finishCompetition(id),
    onSuccess: invalidate,
  });
  const updateMutation = useMutation({
    mutationFn: (values: CompetitionInput) => adminApi.updateCompetition(id, values),
    onSuccess: invalidate,
  });
  const visibilityMutation = useMutation({
    mutationFn: (essaysPublic: boolean) => adminApi.setCompetitionVisibility(id, essaysPublic),
    onSuccess: invalidate,
  });

  if (compQ.isLoading) {
    return (
      <AdminShell title="Musobaqa">
        <div className="space-y-3">
          <Skeleton className="h-[120px] rounded-2xl" />
          <Skeleton className="h-[200px] rounded-2xl" />
        </div>
      </AdminShell>
    );
  }

  if (compQ.error || !compQ.data) {
    return (
      <AdminShell title="Musobaqa">
        <p className="text-sm" style={{ color: "var(--tone-bad)" }}>
          Musobaqa topilmadi.
        </p>
      </AdminShell>
    );
  }

  const competition = compQ.data;
  const editable =
    competition.status === "draft" ||
    competition.status === "upcoming" ||
    competition.status === "open";
  const busy = statusMutation.isPending || finishMutation.isPending;

  return (
    <AdminShell title={competition.title}>
      <div className="space-y-5">
        <StatusPanel
          competition={competition}
          busy={busy}
          onStatus={(s) => statusMutation.mutate(s)}
          onFinish={() => finishMutation.mutate()}
        />

        {(statusMutation.isError || finishMutation.isError) && (
          <p className="text-sm font-medium" style={{ color: "var(--tone-bad)" }}>
            {((statusMutation.error || finishMutation.error) as Error)?.message ??
              "Amal bajarilmadi."}
          </p>
        )}

        <VisibilityCard
          essaysPublic={competition.essaysPublic}
          pending={visibilityMutation.isPending}
          onToggle={(value) => visibilityMutation.mutate(value)}
        />

        {editable && (
          <div>
            <p className="mb-3 text-sm font-semibold text-foreground">Tahrirlash</p>
            <CompetitionForm
              key={competition.updatedAt ?? competition.id}
              initial={competition}
              submitLabel="O'zgarishlarni saqlash"
              submitting={updateMutation.isPending}
              onSubmit={(values) => updateMutation.mutate(values)}
            />
            {updateMutation.isSuccess && (
              <p className="mt-3 text-sm font-medium" style={{ color: "var(--tone-excellent)" }}>
                Saqlandi.
              </p>
            )}
          </div>
        )}

        <EntriesList
          entries={competition.entries ?? []}
          finished={competition.status === "finished"}
          registeredCount={competition.registeredCount}
          participantCount={competition.participantCount}
        />
      </div>
    </AdminShell>
  );
}

function VisibilityCard({
  essaysPublic,
  pending,
  onToggle,
}: {
  essaysPublic: boolean;
  pending: boolean;
  onToggle: (value: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl bg-card p-5 shadow-card">
      <div className="flex items-start gap-3">
        <span
          className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
          style={{
            backgroundColor: essaysPublic ? "var(--tone-excellent-soft)" : "var(--muted)",
            color: essaysPublic ? "var(--tone-excellent)" : "var(--muted-foreground)",
          }}
        >
          {essaysPublic ? (
            <Eye className="h-4.5 w-4.5" strokeWidth={2} />
          ) : (
            <EyeOff className="h-4.5 w-4.5" strokeWidth={2} />
          )}
        </span>
        <div>
          <p className="text-sm font-medium text-foreground">Ishtirokchilar esselari ochiq</p>
          <p className="text-xs leading-relaxed text-muted-foreground">
            Yoqilsa, ishtirokchilar natijalarda bir-birining essesi va tahlilini ko'ra oladi. O'z
            essesini har kim baribir ko'radi. Istalgan vaqtda o'zgartirsangiz bo'ladi.
          </p>
        </div>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={essaysPublic}
        disabled={pending}
        onClick={() => onToggle(!essaysPublic)}
        className="relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-50"
        style={{ backgroundColor: essaysPublic ? "var(--primary)" : "var(--muted)" }}
      >
        <span
          className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform"
          style={{ transform: essaysPublic ? "translateX(22px)" : "translateX(2px)" }}
        />
      </button>
    </div>
  );
}

function StatusPanel({
  competition,
  busy,
  onStatus,
  onFinish,
}: {
  competition: CompetitionAdmin;
  busy: boolean;
  onStatus: (s: CompetitionStatus) => void;
  onFinish: () => void;
}) {
  const meta = COMPETITION_STATUS_META[competition.status];
  const tone = meta.tone === "muted" ? "muted" : meta.tone;

  return (
    <div className="rounded-2xl bg-card p-5 shadow-card">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Holat
          </p>
          <p
            className="mt-1 text-lg font-bold"
            style={{ color: tone === "muted" ? "var(--foreground)" : `var(--tone-${tone})` }}
          >
            {meta.label}
          </p>
          <p className="text-[12.5px] text-muted-foreground">{meta.hint}</p>
        </div>
        {competition.status === "evaluating" && competition.evalProgress && (
          <div className="text-right">
            <p className="flex items-center gap-1.5 text-sm font-bold tabular-nums text-primary">
              <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2} />
              {competition.evalProgress.done}/{competition.evalProgress.total}
            </p>
            <p className="text-[11px] text-muted-foreground">baholandi</p>
          </div>
        )}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {competition.status === "draft" && (
          <>
            <ActionBtn
              icon={CalendarClock}
              label="E'lon qilish (ro'yxat ochish)"
              tone="ok"
              disabled={busy}
              onClick={() => onStatus("upcoming")}
            />
            <ActionBtn
              icon={Play}
              label="Darhol ochish"
              tone="excellent"
              disabled={busy}
              onClick={() => onStatus("open")}
            />
          </>
        )}
        {competition.status === "upcoming" && (
          <ActionBtn
            icon={Play}
            label="Qabulni boshlash"
            tone="excellent"
            disabled={busy}
            onClick={() => onStatus("open")}
          />
        )}
        {competition.status === "open" && (
          <ActionBtn
            icon={Lock}
            label="Qabulni yopish"
            tone="weak"
            disabled={busy}
            onClick={() => onStatus("closed")}
          />
        )}
        {competition.status === "closed" && (
          <>
            <ActionBtn
              icon={Play}
              label="Qayta ochish"
              tone="ok"
              disabled={busy}
              onClick={() => onStatus("open")}
            />
            <ActionBtn
              icon={Sparkles}
              label="AI baholash va yakunlash"
              tone="primary"
              disabled={busy}
              onClick={onFinish}
            />
          </>
        )}
        {["draft", "upcoming", "open", "closed"].includes(competition.status) && (
          <ActionBtn
            icon={XCircle}
            label="Bekor qilish"
            tone="bad"
            disabled={busy}
            onClick={() => onStatus("cancelled")}
          />
        )}
      </div>

      {competition.status === "upcoming" && (
        <p className="mt-3 text-[12px] leading-relaxed text-muted-foreground">
          Musobaqa "Tez orada" — foydalanuvchilar oldindan ro'yxatdan o'tishi va kirish to'lovini
          to'lab ishtirokchi bo'lishi mumkin. Esse qabul qilish uchun "Qabulni boshlash"ni bosing.
        </p>
      )}

      {competition.status === "closed" && (
        <p className="mt-3 text-[12px] leading-relaxed text-muted-foreground">
          "AI baholash" bosilgach esselar median usulida baholanadi va top o'rinlar juftma-juft
          aniqlanadi. Bu bir necha daqiqa olishi mumkin — progress shu yerda yangilanib turadi.
        </p>
      )}
    </div>
  );
}

function ActionBtn({
  icon: Icon,
  label,
  tone,
  disabled,
  onClick,
}: {
  icon: typeof Play;
  label: string;
  tone: string;
  disabled: boolean;
  onClick: () => void;
}) {
  const isPrimary = tone === "primary";
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className="inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-opacity hover:opacity-90 disabled:opacity-50"
      style={{
        backgroundColor: isPrimary ? "var(--primary)" : `var(--tone-${tone}-soft)`,
        color: isPrimary ? "var(--primary-foreground)" : `var(--tone-${tone})`,
      }}
    >
      <Icon className="h-4 w-4" strokeWidth={2} />
      {label}
    </button>
  );
}

function EntriesList({
  entries,
  finished,
  registeredCount,
  participantCount,
}: {
  entries: CompetitionEntryAdmin[];
  finished: boolean;
  registeredCount: number;
  participantCount: number;
}) {
  const sorted = [...entries].sort((a, b) => {
    if (a.rank != null && b.rank != null) return a.rank - b.rank;
    if (a.rank != null) return -1;
    if (b.rank != null) return 1;
    // To'laganlar oldinda ko'rinsin.
    if (a.paid !== b.paid) return a.paid ? -1 : 1;
    return 0;
  });

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm font-semibold text-foreground">Ishtirokchilar ({entries.length})</p>
        <div className="flex items-center gap-2">
          <span
            className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold"
            style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
          >
            <Users className="h-3 w-3" strokeWidth={2.5} />
            {registeredCount} ro'yxat
          </span>
          <span
            className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold"
            style={{
              backgroundColor: "var(--tone-excellent-soft)",
              color: "var(--tone-excellent)",
            }}
          >
            <CheckCircle2 className="h-3 w-3" strokeWidth={2.5} />
            {participantCount} to'lagan
          </span>
        </div>
      </div>

      {entries.length === 0 ? (
        <div className="rounded-2xl bg-card p-6 text-center text-sm text-muted-foreground shadow-card">
          Hali qatnashuvchi yo'q.
        </div>
      ) : (
        <div className="space-y-2">
          {sorted.map((entry) => (
            <div
              key={entry.id}
              className="flex items-center gap-3 rounded-2xl bg-card p-3.5 shadow-card"
            >
              <div
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold"
                style={{ backgroundColor: "var(--muted)", color: "var(--muted-foreground)" }}
              >
                {finished && entry.rank != null ? entry.rank : "—"}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <p className="truncate text-sm font-medium text-foreground">
                    {entry.user?.firstName ?? "Noma'lum"}
                  </p>
                  <span
                    className="shrink-0 rounded-full px-1.5 py-0.5 text-[9.5px] font-bold uppercase"
                    style={{
                      backgroundColor: entry.paid ? "var(--tone-excellent-soft)" : "var(--muted)",
                      color: entry.paid ? "var(--tone-excellent)" : "var(--muted-foreground)",
                    }}
                  >
                    {entry.paid ? "to'lagan" : "ro'yxat"}
                  </span>
                </div>
                <p className="flex items-center gap-1 text-[11.5px] text-muted-foreground">
                  {entry.essayId ? (
                    <>
                      <CheckCircle2
                        className="h-3 w-3"
                        style={{ color: "var(--tone-excellent)" }}
                        strokeWidth={2.5}
                      />
                      Esse yuborilgan
                    </>
                  ) : (
                    "Esse yubormagan"
                  )}
                  {entry.awardedPrize?.reward && ` · 🏆 ${entry.awardedPrize.reward}`}
                </p>
              </div>
              {finished && entry.scaledScore != null && (
                <span className="shrink-0 text-sm font-bold tabular-nums text-primary">
                  {entry.scaledScore}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
