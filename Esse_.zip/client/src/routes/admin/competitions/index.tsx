import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Plus, Trophy } from "lucide-react";
import { adminApi, type CompetitionAdmin } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { Skeleton } from "@/components/Skeleton";
import { formatDate, formatSum } from "@/lib/format";
import { COMPETITION_STATUS_META } from "@/lib/competition";

export const Route = createFileRoute("/admin/competitions/")({
  head: () => ({ meta: [{ title: "Admin — Musobaqalar" }] }),
  component: () => (
    <AdminGate>
      <AdminCompetitionsPage />
    </AdminGate>
  ),
});

function AdminCompetitionsPage() {
  const listQ = useQuery({
    queryKey: ["admin-competitions"],
    queryFn: adminApi.listCompetitions,
  });

  return (
    <AdminShell
      title="Musobaqalar"
      actions={
        <Link
          to="/admin/competitions/new"
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
        >
          <Plus className="h-4 w-4" strokeWidth={2.5} />
          Yangi musobaqa
        </Link>
      }
    >
      {listQ.isLoading && (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-[76px] rounded-2xl" />
          ))}
        </div>
      )}

      {listQ.data && listQ.data.length === 0 && (
        <div className="rounded-2xl bg-card p-10 text-center shadow-card">
          <div
            className="mx-auto flex h-14 w-14 items-center justify-center rounded-full"
            style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
          >
            <Trophy className="h-7 w-7" strokeWidth={1.8} />
          </div>
          <p className="mt-3 text-sm text-muted-foreground">Hali musobaqa qo'shilmagan.</p>
        </div>
      )}

      {listQ.data && listQ.data.length > 0 && (
        <div className="space-y-2.5">
          {listQ.data.map((c) => (
            <CompetitionRow key={c.id} competition={c} />
          ))}
        </div>
      )}
    </AdminShell>
  );
}

function CompetitionRow({ competition }: { competition: CompetitionAdmin }) {
  const meta = COMPETITION_STATUS_META[competition.status];
  const tone = meta.tone === "muted" ? null : meta.tone;

  return (
    <Link
      to="/admin/competitions/$id"
      params={{ id: String(competition.id) }}
      className="flex items-center gap-3 rounded-2xl bg-card p-4 shadow-card transition-transform active:scale-[0.99]"
    >
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-foreground">{competition.title}</p>
        <p className="mt-0.5 text-xs text-muted-foreground">
          {formatDate(competition.createdAt)}
          {competition.entryFee > 0 && ` · ${formatSum(competition.entryFee)}`}
        </p>
      </div>

      {competition.status === "evaluating" && competition.evalProgress && (
        <span className="shrink-0 text-[11px] font-medium tabular-nums text-muted-foreground">
          {competition.evalProgress.done}/{competition.evalProgress.total}
        </span>
      )}

      <span
        className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold"
        style={{
          backgroundColor: tone ? `var(--tone-${tone}-soft)` : "var(--muted)",
          color: tone ? `var(--tone-${tone})` : "var(--muted-foreground)",
        }}
      >
        {meta.label}
      </span>
    </Link>
  );
}
