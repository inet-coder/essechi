import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { adminApi, type CompetitionInput } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { CompetitionForm } from "@/components/CompetitionForm";

export const Route = createFileRoute("/admin/competitions/new")({
  head: () => ({ meta: [{ title: "Admin — Yangi musobaqa" }] }),
  component: () => (
    <AdminGate>
      <NewCompetitionPage />
    </AdminGate>
  ),
});

function NewCompetitionPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (values: CompetitionInput) => adminApi.createCompetition(values),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-competitions"] });
      navigate({ to: "/admin/competitions" });
    },
  });

  return (
    <AdminShell title="Yangi musobaqa">
      <CompetitionForm
        submitLabel="Yaratish (qoralama)"
        submitting={createMutation.isPending}
        onSubmit={(values) => createMutation.mutate(values)}
      />
      {createMutation.isError && (
        <p className="mt-3 text-sm font-medium" style={{ color: "var(--tone-bad)" }}>
          Saqlashda xatolik yuz berdi. Qayta urinib ko'ring.
        </p>
      )}
    </AdminShell>
  );
}
