import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, User as UserIcon, FileText } from "lucide-react";
import { adminApi, ApiError } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { formatDate, scoreTone, scaledTone } from "@/lib/format";

export const Route = createFileRoute("/admin/essays/$essayId")({
  head: () => ({ meta: [{ title: "Admin — Esse tahlili" }] }),
  component: () => (
    <AdminGate>
      <AdminEssayDetailPage />
    </AdminGate>
  ),
});

const TONE_VAR: Record<string, string> = {
  excellent: "var(--tone-excellent)",
  good: "var(--tone-good)",
  ok: "var(--tone-ok)",
  weak: "var(--tone-weak)",
  bad: "var(--tone-bad)",
};

function AdminEssayDetailPage() {
  const { essayId } = Route.useParams();
  const essayQ = useQuery({
    queryKey: ["admin", "essay", essayId],
    queryFn: () => adminApi.getEssay(essayId),
  });

  const e = essayQ.data;
  const ev = e?.evaluationResult;

  return (
    <AdminShell title="Esse tahlili">
      <Link
        to="/admin/users"
        className="mb-2 inline-flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={2} />
        Orqaga
      </Link>

      {essayQ.isLoading && <p className="text-sm text-muted-foreground">Yuklanmoqda…</p>}
      {essayQ.error && (
        <div className="rounded-2xl border border-border bg-card p-6 text-center">
          <p className="text-sm text-muted-foreground">
            {(essayQ.error as ApiError).status === 404
              ? "Esse topilmadi"
              : "Ma'lumotni yuklab bo'lmadi"}
          </p>
        </div>
      )}

      {e && (
        <div className="mx-auto max-w-[640px] space-y-4">
          {/* Sarlavha + muallif */}
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span>{formatDate(e.createdAt)}</span>
              <span>·</span>
              <span>{e.sourceType === "pdf" ? "PDF" : "Matn"}</span>
              <span>·</span>
              <span>{e.wordCount} so'z</span>
            </div>
            <p className="mt-2 text-[15px] font-medium leading-relaxed text-foreground">
              {e.topic}
            </p>
            {e.author && (
              <Link
                to="/admin/users/$telegramId"
                params={{ telegramId: e.author.telegramId }}
                className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-muted/60 px-2.5 py-1.5 text-[13px] font-medium text-foreground transition-colors hover:bg-muted"
              >
                <UserIcon className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={2} />
                {e.author.firstName || "(ismsiz)"}
                {e.author.username && (
                  <span className="text-muted-foreground">@{e.author.username}</span>
                )}
                <span className="text-muted-foreground">· ID {e.author.telegramId}</span>
              </Link>
            )}
          </div>

          {/* Umumiy ball */}
          {ev && ev.status === "completed" && (
            <div className="rounded-2xl border border-border bg-card p-5 text-center">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Umumiy natija
              </p>
              <p
                className="mt-1 text-4xl font-bold tabular-nums"
                style={{ color: TONE_VAR[scaledTone(ev.scaledScore)] }}
              >
                {ev.scaledScore}
                <span className="text-lg text-muted-foreground">/75</span>
              </p>
              <p className="mt-0.5 text-[13px] text-muted-foreground">Xom ball: {ev.totalScore}</p>
            </div>
          )}

          {ev && ev.status === "auto_rejected" && (
            <div
              className="rounded-2xl border p-4"
              style={{
                borderColor: "color-mix(in oklch, var(--tone-bad) 30%, transparent)",
                backgroundColor: "color-mix(in oklch, var(--tone-bad) 8%, transparent)",
              }}
            >
              <p className="text-sm font-semibold" style={{ color: "var(--tone-bad)" }}>
                Avtomatik rad etilgan
              </p>
              {ev.rejectionReason && (
                <p className="mt-1 text-[13px] text-foreground">{ev.rejectionReason}</p>
              )}
            </div>
          )}

          {!ev && (
            <div className="rounded-2xl border border-border bg-card p-6 text-center">
              <p className="text-sm text-muted-foreground">Bu esse hali tekshirilmagan.</p>
            </div>
          )}

          {/* Band natijalari */}
          {ev && ev.status === "completed" && ev.bandResults.length > 0 && (
            <div className="rounded-2xl border border-border bg-card p-4">
              <h2 className="mb-3 text-sm font-bold text-foreground">Mezonlar bo'yicha</h2>
              <div className="space-y-2.5">
                {ev.bandResults.map((b) => (
                  <div key={b.band} className="rounded-xl bg-muted/40 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-[13px] font-semibold text-foreground">
                        {b.band}. {b.criterion_name}
                      </p>
                      <span
                        className="shrink-0 rounded-full px-2 py-0.5 text-[12px] font-bold tabular-nums"
                        style={{
                          backgroundColor: `color-mix(in oklch, ${TONE_VAR[scoreTone(b.score)]} 15%, transparent)`,
                          color: TONE_VAR[scoreTone(b.score)],
                        }}
                      >
                        {b.score}
                      </span>
                    </div>
                    {b.comment && (
                      <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted-foreground">
                        {b.comment}
                      </p>
                    )}
                    {b.errors && b.errors.length > 0 && (
                      <div className="mt-2 space-y-1.5">
                        {b.errors.map((err, i) => (
                          <div
                            key={i}
                            className="rounded-lg border border-border bg-background px-2.5 py-1.5 text-[12px]"
                          >
                            <p className="text-muted-foreground line-through">{err.original}</p>
                            <p className="font-medium text-foreground">{err.suggestion}</p>
                            {err.explanation && (
                              <p className="mt-0.5 text-[11px] text-muted-foreground">
                                {err.explanation}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tavsiyalar */}
          {ev && ev.recommendations.length > 0 && (
            <div className="rounded-2xl border border-border bg-card p-4">
              <h2 className="mb-2 text-sm font-bold text-foreground">Tavsiyalar</h2>
              <ul className="space-y-1.5">
                {ev.recommendations.map((r, i) => (
                  <li key={i} className="flex gap-2 text-[13px] leading-relaxed text-foreground">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    {r}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Esse matni */}
          <div className="rounded-2xl border border-border bg-card p-4">
            <h2 className="mb-2 flex items-center gap-2 text-sm font-bold text-foreground">
              <FileText className="h-4 w-4 text-muted-foreground" strokeWidth={2} />
              Esse matni
            </h2>
            <p className="whitespace-pre-wrap text-[13.5px] leading-relaxed text-foreground">
              {e.rawText}
            </p>
          </div>
        </div>
      )}
    </AdminShell>
  );
}
