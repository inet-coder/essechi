import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Users,
  FileText,
  CheckCircle2,
  Wallet,
  Clock,
  TrendingUp,
  Gauge,
  Gift,
  Loader2,
  ArrowRight,
} from "lucide-react";
import { adminApi, type AdminStats, type AdminFreeEssaySettings } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { formatSum, formatDate } from "@/lib/format";

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [{ title: "Admin — Boshqaruv" }] }),
  component: () => (
    <AdminGate>
      <AdminDashboard />
    </AdminGate>
  ),
});

function AdminDashboard() {
  const statsQ = useQuery({ queryKey: ["admin", "stats"], queryFn: adminApi.stats });
  const paymentsQ = useQuery({
    queryKey: ["admin", "payments", "recent"],
    queryFn: () => adminApi.listPayments({ status: "confirmed", limit: 6 }),
  });
  const essaysQ = useQuery({
    queryKey: ["admin", "essays", "recent"],
    queryFn: () => adminApi.listEssays({ limit: 6 }),
  });

  const s = statsQ.data;

  return (
    <AdminShell title="Boshqaruv paneli">
      {statsQ.isLoading && <div className="text-sm text-muted-foreground">Yuklanmoqda…</div>}

      {s && (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <StatCard
              icon={Users}
              tone="primary"
              label="Foydalanuvchilar"
              value={s.userCount.toLocaleString("ru-RU")}
              hint={s.usersToday > 0 ? `Bugun +${s.usersToday}` : "Bugun 0"}
            />
            <StatCard
              icon={FileText}
              tone="good"
              label="Jami esselar"
              value={s.essayCount.toLocaleString("ru-RU")}
              hint={s.essaysToday > 0 ? `Bugun +${s.essaysToday}` : "Bugun 0"}
            />
            <StatCard
              icon={CheckCircle2}
              tone="excellent"
              label="Tekshirilgan"
              value={s.checkedCount.toLocaleString("ru-RU")}
              hint={`${s.essayCount ? Math.round((s.checkedCount / s.essayCount) * 100) : 0}% esselar`}
            />
            <StatCard
              icon={Wallet}
              tone="excellent"
              label="Jami tushum"
              value={formatSum(s.revenue)}
              hint={`${s.paidPaymentsCount} ta to'lov`}
            />
            <StatCard
              icon={Clock}
              tone={s.pendingPayments > 0 ? "weak" : "ok"}
              label="Kutilayotgan"
              value={s.pendingPayments.toLocaleString("ru-RU")}
              hint="to'lov jarayonda"
            />
            <StatCard
              icon={Gauge}
              tone="good"
              label="O'rtacha ball"
              value={s.avgScaledScore != null ? `${s.avgScaledScore}/75` : "—"}
              hint="tekshirilgan esselar"
            />
          </div>

          <FreeEssayCard />

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            {/* So'nggi esselar */}
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="flex items-center gap-2 text-sm font-bold text-foreground">
                  <FileText className="h-4 w-4 text-primary" strokeWidth={2} />
                  So'nggi esselar
                </h2>
              </div>
              <div className="space-y-1.5">
                {essaysQ.data?.essays.slice(0, 6).map((e) => (
                  <Link
                    key={e.id}
                    to="/admin/essays/$essayId"
                    params={{ essayId: String(e.id) }}
                    className="flex items-center gap-3 rounded-xl px-2.5 py-2 transition-colors hover:bg-muted"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-medium text-foreground">{e.topic}</p>
                      <p className="truncate text-[11px] text-muted-foreground">
                        {e.author?.firstName || "—"} · {formatDate(e.createdAt)}
                      </p>
                    </div>
                    <EssayStatusBadge status={e.status} scaled={e.evaluationResult?.scaledScore} />
                  </Link>
                ))}
                {essaysQ.data && essaysQ.data.essays.length === 0 && (
                  <p className="px-2.5 py-4 text-center text-xs text-muted-foreground">
                    Hali esse yo'q
                  </p>
                )}
              </div>
            </div>

            {/* So'nggi to'lovlar */}
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="flex items-center gap-2 text-sm font-bold text-foreground">
                  <TrendingUp className="h-4 w-4 text-primary" strokeWidth={2} />
                  So'nggi to'lovlar
                </h2>
                <Link
                  to="/admin/payments"
                  className="flex items-center gap-0.5 text-xs font-medium text-primary hover:underline"
                >
                  Barchasi
                  <ArrowRight className="h-3 w-3" strokeWidth={2.2} />
                </Link>
              </div>
              <div className="space-y-1.5">
                {paymentsQ.data?.payments.slice(0, 6).map((p) => (
                  <Link
                    key={p.id}
                    to="/admin/users/$telegramId"
                    params={{ telegramId: p.user?.telegramId ?? "" }}
                    className="flex items-center gap-3 rounded-xl px-2.5 py-2 transition-colors hover:bg-muted"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-medium text-foreground">
                        {p.user?.firstName || "—"}
                      </p>
                      <p className="truncate text-[11px] text-muted-foreground">
                        {p.kind === "package" ? `${p.essayCredits} kredit paket` : "Balans"} ·{" "}
                        {formatDate(p.createdAt)}
                      </p>
                    </div>
                    <span className="shrink-0 text-[13px] font-bold tabular-nums text-foreground">
                      {formatSum(p.amount)}
                    </span>
                  </Link>
                ))}
                {paymentsQ.data && paymentsQ.data.payments.length === 0 && (
                  <p className="px-2.5 py-4 text-center text-xs text-muted-foreground">
                    Hali to'lov yo'q
                  </p>
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </AdminShell>
  );
}

function FreeEssayCard() {
  const queryClient = useQueryClient();
  const q = useQuery({ queryKey: ["admin", "free-essay"], queryFn: adminApi.freeEssay });
  const [draft, setDraft] = useState("");

  // Ma'lumot kelganda inputni joriy limit bilan to'ldiramiz (bir marta).
  useEffect(() => {
    if (q.data && draft === "") setDraft(String(q.data.limit));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q.data]);

  const mutation = useMutation({
    mutationFn: (limit: number) => adminApi.setFreeEssayLimit(limit),
    onSuccess: (data) => {
      queryClient.setQueryData(["admin", "free-essay"], data);
      setDraft(String(data.limit));
    },
  });

  const data = q.data;
  const parsed = Number(draft);
  const valid = draft.trim() !== "" && Number.isInteger(parsed) && parsed >= 0;
  const changed = Boolean(data && valid && parsed !== data.limit);

  return (
    <div className="mt-6 rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-2.5">
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
          style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
        >
          <Gift className="h-4.5 w-4.5" strokeWidth={2} />
        </span>
        <div>
          <h2 className="text-sm font-bold text-foreground">Bepul esse tekshiruvi</h2>
          <p className="text-[11.5px] text-muted-foreground">
            Har bir foydalanuvchiga beriladigan bepul tekshiruvlar soni
          </p>
        </div>
      </div>

      {data && (
        <>
          <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
            <MiniStat label="Jami sarflangan" value={data.totalUsed} />
            <MiniStat label="Foydalanganlar" value={data.usersUsedAny} />
            <MiniStat label="Tugatganlar" value={data.usersUsedUp} />
            <MiniStat label="Bepuli borlar" value={data.usersWithRemaining} />
          </div>

          <div className="mt-4 flex flex-wrap items-end gap-3">
            <div>
              <label
                htmlFor="free-limit"
                className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground"
              >
                Bepul tekshiruvlar soni
              </label>
              <input
                id="free-limit"
                type="number"
                min={0}
                step={1}
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                className="mt-1.5 w-32 rounded-xl border border-input bg-background px-3.5 py-2.5 text-sm font-semibold text-foreground outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <button
              type="button"
              disabled={!changed || mutation.isPending}
              onClick={() => valid && mutation.mutate(parsed)}
              className="flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
            >
              {mutation.isPending && <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2} />}
              Saqlash
            </button>
            {draft.trim() !== "" && !valid && (
              <p className="text-[12px] font-medium" style={{ color: "var(--tone-bad)" }}>
                Manfiy bo'lmagan butun son kiriting
              </p>
            )}
          </div>

          <p className="mt-3 text-[11.5px] leading-relaxed text-muted-foreground">
            Hozir har bir foydalanuvchi <b className="text-foreground">{data.limit}</b> ta bepul
            tekshiruvdan foydalana oladi. 0 kiritilsa bepul tekshiruv berilmaydi. Bu o'zgarish faqat
            yangi tekshiruvlarga ta'sir qiladi.
          </p>
        </>
      )}

      {q.isLoading && <p className="mt-4 text-sm text-muted-foreground">Yuklanmoqda…</p>}
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl bg-muted/60 px-3 py-2.5">
      <p className="text-lg font-bold tabular-nums text-foreground">
        {value.toLocaleString("ru-RU")}
      </p>
      <p className="text-[11px] text-muted-foreground">{label}</p>
    </div>
  );
}

const TONE_VAR: Record<string, string> = {
  primary: "var(--primary)",
  excellent: "var(--tone-excellent)",
  good: "var(--tone-good)",
  ok: "var(--tone-ok)",
  weak: "var(--tone-weak)",
  bad: "var(--tone-bad)",
};

function StatCard({
  icon: Icon,
  tone,
  label,
  value,
  hint,
}: {
  icon: typeof Users;
  tone: keyof typeof TONE_VAR;
  label: string;
  value: string;
  hint?: string;
}) {
  const color = TONE_VAR[tone];
  return (
    <div className="rounded-2xl border border-border bg-card p-3.5 shadow-card">
      <div
        className="flex h-8 w-8 items-center justify-center rounded-lg"
        style={{ backgroundColor: `color-mix(in oklch, ${color} 14%, transparent)` }}
      >
        <Icon className="h-4 w-4" style={{ color }} strokeWidth={2} />
      </div>
      <p className="mt-2.5 text-[19px] font-bold leading-tight tabular-nums text-foreground">
        {value}
      </p>
      <p className="text-[12px] font-medium text-muted-foreground">{label}</p>
      {hint && <p className="mt-0.5 text-[11px] text-muted-foreground/80">{hint}</p>}
    </div>
  );
}

function EssayStatusBadge({ status, scaled }: { status: string; scaled?: number }) {
  if (status === "checked" && scaled != null) {
    return (
      <span
        className="shrink-0 rounded-full px-2 py-0.5 text-[11px] font-bold tabular-nums"
        style={{
          backgroundColor: "color-mix(in oklch, var(--tone-good) 14%, transparent)",
          color: "var(--tone-good)",
        }}
      >
        {scaled}/75
      </span>
    );
  }
  const map: Record<string, { label: string; tone: string }> = {
    pending: { label: "Kutilmoqda", tone: "var(--tone-weak)" },
    rejected: { label: "Rad etilgan", tone: "var(--tone-bad)" },
    checked: { label: "Tekshirilgan", tone: "var(--tone-good)" },
  };
  const m = map[status] ?? { label: status, tone: "var(--muted-foreground)" };
  return (
    <span
      className="shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold"
      style={{
        backgroundColor: `color-mix(in oklch, ${m.tone} 14%, transparent)`,
        color: m.tone,
      }}
    >
      {m.label}
    </span>
  );
}
