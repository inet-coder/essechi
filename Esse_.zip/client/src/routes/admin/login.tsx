import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { adminApi, ApiError } from "@/lib/api";

export const Route = createFileRoute("/admin/login")({
  head: () => ({ meta: [{ title: "Admin — Kirish" }] }),
  component: AdminLoginPage,
});

function AdminLoginPage() {
  const navigate = useNavigate();
  const [key, setKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!key.trim()) return;
    setLoading(true);
    setError(null);
    try {
      await adminApi.login(key.trim());
      navigate({ to: "/admin" });
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setError("Kalit notoʻgʻri. Qayta urinib koʻring.");
      } else {
        setError("Ulanishda xatolik. Internetni tekshiring.");
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-6">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm rounded-2xl bg-card p-8 shadow-elevated"
      >
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-soft text-primary">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="h-7 w-7"
          >
            <rect x="3" y="11" width="18" height="10" rx="2" />
            <path d="M7 11V7a5 5 0 0110 0v4" />
          </svg>
        </div>
        <h1 className="text-center text-lg font-semibold text-foreground">Admin panel</h1>
        <p className="mt-1.5 text-center text-sm text-muted-foreground">
          Davom etish uchun admin kalitni kiriting.
        </p>

        <input
          type="password"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="Admin kalit"
          autoFocus
          className="mt-6 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
        />

        {error && (
          <p className="mt-2 text-xs font-medium" style={{ color: "var(--tone-bad)" }}>
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading || !key.trim()}
          className="mt-4 w-full rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
        >
          {loading ? "Tekshirilmoqda…" : "Kirish"}
        </button>
      </form>
    </div>
  );
}
