import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import {
  CheckCircle2,
  Clock,
  XCircle,
  ChevronLeft,
  ChevronRight,
  Package,
  Wallet,
} from "lucide-react";
import { adminApi } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { formatSum, formatDate } from "@/lib/format";

export const Route = createFileRoute("/admin/payments/")({
  head: () => ({ meta: [{ title: "Admin — To'lovlar" }] }),
  component: () => (
    <AdminGate>
      <AdminPaymentsPage />
    </AdminGate>
  ),
});

const FILTERS = [
  { value: "", label: "Barchasi" },
  { value: "confirmed", label: "Tasdiqlangan" },
  { value: "pending", label: "Kutilayotgan" },
  { value: "expired", label: "Muddati o'tgan" },
];

function AdminPaymentsPage() {
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);

  const paymentsQ = useQuery({
    queryKey: ["admin", "payments", status, page],
    queryFn: () => adminApi.listPayments({ status, page, limit: 30 }),
    placeholderData: keepPreviousData,
  });

  const data = paymentsQ.data;

  return (
    <AdminShell title="To'lovlar jurnali">
      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => {
          const active = status === f.value;
          return (
            <button
              key={f.value}
              type="button"
              onClick={() => {
                setStatus(f.value);
                setPage(1);
              }}
              className="rounded-full border px-3.5 py-1.5 text-[13px] font-medium transition-colors"
              style={{
                backgroundColor: active ? "var(--primary)" : "var(--card)",
                borderColor: active ? "var(--primary)" : "var(--border)",
                color: active ? "var(--primary-foreground)" : "var(--muted-foreground)",
              }}
            >
              {f.label}
            </button>
          );
        })}
      </div>

      {data && (
        <p className="mt-3 text-xs text-muted-foreground">
          Jami {data.total.toLocaleString("ru-RU")} ta yozuv
        </p>
      )}

      <div className="mt-3 space-y-2">
        {paymentsQ.isLoading && <p className="text-sm text-muted-foreground">Yuklanmoqda…</p>}

        {data?.payments.map((p) => (
          <div
            key={p.id}
            className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3.5 shadow-card"
          >
            <StatusIcon status={p.status} />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                {p.kind === "package" ? (
                  <Package className="h-3.5 w-3.5 shrink-0 text-muted-foreground" strokeWidth={2} />
                ) : (
                  <Wallet className="h-3.5 w-3.5 shrink-0 text-muted-foreground" strokeWidth={2} />
                )}
                <p className="truncate text-[13px] font-semibold text-foreground">
                  {p.kind === "package" ? `${p.essayCredits} kredit paketi` : "Balans to'ldirish"}
                </p>
              </div>
              {p.user ? (
                <Link
                  to="/admin/users/$telegramId"
                  params={{ telegramId: p.user.telegramId }}
                  className="truncate text-[11px] text-primary hover:underline"
                >
                  {p.user.firstName || "(ismsiz)"} · ID {p.user.telegramId}
                </Link>
              ) : (
                <p className="text-[11px] text-muted-foreground">Foydalanuvchi o'chirilgan</p>
              )}
              <p className="text-[11px] text-muted-foreground">
                {formatDate(p.createdAt)}
                {p.note && ` · ${p.note}`}
              </p>
            </div>
            <div className="shrink-0 text-right">
              <p className="text-[14px] font-bold tabular-nums text-foreground">
                {formatSum(p.amount)}
              </p>
              <StatusText status={p.status} />
            </div>
          </div>
        ))}

        {data && data.payments.length === 0 && !paymentsQ.isLoading && (
          <div className="rounded-2xl border border-border bg-card p-8 text-center">
            <p className="text-sm text-muted-foreground">Yozuv topilmadi</p>
          </div>
        )}
      </div>

      {data && (data.page > 1 || data.hasMore) && (
        <div className="mt-5 flex items-center justify-center gap-3">
          <button
            type="button"
            disabled={data.page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="flex items-center gap-1 rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium text-foreground disabled:opacity-40"
          >
            <ChevronLeft className="h-4 w-4" strokeWidth={2} />
            Oldingi
          </button>
          <span className="text-sm text-muted-foreground">{data.page}-sahifa</span>
          <button
            type="button"
            disabled={!data.hasMore}
            onClick={() => setPage((p) => p + 1)}
            className="flex items-center gap-1 rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium text-foreground disabled:opacity-40"
          >
            Keyingi
            <ChevronRight className="h-4 w-4" strokeWidth={2} />
          </button>
        </div>
      )}
    </AdminShell>
  );
}

function StatusIcon({ status }: { status: string }) {
  if (status === "confirmed")
    return (
      <CheckCircle2
        className="h-5 w-5 shrink-0"
        style={{ color: "var(--tone-good)" }}
        strokeWidth={2}
      />
    );
  if (status === "pending")
    return (
      <Clock className="h-5 w-5 shrink-0" style={{ color: "var(--tone-weak)" }} strokeWidth={2} />
    );
  return (
    <XCircle
      className="h-5 w-5 shrink-0"
      style={{ color: "var(--muted-foreground)" }}
      strokeWidth={2}
    />
  );
}

function StatusText({ status }: { status: string }) {
  const map: Record<string, { label: string; tone: string }> = {
    confirmed: { label: "Tasdiqlangan", tone: "var(--tone-good)" },
    pending: { label: "Kutilmoqda", tone: "var(--tone-weak)" },
    expired: { label: "Muddati o'tgan", tone: "var(--muted-foreground)" },
  };
  const m = map[status] ?? { label: status, tone: "var(--muted-foreground)" };
  return (
    <p className="text-[11px] font-medium" style={{ color: m.tone }}>
      {m.label}
    </p>
  );
}
