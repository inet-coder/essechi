import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Folder, FolderPlus, ListTodo, Plus, Tag, Trash2, X } from "lucide-react";
import { adminApi, type Category, type Topic } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { Skeleton } from "@/components/Skeleton";

export const Route = createFileRoute("/admin/topics/")({
  head: () => ({ meta: [{ title: "Admin — Mavzular" }] }),
  component: () => (
    <AdminGate>
      <AdminTopicsPage />
    </AdminGate>
  ),
});

const NO_CATEGORY = "none";
const NEW_CATEGORY = "new";

const inputClass =
  "mt-2 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring";
const labelClass = "text-xs font-semibold uppercase tracking-wide text-muted-foreground";

function AdminTopicsPage() {
  const queryClient = useQueryClient();

  const topicsQ = useQuery({ queryKey: ["admin-topics"], queryFn: adminApi.listTopicsAdmin });
  const categoriesQ = useQuery({
    queryKey: ["admin-topic-categories"],
    queryFn: adminApi.listCategoriesAdmin,
  });

  const activeCategories = useMemo(
    () => (categoriesQ.data ?? []).filter((c) => c.isActive),
    [categoriesQ.data],
  );
  const activeTopics = useMemo(
    () => (topicsQ.data ?? []).filter((t) => t.isActive),
    [topicsQ.data],
  );

  const topicCountByCategory = useMemo(() => {
    const map = new Map<number, number>();
    for (const t of activeTopics) {
      if (t.category) map.set(t.category.id, (map.get(t.category.id) ?? 0) + 1);
    }
    return map;
  }, [activeTopics]);

  const groupedTopics = useMemo(() => {
    const groups = new Map<string, Topic[]>();
    for (const t of activeTopics) {
      const key = t.category?.name ?? "Kategoriyasiz";
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(t);
    }
    return Array.from(groups.entries()).sort(([a], [b]) => {
      if (a === "Kategoriyasiz") return 1;
      if (b === "Kategoriyasiz") return -1;
      return a.localeCompare(b);
    });
  }, [activeTopics]);

  // --- Kategoriya qo'shish ---
  const [addingCategory, setAddingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState("");

  const createCategoryMutation = useMutation({
    mutationFn: (name: string) => adminApi.createCategory(name),
    onSuccess: () => {
      setNewCategoryName("");
      setAddingCategory(false);
      queryClient.invalidateQueries({ queryKey: ["admin-topic-categories"] });
    },
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: (id: number) => adminApi.deleteCategory(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-topic-categories"] });
      queryClient.invalidateQueries({ queryKey: ["admin-topics"] });
    },
  });

  // --- Mavzu qo'shish ---
  const [addingTopic, setAddingTopic] = useState(false);
  const [newTopicText, setNewTopicText] = useState("");
  const [categoryChoice, setCategoryChoice] = useState<string>(NO_CATEGORY);
  const [newTopicCategoryName, setNewTopicCategoryName] = useState("");

  const createTopicMutation = useMutation({
    mutationFn: () => {
      const text = newTopicText.trim();
      if (categoryChoice === NEW_CATEGORY) {
        return adminApi.createTopic({ text, newCategoryName: newTopicCategoryName.trim() });
      }
      if (categoryChoice === NO_CATEGORY) {
        return adminApi.createTopic({ text, categoryId: null });
      }
      return adminApi.createTopic({ text, categoryId: Number(categoryChoice) });
    },
    onSuccess: () => {
      setNewTopicText("");
      setNewTopicCategoryName("");
      setCategoryChoice(NO_CATEGORY);
      setAddingTopic(false);
      queryClient.invalidateQueries({ queryKey: ["admin-topics"] });
      queryClient.invalidateQueries({ queryKey: ["admin-topic-categories"] });
    },
  });

  const deleteTopicMutation = useMutation({
    mutationFn: (id: number) => adminApi.deleteTopic(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-topics"] }),
  });

  const isLoading = topicsQ.isLoading || categoriesQ.isLoading;

  return (
    <AdminShell title="Mavzular">
      {isLoading && (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-[76px] rounded-2xl" />
          ))}
        </div>
      )}

      {!isLoading && (
        <div className="space-y-8">
          {/* ---------- Kategoriyalar ---------- */}
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-sm font-bold text-foreground">
                <Folder className="h-4 w-4 text-primary" strokeWidth={2} />
                Kategoriyalar
                <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">
                  {activeCategories.length}
                </span>
              </h2>
              {!addingCategory && (
                <button
                  type="button"
                  onClick={() => setAddingCategory(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                >
                  <FolderPlus className="h-3.5 w-3.5" strokeWidth={2} />
                  Kategoriya qoʻshish
                </button>
              )}
            </div>

            {addingCategory && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (newCategoryName.trim()) createCategoryMutation.mutate(newCategoryName);
                }}
                className="mb-3 flex items-center gap-2 rounded-2xl bg-card p-3 shadow-card"
              >
                <input
                  autoFocus
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="Kategoriya nomi (masalan: Ijtimoiy hayot)"
                  className="w-full rounded-xl border border-input bg-background px-3.5 py-2 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
                />
                <button
                  type="submit"
                  disabled={createCategoryMutation.isPending || !newCategoryName.trim()}
                  className="shrink-0 rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground disabled:opacity-50"
                >
                  Saqlash
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAddingCategory(false);
                    setNewCategoryName("");
                  }}
                  className="shrink-0 rounded-lg p-2 text-muted-foreground hover:bg-muted"
                  aria-label="Bekor qilish"
                >
                  <X className="h-4 w-4" strokeWidth={2} />
                </button>
              </form>
            )}

            {createCategoryMutation.isError && (
              <p className="mb-3 text-xs font-medium" style={{ color: "var(--tone-bad)" }}>
                Kategoriya qoʻshishda xatolik yuz berdi.
              </p>
            )}

            {activeCategories.length === 0 ? (
              <div className="rounded-2xl bg-card p-6 text-center shadow-card">
                <p className="text-sm text-muted-foreground">Hali kategoriya qoʻshilmagan.</p>
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {activeCategories.map((cat: Category) => (
                  <div
                    key={cat.id}
                    className="group flex items-center gap-2 rounded-full bg-card py-1.5 pl-3.5 pr-2 shadow-card"
                  >
                    <Tag className="h-3.5 w-3.5 text-primary" strokeWidth={2} />
                    <span className="text-sm font-medium text-foreground">{cat.name}</span>
                    <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
                      {topicCountByCategory.get(cat.id) ?? 0}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`"${cat.name}" kategoriyasini oʻchirasizmi?`)) {
                          deleteCategoryMutation.mutate(cat.id);
                        }
                      }}
                      className="rounded-full p-1 text-muted-foreground transition-colors hover:bg-muted"
                      style={{ color: "var(--tone-bad)" }}
                      aria-label="Kategoriyani oʻchirish"
                    >
                      <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* ---------- Mavzular ---------- */}
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-sm font-bold text-foreground">
                <ListTodo className="h-4 w-4 text-primary" strokeWidth={2} />
                Esse mavzulari
                <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">
                  {activeTopics.length}
                </span>
              </h2>
              {!addingTopic && (
                <button
                  type="button"
                  onClick={() => setAddingTopic(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                >
                  <Plus className="h-3.5 w-3.5" strokeWidth={2} />
                  Mavzu qoʻshish
                </button>
              )}
            </div>

            {addingTopic && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (
                    newTopicText.trim() &&
                    !(categoryChoice === NEW_CATEGORY && !newTopicCategoryName.trim())
                  ) {
                    createTopicMutation.mutate();
                  }
                }}
                className="mb-4 space-y-3 rounded-2xl bg-card p-4 shadow-card"
              >
                <div>
                  <label className={labelClass}>Mavzu (vaziyat) matni</label>
                  <textarea
                    autoFocus
                    value={newTopicText}
                    onChange={(e) => setNewTopicText(e.target.value)}
                    placeholder="Masalan: Zamonaviy texnologiyalar ta'lim sifatiga qanday ta'sir qiladi?"
                    rows={3}
                    className={`${inputClass} resize-y leading-relaxed`}
                  />
                </div>

                <div>
                  <label className={labelClass}>Kategoriya</label>
                  <select
                    value={categoryChoice}
                    onChange={(e) => setCategoryChoice(e.target.value)}
                    className={inputClass}
                  >
                    <option value={NO_CATEGORY}>Kategoriyasiz</option>
                    {activeCategories.map((cat) => (
                      <option key={cat.id} value={String(cat.id)}>
                        {cat.name}
                      </option>
                    ))}
                    <option value={NEW_CATEGORY}>➕ Yangi kategoriya…</option>
                  </select>
                </div>

                {categoryChoice === NEW_CATEGORY && (
                  <div>
                    <label className={labelClass}>Yangi kategoriya nomi</label>
                    <input
                      value={newTopicCategoryName}
                      onChange={(e) => setNewTopicCategoryName(e.target.value)}
                      placeholder="Kategoriya nomi"
                      className={inputClass}
                    />
                  </div>
                )}

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={createTopicMutation.isPending || !newTopicText.trim()}
                    className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
                  >
                    Mavzuni saqlash
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAddingTopic(false);
                      setNewTopicText("");
                      setNewTopicCategoryName("");
                      setCategoryChoice(NO_CATEGORY);
                    }}
                    className="rounded-lg px-4 py-2 text-sm font-medium text-muted-foreground hover:bg-muted"
                  >
                    Bekor qilish
                  </button>
                </div>

                {createTopicMutation.isError && (
                  <p className="text-xs font-medium" style={{ color: "var(--tone-bad)" }}>
                    Mavzu qoʻshishda xatolik yuz berdi.
                  </p>
                )}
              </form>
            )}

            {activeTopics.length === 0 ? (
              <div className="rounded-2xl bg-card p-10 text-center shadow-card">
                <p className="text-sm text-muted-foreground">Hali mavzu qoʻshilmagan.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {groupedTopics.map(([categoryName, topics]) => (
                  <div key={categoryName}>
                    <div className="mb-2 flex items-center gap-1.5 px-1">
                      <Folder className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={2} />
                      <h3 className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                        {categoryName}
                      </h3>
                    </div>
                    <div className="space-y-2">
                      {topics.map((topic) => (
                        <div
                          key={topic.id}
                          className="flex items-center gap-3 rounded-2xl bg-card p-3.5 shadow-card"
                        >
                          <p className="min-w-0 flex-1 text-sm leading-relaxed text-foreground">
                            {topic.text}
                          </p>
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm("Ushbu mavzuni oʻchirasizmi?")) {
                                deleteTopicMutation.mutate(topic.id);
                              }
                            }}
                            className="shrink-0 rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted"
                            style={{ color: "var(--tone-bad)" }}
                            aria-label="Mavzuni oʻchirish"
                          >
                            <Trash2 className="h-4 w-4" strokeWidth={2} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}
    </AdminShell>
  );
}
