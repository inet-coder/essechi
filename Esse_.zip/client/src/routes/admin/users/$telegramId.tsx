import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  Wallet,
  Ticket,
  FileText,
  Plus,
  Minus,
  Gift,
  Clock,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { adminApi, ApiError, type AdminUserDetail } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { formatSum, formatDate } from "@/lib/format";

export const Route = createFileRoute("/admin/users/$telegramId")({
  head: () => ({ meta: [{ title: "Admin — Foydalanuvchi" }] }),
  component: () => (
    <AdminGate>
      <AdminUserDetailPage />
    </AdminGate>
  ),
});

const labelClass = "text-xs font-semibold uppercase tracking-wide text-muted-foreground";
const fieldClass =
  "mt-2 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring";

function AdminUserDetailPage() {
  const { telegramId } = Route.useParams();
  const qc = useQueryClient();
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const detailQ = useQuery({
    queryKey: ["admin", "user", telegramId],
    queryFn: () => adminApi.getUserDetail(telegramId),
  });

  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [credits, setCredits] = useState("");

  const refetch = () => qc.invalidateQueries({ queryKey: ["admin", "user", telegramId] });

  const adjust = useMutation({
    mutationFn: (signed: number) =>
      adminApi.adjustBalance(telegramId, signed, note.trim() || undefined),
    onSuccess: (res) => {
      const sign = res.applied > 0 ? "+" : "−";
      setMessage({
        ok: true,
        text: `${sign}${formatSum(Math.abs(res.applied))} qo'llandi · yangi balans ${formatSum(res.balance)}`,
      });
      setAmount("");
      setNote("");
      refetch();
    },
    onError: (e: ApiError) => setMessage({ ok: false, text: e.message || "Xatolik" }),
  });

  const grant = useMutation({
    mutationFn: (n: number) => adminApi.grantCredits(telegramId, n),
    onSuccess: (res) => {
      setMessage({
        ok: true,
        text: `+${res.granted} kredit berildi · jami ${res.essayCredits} ta (30 kun)`,
      });
      setCredits("");
      refetch();
    },
    onError: (e: ApiError) => setMessage({ ok: false, text: e.message || "Xatolik" }),
  });

  const amountNum = Math.trunc(Number(amount));
  const validAmount = Number.isFinite(amountNum) && amountNum > 0;
  const creditNum = Math.trunc(Number(credits));
  const validCredit = Number.isFinite(creditNum) && creditNum > 0;

  const d = detailQ.data;

  return (
    <AdminShell title="Foydalanuvchi">
      <Link
        to="/admin/users"
        className="mb-2 inline-flex items-center gap-1 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={2} />
        Foydalanuvchilar
      </Link>

      {detailQ.isLoading && <p className="text-sm text-muted-foreground">Yuklanmoqda…</p>}
      {detailQ.error && (
        <div className="rounded-2xl border border-border bg-card p-6 text-center">
          <p className="text-sm text-muted-foreground">
            {(detailQ.error as ApiError).status === 404
              ? "Foydalanuvchi topilmadi"
              : "Ma'lumotni yuklab bo'lmadi"}
          </p>
        </div>
      )}

      {d && (
        <div className="space-y-4">
          {/* Profil */}
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary-soft text-lg font-bold text-primary">
                {d.user.firstName?.[0]?.toUpperCase() ?? "?"}
              </div>
              <div className="min-w-0">
                <p className="truncate text-base font-bold text-foreground">
                  {d.user.firstName || "(ismsiz)"}
                  {d.user.username && (
                    <span className="ml-1.5 text-sm font-normal text-muted-foreground">
                      @{d.user.username}
                    </span>
                  )}
                </p>
                <p className="text-xs text-muted-foreground">
                  ID {d.user.telegramId} · {formatDate(d.user.createdAt)} dan beri
                </p>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <MiniStat icon={Wallet} label="Balans" value={formatSum(d.user.balance)} />
              <MiniStat icon={Ticket} label="Kredit" value={`${d.user.essayCredits} ta`} />
              <MiniStat icon={FileText} label="Esselar" value={`${d.essays.length} ta`} />
              <MiniStat
                icon={CheckCircle2}
                label="Urinishlar"
                value={`${d.user.totalAttemptsUsed} ta`}
              />
            </div>
          </div>

          {message && (
            <p
              className="rounded-xl px-4 py-3 text-sm font-medium"
              style={{
                backgroundColor: message.ok
                  ? "color-mix(in oklch, var(--tone-excellent) 15%, transparent)"
                  : "color-mix(in oklch, var(--tone-bad) 15%, transparent)",
                color: message.ok ? "var(--tone-excellent)" : "var(--tone-bad)",
              }}
            >
              {message.text}
            </p>
          )}

          {/* Boshqaruv: balans + kredit */}
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="rounded-2xl border border-border bg-card p-4">
              <h2 className="text-sm font-bold text-foreground">Balansni o'zgartirish</h2>
              <label className={`${labelClass} mt-3 block`}>Summa (so'm)</label>
              <input
                className={fieldClass}
                value={amount}
                inputMode="numeric"
                placeholder="Masalan: 50000"
                onChange={(e) => setAmount(e.target.value.replace(/[^0-9]/g, ""))}
              />
              <label className={`${labelClass} mt-3 block`}>Izoh (ixtiyoriy)</label>
              <input
                className={fieldClass}
                value={note}
                placeholder="Masalan: Musobaqa mukofoti"
                onChange={(e) => setNote(e.target.value)}
              />
              <div className="mt-3 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  disabled={!validAmount || adjust.isPending}
                  onClick={() => adjust.mutate(amountNum)}
                  className="flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
                  style={{ backgroundColor: "var(--tone-excellent)" }}
                >
                  <Plus className="h-4 w-4" strokeWidth={2.5} />
                  Qo'shish
                </button>
                <button
                  type="button"
                  disabled={!validAmount || adjust.isPending}
                  onClick={() => adjust.mutate(-amountNum)}
                  className="flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
                  style={{ backgroundColor: "var(--tone-bad)" }}
                >
                  <Minus className="h-4 w-4" strokeWidth={2.5} />
                  Ayirish
                </button>
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-card p-4">
              <h2 className="text-sm font-bold text-foreground">Esse krediti berish</h2>
              <p className="mt-1 text-xs text-muted-foreground">
                Sovg'a/kompensatsiya sifatida bepul tekshiruv krediti (30 kun amal qiladi).
              </p>
              <label className={`${labelClass} mt-3 block`}>Kredit soni</label>
              <input
                className={fieldClass}
                value={credits}
                inputMode="numeric"
                placeholder="Masalan: 5"
                onChange={(e) => setCredits(e.target.value.replace(/[^0-9]/g, ""))}
              />
              <button
                type="button"
                disabled={!validCredit || grant.isPending}
                onClick={() => grant.mutate(creditNum)}
                className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
                style={{ backgroundColor: "var(--primary)" }}
              >
                <Gift className="h-4 w-4" strokeWidth={2.2} />
                Kredit berish
              </button>
            </div>
          </div>

          {/* Esselar */}
          <Section title="Esselar" count={d.essays.length}>
            {d.essays.length === 0 ? (
              <Empty text="Esse yo'q" />
            ) : (
              <div className="space-y-1.5">
                {d.essays.map((e) => (
                  <Link
                    key={e.id}
                    to="/admin/essays/$essayId"
                    params={{ essayId: String(e.id) }}
                    className="flex items-center gap-3 rounded-xl px-2.5 py-2 transition-colors hover:bg-muted"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-medium text-foreground">{e.topic}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {e.sourceType === "pdf" ? "PDF" : "Matn"} · {e.wordCount} so'z ·{" "}
                        {formatDate(e.createdAt)}
                      </p>
                    </div>
                    {e.status === "checked" && e.evaluationResult ? (
                      <span
                        className="shrink-0 rounded-full px-2 py-0.5 text-[11px] font-bold tabular-nums"
                        style={{
                          backgroundColor: "color-mix(in oklch, var(--tone-good) 14%, transparent)",
                          color: "var(--tone-good)",
                        }}
                      >
                        {e.evaluationResult.scaledScore}/75
                      </span>
                    ) : (
                      <StatusPill status={e.status} />
                    )}
                  </Link>
                ))}
              </div>
            )}
          </Section>

          {/* To'lovlar */}
          <Section title="To'lovlar tarixi" count={d.payments.length}>
            {d.payments.length === 0 ? (
              <Empty text="To'lov yo'q" />
            ) : (
              <div className="space-y-1.5">
                {d.payments.map((p) => (
                  <div key={p.id} className="flex items-center gap-3 rounded-xl px-2.5 py-2">
                    <PaymentStatusIcon status={p.status} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-medium text-foreground">
                        {p.kind === "package" ? `${p.essayCredits} kredit paketi` : "Balans"}
                        {p.note && (
                          <span className="font-normal text-muted-foreground"> · {p.note}</span>
                        )}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {formatDate(p.createdAt)} · {statusLabel(p.status)}
                      </p>
                    </div>
                    <span className="shrink-0 text-[13px] font-bold tabular-nums text-foreground">
                      {formatSum(p.amount)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </Section>

          {/* Kredit partiyalari */}
          {d.grants.length > 0 && (
            <Section title="Kredit partiyalari" count={d.grants.length}>
              <div className="space-y-1.5">
                {d.grants.map((g) => (
                  <div key={g.id} className="flex items-center gap-3 rounded-xl px-2.5 py-2">
                    <Ticket
                      className="h-4 w-4 shrink-0"
                      style={{ color: g.active ? "var(--tone-good)" : "var(--muted-foreground)" }}
                      strokeWidth={2}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] font-medium text-foreground">
                        {g.remaining}/{g.credits} qoldi
                        <span className="ml-1.5 font-normal text-muted-foreground">
                          {g.source === "admin" ? "· admin bergan" : "· paket"}
                        </span>
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {formatDate(g.createdAt)} · {formatDate(g.expiresAt)} gacha
                      </p>
                    </div>
                    <span
                      className="shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold"
                      style={{
                        backgroundColor: g.active
                          ? "color-mix(in oklch, var(--tone-good) 14%, transparent)"
                          : "var(--muted)",
                        color: g.active ? "var(--tone-good)" : "var(--muted-foreground)",
                      }}
                    >
                      {g.active ? "Faol" : "Tugagan"}
                    </span>
                  </div>
                ))}
              </div>
            </Section>
          )}
        </div>
      )}
    </AdminShell>
  );
}

function MiniStat({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Wallet;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl bg-muted/50 px-3 py-2">
      <p className="flex items-center gap-1 text-[11px] text-muted-foreground">
        <Icon className="h-3 w-3" strokeWidth={2} />
        {label}
      </p>
      <p className="mt-0.5 text-[13px] font-bold text-foreground">{value}</p>
    </div>
  );
}

function Section({
  title,
  count,
  children,
}: {
  title: string;
  count: number;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <h2 className="mb-2 flex items-center gap-2 text-sm font-bold text-foreground">
        {title}
        <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">
          {count}
        </span>
      </h2>
      {children}
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <p className="px-2.5 py-4 text-center text-xs text-muted-foreground">{text}</p>;
}

function statusLabel(status: string): string {
  if (status === "confirmed") return "tasdiqlangan";
  if (status === "pending") return "kutilmoqda";
  if (status === "expired") return "muddati o'tgan";
  return status;
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { label: string; tone: string }> = {
    pending: { label: "Kutilmoqda", tone: "var(--tone-weak)" },
    rejected: { label: "Rad etilgan", tone: "var(--tone-bad)" },
    checked: { label: "Tekshirilgan", tone: "var(--tone-good)" },
  };
  const m = map[status] ?? { label: status, tone: "var(--muted-foreground)" };
  return (
    <span
      className="shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold"
      style={{
        backgroundColor: `color-mix(in oklch, ${m.tone} 14%, transparent)`,
        color: m.tone,
      }}
    >
      {m.label}
    </span>
  );
}

function PaymentStatusIcon({ status }: { status: string }) {
  if (status === "confirmed")
    return (
      <CheckCircle2
        className="h-4 w-4 shrink-0"
        style={{ color: "var(--tone-good)" }}
        strokeWidth={2}
      />
    );
  if (status === "pending")
    return (
      <Clock className="h-4 w-4 shrink-0" style={{ color: "var(--tone-weak)" }} strokeWidth={2} />
    );
  return (
    <XCircle
      className="h-4 w-4 shrink-0"
      style={{ color: "var(--muted-foreground)" }}
      strokeWidth={2}
    />
  );
}
