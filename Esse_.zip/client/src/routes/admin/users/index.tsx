import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { Search, Wallet, Ticket, FileText, ChevronLeft, ChevronRight } from "lucide-react";
import { adminApi } from "@/lib/api";
import { AdminGate } from "@/components/AdminGate";
import { AdminShell } from "@/components/AdminShell";
import { formatSum, formatDate } from "@/lib/format";

export const Route = createFileRoute("/admin/users/")({
  head: () => ({ meta: [{ title: "Admin — Foydalanuvchilar" }] }),
  component: () => (
    <AdminGate>
      <AdminUsersPage />
    </AdminGate>
  ),
});

function AdminUsersPage() {
  const [input, setInput] = useState("");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);

  const usersQ = useQuery({
    queryKey: ["admin", "users", query, page],
    queryFn: () => adminApi.listUsers({ query, page, limit: 20 }),
    placeholderData: keepPreviousData,
  });

  const data = usersQ.data;

  function runSearch() {
    setQuery(input.trim());
    setPage(1);
  }

  return (
    <AdminShell title="Foydalanuvchilar">
      <div className="flex items-stretch gap-2">
        <input
          className="min-w-0 flex-1 rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
          value={input}
          placeholder="Ism, username yoki Telegram ID bo'yicha qidirish"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") runSearch();
          }}
        />
        <button
          type="button"
          onClick={runSearch}
          className="flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl px-4 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          style={{ backgroundColor: "var(--primary)" }}
        >
          <Search className="h-4 w-4 shrink-0" strokeWidth={2} />
          Qidirish
        </button>
      </div>

      {data && (
        <p className="mt-3 text-xs text-muted-foreground">
          Jami {data.total.toLocaleString("ru-RU")} ta foydalanuvchi
          {query && ` · "${query}" bo'yicha`}
        </p>
      )}

      <div className="mt-3 space-y-2">
        {usersQ.isLoading && <p className="text-sm text-muted-foreground">Yuklanmoqda…</p>}

        {data?.users.map((u) => (
          <Link
            key={u.id}
            to="/admin/users/$telegramId"
            params={{ telegramId: u.telegramId }}
            className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3.5 shadow-card transition-transform active:scale-[0.99]"
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary-soft text-sm font-bold text-primary">
              {u.firstName?.[0]?.toUpperCase() ?? "?"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-foreground">
                {u.firstName || "(ismsiz)"}
                {u.username && (
                  <span className="ml-1 font-normal text-muted-foreground">@{u.username}</span>
                )}
              </p>
              <p className="truncate text-[11px] text-muted-foreground">
                ID {u.telegramId} · {formatDate(u.createdAt)}
              </p>
            </div>
            <div className="hidden shrink-0 flex-col items-end gap-1 sm:flex">
              <span className="inline-flex items-center gap-1 text-[12px] font-medium text-foreground">
                <Wallet className="h-3 w-3 text-muted-foreground" strokeWidth={2} />
                {formatSum(u.balance)}
              </span>
              <span className="inline-flex items-center gap-2 text-[11px] text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Ticket className="h-3 w-3" strokeWidth={2} />
                  {u.essayCredits}
                </span>
                <span className="inline-flex items-center gap-1">
                  <FileText className="h-3 w-3" strokeWidth={2} />
                  {u.essayCount}
                </span>
              </span>
            </div>
          </Link>
        ))}

        {data && data.users.length === 0 && !usersQ.isLoading && (
          <div className="rounded-2xl border border-border bg-card p-8 text-center">
            <p className="text-sm text-muted-foreground">Foydalanuvchi topilmadi</p>
          </div>
        )}
      </div>

      {data && (data.page > 1 || data.hasMore) && (
        <div className="mt-5 flex items-center justify-center gap-3">
          <button
            type="button"
            disabled={data.page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="flex items-center gap-1 rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium text-foreground disabled:opacity-40"
          >
            <ChevronLeft className="h-4 w-4" strokeWidth={2} />
            Oldingi
          </button>
          <span className="text-sm text-muted-foreground">{data.page}-sahifa</span>
          <button
            type="button"
            disabled={!data.hasMore}
            onClick={() => setPage((p) => p + 1)}
            className="flex items-center gap-1 rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium text-foreground disabled:opacity-40"
          >
            Keyingi
            <ChevronRight className="h-4 w-4" strokeWidth={2} />
          </button>
        </div>
      )}
    </AdminShell>
  );
}
