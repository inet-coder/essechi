import { useState } from "react";
import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bot,
  Check,
  ChevronLeft,
  CreditCard,
  History,
  MessageCircle,
  WifiOff,
} from "lucide-react";
import {
  api,
  type AiAnalysisContent,
  type AiAnalysisRecord,
  type AiAnalysisStatus,
  ApiError,
} from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { Skeleton } from "@/components/Skeleton";
import { formatDate, formatSum } from "@/lib/format";

export const Route = createFileRoute("/analysis")({
  head: () => ({
    meta: [{ title: "AI xato tahlili" }],
  }),
  component: () => (
    <TelegramGate>
      <AnalysisPage />
    </TelegramGate>
  ),
});

function AnalysisPage() {
  const router = useRouter();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Ko'rsatilayotgan tahlil id'si (null = eng so'nggisi)
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const statusQ = useQuery<AiAnalysisStatus, ApiError>({
    queryKey: ["ai-analysis-status"],
    queryFn: api.aiAnalysisStatus,
    retry: false,
  });

  const historyQ = useQuery<AiAnalysisRecord[], ApiError>({
    queryKey: ["ai-analysis-history"],
    queryFn: api.aiAnalysisHistory,
    retry: false,
  });

  const generateMutation = useMutation({
    mutationFn: api.generateAiAnalysis,
    onSuccess: (record) => {
      setSelectedId(record.id);
      queryClient.invalidateQueries({ queryKey: ["ai-analysis-status"] });
      queryClient.invalidateQueries({ queryKey: ["ai-analysis-history"] });
      queryClient.invalidateQueries({ queryKey: ["me"] });
    },
  });

  const history = historyQ.data ?? [];
  const selected =
    (selectedId != null && history.find((a) => a.id === selectedId)) ||
    generateMutation.data ||
    history[0] ||
    statusQ.data?.lastAnalysis ||
    null;

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-[560px] items-center gap-3 px-4 py-3">
          <button
            type="button"
            onClick={() =>
              router.history.length > 1 ? router.history.back() : navigate({ to: "/profile" })
            }
            className="-ml-2 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-foreground transition-colors hover:bg-muted"
            aria-label="Orqaga"
          >
            <ChevronLeft className="h-5 w-5" strokeWidth={2} />
          </button>
          <h1 className="flex items-center gap-1.5 text-[15px] font-semibold text-foreground">
            <Bot className="h-4 w-4" strokeWidth={2} />
            AI xato tahlili
          </h1>
        </div>
      </div>

      <div className="mx-auto max-w-[560px] space-y-4 px-4 pb-12 pt-4">
        {statusQ.isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-40 rounded-2xl" />
          </div>
        ) : statusQ.error ? (
          <div className="mt-6 rounded-2xl bg-card p-6 text-center shadow-card">
            <WifiOff className="mx-auto h-8 w-8 text-muted-foreground" strokeWidth={1.5} />
            <h3 className="mt-3 text-base font-semibold text-foreground">Yuklab bo'lmadi</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Internetni tekshirib, qayta urinib ko'ring.
            </p>
            <button
              onClick={() => statusQ.refetch()}
              className="mt-4 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
            >
              Qayta urinish
            </button>
          </div>
        ) : (
          statusQ.data && (
            <IntroCard
              status={statusQ.data}
              pending={generateMutation.isPending}
              error={
                generateMutation.isError
                  ? generateMutation.error instanceof ApiError
                    ? generateMutation.error.message
                    : "Xatolik yuz berdi. Qayta urinib ko'ring."
                  : null
              }
              onGenerate={() => generateMutation.mutate()}
            />
          )
        )}

        {selected && (
          <div className="space-y-3 rounded-2xl bg-card p-5 shadow-card">
            <p className="text-[11px] text-muted-foreground">
              Tahlil sanasi: {formatDate(selected.createdAt)}
            </p>
            <AiAnalysisContentView content={selected.content} />
          </div>
        )}

        {history.length > 1 && (
          <div>
            <h3 className="flex items-center gap-1.5 px-1 pb-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              <History className="h-4 w-4" strokeWidth={2} />
              Oldingi tahlillar
            </h3>
            <div className="space-y-2">
              {history.map((record) => {
                const active = selected?.id === record.id;
                return (
                  <button
                    key={record.id}
                    type="button"
                    onClick={() => setSelectedId(record.id)}
                    className="flex w-full items-center gap-3 rounded-2xl border-[1.5px] bg-card p-3.5 text-left shadow-card transition-transform active:scale-[0.99]"
                    style={{ borderColor: active ? "var(--primary)" : "var(--border)" }}
                  >
                    <div
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                      style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
                    >
                      <Bot className="h-4 w-4" strokeWidth={2} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-foreground">
                        {formatDate(record.createdAt)}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        {record.content.overallSummary}
                      </p>
                    </div>
                    {active && (
                      <Check
                        className="h-4 w-4 shrink-0"
                        style={{ color: "var(--primary)" }}
                        strokeWidth={2.5}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function IntroCard({
  status,
  pending,
  error,
  onGenerate,
}: {
  status: AiAnalysisStatus;
  pending: boolean;
  error: string | null;
  onGenerate: () => void;
}) {
  return (
    <div className="rounded-2xl bg-card p-6 text-center shadow-card">
      <div
        className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl"
        style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
      >
        <Bot className="h-8 w-8" strokeWidth={1.8} />
      </div>
      <h2 className="mt-4 text-lg font-bold text-foreground">Xatolaringizni AI tahlil qilsin</h2>
      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
        Esselaringiz bo'yicha takrorlanuvchi xatolarni AI tahlil qiladi va aniq tavsiyalar beradi.{" "}
        <span>
          Narxi {formatSum(status.price)}. Balansingiz: {formatSum(status.balance)}.
          {status.balance < status.price &&
            " Balans yetarli emas — botdagi \"💰 Balansni to'ldirish\" bo'limidan to'ldiring."}
        </span>
      </p>

      <button
        type="button"
        onClick={onGenerate}
        disabled={pending}
        className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
        style={{ backgroundColor: "var(--primary)" }}
      >
        {pending ? (
          "Tahlil qilinmoqda..."
        ) : (
          <>
            <CreditCard className="h-4 w-4" strokeWidth={2} />
            {formatSum(status.price)} evaziga tahlil olish
          </>
        )}
      </button>

      {error && (
        <p className="mt-3 text-xs font-medium" style={{ color: "var(--tone-bad)" }}>
          {error}
        </p>
      )}
    </div>
  );
}

function AiAnalysisContentView({ content }: { content: AiAnalysisContent }) {
  return (
    <div className="space-y-4 border-t border-border pt-3">
      <p className="text-[13.5px] leading-relaxed text-foreground">{content.overallSummary}</p>

      {content.recurringMistakes.length > 0 && (
        <div>
          <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Takrorlanuvchi xatolar
          </p>
          <div className="space-y-2">
            {content.recurringMistakes.map((mistake, i) => (
              <div
                key={i}
                className="rounded-xl p-3"
                style={{ backgroundColor: "var(--tone-weak-soft)" }}
              >
                <p className="text-[13px] font-semibold" style={{ color: "var(--tone-weak)" }}>
                  {mistake.title}
                </p>
                <p className="mt-0.5 text-[12.5px] leading-relaxed text-foreground">
                  {mistake.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {content.strengths.length > 0 && (
        <div>
          <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Kuchli tomonlar
          </p>
          <ul className="space-y-1">
            {content.strengths.map((s, i) => (
              <li key={i} className="flex items-start gap-1.5 text-[13px] text-foreground">
                <Check
                  className="mt-0.5 h-3.5 w-3.5 shrink-0"
                  style={{ color: "var(--tone-excellent)" }}
                  strokeWidth={2.5}
                />
                {s}
              </li>
            ))}
          </ul>
        </div>
      )}

      {content.actionPlan.length > 0 && (
        <div>
          <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Harakat rejasi
          </p>
          <ul className="space-y-1.5">
            {content.actionPlan.map((step, i) => (
              <li
                key={i}
                className="flex items-start gap-2 text-[13px] leading-relaxed text-foreground"
              >
                <span
                  className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[9px] font-bold"
                  style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
                >
                  {i + 1}
                </span>
                {step}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex items-start gap-2 rounded-xl bg-primary-soft p-3">
        <MessageCircle
          className="mt-0.5 h-4 w-4 shrink-0 text-primary"
          strokeWidth={2}
          aria-hidden
        />
        <p className="text-[12.5px] italic leading-relaxed text-foreground">
          {content.motivationalNote}
        </p>
      </div>
    </div>
  );
}
