import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, Library } from "lucide-react";
import { api, resolveAssetUrl, type Article, type ArticleDetail, ApiError } from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { Skeleton } from "@/components/Skeleton";
import { ArticleListCard } from "@/components/ArticleCards";
import { formatDate } from "@/lib/format";
import { addRecentlyRead } from "@/lib/recentlyRead";

export const Route = createFileRoute("/articles/$id")({
  head: () => ({
    meta: [{ title: "Maqola" }],
  }),
  component: () => (
    <TelegramGate>
      <ArticleDetailPage />
    </TelegramGate>
  ),
});

const FONT_SIZES = [
  { key: "sm", label: "A", px: 15, lh: 1.7 },
  { key: "md", label: "A", px: 17, lh: 1.8 },
  { key: "lg", label: "A", px: 19, lh: 1.85 },
] as const;

function ArticleDetailPage() {
  const { id } = Route.useParams();
  const router = useRouter();
  const [fontLevel, setFontLevel] = useState(1);
  const [progress, setProgress] = useState(0);

  const articleQ = useQuery<ArticleDetail, ApiError>({
    queryKey: ["article", id],
    queryFn: () => api.article(id),
    retry: false,
  });

  const allArticlesQ = useQuery<Article[], ApiError>({
    queryKey: ["articles"],
    queryFn: api.articles,
    retry: false,
  });

  useEffect(() => {
    function onScroll() {
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const pct = docHeight > 0 ? Math.min(1, Math.max(0, window.scrollY / docHeight)) : 0;
      setProgress(pct);
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (articleQ.data) addRecentlyRead(articleQ.data.id);
  }, [articleQ.data]);

  const cover = resolveAssetUrl(articleQ.data?.coverImage);
  const font = FONT_SIZES[fontLevel];

  const paragraphs = useMemo(() => {
    if (!articleQ.data) return [];
    return articleQ.data.body.split(/\n{2,}/).filter((p) => p.trim().length > 0);
  }, [articleQ.data]);

  const relatedArticles = useMemo(() => {
    if (!allArticlesQ.data) return [];
    return allArticlesQ.data.filter((a) => String(a.id) !== id).slice(0, 3);
  }, [allArticlesQ.data, id]);

  return (
    <div className="min-h-screen bg-background">
      {/* Reading progress bar */}
      <div className="fixed inset-x-0 top-0 z-20 h-[3px] bg-transparent">
        <div
          className="h-full bg-primary transition-[width] duration-150"
          style={{ width: `${progress * 100}%` }}
        />
      </div>

      <div className="sticky top-0 z-10 flex items-center justify-between bg-background/85 px-4 py-3 backdrop-blur-md">
        <button
          type="button"
          onClick={() => router.history.back()}
          className="-ml-2 inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Orqaga
        </button>

        {articleQ.data && (
          <div className="flex items-center gap-1 rounded-full bg-muted p-1">
            <button
              type="button"
              onClick={() => setFontLevel((l) => Math.max(0, l - 1))}
              disabled={fontLevel === 0}
              className="flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold text-foreground transition-colors hover:bg-card disabled:opacity-30"
              aria-label="Shriftni kichraytirish"
            >
              A-
            </button>
            <button
              type="button"
              onClick={() => setFontLevel((l) => Math.min(FONT_SIZES.length - 1, l + 1))}
              disabled={fontLevel === FONT_SIZES.length - 1}
              className="flex h-7 w-7 items-center justify-center rounded-full text-sm font-bold text-foreground transition-colors hover:bg-card disabled:opacity-30"
              aria-label="Shriftni kattalashtirish"
            >
              A+
            </button>
          </div>
        )}
      </div>

      <div className="mx-auto max-w-[640px] px-4 pb-16">
        {articleQ.isLoading && (
          <div className="space-y-4 pt-2">
            <Skeleton className="h-52 rounded-2xl" />
            <Skeleton className="h-6 w-3/4 rounded" />
            <Skeleton className="h-4 rounded" />
            <Skeleton className="h-4 rounded" />
            <Skeleton className="h-4 w-2/3 rounded" />
          </div>
        )}

        {articleQ.error && (
          <div className="mt-6 rounded-2xl bg-card p-6 text-center shadow-card">
            <h2 className="text-base font-semibold text-foreground">Maqola topilmadi</h2>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Bu maqola mavjud emas yoki oʻchirilgan.
            </p>
            <Link
              to="/articles"
              className="mt-4 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            >
              Maqolalarga qaytish
            </Link>
          </div>
        )}

        {articleQ.data && (
          <>
            <article className="pt-2">
              {cover && (
                <div className="-mx-4 relative mb-5 aspect-[16/10] w-[calc(100%+2rem)] overflow-hidden bg-muted sm:mx-0 sm:w-full sm:rounded-2xl">
                  <img src={cover} alt="" className="h-full w-full object-cover" />
                  <div className="absolute bottom-3 left-3 flex items-center gap-1.5 rounded-full bg-black/45 px-2.5 py-1 text-[11px] font-medium text-white backdrop-blur-sm">
                    <BookOpen className="h-3 w-3" strokeWidth={2} />
                    {articleQ.data.readingMinutes} daqiqa o'qish
                  </div>
                </div>
              )}

              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                {formatDate(articleQ.data.createdAt)}
                {!cover && ` · ${articleQ.data.readingMinutes} daqiqa o'qish`}
              </p>
              <h1 className="mt-2 text-[26px] font-bold leading-tight tracking-tight text-foreground">
                {articleQ.data.title}
              </h1>

              <div className="mt-6 space-y-4">
                {paragraphs.map((paragraph, i) => (
                  <p
                    key={i}
                    className={`whitespace-pre-wrap text-foreground/90 ${
                      i === 0
                        ? "first-letter:float-left first-letter:mr-2 first-letter:mt-1 first-letter:text-[3em] first-letter:font-bold first-letter:leading-[0.8] first-letter:text-primary"
                        : ""
                    }`}
                    style={{ fontSize: font.px, lineHeight: font.lh }}
                  >
                    {paragraph}
                  </p>
                ))}
              </div>
            </article>

            {relatedArticles.length > 0 && (
              <section className="mt-10 border-t border-border pt-6">
                <h2 className="mb-3 flex items-center gap-1.5 px-1 text-[15px] font-bold text-foreground">
                  <Library className="h-4 w-4" strokeWidth={2} />
                  Yana o'qing
                </h2>
                <div className="space-y-2.5">
                  {relatedArticles.map((article) => (
                    <ArticleListCard key={article.id} article={article} />
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </div>
  );
}
