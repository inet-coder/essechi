import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { History, Library, Search, Sparkles, X } from "lucide-react";
import { api, type Article, ApiError } from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { Skeleton } from "@/components/Skeleton";
import { FeaturedArticleCard, ArticleGridCard } from "@/components/ArticleCards";
import { BottomNav } from "@/components/BottomNav";
import { useRecentlyReadIds } from "@/hooks/useRecentlyReadIds";

export const Route = createFileRoute("/articles/")({
  head: () => ({
    meta: [
      { title: "Maqolalar" },
      { name: "description", content: "Esse yozish va til boʻyicha foydali maqolalar." },
    ],
  }),
  component: () => (
    <TelegramGate>
      <ArticlesPage />
    </TelegramGate>
  ),
});

function ArticlesPage() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const articlesQ = useQuery<Article[], ApiError>({
    queryKey: ["articles"],
    queryFn: api.articles,
    retry: false,
  });

  const categories = useMemo(() => {
    const set = new Set<string>();
    for (const a of articlesQ.data ?? []) if (a.category) set.add(a.category);
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [articlesQ.data]);

  const recentIds = useRecentlyReadIds();
  const recentArticles = useMemo(() => {
    if (!articlesQ.data) return [];
    const byId = new Map(articlesQ.data.map((a) => [a.id, a]));
    return recentIds.map((id) => byId.get(id)).filter((a): a is Article => Boolean(a));
  }, [articlesQ.data, recentIds]);

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;
    return (articlesQ.data ?? []).filter(
      (a) => a.title.toLowerCase().includes(q) || a.excerpt.toLowerCase().includes(q),
    );
  }, [articlesQ.data, query]);

  // Bo'lim bo'yicha filtrlangan ro'yxat (qidiruv faol bo'lmaganda).
  const categoryFiltered = useMemo(() => {
    if (!activeCategory) return null;
    return (articlesQ.data ?? []).filter((a) => a.category === activeCategory);
  }, [articlesQ.data, activeCategory]);

  const [featured, ...rest] = articlesQ.data ?? [];
  const isSearching = searchResults !== null;

  return (
    <div className="min-h-screen bg-background pb-28">
      <Hero count={articlesQ.data?.length} query={query} onQueryChange={setQuery} />

      <div className="mx-auto max-w-[560px] px-4 pt-5">
        {articlesQ.isLoading && (
          <div className="space-y-3">
            <Skeleton className="aspect-[4/3] w-full rounded-2xl" />
            <div className="grid grid-cols-2 gap-3">
              <Skeleton className="aspect-square rounded-2xl" />
              <Skeleton className="aspect-square rounded-2xl" />
            </div>
          </div>
        )}

        {articlesQ.error && (
          <ErrorState
            title="Maqolalarni yuklab boʻlmadi"
            description="Internetni tekshirib, qayta urinib koʻring."
            onRetry={() => articlesQ.refetch()}
          />
        )}

        {articlesQ.data && articlesQ.data.length === 0 && <EmptyState />}

        {!isSearching && categories.length > 0 && (
          <div className="mb-5 flex flex-wrap gap-2">
            <CategoryChip
              label="Barchasi"
              active={activeCategory === null}
              onClick={() => setActiveCategory(null)}
            />
            {categories.map((c) => (
              <CategoryChip
                key={c}
                label={c}
                active={activeCategory === c}
                onClick={() => setActiveCategory(c)}
              />
            ))}
          </div>
        )}

        {isSearching ? (
          <SearchResults results={searchResults} query={query} />
        ) : categoryFiltered ? (
          <CategoryResults results={categoryFiltered} category={activeCategory ?? ""} />
        ) : (
          featured && (
            <div className="space-y-7">
              {recentArticles.length > 0 && <RecentlyReadSection articles={recentArticles} />}

              <div>
                <p
                  className="mb-2.5 flex items-center gap-1.5 px-1 text-[12px] font-bold uppercase tracking-wider"
                  style={{ color: "var(--primary)" }}
                >
                  <Sparkles className="h-3.5 w-3.5" strokeWidth={2} />
                  Tavsiya etilgan
                </p>
                <FeaturedArticleCard article={featured} wide />
              </div>

              {rest.length > 0 && (
                <div>
                  <div className="mb-2.5 flex items-center justify-between px-1">
                    <h2 className="text-[13px] font-bold uppercase tracking-wider text-muted-foreground">
                      Boshqa maqolalar
                    </h2>
                    <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-bold tabular-nums text-muted-foreground ring-1 ring-black/[0.03]">
                      {rest.length} ta
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {rest.map((article, i) => (
                      <div
                        key={article.id}
                        className="animate-fade-slide-up"
                        style={{ animationDelay: `${Math.min(i, 8) * 45}ms` }}
                      >
                        <ArticleGridCard article={article} />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )
        )}
      </div>

      <BottomNav />
    </div>
  );
}

/**
 * Zich nuqta-panjara naqshi — premium gradient fonlarga chuqurlik va
 * to'qima berish uchun, sof dekorativ qatlam.
 */
function DotGrid({ opacity = 0.14 }: { opacity?: number }) {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden
      style={{ opacity }}
    >
      <defs>
        <pattern id="articles-dot-grid" width="14" height="14" patternUnits="userSpaceOnUse">
          <circle cx="1.2" cy="1.2" r="1.2" fill="white" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#articles-dot-grid)" />
    </svg>
  );
}

function Hero({
  count,
  query,
  onQueryChange,
}: {
  count: number | undefined;
  query: string;
  onQueryChange: (q: string) => void;
}) {
  return (
    <div
      className="relative overflow-hidden px-4 pb-5 pt-6"
      style={{
        background:
          "radial-gradient(130% 160% at 0% 0%, oklch(0.5 0.15 285) 0%, var(--primary) 45%, oklch(0.36 0.13 272) 100%)",
      }}
    >
      <DotGrid opacity={0.08} />
      <div
        className="pointer-events-none absolute -right-10 -top-14 h-44 w-44 rounded-full opacity-30 blur-2xl"
        style={{ background: "oklch(0.9 0.08 150)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-16 -left-12 h-44 w-44 rounded-full opacity-20 blur-2xl"
        style={{ background: "oklch(0.85 0.1 85)" }}
      />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px"
        style={{
          background: "linear-gradient(90deg, transparent, oklch(1 0 0 / 0.35), transparent)",
        }}
      />
      <div className="relative mx-auto max-w-[560px]">
        <div className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/25 shadow-inner backdrop-blur-sm">
            <Library className="h-5 w-5 text-white" strokeWidth={2} />
          </div>
          <div>
            <h1 className="text-[20px] font-bold tracking-tight text-white">Maqolalar</h1>
            <p className="text-[12px] text-white/70">
              Yozish mahoratingizni oshiruvchi tanlangan maqolalar
              {typeof count === "number" && count > 0 && ` · ${count} ta`}
            </p>
          </div>
        </div>

        <div className="relative mt-4">
          <Search
            className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            strokeWidth={2}
          />
          <input
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder="Maqola qidirish..."
            className="w-full rounded-2xl bg-card py-2.5 pl-10 pr-9 text-sm text-foreground shadow-elevated outline-none ring-1 ring-black/[0.03] transition-shadow placeholder:text-muted-foreground focus:ring-2 focus:ring-white/40"
          />
          {query && (
            <button
              type="button"
              onClick={() => onQueryChange("")}
              className="absolute right-3 top-1/2 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full bg-muted text-muted-foreground transition-all duration-150 hover:opacity-80 active:scale-90"
              aria-label="Qidiruvni tozalash"
            >
              <X className="h-3 w-3" strokeWidth={2.5} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function RecentlyReadSection({ articles }: { articles: Article[] }) {
  return (
    <div>
      <p className="mb-2.5 flex items-center gap-1.5 px-1 text-[12px] font-bold uppercase tracking-wider text-muted-foreground">
        <History className="h-3.5 w-3.5" strokeWidth={2} />
        So'nggi o'qilganlar
      </p>
      <div className="scrollbar-hide -mx-4 flex gap-3 overflow-x-auto px-4 pb-1">
        {articles.map((article) => (
          <FeaturedArticleCard key={article.id} article={article} />
        ))}
      </div>
    </div>
  );
}

function CategoryChip({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded-full px-3.5 py-1.5 text-[12.5px] font-semibold transition-colors"
      style={{
        backgroundColor: active ? "var(--primary)" : "var(--card)",
        color: active ? "var(--primary-foreground)" : "var(--muted-foreground)",
        boxShadow: active ? "none" : "var(--shadow-card)",
      }}
    >
      {label}
    </button>
  );
}

function CategoryResults({ results, category }: { results: Article[]; category: string }) {
  return (
    <div>
      <p className="mb-2.5 px-1 text-[12px] font-medium text-muted-foreground">
        {category} · {results.length} ta maqola
      </p>
      <div className="grid grid-cols-2 gap-3">
        {results.map((article, i) => (
          <div
            key={article.id}
            className="animate-fade-slide-up"
            style={{ animationDelay: `${Math.min(i, 8) * 45}ms` }}
          >
            <ArticleGridCard article={article} />
          </div>
        ))}
      </div>
    </div>
  );
}

function SearchResults({ results, query }: { results: Article[]; query: string }) {
  if (results.length === 0) {
    return (
      <div className="rounded-2xl bg-card p-8 text-center shadow-card ring-1 ring-black/[0.03]">
        <div
          className="mx-auto flex h-14 w-14 items-center justify-center rounded-full"
          style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
        >
          <Search className="h-6 w-6" strokeWidth={1.8} />
        </div>
        <h3 className="mt-3 text-base font-semibold tracking-tight text-foreground">
          Hech narsa topilmadi
        </h3>
        <p className="mt-1.5 text-sm text-muted-foreground">
          "{query}" boʻyicha mos maqola topilmadi. Boshqa soʻz bilan urinib koʻring.
        </p>
      </div>
    );
  }

  return (
    <div>
      <p className="mb-2.5 px-1 text-[12px] font-medium text-muted-foreground">
        {results.length} ta natija topildi
      </p>
      <div className="grid grid-cols-2 gap-3">
        {results.map((article, i) => (
          <div
            key={article.id}
            className="animate-fade-slide-up"
            style={{ animationDelay: `${Math.min(i, 8) * 45}ms` }}
          >
            <ArticleGridCard article={article} />
          </div>
        ))}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="rounded-2xl bg-card p-8 text-center shadow-card ring-1 ring-black/[0.03]">
      <div
        className="mx-auto flex h-14 w-14 items-center justify-center rounded-full"
        style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
      >
        <Library className="h-7 w-7" strokeWidth={1.8} />
      </div>
      <h3 className="mt-3 text-base font-semibold tracking-tight text-foreground">
        Hozircha maqolalar yoʻq
      </h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Tez orada foydali maqolalar shu yerda paydo boʻladi.
      </p>
    </div>
  );
}

function ErrorState({
  title,
  description,
  onRetry,
}: {
  title: string;
  description: string;
  onRetry?: () => void;
}) {
  return (
    <div className="rounded-2xl bg-card p-6 text-center shadow-card ring-1 ring-black/[0.03]">
      <h3 className="text-base font-semibold tracking-tight text-foreground">{title}</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-sm transition-all duration-200 hover:opacity-90 active:scale-95"
        >
          Qayta urinish
        </button>
      )}
    </div>
  );
}
