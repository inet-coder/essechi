import { useRef, useState } from "react";
import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Award,
  CalendarClock,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Coins,
  Crown,
  FileText,
  ImagePlus,
  Loader2,
  Medal,
  Paperclip,
  Pencil,
  Sparkles,
  Trophy,
  UserCheck,
  Users,
  X,
  XCircle,
} from "lucide-react";
import {
  api,
  type CompetitionDetail,
  type CompetitionResults,
  type CompetitionRankingEntry,
  type CompetitionPrize,
  type CompetitionEntryEssay,
  type Me,
  ApiError,
} from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { Skeleton } from "@/components/Skeleton";
import { BandAccordion } from "@/components/BandAccordion";
import { ImageOcrPanel } from "@/components/ImageOcrPanel";
import { formatSum, scaledTone } from "@/lib/format";
import {
  COMPETITION_STATUS_META,
  formatDeadline,
  formatStartDate,
  medalColor,
} from "@/lib/competition";

const MIN_WORDS = 100;

export const Route = createFileRoute("/competitions/$id")({
  head: () => ({ meta: [{ title: "Musobaqa" }] }),
  component: () => (
    <TelegramGate>
      <CompetitionDetailPage />
    </TelegramGate>
  ),
});

function CompetitionDetailPage() {
  const { id } = Route.useParams();

  const detailQ = useQuery<CompetitionDetail, ApiError>({
    queryKey: ["competition", id],
    queryFn: () => api.competition(id),
    retry: false,
  });

  return (
    <div className="min-h-screen bg-background pb-10">
      <TopBar />
      <div className="mx-auto max-w-[560px] px-4 pt-4">
        {detailQ.isLoading && (
          <div className="space-y-3">
            <Skeleton className="h-[120px] rounded-2xl" />
            <Skeleton className="h-[160px] rounded-2xl" />
          </div>
        )}

        {detailQ.error && (
          <InfoCard
            icon={XCircle}
            tone="bad"
            title="Musobaqa topilmadi"
            text="Bu musobaqa mavjud emas yoki hali e'lon qilinmagan."
          />
        )}

        {detailQ.data && <Body id={id} detail={detailQ.data} />}
      </div>
    </div>
  );
}

function TopBar() {
  const router = useRouter();
  const navigate = useNavigate();
  return (
    <div className="sticky top-0 z-10 flex items-center gap-2 border-b border-border bg-background/90 px-3 py-3 backdrop-blur-md">
      <button
        type="button"
        onClick={() =>
          router.history.length > 1 ? router.history.back() : navigate({ to: "/competitions" })
        }
        className="-ml-1 inline-flex h-9 w-9 items-center justify-center rounded-lg text-foreground transition-colors hover:bg-muted"
        aria-label="Orqaga"
      >
        <ChevronLeft className="h-5 w-5" strokeWidth={2} />
      </button>
      <h1 className="flex items-center gap-1.5 text-[15px] font-semibold text-foreground">
        <Trophy className="h-4 w-4" strokeWidth={2} />
        Musobaqa
      </h1>
    </div>
  );
}

function Body({ id, detail }: { id: string; detail: CompetitionDetail }) {
  const { competition } = detail;
  const meta = COMPETITION_STATUS_META[competition.status];
  const deadline = formatDeadline(competition.endsAt);
  const startDate = formatStartDate(competition.startsAt);
  const prizes = [...competition.prizes].sort((a, b) => a.place - b.place);

  return (
    <div className="space-y-4">
      {/* Sarlavha kartasi */}
      <div
        className="relative overflow-hidden rounded-2xl p-5 shadow-elevated"
        style={{ background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))" }}
      >
        <div
          className="pointer-events-none absolute -right-8 -top-10 h-36 w-36 rounded-full opacity-30 blur-2xl"
          style={{ background: "oklch(0.9 0.08 85)" }}
        />
        <div className="relative">
          <span className="inline-block rounded-full bg-white/20 px-2.5 py-1 text-[11px] font-semibold text-white ring-1 ring-white/25">
            {meta.label}
          </span>
          <h2 className="mt-2.5 text-[20px] font-bold leading-tight text-white">
            {competition.title}
          </h2>
          {competition.description && (
            <p className="mt-1.5 text-[13px] leading-relaxed text-white/80">
              {competition.description}
            </p>
          )}
          <div className="mt-3 flex flex-wrap gap-2">
            <HeroChip
              icon={Coins}
              text={
                competition.entryFee > 0
                  ? `Kirish: ${formatSum(competition.entryFee)}`
                  : "Bepul kirish"
              }
            />
            {competition.status === "upcoming" && startDate && (
              <HeroChip icon={CalendarClock} text={`${startDate} da boshlanadi`} />
            )}
            {deadline && competition.status === "open" && (
              <HeroChip icon={Clock} text={`${deadline} gacha`} />
            )}
          </div>
        </div>
      </div>

      {/* Mavzu */}
      <div className="rounded-2xl bg-card p-4 shadow-card">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
          Esse mavzusi
        </p>
        <p className="mt-1.5 text-[14px] leading-relaxed text-foreground">{competition.topic}</p>
      </div>

      {/* Mukofotlar */}
      {prizes.length > 0 && <PrizeList prizes={prizes} />}

      {/* Holatga qarab harakat qismi */}
      <ActionArea id={id} detail={detail} />
    </div>
  );
}

function HeroChip({ icon: Icon, text }: { icon: typeof Coins; text: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[12px] font-medium text-white ring-1 ring-white/15">
      <Icon className="h-3.5 w-3.5" strokeWidth={2} />
      {text}
    </span>
  );
}

function PrizeList({ prizes }: { prizes: CompetitionPrize[] }) {
  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        <Award className="h-3.5 w-3.5" strokeWidth={2} />
        Yutuqlar
      </p>
      <div className="mt-3 space-y-2">
        {prizes.map((prize) => {
          const color = medalColor(prize.place);
          return (
            <div
              key={prize.place}
              className="flex items-center gap-3 rounded-xl bg-muted/40 px-3 py-2.5"
            >
              <span
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[13px] font-bold text-white"
                style={{ background: color ?? "var(--muted-foreground)" }}
              >
                {prize.place}
              </span>
              <span className="flex-1 text-[13.5px] font-medium text-foreground">
                {prize.reward}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ActionArea({ id, detail }: { id: string; detail: CompetitionDetail }) {
  const { competition, joined } = detail;

  if (competition.status === "finished") {
    return <ResultsView id={id} />;
  }

  if (competition.status === "cancelled") {
    return (
      <InfoCard
        icon={XCircle}
        tone="bad"
        title="Musobaqa bekor qilindi"
        text="Kirish to'lovini to'lagan bo'lsangiz, balansingizga qaytarildi."
      />
    );
  }

  if (competition.status === "closed" || competition.status === "evaluating") {
    return (
      <InfoCard
        icon={Loader2}
        tone="ok"
        spin={competition.status === "evaluating"}
        title="Natijalar tayyorlanmoqda"
        text={
          joined
            ? "Esselaringiz AI tomonidan baholanmoqda. Yakunlangach shu yerda o'rningizni va tahlilni ko'rasiz."
            : "Bu musobaqa qabuli yopilgan. Natijalar tez orada e'lon qilinadi."
        }
      />
    );
  }

  // status === "upcoming" yoki "open"
  return <EntryArea id={id} detail={detail} />;
}

// Ro'yxatdan o'tganlar va to'lagan ishtirokchilar sonini ko'rsatuvchi kartochka.
function RegistrationStats({
  registered,
  participants,
}: {
  registered: number;
  participants: number;
}) {
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-card p-4 shadow-card">
      <span
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
        style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
      >
        <Users className="h-5 w-5" strokeWidth={2} />
      </span>
      <div className="flex flex-1 items-center justify-around">
        <div className="text-center">
          <p className="text-lg font-bold tabular-nums text-foreground">{registered}</p>
          <p className="text-[11.5px] text-muted-foreground">ro'yxatdan o'tgan</p>
        </div>
        <span className="h-8 w-px bg-border" />
        <div className="text-center">
          <p className="text-lg font-bold tabular-nums text-primary">{participants}</p>
          <p className="text-[11.5px] text-muted-foreground">ishtirokchi</p>
        </div>
      </div>
    </div>
  );
}

// "upcoming" va "open" holatlar uchun umumiy: sonlar + (holatga qarab)
// ro'yxatdan o'tish/to'lov yoki esse yuborish.
function EntryArea({ id, detail }: { id: string; detail: CompetitionDetail }) {
  const { competition, paid, hasEssay } = detail;
  const upcoming = competition.status === "upcoming";
  const startDate = formatStartDate(competition.startsAt);

  return (
    <div className="space-y-4">
      <RegistrationStats
        registered={detail.registeredCount}
        participants={detail.participantCount}
      />

      {upcoming && (
        <div className="flex items-center gap-3 rounded-2xl bg-card p-4 shadow-card">
          <span
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
            style={{ backgroundColor: "var(--tone-ok-soft)", color: "var(--tone-ok)" }}
          >
            <CalendarClock className="h-5 w-5" strokeWidth={2} />
          </span>
          <div>
            <p className="text-[11.5px] font-semibold uppercase tracking-wide text-muted-foreground">
              Boshlanish
            </p>
            <p className="text-[14px] font-bold text-foreground">
              {startDate ?? "Sana keyinroq e'lon qilinadi"}
            </p>
          </div>
        </div>
      )}

      {paid ? (
        upcoming ? (
          <div
            className="flex items-start gap-2.5 rounded-2xl p-4 shadow-card"
            style={{
              backgroundColor: "var(--tone-excellent-soft)",
              color: "var(--tone-excellent)",
            }}
          >
            <UserCheck className="mt-0.5 h-5 w-5 shrink-0" strokeWidth={2} />
            <p className="text-[13.5px] font-medium leading-relaxed text-foreground">
              Siz to'liq ishtirokchisiz. Musobaqa boshlanganda shu yerdan esse yuborasiz.
            </p>
          </div>
        ) : (
          <SubmitCard id={id} hasEssay={hasEssay} />
        )
      ) : (
        <EntryCard id={id} detail={detail} />
      )}
    </div>
  );
}

// Ro'yxatdan o'tish (tekin) yoki kirish to'lovini to'lash (ishtirokchi bo'lish).
function EntryCard({ id, detail }: { id: string; detail: CompetitionDetail }) {
  const { competition, joined } = detail;
  const entryFee = competition.entryFee;
  const queryClient = useQueryClient();
  const meQ = useQuery<Me, ApiError>({ queryKey: ["me"], queryFn: api.me, retry: false });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["competition", id] });
    queryClient.invalidateQueries({ queryKey: ["me"] });
  };
  const registerM = useMutation({
    mutationFn: () => api.registerCompetition(id),
    onSuccess: invalidate,
  });
  const payM = useMutation({ mutationFn: () => api.payCompetition(id), onSuccess: invalidate });

  const balance = meQ.data?.balance ?? 0;
  const notEnough = entryFee > 0 && balance < entryFee;
  const busy = registerM.isPending || payM.isPending;
  const err = (registerM.error || payM.error) as ApiError | null;

  return (
    <div className="rounded-2xl bg-card p-5 shadow-card">
      <div className="flex items-center gap-3">
        <span
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl"
          style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
        >
          <Sparkles className="h-5 w-5" strokeWidth={2} />
        </span>
        <div>
          <p className="text-[15px] font-bold text-foreground">Musobaqaga qatnashing</p>
          <p className="text-[12.5px] text-muted-foreground">
            {entryFee > 0 ? `Kirish to'lovi: ${formatSum(entryFee)}` : "Qatnashish bepul"}
          </p>
        </div>
      </div>

      {joined && (
        <div
          className="mt-4 flex items-center gap-2 rounded-xl px-3 py-2.5 text-[12.5px] font-medium"
          style={{ backgroundColor: "var(--tone-ok-soft)", color: "var(--tone-ok)" }}
        >
          <CheckCircle2 className="h-4 w-4 shrink-0" strokeWidth={2} />
          Ro'yxatdan o'tgansiz — joyingiz band. Ishtirokchi bo'lish uchun kirish to'lovini to'lang.
        </div>
      )}

      {notEnough && (
        <div
          className="mt-3 rounded-xl px-3 py-2.5 text-[12.5px] font-medium"
          style={{ backgroundColor: "var(--tone-bad-soft)", color: "var(--tone-bad)" }}
        >
          Balans yetarli emas ({formatSum(balance)}). Botdagi "Balansni to'ldirish" orqali
          to'ldiring.
        </div>
      )}

      {err && !notEnough && (
        <div
          className="mt-3 rounded-xl px-3 py-2.5 text-[12.5px] font-medium"
          style={{ backgroundColor: "var(--tone-bad-soft)", color: "var(--tone-bad)" }}
        >
          {err.message ?? "Xatolik yuz berdi."}
        </div>
      )}

      <div className="mt-4 space-y-2.5">
        {/* Ro'yxatdan o'tmagan bo'lsa: tekin ro'yxat tugmasi. Kirish to'lovi 0
            bo'lsa bu darhol to'liq ishtirokchi qiladi. */}
        {!joined && (
          <button
            type="button"
            disabled={busy}
            onClick={() => registerM.mutate()}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-primary bg-primary-soft py-3 text-sm font-semibold text-primary transition-opacity hover:opacity-90 disabled:opacity-50"
          >
            {registerM.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2} />
            ) : (
              <Users className="h-4 w-4" strokeWidth={2} />
            )}
            {entryFee > 0 ? "Ro'yxatdan o'tish (bepul)" : "Ro'yxatdan o'tish"}
          </button>
        )}

        {/* Kirish to'lovi bor bo'lsa: to'lab to'liq ishtirokchi bo'lish. */}
        {entryFee > 0 && (
          <button
            type="button"
            disabled={busy || notEnough}
            onClick={() => payM.mutate()}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
          >
            {payM.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2} />
            ) : (
              <Trophy className="h-4 w-4" strokeWidth={2} />
            )}
            To'lab ishtirokchi bo'lish — {formatSum(entryFee)}
          </button>
        )}
      </div>
    </div>
  );
}

function SubmitCard({ id, hasEssay }: { id: string; hasEssay: boolean }) {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [mode, setMode] = useState<"text" | "image" | "pdf">("text");
  const [text, setText] = useState("");

  const meQ = useQuery<Me, ApiError>({ queryKey: ["me"], queryFn: api.me, retry: false });

  const submitMutation = useMutation({
    mutationFn: (payload: { text?: string; file?: File }) =>
      payload.file
        ? api.submitCompetitionPdf(id, payload.file)
        : api.submitCompetitionText(id, payload.text ?? ""),
    onSuccess: () => {
      setText("");
      setMode("text");
      queryClient.invalidateQueries({ queryKey: ["competition", id] });
    },
  });

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (file) submitMutation.mutate({ file });
  }

  return (
    <div className="rounded-2xl bg-card p-5 shadow-card">
      {hasEssay && (
        <div
          className="mb-4 flex items-center gap-2 rounded-xl px-3 py-2.5 text-[12.5px] font-medium"
          style={{
            backgroundColor: "var(--tone-excellent-soft)",
            color: "var(--tone-excellent)",
          }}
        >
          <CheckCircle2 className="h-4 w-4 shrink-0" strokeWidth={2} />
          Esseingiz qabul qilindi. Deadline'gacha yangisini yuborib almashtirishingiz mumkin.
        </div>
      )}

      <p className="text-[15px] font-bold text-foreground">
        {hasEssay ? "Esseni almashtirish" : "Essengizni yuboring"}
      </p>
      <p className="mt-1 text-[12.5px] text-muted-foreground">
        Matn yozing, qo'lyozma suratini yuklang yoki PDF fayl biriktiring (kamida {MIN_WORDS} so'z).
        Rasmdan matn o'qish bepul.
      </p>

      {/* Rejim tanlash */}
      <div className="mt-3 flex gap-1 rounded-2xl bg-muted p-1">
        <SubmitModeTab
          active={mode === "text"}
          onClick={() => setMode("text")}
          icon={Pencil}
          label="Matn"
        />
        <SubmitModeTab
          active={mode === "image"}
          onClick={() => setMode("image")}
          icon={ImagePlus}
          label="Rasm"
        />
        <SubmitModeTab
          active={mode === "pdf"}
          onClick={() => setMode("pdf")}
          icon={FileText}
          label="PDF"
        />
      </div>

      {submitMutation.isError && (
        <div
          className="mt-3 rounded-xl px-3 py-2.5 text-[12.5px] font-medium"
          style={{ backgroundColor: "var(--tone-bad-soft)", color: "var(--tone-bad)" }}
        >
          {(submitMutation.error as ApiError)?.message ?? "Yuborishda xatolik."}
        </div>
      )}

      {mode === "text" && (
        <>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Essengizni shu yerga yozing…"
            rows={8}
            disabled={submitMutation.isPending}
            className="mt-3 w-full resize-y rounded-xl border border-input bg-background px-4 py-3 text-sm leading-relaxed text-foreground outline-none focus:ring-2 focus:ring-ring disabled:opacity-60"
          />
          <button
            type="button"
            disabled={submitMutation.isPending || !text.trim()}
            onClick={() => submitMutation.mutate({ text })}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
          >
            {submitMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2} />
            ) : null}
            {hasEssay ? "Almashtirish" : "Yuborish"}
          </button>
        </>
      )}

      {mode === "image" && (
        <ImageOcrPanel
          extract={(files) => api.extractCompetitionImageText(id, files)}
          onConfirm={(t) => submitMutation.mutate({ text: t })}
          confirmLabel={hasEssay ? "Almashtirish" : "Yuborish"}
          confirming={submitMutation.isPending}
          minWords={MIN_WORDS}
          maxPages={meQ.data?.imageMaxPages ?? 2}
        />
      )}

      {mode === "pdf" && (
        <div className="mt-3">
          <button
            type="button"
            disabled={submitMutation.isPending}
            onClick={() => fileInputRef.current?.click()}
            className="flex min-h-[160px] w-full flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border bg-card p-6 text-center transition-colors hover:border-primary/50 hover:bg-primary-soft/30 disabled:opacity-50"
          >
            <span
              className="flex h-12 w-12 items-center justify-center rounded-2xl"
              style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
            >
              <Paperclip className="h-5 w-5" strokeWidth={2} />
            </span>
            <span className="text-[13.5px] font-semibold text-foreground">
              {submitMutation.isPending ? "Yuborilmoqda…" : "PDF faylni tanlang"}
            </span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf"
            onChange={handleFile}
            className="hidden"
          />
        </div>
      )}
    </div>
  );
}

function SubmitModeTab({
  active,
  onClick,
  icon: Icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: typeof Pencil;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-[13px] font-semibold transition-all"
      style={
        active
          ? {
              backgroundColor: "var(--card)",
              color: "var(--primary)",
              boxShadow: "var(--shadow-card)",
            }
          : { color: "var(--muted-foreground)" }
      }
    >
      <Icon className="h-4 w-4" strokeWidth={2} />
      {label}
    </button>
  );
}

// --- Natijalar ---

function ResultsView({ id }: { id: string }) {
  const [openUserId, setOpenUserId] = useState<number | null>(null);
  const resultsQ = useQuery<CompetitionResults, ApiError>({
    queryKey: ["competition-results", id],
    queryFn: () => api.competitionResults(id),
    retry: false,
  });

  if (resultsQ.isLoading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-[200px] rounded-2xl" />
        <Skeleton className="h-[120px] rounded-2xl" />
      </div>
    );
  }

  if (resultsQ.error || !resultsQ.data) {
    return (
      <InfoCard
        icon={XCircle}
        tone="bad"
        title="Natijalarni yuklab bo'lmadi"
        text="Iltimos, birozdan so'ng qayta urinib ko'ring."
      />
    );
  }

  const { ranking, myResult } = resultsQ.data;
  const essaysPublic = resultsQ.data.competition.essaysPublic;
  const top3 = ranking.filter((e) => e.status === "completed").slice(0, 3);
  const rest = ranking.filter((e) => !top3.includes(e));

  // Ishtirokchi essesini ko'rish mumkinmi: o'ziniki har doim, boshqalarniki
  // faqat admin ruxsat bergan (essaysPublic) bo'lsa.
  const canView = (entry: CompetitionRankingEntry) => essaysPublic || entry.isMe;

  return (
    <div className="space-y-4">
      {myResult && <MyResultCard result={myResult} />}

      {essaysPublic && ranking.length > 1 && (
        <p className="flex items-center gap-1.5 px-1 text-[12.5px] text-muted-foreground">
          <FileText className="h-3.5 w-3.5" strokeWidth={2} />
          Ishtirokchi ustiga bosib, uning essesi va tahlilini ko'ring.
        </p>
      )}

      {top3.length > 0 && (
        <div className="rounded-2xl bg-card p-4 pt-5 shadow-card">
          <Podium entries={top3} onOpen={setOpenUserId} canView={canView} />
        </div>
      )}

      {rest.length > 0 && (
        <div className="space-y-2">
          {rest.map((entry) => (
            <RankingRow
              key={entry.rank}
              entry={entry}
              canOpen={canView(entry)}
              onOpen={() => setOpenUserId(entry.userId)}
            />
          ))}
        </div>
      )}

      {myResult && myResult.status === "completed" && myResult.bandResults.length > 0 && (
        <MyAnalysis result={myResult} />
      )}

      {openUserId != null && (
        <EntryEssayModal id={id} userId={openUserId} onClose={() => setOpenUserId(null)} />
      )}
    </div>
  );
}

// Ishtirokchi essesi va tahlilini ko'rsatuvchi modal oyna.
function EntryEssayModal({
  id,
  userId,
  onClose,
}: {
  id: string;
  userId: number;
  onClose: () => void;
}) {
  const essayQ = useQuery<CompetitionEntryEssay, ApiError>({
    queryKey: ["competition-entry-essay", id, userId],
    queryFn: () => api.competitionEntryEssay(id, userId),
    retry: false,
  });

  const data = essayQ.data;
  const completed = data?.status === "completed";
  const tone = completed && data?.scaledScore != null ? scaledTone(data.scaledScore) : "bad";

  return (
    <div
      className="fixed inset-0 z-30 flex items-end justify-center bg-black/40 backdrop-blur-sm sm:items-center"
      onClick={onClose}
    >
      <div
        className="max-h-[88vh] w-full max-w-[560px] overflow-y-auto rounded-t-3xl bg-background p-4 shadow-elevated sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sarlavha */}
        <div className="sticky -top-4 -mx-4 mb-3 flex items-center justify-between border-b border-border bg-background/95 px-4 py-3 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white"
              style={{ background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))" }}
            >
              {data?.firstName?.[0]?.toUpperCase() ?? "?"}
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-foreground">
                {data ? (data.isMe ? "Sizning essengiz" : data.firstName) : "Yuklanmoqda…"}
              </p>
              {data && (
                <p className="text-[11.5px] text-muted-foreground">
                  {data.rank}-o'rin
                  {completed && data.scaledScore != null && ` · ${data.scaledScore}/75 ball`}
                </p>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted"
            aria-label="Yopish"
          >
            <X className="h-5 w-5" strokeWidth={2} />
          </button>
        </div>

        {essayQ.isLoading && <Skeleton className="h-40 rounded-2xl" />}

        {essayQ.error && (
          <div
            className="rounded-2xl px-4 py-3 text-sm font-medium"
            style={{ backgroundColor: "var(--tone-bad-soft)", color: "var(--tone-bad)" }}
          >
            {essayQ.error.status === 403
              ? "Bu musobaqada ishtirokchilar esselari yopiq."
              : "Esseni yuklab bo'lmadi."}
          </div>
        )}

        {data && (
          <div className="space-y-4">
            {/* Esse matni */}
            <div className="rounded-2xl bg-card p-4 shadow-card">
              <p className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                <FileText className="h-3.5 w-3.5" strokeWidth={2} />
                Esse matni
              </p>
              <p className="whitespace-pre-wrap text-[13.5px] leading-relaxed text-foreground">
                {data.rawText}
              </p>
            </div>

            {/* Tahlil */}
            {completed && data.bandResults.length > 0 && (
              <div>
                <p className="mb-2 flex items-center gap-1.5 px-1 text-[13px] font-semibold text-foreground">
                  <Sparkles className="h-4 w-4 text-primary" strokeWidth={2} />
                  Tahlil (12 mezon)
                </p>
                <div className="space-y-2">
                  {data.bandResults.map((band) => (
                    <BandAccordion key={band.band} band={band} />
                  ))}
                </div>
              </div>
            )}

            {!completed && (
              <div
                className="rounded-2xl px-4 py-3 text-sm font-medium"
                style={{
                  backgroundColor: `var(--tone-${tone}-soft)`,
                  color: `var(--tone-${tone})`,
                }}
              >
                Bu esse baholanmadi.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function MyResultCard({ result }: { result: CompetitionResults["myResult"] }) {
  if (!result) return null;
  const completed = result.status === "completed";
  const tone = completed && result.scaledScore != null ? scaledTone(result.scaledScore) : "bad";

  return (
    <div
      className="rounded-2xl p-5 shadow-card"
      style={{ background: "linear-gradient(135deg, var(--primary-soft), transparent 160%)" }}
    >
      <div className="flex items-center gap-4">
        <div
          className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-2xl text-white"
          style={{ background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))" }}
        >
          <span className="text-[10px] font-medium opacity-80">O'rin</span>
          <span className="text-2xl font-bold leading-none">{result.rank}</span>
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[13px] font-medium text-muted-foreground">Sizning natijangiz</p>
          {completed ? (
            <p className="text-2xl font-bold tabular-nums" style={{ color: `var(--tone-${tone})` }}>
              {result.scaledScore}
              <span className="text-base font-semibold text-muted-foreground">/75</span>
            </p>
          ) : (
            <p className="text-sm font-semibold" style={{ color: "var(--tone-bad)" }}>
              {result.rejectionReason ?? "Esse baholanmadi"}
            </p>
          )}
        </div>
      </div>

      {result.prize && (
        <div
          className="mt-3 flex items-start gap-2 rounded-xl px-3 py-2.5 text-[13px] font-semibold"
          style={{ backgroundColor: "var(--tone-ok-soft)", color: "var(--tone-ok)" }}
        >
          <Crown className="h-4 w-4 shrink-0" strokeWidth={2} />
          <span>
            Tabriklaymiz! Mukofotingiz: {result.prize.reward}. Uni topshirish uchun administrator
            siz bilan bog'lanadi.
          </span>
        </div>
      )}
    </div>
  );
}

const PODIUM_HEIGHTS: Record<number, string> = {
  1: "h-[92px]",
  2: "h-[72px]",
  3: "h-[58px]",
};

function Podium({
  entries,
  onOpen,
  canView,
}: {
  entries: CompetitionRankingEntry[];
  onOpen: (userId: number) => void;
  canView: (entry: CompetitionRankingEntry) => boolean;
}) {
  const [first, second, third] = entries;
  const order = [second, first, third].filter(Boolean) as CompetitionRankingEntry[];

  return (
    <div className="flex items-end justify-center gap-2.5">
      {order.map((entry) => {
        const color = medalColor(entry.rank) ?? "var(--muted-foreground)";
        const isFirst = entry.rank === 1;
        const openable = canView(entry);
        return (
          <button
            key={entry.rank}
            type="button"
            disabled={!openable}
            onClick={() => onOpen(entry.userId)}
            className={`flex w-[100px] flex-col items-center ${isFirst ? "relative z-10" : ""} ${openable ? "transition-transform active:scale-[0.97]" : "cursor-default"}`}
          >
            {isFirst && (
              <Crown className="mb-1 h-5 w-5" style={{ color }} strokeWidth={2} fill={color} />
            )}
            <div
              className="flex items-center justify-center rounded-2xl text-lg font-bold text-white"
              style={{
                height: isFirst ? "3rem" : "2.75rem",
                width: isFirst ? "3rem" : "2.75rem",
                background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))",
                boxShadow: entry.isMe
                  ? `0 0 0 3px var(--card), 0 0 0 5px ${color}`
                  : "0 0 0 3px var(--card)",
              }}
            >
              {entry.firstName?.[0]?.toUpperCase() ?? "?"}
            </div>
            <p className="mt-1.5 max-w-full truncate text-[12px] font-semibold text-foreground">
              {entry.isMe ? "Siz" : entry.firstName}
            </p>
            <p className="text-[12px] font-bold tabular-nums text-primary">{entry.scaledScore}</p>
            <div
              className={`mt-2 flex w-full flex-col items-center gap-1 rounded-t-2xl pt-2.5 ${PODIUM_HEIGHTS[entry.rank]}`}
              style={{
                background: "linear-gradient(180deg, var(--primary-soft), transparent 140%)",
              }}
            >
              <Medal className="h-6 w-6" style={{ color }} strokeWidth={2} />
              <span className="text-[11px] font-bold text-muted-foreground">#{entry.rank}</span>
            </div>
          </button>
        );
      })}
    </div>
  );
}

function RankingRow({
  entry,
  canOpen,
  onOpen,
}: {
  entry: CompetitionRankingEntry;
  canOpen: boolean;
  onOpen: () => void;
}) {
  const rejected = entry.status !== "completed";
  const tone = !rejected && entry.scaledScore != null ? scaledTone(entry.scaledScore) : "bad";

  return (
    <button
      type="button"
      disabled={!canOpen}
      onClick={onOpen}
      className={`flex w-full items-center gap-3 rounded-2xl p-3.5 text-left shadow-card ${canOpen ? "transition-transform active:scale-[0.99]" : "cursor-default"}`}
      style={{
        backgroundColor: entry.isMe ? "var(--primary-soft)" : "var(--card)",
        border: entry.isMe ? "1.5px solid var(--primary)" : "1.5px solid transparent",
      }}
    >
      <div
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold"
        style={{
          backgroundColor: entry.isMe ? "var(--primary)" : "var(--muted)",
          color: entry.isMe ? "var(--primary-foreground)" : "var(--muted-foreground)",
        }}
      >
        {entry.rank}
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium text-foreground">
          {entry.isMe ? "Siz" : entry.firstName}
        </div>
        {entry.prize && (
          <div className="text-[11.5px] font-medium text-primary">{entry.prize.reward}</div>
        )}
      </div>
      <span
        className="shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold tabular-nums"
        style={{ backgroundColor: `var(--tone-${tone}-soft)`, color: `var(--tone-${tone})` }}
      >
        {rejected ? "—" : `${entry.scaledScore}/75`}
      </span>
      {canOpen && (
        <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={2} />
      )}
    </button>
  );
}

function MyAnalysis({ result }: { result: NonNullable<CompetitionResults["myResult"]> }) {
  return (
    <div>
      <p className="mb-3 flex items-center gap-1.5 px-1 text-[15px] font-bold text-foreground">
        <Sparkles className="h-4 w-4 text-primary" strokeWidth={2} />
        Essengiz tahlili
      </p>
      <div className="space-y-2">
        {result.bandResults.map((band) => (
          <BandAccordion key={band.band} band={band} />
        ))}
      </div>

      {result.recommendations.length > 0 && (
        <div className="mt-3 rounded-2xl bg-card p-4 shadow-card">
          <p className="text-[13px] font-semibold text-foreground">Tavsiyalar</p>
          <ul className="mt-2 space-y-1.5">
            {result.recommendations.map((rec, i) => (
              <li key={i} className="flex gap-2 text-[13px] leading-relaxed text-muted-foreground">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                {rec}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function InfoCard({
  icon: Icon,
  tone,
  title,
  text,
  spin,
}: {
  icon: typeof XCircle;
  tone: string;
  title: string;
  text: string;
  spin?: boolean;
}) {
  return (
    <div className="rounded-2xl bg-card p-6 text-center shadow-card">
      <div
        className="mx-auto flex h-14 w-14 items-center justify-center rounded-full"
        style={{ backgroundColor: `var(--tone-${tone}-soft)`, color: `var(--tone-${tone})` }}
      >
        <Icon className={`h-7 w-7 ${spin ? "animate-spin" : ""}`} strokeWidth={1.8} />
      </div>
      <h3 className="mt-3 text-base font-semibold text-foreground">{title}</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">{text}</p>
      <Link
        to="/competitions"
        className="mt-4 inline-block text-[13px] font-semibold text-primary transition-opacity hover:opacity-70"
      >
        Musobaqalarga qaytish
      </Link>
    </div>
  );
}
