import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, CalendarClock, Clock, Coins, Trophy, Users } from "lucide-react";
import { api, type Competition, ApiError } from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { BottomNav } from "@/components/BottomNav";
import { Skeleton } from "@/components/Skeleton";
import { formatSum } from "@/lib/format";
import { COMPETITION_STATUS_META, formatDeadline, formatStartDate } from "@/lib/competition";

export const Route = createFileRoute("/competitions/")({
  head: () => ({
    meta: [
      { title: "Musobaqalar" },
      {
        name: "description",
        content: "Esse musobaqalarida qatnashing va yutuqlarni qo'lga kiriting.",
      },
    ],
  }),
  component: () => (
    <TelegramGate>
      <CompetitionsPage />
    </TelegramGate>
  ),
});

function topPrizeOf(c: Competition) {
  return [...c.prizes].sort((a, b) => a.place - b.place)[0] ?? null;
}

function prizeText(c: Competition): string | null {
  const p = topPrizeOf(c);
  if (!p) return null;
  return p.reward || null;
}

function CompetitionsPage() {
  const competitionsQ = useQuery<Competition[], ApiError>({
    queryKey: ["competitions"],
    queryFn: api.competitions,
    retry: false,
  });

  const items = competitionsQ.data ?? [];
  const featured =
    items.find((c) => c.status === "open") ?? items.find((c) => c.status === "upcoming") ?? null;
  const rest = featured ? items.filter((c) => c.id !== featured.id) : items;

  return (
    <div className="min-h-screen bg-background pb-28">
      <Hero count={items.length} />

      <div className="mx-auto max-w-[560px] px-4 pt-5">
        {competitionsQ.isLoading && (
          <div className="space-y-3">
            <Skeleton className="h-[168px] rounded-2xl" />
            <Skeleton className="h-[132px] rounded-2xl" />
          </div>
        )}

        {competitionsQ.data && items.length === 0 && <EmptyState />}

        {featured && (
          <section>
            <FeaturedCard competition={featured} />
          </section>
        )}

        {rest.length > 0 && (
          <section className={featured ? "mt-6" : ""}>
            {featured && (
              <h2 className="mb-3 px-1 text-[13px] font-bold uppercase tracking-wide text-muted-foreground">
                Boshqa musobaqalar
              </h2>
            )}
            <div className="space-y-3">
              {rest.map((c, i) => (
                <CompetitionCard key={c.id} competition={c} index={i} />
              ))}
            </div>
          </section>
        )}
      </div>

      <BottomNav />
    </div>
  );
}

function Hero({ count }: { count: number }) {
  return (
    <div
      className="relative overflow-hidden px-4 pb-6 pt-6"
      style={{ background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))" }}
    >
      <div
        className="pointer-events-none absolute -right-10 -top-14 h-44 w-44 rounded-full opacity-30 blur-2xl"
        style={{ background: "oklch(0.9 0.08 150)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-16 -left-12 h-44 w-44 rounded-full opacity-20 blur-2xl"
        style={{ background: "oklch(0.85 0.1 85)" }}
      />
      <div className="relative mx-auto max-w-[560px]">
        <div className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/25 backdrop-blur-sm">
            <Trophy className="h-5 w-5 text-white" strokeWidth={2} />
          </div>
          <div>
            <h1 className="text-[20px] font-bold text-white">Musobaqalar</h1>
            <p className="text-[12px] text-white/75">
              Esse yozing, eng zo'rlar qatoriga chiqing
              {count > 0 && ` · ${count} ta`}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

/* Faol musobaqa uchun ajralib turadigan premium karta */
function FeaturedCard({ competition }: { competition: Competition }) {
  const meta = COMPETITION_STATUS_META[competition.status];
  const prize = prizeText(competition);
  const deadline = formatDeadline(competition.endsAt);
  const isUpcoming = competition.status === "upcoming";
  const startDate = formatStartDate(competition.startsAt);

  return (
    <Link
      to="/competitions/$id"
      params={{ id: String(competition.id) }}
      className="relative block overflow-hidden rounded-2xl p-4 shadow-elevated transition-transform active:scale-[0.99]"
      style={{ background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))" }}
    >
      <div
        className="pointer-events-none absolute -right-8 -top-10 h-32 w-32 rounded-full opacity-30 blur-2xl"
        style={{ background: "oklch(0.9 0.08 150)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-12 -left-8 h-32 w-32 rounded-full opacity-20 blur-2xl"
        style={{ background: "oklch(0.85 0.1 85)" }}
      />

      <div className="relative">
        <div className="flex items-center justify-between gap-2">
          <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2.5 py-1 text-[11px] font-bold text-white ring-1 ring-white/20">
            <span className="h-1.5 w-1.5 rounded-full bg-white" />
            {meta.label}
          </span>
          {competition.entryFee > 0 ? (
            <span className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-semibold text-white">
              {formatSum(competition.entryFee)}
            </span>
          ) : (
            <span className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-semibold text-white">
              Bepul
            </span>
          )}
        </div>

        <h2 className="mt-3 text-[17px] font-bold leading-snug text-white">{competition.title}</h2>
        <p className="mt-1 line-clamp-2 text-[13px] leading-relaxed text-white/80">
          {competition.topic}
        </p>

        {prize && (
          <div className="mt-3.5 flex items-center gap-2.5 rounded-2xl bg-white/12 p-3 ring-1 ring-white/15 backdrop-blur-sm">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/20 text-white">
              <Trophy className="h-[18px] w-[18px]" strokeWidth={2} />
            </span>
            <div className="min-w-0">
              <p className="text-[10.5px] uppercase tracking-wide text-white/70">Bosh yutuq</p>
              <p className="truncate text-[15px] font-bold text-white">{prize}</p>
            </div>
          </div>
        )}

        <div className="mt-3.5 flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-[12px] text-white/85">
            {isUpcoming ? (
              <>
                <CalendarClock className="h-3.5 w-3.5" strokeWidth={2} />
                {startDate ? `${startDate} da boshlanadi` : "Tez orada"}
              </>
            ) : deadline ? (
              <>
                <Clock className="h-3.5 w-3.5" strokeWidth={2} />
                {deadline} gacha
              </>
            ) : (
              "Hoziroq qatnashing"
            )}
          </span>
          <span
            className="flex h-9 shrink-0 items-center gap-1 rounded-full bg-white px-4 text-[13px] font-bold"
            style={{ color: "var(--primary)" }}
          >
            {isUpcoming ? "Ro'yxatdan o'tish" : "Qatnashish"}
            <ArrowRight className="h-3.5 w-3.5" strokeWidth={2.4} />
          </span>
        </div>
      </div>
    </Link>
  );
}

function CompetitionCard({ competition, index }: { competition: Competition; index: number }) {
  const meta = COMPETITION_STATUS_META[competition.status];
  const prize = prizeText(competition);
  const deadline = formatDeadline(competition.endsAt);
  const startDate = formatStartDate(competition.startsAt);
  const accent = meta.tone === "muted" ? "var(--border)" : `var(--tone-${meta.tone})`;
  const isFinished = competition.status === "finished";
  const isUpcoming = competition.status === "upcoming";
  const registered = competition.registeredCount ?? 0;

  return (
    <Link
      to="/competitions/$id"
      params={{ id: String(competition.id) }}
      className="relative block animate-fade-slide-up overflow-hidden rounded-2xl border border-border bg-card p-4 pl-5 shadow-card transition-transform active:scale-[0.99]"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {/* Status rangidagi chap aksent */}
      <span className="absolute inset-y-0 left-0 w-1.5" style={{ backgroundColor: accent }} />

      <div className="flex items-start justify-between gap-3">
        <h2 className="text-[15px] font-bold leading-snug text-foreground">{competition.title}</h2>
        <StatusBadge tone={meta.tone} label={meta.label} />
      </div>

      <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-muted-foreground">
        {competition.topic}
      </p>

      {prize && (
        <div className="mt-3 flex items-center gap-2 rounded-xl bg-muted/60 px-3 py-2">
          <Trophy
            className="h-4 w-4 shrink-0"
            style={{ color: "var(--tone-ok)" }}
            strokeWidth={2}
          />
          <span className="text-[11px] text-muted-foreground">Bosh yutuq:</span>
          <span className="truncate text-[13px] font-bold text-foreground">{prize}</span>
        </div>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {competition.entryFee > 0 ? (
          <Chip icon={Coins} tone="ok" text={formatSum(competition.entryFee)} />
        ) : (
          <Chip icon={Coins} tone="excellent" text="Bepul" />
        )}
        {isUpcoming && startDate && (
          <Chip icon={CalendarClock} tone="ok" text={`${startDate} da`} />
        )}
        {deadline && competition.status === "open" && (
          <Chip icon={Clock} tone="weak" text={`${deadline} gacha`} />
        )}
        {(isUpcoming || competition.status === "open") && registered > 0 && (
          <Chip icon={Users} tone="primary" text={`${registered} ro'yxatda`} />
        )}
        {isFinished && (
          <span className="ml-auto flex items-center gap-1 text-[12.5px] font-semibold text-primary">
            Natijalarni ko'rish
            <ArrowRight className="h-3.5 w-3.5" strokeWidth={2.2} />
          </span>
        )}
      </div>
    </Link>
  );
}

function StatusBadge({ tone, label }: { tone: string; label: string }) {
  const isPrimary = tone === "primary";
  const bg =
    tone === "muted"
      ? "var(--muted)"
      : isPrimary
        ? "var(--primary-soft)"
        : `var(--tone-${tone}-soft)`;
  const fg =
    tone === "muted"
      ? "var(--muted-foreground)"
      : isPrimary
        ? "var(--primary)"
        : `var(--tone-${tone})`;
  return (
    <span
      className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold"
      style={{ backgroundColor: bg, color: fg }}
    >
      {label}
    </span>
  );
}

function Chip({ icon: Icon, tone, text }: { icon: typeof Coins; tone: string; text: string }) {
  const isPrimary = tone === "primary";
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[12px] font-medium"
      style={{
        backgroundColor: isPrimary ? "var(--primary-soft)" : `var(--tone-${tone}-soft)`,
        color: isPrimary ? "var(--primary)" : `var(--tone-${tone})`,
      }}
    >
      <Icon className="h-3.5 w-3.5" strokeWidth={2} />
      {text}
    </span>
  );
}

function EmptyState() {
  return (
    <div className="mt-6 rounded-2xl bg-card p-8 text-center shadow-card">
      <div
        className="mx-auto flex h-14 w-14 items-center justify-center rounded-full"
        style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
      >
        <Trophy className="h-7 w-7" strokeWidth={1.8} />
      </div>
      <h3 className="mt-3 text-base font-semibold text-foreground">Hozircha musobaqa yo'q</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Yangi musobaqa e'lon qilinganda shu yerda ko'rinadi.
      </p>
    </div>
  );
}
