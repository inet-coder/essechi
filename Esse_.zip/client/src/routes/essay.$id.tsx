import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Clock, Lightbulb, TriangleAlert, X } from "lucide-react";
import { api, type Essay, type PublicEssay, ApiError } from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { ScoreRing } from "@/components/ScoreRing";
import { BandAccordion } from "@/components/BandAccordion";
import { AnnotatedEssayText } from "@/components/AnnotatedEssayText";
import { Skeleton } from "@/components/Skeleton";
import { formatDate, totalLabel, totalTone } from "@/lib/format";

export const Route = createFileRoute("/essay/$id")({
  head: () => ({
    meta: [
      { title: "Esse natijasi — Milliy sertifikat" },
      {
        name: "description",
        content: "Esse boʻyicha 12 mezon asosida batafsil baholash natijalari.",
      },
    ],
  }),
  component: () => (
    <TelegramGate>
      <EssayDetailPage />
    </TelegramGate>
  ),
});

function EssayDetailPage() {
  const { id } = Route.useParams();
  const router = useRouter();

  const historyQ = useQuery<Essay[], ApiError>({
    queryKey: ["history"],
    queryFn: api.history,
    retry: false,
  });

  const ownEssay = historyQ.data?.find((e) => String(e.id) === id);

  // O'z tarixida topilmasa - bu boshqa foydalanuvchining essesi (masalan,
  // reytingdan ochilgan). Ommaviy endpointdan yuklaymiz. Faqat tarix yuklanib
  // bo'lgach va o'zimizniki emasligi aniqlangach so'rov yuboriladi.
  const publicEnabled = Boolean(historyQ.data) && !ownEssay;
  const publicQ = useQuery<PublicEssay, ApiError>({
    queryKey: ["publicEssay", id],
    queryFn: () => api.publicEssay(id),
    enabled: publicEnabled,
    retry: false,
  });

  const essay = ownEssay ?? publicQ.data;
  const isOwner = Boolean(ownEssay);
  const authorName = ownEssay ? null : (publicQ.data?.authorName ?? null);

  const isLoading = historyQ.isLoading || (publicEnabled && publicQ.isLoading);
  const publicIs404 = publicQ.error?.status === 404;
  const notFound =
    publicEnabled && (publicIs404 || (!publicQ.isLoading && !publicQ.data && !publicQ.error));
  const loadError = historyQ.error ?? (publicQ.error && !publicIs404 ? publicQ.error : null);

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-[560px] px-4 pb-12">
        <div className="sticky top-0 z-10 -mx-4 flex items-center bg-background/85 px-4 py-3 backdrop-blur-md">
          <button
            type="button"
            onClick={() => router.history.back()}
            className="-ml-2 inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <polyline points="15 18 9 12 15 6" />
            </svg>
            Orqaga
          </button>
        </div>

        {isLoading && (
          <div className="space-y-4 pt-2">
            <Skeleton className="h-40 rounded-2xl" />
            <Skeleton className="h-14 rounded-xl" />
            <Skeleton className="h-14 rounded-xl" />
            <Skeleton className="h-14 rounded-xl" />
          </div>
        )}

        {!isLoading && loadError && (
          <div className="mt-6 rounded-2xl bg-card p-6 text-center shadow-card">
            <p className="text-sm text-muted-foreground">
              {loadError.status === 401
                ? "Sessiya muddati tugagan. Botni qayta oching."
                : "Maʼlumotni yuklab boʻlmadi."}
            </p>
          </div>
        )}

        {!isLoading && !loadError && notFound && (
          <div className="mt-6 rounded-2xl bg-card p-6 text-center shadow-card">
            <h2 className="text-base font-semibold">Esse topilmadi</h2>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Bu esse mavjud emas, oʻchirilgan yoki hali tekshirilmagan.
            </p>
            <Link
              to="/"
              className="mt-4 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            >
              Bosh sahifa
            </Link>
          </div>
        )}

        {essay && <EssayBody essay={essay} isOwner={isOwner} authorName={authorName} />}
      </div>
    </div>
  );
}

function EssayBody({
  essay,
  isOwner,
  authorName,
}: {
  essay: Essay;
  isOwner: boolean;
  authorName: string | null;
}) {
  const ev = essay.evaluationResult;

  return (
    <div className="space-y-5 pt-2">
      <div className="rounded-2xl bg-card p-5 shadow-card">
        <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {formatDate(essay.createdAt)} · {essay.wordCount} soʻz
        </div>
        <p className="mt-2 text-[15px] leading-relaxed text-foreground">{essay.topic}</p>
      </div>

      <div className="rounded-2xl bg-card p-5 shadow-card">
        <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          {isOwner ? "Sizning essengiz" : `${authorName ?? "Muallif"} essesi`}
        </h3>
        <AnnotatedEssayText
          text={essay.rawText}
          bandResults={ev?.status === "completed" ? ev.bandResults : []}
        />
      </div>

      {!ev && <NotCheckedState />}

      {ev?.status === "completed" && <CompletedView ev={ev} />}
      {ev?.status === "auto_rejected" && <RejectedView ev={ev} />}
      {ev?.status === "failed" && <FailedView />}
    </div>
  );
}

function CompletedView({ ev }: { ev: NonNullable<Essay["evaluationResult"]> }) {
  const tone = totalTone(ev.totalScore);
  return (
    <>
      <div
        className="flex flex-col items-center rounded-2xl p-6 text-center shadow-card"
        style={{ backgroundColor: "var(--card)" }}
      >
        <ScoreRing totalScore={ev.totalScore} scaledScore={ev.scaledScore} />
        <div
          className="mt-3 inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold"
          style={{
            backgroundColor: `var(--tone-${tone}-soft)`,
            color: `var(--tone-${tone})`,
          }}
        >
          {totalLabel(ev.totalScore)}
        </div>
      </div>

      <div>
        <h3 className="px-1 pb-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          12 mezon boʻyicha
        </h3>
        <div className="space-y-2.5">
          {ev.bandResults.map((b) => (
            <BandAccordion key={b.band} band={b} />
          ))}
        </div>
      </div>

      {ev.recommendations.length > 0 && (
        <div className="rounded-2xl bg-card p-5 shadow-card">
          <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Tavsiyalar
          </h3>
          <ul className="mt-3 space-y-2.5">
            {ev.recommendations.map((r, i) => (
              <li key={i} className="flex gap-2.5 text-sm leading-relaxed text-foreground">
                <Lightbulb
                  className="mt-0.5 h-4 w-4 shrink-0 text-primary"
                  strokeWidth={2}
                  aria-hidden
                />
                <span>{r}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </>
  );
}

function RejectedView({ ev }: { ev: NonNullable<Essay["evaluationResult"]> }) {
  return (
    <>
      <div className="flex flex-col items-center rounded-2xl bg-card p-6 text-center shadow-card">
        <ScoreRing totalScore={ev.totalScore} scaledScore={ev.scaledScore} />
      </div>
      <div
        className="rounded-2xl border p-5"
        style={{
          backgroundColor: "var(--tone-weak-soft)",
          borderColor: "var(--tone-weak)",
          color: "var(--tone-weak)",
        }}
      >
        <div className="flex items-start gap-3">
          <TriangleAlert className="h-5 w-5 shrink-0" strokeWidth={2} />
          <div>
            <div className="text-sm font-semibold">Esse rad etildi</div>
            <p className="mt-1 text-sm font-medium">{ev.rejectionReason}</p>
          </div>
        </div>
      </div>
      <p className="px-1 text-sm text-muted-foreground">
        Bu esse batafsil tekshirilmadi, chunki yuqoridagi sabab tufayli avtomatik rad etildi.
      </p>
    </>
  );
}

function FailedView() {
  return (
    <div
      className="rounded-2xl border p-5"
      style={{
        backgroundColor: "var(--tone-bad-soft)",
        borderColor: "var(--tone-bad)",
        color: "var(--tone-bad)",
      }}
    >
      <div className="flex items-start gap-3">
        <X className="h-5 w-5 shrink-0" strokeWidth={2.5} />
        <div>
          <div className="text-sm font-semibold">Tekshirishda texnik xatolik yuz berdi</div>
          <p className="mt-2 text-sm font-medium">
            Hisobingizdan hech narsa yechilmadi. Iltimos, botda qayta urinib koʻring.
          </p>
        </div>
      </div>
    </div>
  );
}

function NotCheckedState() {
  return (
    <div className="rounded-2xl bg-card p-8 text-center shadow-card">
      <div className="flex justify-center text-muted-foreground">
        <Clock className="h-9 w-9" strokeWidth={1.5} />
      </div>
      <h3 className="mt-3 text-base font-semibold text-foreground">Bu esse hali tekshirilmagan</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Natija tayyor boʻlishi bilan shu yerda koʻrinadi.
      </p>
    </div>
  );
}
