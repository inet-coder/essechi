import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  Bot,
  Brain,
  History,
  Layers,
  Library,
  Lightbulb,
  Medal,
  PenLine,
  Sparkles,
  Swords,
  Trophy,
} from "lucide-react";
import {
  api,
  type Me,
  type Essay,
  type MySummary,
  type Article,
  type Topic,
  type Competition,
  ApiError,
} from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { EssayCard } from "@/components/EssayCard";
import { Skeleton } from "@/components/Skeleton";
import { SectionHeader } from "@/components/SectionHeader";
import { FeaturedArticleCard } from "@/components/ArticleCards";
import { BottomNav } from "@/components/BottomNav";
import { greeting, formatSum } from "@/lib/format";
import { COMPETITION_STATUS_META } from "@/lib/competition";
import { todaysTip } from "@/lib/tips";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Milliy sertifikat — Esselarim" },
      { name: "description", content: "Yuborgan esselaringizning natijalari va batafsil tahlili." },
    ],
  }),
  component: () => (
    <TelegramGate>
      <HomePage />
    </TelegramGate>
  ),
});

function HomePage() {
  const meQ = useQuery<Me, ApiError>({ queryKey: ["me"], queryFn: api.me, retry: false });
  const historyQ = useQuery<Essay[], ApiError>({
    queryKey: ["history"],
    queryFn: api.history,
    retry: false,
  });
  const summaryQ = useQuery<MySummary, ApiError>({
    queryKey: ["summary"],
    queryFn: api.summary,
    retry: false,
  });
  const articlesQ = useQuery<Article[], ApiError>({
    queryKey: ["articles"],
    queryFn: api.articles,
    retry: false,
  });
  const topicsQ = useQuery<Topic[], ApiError>({
    queryKey: ["topics"],
    queryFn: api.topics,
    retry: false,
  });
  const competitionsQ = useQuery<Competition[], ApiError>({
    queryKey: ["competitions"],
    queryFn: api.competitions,
    retry: false,
  });

  const fatalError = meQ.error?.status === 0 || historyQ.error?.status === 0;
  const [lastEssay] = historyQ.data ?? [];

  // Bannerda ko'rsatiladigan musobaqa: avval ochig'i, bo'lmasa yakunlangani
  // (natijalarni ko'rish uchun).
  const competitions = competitionsQ.data ?? [];
  const featuredCompetition =
    competitions.find((c) => c.status === "open") ??
    competitions.find((c) => c.status === "finished") ??
    null;

  return (
    <div
      className="min-h-screen pb-28"
      style={{
        background:
          "linear-gradient(180deg, var(--primary-soft) 0%, var(--background) 380px, var(--background) 100%)",
      }}
    >
      <div className="mx-auto max-w-[560px] px-4 pt-6">
        <HeroCard me={meQ.data} loading={meQ.isLoading} summary={summaryQ.data} />

        {/* Tez kirish — asosiy vositalar */}
        <QuickTiles />

        {/* Raqobatchilarim — musobaqalar bo'limi */}
        <section className="mt-8">
          <SectionHeader
            icon={Swords}
            title="Raqobatchilarim"
            tone="primary"
            subtitle="Musobaqalarda kuchingizni sinang"
            linkTo="/competitions"
          />
          <RivalsCard competition={featuredCompetition} />
        </section>

        {fatalError && (
          <div className="mt-4">
            <ErrorState
              title="Internetni tekshiring"
              description="Maʼlumotlarni yuklab boʻlmadi."
              onRetry={() => {
                meQ.refetch();
                historyQ.refetch();
              }}
            />
          </div>
        )}

        {!fatalError && historyQ.error?.status === 401 && (
          <div className="mt-4">
            <ErrorState title="Sessiya tugagan" description="Iltimos, botni qayta oching." />
          </div>
        )}

        {!fatalError && historyQ.error?.status !== 401 && (
          <>
            {/* Continue last essay */}
            {historyQ.isLoading && (
              <div className="mt-8">
                <Skeleton className="h-[104px] rounded-2xl" />
              </div>
            )}

            {lastEssay && (
              <section className="mt-8">
                <SectionHeader icon={History} title="So'nggi essengiz" tone="primary" />
                <EssayCard essay={lastEssay} />
              </section>
            )}

            {/* Featured articles */}
            {articlesQ.data && articlesQ.data.length > 0 && (
              <section className="mt-9">
                <SectionHeader icon={Library} title="Maqolalar" tone="good" linkTo="/articles" />
                <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-1">
                  {articlesQ.data.slice(0, 4).map((article) => (
                    <FeaturedArticleCard key={article.id} article={article} />
                  ))}
                </div>
              </section>
            )}

            {/* Esse mavzulari — alohida bo'limga o'tish uchun o'zgacha CTA */}
            {topicsQ.data && topicsQ.data.length > 0 && (
              <section className="mt-9">
                <TopicsEntry topics={topicsQ.data} />
              </section>
            )}

            {/* Learning tip */}
            <section className="mt-9">
              <LearningTip />
            </section>
          </>
        )}
      </div>

      <BottomNav />
    </div>
  );
}

/**
 * Zich nuqta-panjara naqshi — premium karta fonlarida chuqurlik va
 * to'qima berish uchun, brend ranglaridan mustaqil, sof dekorativ qatlam.
 */
function DotGrid({ opacity = 0.14 }: { opacity?: number }) {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden
      style={{ opacity }}
    >
      <defs>
        <pattern id="dot-grid" width="14" height="14" patternUnits="userSpaceOnUse">
          <circle cx="1.2" cy="1.2" r="1.2" fill="white" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#dot-grid)" />
    </svg>
  );
}

const PODIUM_ACCENT: Record<number, { ring: string; bg: string; text: string }> = {
  1: {
    ring: "ring-[oklch(0.85_0.14_85)]/40",
    bg: "bg-[oklch(0.85_0.14_85)]/20",
    text: "text-[oklch(0.92_0.1_95)]",
  },
  2: { ring: "ring-white/25", bg: "bg-white/12", text: "text-white/90" },
  3: {
    ring: "ring-[oklch(0.72_0.1_50)]/40",
    bg: "bg-[oklch(0.72_0.1_50)]/20",
    text: "text-[oklch(0.85_0.08_60)]",
  },
};

/** Musobaqa yo'q holatida ko'rsatiladigan ixcham taklif kartasi. */
function RivalsEmptyCard() {
  return (
    <Link
      to="/competitions"
      className="group relative flex items-center gap-3.5 overflow-hidden rounded-2xl p-4 shadow-card ring-1 ring-white/10 transition-all duration-300 active:scale-[0.99]"
      style={{
        background:
          "radial-gradient(120% 140% at 0% 0%, oklch(0.55 0.14 300) 0%, oklch(0.44 0.15 265) 100%)",
      }}
    >
      <DotGrid opacity={0.1} />
      <span className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/15 text-white ring-1 ring-white/20">
        <Trophy className="h-5 w-5" strokeWidth={2} />
      </span>
      <div className="relative min-w-0 flex-1">
        <p className="text-[14.5px] font-bold tracking-tight text-white">
          Musobaqalarda qatnashing
        </p>
        <p className="truncate text-[12px] text-white/70">
          Yangi musobaqalar shu yerda e'lon qilinadi
        </p>
      </div>
      <ArrowRight className="relative h-4 w-4 shrink-0 text-white/70" strokeWidth={2.4} />
    </Link>
  );
}

function RivalsCard({ competition }: { competition: Competition | null }) {
  if (!competition) return <RivalsEmptyCard />;

  const meta = COMPETITION_STATUS_META[competition.status];
  const topPrizes = [...competition.prizes].sort((a, b) => a.place - b.place).slice(0, 3);
  const isFinished = competition.status === "finished";

  return (
    <Link
      to="/competitions"
      className="group relative block overflow-hidden rounded-3xl p-5 shadow-elevated ring-1 ring-white/10 transition-all duration-300 active:scale-[0.99]"
      style={{
        background:
          "radial-gradient(130% 160% at 100% 0%, oklch(0.58 0.16 300) 0%, oklch(0.47 0.17 270) 50%, oklch(0.36 0.14 250) 100%)",
      }}
    >
      <DotGrid opacity={0.1} />
      <div
        className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 rounded-full opacity-40 blur-2xl transition-transform duration-500 group-hover:scale-110"
        style={{ background: "oklch(0.88 0.13 85)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-14 -left-12 h-40 w-40 rounded-full opacity-20 blur-2xl"
        style={{ background: "oklch(0.85 0.1 150)" }}
      />

      <div className="relative">
        {/* Sarlavha qatori */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/15 text-white ring-1 ring-white/25 shadow-inner backdrop-blur-sm">
              <Trophy className="h-6 w-6" strokeWidth={2} />
            </span>
            <div className="min-w-0">
              <span className="inline-flex items-center rounded-full bg-white/20 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-white ring-1 ring-white/10">
                {meta.label}
              </span>
              <p className="mt-1.5 max-w-[190px] text-[16px] font-bold leading-tight tracking-tight text-white">
                {competition.title}
              </p>
            </div>
          </div>
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 ring-1 ring-white/15 transition-transform duration-300 group-active:translate-x-0.5">
            <ArrowRight className="h-3.5 w-3.5 text-white/85" strokeWidth={2.4} />
          </span>
        </div>

        {/* Yutuqlar podiumi — sovrinlar mavjud bo'lsa */}
        {topPrizes.length > 0 ? (
          <div className="mt-4 flex items-stretch gap-2">
            {topPrizes.map((p) => {
              const accent = PODIUM_ACCENT[p.place] ?? PODIUM_ACCENT[3];
              return (
                <div
                  key={p.place}
                  className={`flex flex-1 flex-col items-center gap-1 rounded-xl px-2 py-2.5 text-center ring-1 ${accent.bg} ${accent.ring}`}
                >
                  <span className={`text-[11px] font-bold tabular-nums ${accent.text}`}>
                    {p.place}-o'rin
                  </span>
                  <span className="truncate text-[11px] font-medium text-white/80">{p.reward}</span>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="mt-4 text-[12.5px] text-white/70">Hoziroq qatnashing va g'olib bo'ling</p>
        )}

        {/* Amal tugmasi */}
        <span
          className="mt-4 flex h-10 items-center justify-center gap-1.5 rounded-xl bg-white text-[13.5px] font-bold shadow-sm transition-transform duration-300 group-active:scale-[0.98]"
          style={{ color: "oklch(0.47 0.17 270)" }}
        >
          {isFinished ? "Natijalarni ko'rish" : "Musobaqaga o'tish"}
          <ArrowRight className="h-3.5 w-3.5" strokeWidth={2.4} />
        </span>
      </div>
    </Link>
  );
}

function TopicsEntry({ topics }: { topics: Topic[] }) {
  const count = topics.length;
  // Kategoriya nomlarini takrorsiz yig'amiz (chip'larda ko'rsatish uchun).
  const catNames = [
    ...new Set(topics.map((t) => t.category?.name).filter((n): n is string => Boolean(n))),
  ];
  const shownCats = catNames.slice(0, 3);
  const extraCats = catNames.length - shownCats.length;

  return (
    <Link
      to="/topics"
      className="group relative block overflow-hidden rounded-2xl p-4 shadow-elevated ring-1 ring-white/10 transition-all duration-300 active:scale-[0.99]"
      style={{
        background:
          "radial-gradient(120% 140% at 100% 0%, oklch(0.5 0.15 285) 0%, var(--primary) 55%, oklch(0.36 0.13 275) 100%)",
      }}
    >
      <DotGrid opacity={0.1} />
      {/* Dekorativ blur dog'lar */}
      <div
        className="pointer-events-none absolute -right-8 -top-10 h-32 w-32 rounded-full opacity-30 blur-2xl"
        style={{ background: "oklch(0.9 0.08 150)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-12 -left-8 h-32 w-32 rounded-full opacity-20 blur-2xl"
        style={{ background: "oklch(0.85 0.1 85)" }}
      />

      {/* Signatura: yelpig'ichsimon karta to'plami — "mavzular to'plami" ramzi */}
      <div
        className="pointer-events-none absolute right-4 top-4 h-14 w-14 transition-transform duration-500 group-hover:rotate-3"
        aria-hidden
      >
        <span className="absolute inset-0 rotate-[12deg] rounded-xl bg-white/10 ring-1 ring-white/10" />
        <span className="absolute inset-0 rotate-[-8deg] rounded-xl bg-white/15 ring-1 ring-white/10" />
        <span className="absolute inset-0 rounded-xl bg-white/10 ring-1 ring-white/25" />
      </div>

      <div className="relative">
        <div className="flex items-center gap-2.5">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/25 shadow-inner backdrop-blur-sm">
            <Layers className="h-5 w-5 text-white" strokeWidth={2} />
          </span>
          <div>
            <h3 className="text-[16px] font-bold tracking-tight text-white">Esse mavzulari</h3>
            <p className="text-[12px] text-white/75">{count} ta mavzu · kategoriyalar bo'yicha</p>
          </div>
        </div>

        {shownCats.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {shownCats.map((c) => (
              <span
                key={c}
                className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-semibold text-white ring-1 ring-white/15"
              >
                {c}
              </span>
            ))}
            {extraCats > 0 && (
              <span className="rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-semibold text-white/75 ring-1 ring-white/10">
                +{extraCats}
              </span>
            )}
          </div>
        )}

        <div className="mt-4 flex items-center justify-between">
          <span className="text-[12.5px] font-medium text-white/85">
            Mavzu tanlab, yozishni boshlang
          </span>
          <span
            className="flex h-9 shrink-0 items-center gap-1 rounded-full bg-white px-3.5 text-[13px] font-bold shadow-sm transition-transform duration-300 group-active:scale-95"
            style={{ color: "var(--primary)" }}
          >
            Ko'rish
            <ArrowRight className="h-3.5 w-3.5" strokeWidth={2.4} />
          </span>
        </div>
      </div>
    </Link>
  );
}

function QuickTiles() {
  const tiles: {
    to: string;
    label: string;
    icon: typeof Medal;
    tone: "primary" | "good" | "ok";
  }[] = [
    { to: "/leaderboard", label: "Reyting", icon: Medal, tone: "primary" },
    { to: "/quiz", label: "AI viktorina", icon: Brain, tone: "good" },
    { to: "/analysis", label: "AI tahlil", icon: Bot, tone: "ok" },
  ];

  return (
    <div className="mt-5 grid grid-cols-3 gap-2.5">
      {tiles.map((t) => {
        const fg = t.tone === "primary" ? "var(--primary)" : `var(--tone-${t.tone})`;
        const soft = t.tone === "primary" ? "var(--primary-soft)" : `var(--tone-${t.tone}-soft)`;
        return (
          <Link
            key={t.to}
            to={t.to}
            className="group flex flex-col items-center gap-2 rounded-2xl bg-card p-3.5 shadow-card ring-1 ring-black/[0.03] transition-all duration-200 active:scale-[0.96] active:shadow-none"
          >
            <span
              className="flex h-10 w-10 items-center justify-center rounded-2xl ring-1 ring-black/[0.02] transition-transform duration-200 group-active:scale-90"
              style={{ backgroundColor: soft, color: fg }}
            >
              <t.icon className="h-5 w-5" strokeWidth={2} />
            </span>
            <span className="text-[12px] font-semibold tracking-tight text-foreground">
              {t.label}
            </span>
          </Link>
        );
      })}
    </div>
  );
}

function HeroCard({
  me,
  loading,
  summary,
}: {
  me: Me | undefined;
  loading: boolean;
  summary: MySummary | undefined;
}) {
  return (
    <div
      className="relative overflow-hidden rounded-3xl p-5 shadow-elevated ring-1 ring-white/10"
      style={{
        background:
          "radial-gradient(130% 160% at 0% 0%, oklch(0.5 0.15 285) 0%, var(--primary) 45%, oklch(0.38 0.13 272) 100%)",
      }}
    >
      <DotGrid opacity={0.08} />
      {/* Decorative blurred blobs */}
      <div
        className="pointer-events-none absolute -right-10 -top-12 h-44 w-44 rounded-full opacity-40 blur-2xl"
        style={{ background: "oklch(0.9 0.08 150)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-16 -left-12 h-44 w-44 rounded-full opacity-25 blur-2xl"
        style={{ background: "oklch(0.85 0.1 85)" }}
      />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px"
        style={{
          background: "linear-gradient(90deg, transparent, oklch(1 0 0 / 0.35), transparent)",
        }}
      />

      <div className="relative">
        {loading ? (
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 animate-pulse rounded-2xl bg-white/20" />
            <div className="space-y-2">
              <div className="h-4 w-32 animate-pulse rounded bg-white/20" />
              <div className="h-3 w-40 animate-pulse rounded bg-white/15" />
            </div>
          </div>
        ) : me ? (
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/15 text-lg font-bold text-white ring-1 ring-white/25 shadow-inner backdrop-blur-sm">
              {me.firstName?.[0]?.toUpperCase() ?? "?"}
            </div>
            <div className="min-w-0">
              <h1 className="truncate text-[20px] font-bold tracking-tight text-white">
                {greeting()}, {me.firstName}!
              </h1>
              <p className="flex items-center gap-1 text-[13px] text-white/70">
                Bugun ham til mahoratingizni oshiring
                <Sparkles className="h-3.5 w-3.5" strokeWidth={2} />
              </p>
            </div>
          </div>
        ) : (
          <p className="text-sm text-white/80">Profil yuklanmadi.</p>
        )}

        {/* Asosiy amal — esse yozish */}
        {me && (
          <Link
            to="/write"
            search={{ topic: undefined }}
            className="group mt-4 flex items-center justify-between rounded-2xl bg-white px-4 py-3 shadow-card transition-all duration-200 active:scale-[0.98]"
          >
            <span
              className="flex items-center gap-2.5 text-[14.5px] font-bold"
              style={{ color: "var(--primary)" }}
            >
              <span
                className="flex h-8 w-8 items-center justify-center rounded-xl"
                style={{ backgroundColor: "var(--primary-soft)" }}
              >
                <PenLine className="h-4 w-4" strokeWidth={2.2} />
              </span>
              Yangi esse yozish
            </span>
            <ArrowRight
              className="h-4 w-4 transition-transform duration-200 group-active:translate-x-0.5"
              strokeWidth={2.4}
              style={{ color: "var(--primary)" }}
            />
          </Link>
        )}

        {summary && summary.checkedEssayCount > 0 && (
          <Link
            to="/stats"
            className="mt-3 flex items-stretch overflow-hidden rounded-2xl bg-white/10 ring-1 ring-white/15 backdrop-blur-sm"
          >
            <HeroStat value={`${summary.averageScaledScore ?? 0}`} label="O'rtacha" />
            <HeroStatDivider />
            <HeroStat
              value={summary.bestScaledScore !== null ? `${summary.bestScaledScore}` : "—"}
              label="Eng yaxshi"
            />
            <HeroStatDivider />
            <HeroStat value={`${summary.checkedEssayCount}`} label="Tekshirilgan" />
          </Link>
        )}
      </div>
    </div>
  );
}

function HeroStatDivider() {
  return <span className="my-2.5 w-px shrink-0 bg-white/15" aria-hidden />;
}

function HeroStat({ value, label }: { value: string; label: string }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-0.5 px-2 py-2.5 text-center">
      <div className="text-[17px] font-bold tabular-nums tracking-tight text-white">{value}</div>
      <div className="text-[10.5px] text-white/65">{label}</div>
    </div>
  );
}

function LearningTip() {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-card p-4 pl-5 shadow-card ring-1 ring-black/[0.03]">
      <span
        className="absolute inset-y-0 left-0 w-1"
        style={{ background: "linear-gradient(180deg, var(--tone-weak), var(--tone-ok))" }}
        aria-hidden
      />
      <div className="flex items-start gap-3">
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
          style={{ backgroundColor: "var(--tone-weak-soft)", color: "var(--tone-weak)" }}
          aria-hidden
        >
          <Lightbulb className="h-4.5 w-4.5" strokeWidth={2} />
        </span>
        <div className="min-w-0">
          <p
            className="text-[11px] font-bold uppercase tracking-wider"
            style={{ color: "var(--tone-weak)" }}
          >
            Bugungi maslahat
          </p>
          <p className="mt-1 text-[13px] leading-relaxed text-foreground">{todaysTip()}</p>
        </div>
      </div>
    </div>
  );
}

function ErrorState({
  title,
  description,
  onRetry,
}: {
  title: string;
  description: string;
  onRetry?: () => void;
}) {
  return (
    <div
      className="rounded-2xl p-6 text-center ring-1 ring-black/[0.03]"
      style={{ backgroundColor: "var(--tone-bad-soft)" }}
    >
      <h3 className="text-sm font-semibold" style={{ color: "var(--tone-bad)" }}>
        {title}
      </h3>
      <p className="mt-1 text-xs" style={{ color: "var(--tone-bad)", opacity: 0.85 }}>
        {description}
      </p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 rounded-xl px-4 py-2 text-xs font-semibold text-primary-foreground shadow-sm transition-transform duration-200 active:scale-95"
          style={{ backgroundColor: "var(--tone-bad)" }}
        >
          Qayta urinish
        </button>
      )}
    </div>
  );
}
