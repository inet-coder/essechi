import { useRef, useState, type RefObject } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ChevronUp, Crown, FileText, Medal, Star, Trophy, Users } from "lucide-react";
import {
  api,
  type Leaderboard,
  type LeaderboardEntry,
  type LeaderboardMetric,
  type LeaderboardPeriod,
  type Me,
  ApiError,
} from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { Skeleton } from "@/components/Skeleton";
import { BottomNav } from "@/components/BottomNav";
import { totalTone } from "@/lib/format";

export const Route = createFileRoute("/leaderboard")({
  head: () => ({
    meta: [
      { title: "Reyting" },
      {
        name: "description",
        content: "Eng yuqori natija koʻrsatgan talabgorlar reytingi.",
      },
    ],
  }),
  component: () => (
    <TelegramGate>
      <LeaderboardPage />
    </TelegramGate>
  ),
});

const PERIOD_LABELS: Record<LeaderboardPeriod, string> = {
  daily: "Kunlik",
  weekly: "Haftalik",
  monthly: "Oylik",
};

const METRIC_LABELS: Record<LeaderboardMetric, string> = {
  score: "Ball bo'yicha",
  count: "Esselar soni",
};

// Tanlangan rejimga qarab asosiy va ikkilamchi ko'rsatkichlar.
function statFor(entry: LeaderboardEntry, metric: LeaderboardMetric) {
  if (metric === "count") {
    return {
      primary: String(entry.essayCount),
      primaryUnit: "ta",
      secondary: `eng yaxshi ${entry.scaledScore}`,
    };
  }
  return {
    primary: String(entry.scaledScore),
    primaryUnit: "/75",
    secondary: `${entry.essayCount} ta esse`,
  };
}

function LeaderboardPage() {
  const [period, setPeriod] = useState<LeaderboardPeriod>("weekly");
  const [metric, setMetric] = useState<LeaderboardMetric>("score");
  const myRowRef = useRef<HTMLAnchorElement>(null);

  const meQ = useQuery<Me, ApiError>({ queryKey: ["me"], queryFn: api.me, retry: false });
  const leaderboardQ = useQuery<Leaderboard, ApiError>({
    queryKey: ["leaderboard", period, metric],
    queryFn: () => api.leaderboard(period, metric),
    retry: false,
  });

  const myId = meQ.data?.id;
  const entries = leaderboardQ.data?.leaderboard ?? [];
  const top3 = entries.slice(0, 3);
  const rest = entries.slice(3);
  const myEntry = entries.find((e) => e.userId === myId);
  const showMyRankBar = Boolean(myEntry && myEntry.rank > 3);

  function scrollToMyRow() {
    myRowRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  return (
    <div className={`min-h-screen bg-background ${showMyRankBar ? "pb-40" : "pb-28"}`}>
      <Hero
        count={entries.length}
        period={period}
        onPeriodChange={setPeriod}
        metric={metric}
        onMetricChange={setMetric}
      />

      <div className="mx-auto max-w-[560px] px-4 pt-5">
        {leaderboardQ.isLoading && (
          <div className="space-y-2.5">
            <Skeleton className="h-[180px] rounded-2xl" />
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-[60px] rounded-2xl" />
            ))}
          </div>
        )}

        {leaderboardQ.error && leaderboardQ.error.status === 401 && (
          <ErrorState title="Sessiya muddati tugagan" description="Iltimos, botni qayta oching." />
        )}

        {leaderboardQ.error &&
          leaderboardQ.error.status !== 401 &&
          leaderboardQ.error.message === "network" && (
            <ErrorState
              title="Internetni tekshiring"
              description="Maʼlumotlarni yuklab boʻlmadi."
              onRetry={() => leaderboardQ.refetch()}
            />
          )}

        {leaderboardQ.data && entries.length === 0 && <EmptyState period={period} />}

        {top3.length > 0 && (
          <div>
            <Podium entries={top3} myId={myId} metric={metric} />
          </div>
        )}

        {rest.length > 0 && (
          <div className="mt-3 space-y-2">
            {rest.map((entry) => (
              <LeaderboardRow
                key={entry.rank}
                entry={entry}
                metric={metric}
                isMe={entry.userId === myId}
                rowRef={entry.userId === myId ? myRowRef : undefined}
              />
            ))}
          </div>
        )}
      </div>

      {showMyRankBar && myEntry && (
        <MyRankBar entry={myEntry} metric={metric} onClick={scrollToMyRow} />
      )}

      <BottomNav />
    </div>
  );
}

function Hero({
  count,
  period,
  onPeriodChange,
  metric,
  onMetricChange,
}: {
  count: number;
  period: LeaderboardPeriod;
  onPeriodChange: (p: LeaderboardPeriod) => void;
  metric: LeaderboardMetric;
  onMetricChange: (m: LeaderboardMetric) => void;
}) {
  return (
    <div
      className="relative overflow-hidden px-4 pb-5 pt-6"
      style={{ background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))" }}
    >
      <div
        className="pointer-events-none absolute -right-10 -top-14 h-44 w-44 rounded-full opacity-30 blur-2xl"
        style={{ background: "oklch(0.9 0.08 150)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-16 -left-12 h-44 w-44 rounded-full opacity-20 blur-2xl"
        style={{ background: "oklch(0.85 0.1 85)" }}
      />
      <div className="relative mx-auto max-w-[560px]">
        <div className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/25 backdrop-blur-sm">
            <Trophy className="h-5 w-5 text-white" strokeWidth={2} />
          </div>
          <div>
            <h1 className="text-[20px] font-bold text-white">Reyting</h1>
            {count > 0 && (
              <p className="flex items-center gap-1 text-[12px] text-white/75">
                <Users className="h-3 w-3" strokeWidth={2} />
                {count} ta ishtirokchi
              </p>
            )}
          </div>
        </div>

        {/* Reyting turi - ball yoki esselar soni bo'yicha */}
        <div className="mt-4">
          <MetricTabs metric={metric} onChange={onMetricChange} />
        </div>

        <div className="mt-2.5">
          <PeriodTabs period={period} onChange={onPeriodChange} />
        </div>
      </div>
    </div>
  );
}

function MetricTabs({
  metric,
  onChange,
}: {
  metric: LeaderboardMetric;
  onChange: (m: LeaderboardMetric) => void;
}) {
  const options: { key: LeaderboardMetric; icon: typeof Trophy; label: string }[] = [
    { key: "score", icon: Star, label: METRIC_LABELS.score },
    { key: "count", icon: FileText, label: METRIC_LABELS.count },
  ];
  return (
    <div className="flex gap-1.5 rounded-2xl bg-white/15 p-1.5 ring-1 ring-white/20 backdrop-blur-sm">
      {options.map(({ key, icon: Icon, label }) => {
        const active = key === metric;
        return (
          <button
            key={key}
            onClick={() => onChange(key)}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2.5 text-[13.5px] font-semibold transition-all"
            style={{
              backgroundColor: active ? "var(--card)" : "transparent",
              color: active ? "var(--primary)" : "rgba(255,255,255,0.9)",
              boxShadow: active ? "0 2px 8px oklch(0 0 0 / 0.15)" : "none",
            }}
          >
            <Icon
              className="h-4 w-4"
              strokeWidth={2.2}
              fill={active && key === "score" ? "var(--primary)" : "none"}
            />
            {label}
          </button>
        );
      })}
    </div>
  );
}

function PeriodTabs({
  period,
  onChange,
}: {
  period: LeaderboardPeriod;
  onChange: (p: LeaderboardPeriod) => void;
}) {
  return (
    <div className="flex gap-2 rounded-2xl bg-card p-1.5 shadow-elevated">
      {(Object.keys(PERIOD_LABELS) as LeaderboardPeriod[]).map((p) => (
        <button
          key={p}
          onClick={() => onChange(p)}
          className="flex-1 rounded-xl py-2 text-sm font-medium transition-colors"
          style={{
            backgroundColor: p === period ? "var(--primary)" : "transparent",
            color: p === period ? "var(--primary-foreground)" : "var(--muted-foreground)",
          }}
        >
          {PERIOD_LABELS[p]}
        </button>
      ))}
    </div>
  );
}

function Podium({
  entries,
  myId,
  metric,
}: {
  entries: LeaderboardEntry[];
  myId: number | undefined;
  metric: LeaderboardMetric;
}) {
  const [first, second, third] = entries;
  const order = [second, first, third].filter(Boolean) as LeaderboardEntry[];

  return (
    <div className="flex items-end justify-center gap-2.5">
      {order.map((entry) => (
        <PodiumSpot key={entry.rank} entry={entry} isMe={entry.userId === myId} metric={metric} />
      ))}
    </div>
  );
}

const PODIUM_STYLE: Record<
  number,
  { height: string; medalColor: string; ring: string; avatarRing: string }
> = {
  1: {
    height: "h-[140px]",
    medalColor: "#F5B700",
    ring: "var(--tone-ok)",
    avatarRing: "0 0 0 3px var(--card), 0 0 0 5px #F5B700",
  },
  2: {
    height: "h-[108px]",
    medalColor: "#AEB6C2",
    ring: "var(--muted-foreground)",
    avatarRing: "0 0 0 3px var(--card), 0 0 0 5px #AEB6C2",
  },
  3: {
    height: "h-[88px]",
    medalColor: "#C97C3D",
    ring: "var(--tone-weak)",
    avatarRing: "0 0 0 3px var(--card), 0 0 0 5px #C97C3D",
  },
};

function PodiumSpot({
  entry,
  isMe,
  metric,
}: {
  entry: LeaderboardEntry;
  isMe: boolean;
  metric: LeaderboardMetric;
}) {
  const style = PODIUM_STYLE[entry.rank];
  const isFirst = entry.rank === 1;
  const stat = statFor(entry, metric);

  return (
    <Link
      to="/essay/$id"
      params={{ id: String(entry.essayId) }}
      className={`flex w-[104px] flex-col items-center transition-transform active:scale-[0.97] ${isFirst ? "relative z-10" : ""}`}
    >
      {isFirst && (
        <Crown
          className="mb-1 h-5 w-5"
          style={{ color: style.medalColor }}
          strokeWidth={2}
          fill={style.medalColor}
        />
      )}
      <div
        className="flex shrink-0 items-center justify-center rounded-2xl text-lg font-bold text-white"
        style={{
          height: isFirst ? "3rem" : "2.75rem",
          width: isFirst ? "3rem" : "2.75rem",
          background: "linear-gradient(135deg, var(--primary), oklch(0.4 0.14 275))",
          boxShadow: isMe ? style.avatarRing : "0 0 0 3px var(--card)",
        }}
      >
        {entry.firstName?.[0]?.toUpperCase() ?? "?"}
      </div>
      <p className="mt-1.5 max-w-full truncate text-[12px] font-semibold text-foreground">
        {isMe ? "Siz" : entry.firstName}
      </p>
      <p className="flex items-baseline gap-0.5 text-[13px] font-bold tabular-nums text-primary">
        {stat.primary}
        <span className="text-[10px] font-semibold text-muted-foreground">{stat.primaryUnit}</span>
      </p>
      <p className="max-w-full truncate text-[10px] text-muted-foreground">{stat.secondary}</p>
      <div
        className={`mt-1.5 flex w-full flex-col items-center justify-start gap-1 rounded-t-2xl pt-2.5 ${style.height}`}
        style={{
          background: `linear-gradient(180deg, var(--primary-soft), transparent 140%)`,
        }}
      >
        <Medal className="h-6 w-6" style={{ color: style.medalColor }} strokeWidth={2} />
        <span className="text-[11px] font-bold text-muted-foreground">#{entry.rank}</span>
      </div>
    </Link>
  );
}

function LeaderboardRow({
  entry,
  metric,
  isMe,
  rowRef,
}: {
  entry: LeaderboardEntry;
  metric: LeaderboardMetric;
  isMe: boolean;
  rowRef?: RefObject<HTMLAnchorElement | null>;
}) {
  const tone = totalTone(entry.totalScore);
  const stat = statFor(entry, metric);
  const isCount = metric === "count";

  return (
    <Link
      to="/essay/$id"
      params={{ id: String(entry.essayId) }}
      ref={rowRef}
      className="flex items-center gap-3 rounded-2xl p-3.5 shadow-card transition-transform active:scale-[0.99]"
      style={{
        backgroundColor: isMe ? "var(--primary-soft)" : "var(--card)",
        border: isMe ? "1.5px solid var(--primary)" : "1.5px solid transparent",
      }}
    >
      <div
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold"
        style={{
          backgroundColor: isMe ? "var(--primary)" : "var(--muted)",
          color: isMe ? "var(--primary-foreground)" : "var(--muted-foreground)",
        }}
      >
        {entry.rank}
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium text-foreground">
          {isMe ? "Siz" : entry.firstName}
        </div>
        <div className="truncate text-[11.5px] text-muted-foreground">{stat.secondary}</div>
      </div>
      {isCount ? (
        <span
          className="flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold tabular-nums"
          style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
        >
          <FileText className="h-3 w-3" strokeWidth={2.2} />
          {entry.essayCount} ta
        </span>
      ) : (
        <span
          className="shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold tabular-nums"
          style={{
            backgroundColor: `var(--tone-${tone}-soft)`,
            color: `var(--tone-${tone})`,
          }}
        >
          {entry.scaledScore}/75
        </span>
      )}
    </Link>
  );
}

function MyRankBar({
  entry,
  metric,
  onClick,
}: {
  entry: LeaderboardEntry;
  metric: LeaderboardMetric;
  onClick: () => void;
}) {
  const tone = totalTone(entry.totalScore);
  const label =
    metric === "count"
      ? `${entry.essayCount} ta esse · eng yaxshi ${entry.scaledScore}`
      : `${entry.scaledScore}/75 ball`;

  return (
    <div
      className="fixed inset-x-0 z-20 mx-auto max-w-[560px] px-4"
      style={{ bottom: "calc(72px + env(safe-area-inset-bottom))" }}
    >
      <button
        type="button"
        onClick={onClick}
        className="flex w-full items-center gap-3 rounded-2xl p-3 shadow-elevated transition-transform active:scale-[0.98]"
        style={{
          backgroundColor: "var(--primary)",
          color: "var(--primary-foreground)",
        }}
      >
        <div
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold"
          style={{ backgroundColor: "oklch(1 0 0 / 0.18)" }}
        >
          {entry.rank}
        </div>
        <div className="min-w-0 flex-1 text-left">
          <p className="text-[11px] font-medium opacity-80">Sizning o'rningiz</p>
          <p className="truncate text-sm font-semibold">{label}</p>
        </div>
        <span
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full"
          style={{
            backgroundColor: `var(--tone-${tone}-soft)`,
            color: `var(--tone-${tone})`,
          }}
        >
          <ChevronUp className="h-4 w-4" strokeWidth={2.5} />
        </span>
      </button>
    </div>
  );
}

function EmptyState({ period }: { period: LeaderboardPeriod }) {
  return (
    <div className="mt-6 rounded-2xl bg-card p-8 text-center shadow-card">
      <div
        className="mx-auto flex h-14 w-14 items-center justify-center rounded-full"
        style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
      >
        <Trophy className="h-7 w-7" strokeWidth={1.8} />
      </div>
      <h3 className="mt-3 text-base font-semibold text-foreground">Hozircha reyting boʻsh</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        {PERIOD_LABELS[period]} davr ichida hech kim esse tekshirtirmagan.
      </p>
    </div>
  );
}

function ErrorState({
  title,
  description,
  onRetry,
}: {
  title: string;
  description: string;
  onRetry?: () => void;
}) {
  return (
    <div className="mt-6 rounded-2xl bg-card p-6 text-center shadow-card">
      <h3 className="text-base font-semibold text-foreground">{title}</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          Qayta urinish
        </button>
      )}
    </div>
  );
}
