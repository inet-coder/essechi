import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bot,
  Brain,
  Check,
  ChevronRight,
  CreditCard,
  FileText,
  Flame,
  Lock,
  type LucideIcon,
  Moon,
  Pencil,
  Sparkles,
  Star,
  Sun,
  Ticket,
  TrendingUp,
  Trophy,
  X,
} from "lucide-react";
import {
  api,
  type Me,
  type Essay,
  type MySummary,
  type AiAnalysisStatus,
  type QuizStatus,
  ApiError,
} from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { EssayCard } from "@/components/EssayCard";
import { Skeleton } from "@/components/Skeleton";
import { BottomNav } from "@/components/BottomNav";
import { useTheme, type Theme } from "@/hooks/useTheme";
import { formatDate, formatSum, scaledTone } from "@/lib/format";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [{ title: "Profil" }],
  }),
  component: () => (
    <TelegramGate>
      <ProfilePage />
    </TelegramGate>
  ),
});

function ProfilePage() {
  const { theme, toggleTheme } = useTheme();
  const meQ = useQuery<Me, ApiError>({ queryKey: ["me"], queryFn: api.me, retry: false });
  const historyQ = useQuery<Essay[], ApiError>({
    queryKey: ["history"],
    queryFn: api.history,
    retry: false,
  });
  const summaryQ = useQuery<MySummary, ApiError>({
    queryKey: ["summary"],
    queryFn: api.summary,
    retry: false,
  });

  const fatalError = meQ.error?.status === 0 || historyQ.error?.status === 0;

  return (
    <div className="min-h-screen bg-background pb-28">
      <Hero
        me={meQ.data}
        loading={meQ.isLoading}
        error={meQ.error ?? null}
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      <div className="mx-auto max-w-[560px] px-4 pt-5">
        {fatalError && (
          <ErrorState
            title="Internetni tekshiring"
            description="Maʼlumotlarni yuklab boʻlmadi."
            onRetry={() => {
              meQ.refetch();
              historyQ.refetch();
            }}
          />
        )}

        {!fatalError && historyQ.error?.status === 401 && (
          <ErrorState title="Sessiya tugagan" description="Iltimos, botni qayta oching." />
        )}

        {!fatalError && historyQ.error?.status !== 401 && (
          <>
            {/* Umumiy ko'rsatkichlar */}
            <OverallStats summary={summaryQ.data} loading={summaryQ.isLoading} />

            {/* Yutuqlar */}
            <Achievements summary={summaryQ.data} loading={summaryQ.isLoading} />

            {/* AI vositalar */}
            <section className="mt-8">
              <SectionTitle>AI vositalar</SectionTitle>
              <div className="mt-3 space-y-2.5">
                <AiAnalysisSection />
                <QuizSection />
              </div>
            </section>

            {/* Esselarim */}
            <section className="mt-8">
              <div className="mb-3 flex items-center justify-between px-1">
                <SectionTitle className="mb-0">Esselarim</SectionTitle>
                <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-bold tabular-nums text-muted-foreground ring-1 ring-black/[0.03]">
                  {historyQ.data?.length ?? 0} ta
                </span>
              </div>

              {historyQ.isLoading && (
                <div className="space-y-2.5">
                  {[0, 1, 2].map((i) => (
                    <Skeleton key={i} className="h-[92px] rounded-2xl" />
                  ))}
                </div>
              )}

              {historyQ.data?.length === 0 && <EmptyState />}

              {historyQ.data && historyQ.data.length > 0 && (
                <div className="space-y-2.5">
                  {historyQ.data.map((essay) => (
                    <EssayCard key={essay.id} essay={essay} />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>

      <BottomNav />
    </div>
  );
}

function SectionTitle({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <h2 className={`px-1 text-[17px] font-bold tracking-tight text-foreground ${className}`}>
      {children}
    </h2>
  );
}

/**
 * Zich nuqta-panjara naqshi — premium gradient fonlarga chuqurlik va
 * to'qima berish uchun, sof dekorativ qatlam.
 */
function DotGrid({ opacity = 0.14 }: { opacity?: number }) {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden
      style={{ opacity }}
    >
      <defs>
        <pattern id="profile-dot-grid" width="14" height="14" patternUnits="userSpaceOnUse">
          <circle cx="1.2" cy="1.2" r="1.2" fill="white" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#profile-dot-grid)" />
    </svg>
  );
}

/* ========================================================================= */

function Hero({
  me,
  loading,
  error,
  theme,
  onToggleTheme,
}: {
  me: Me | undefined;
  loading: boolean;
  error: ApiError | null;
  theme: Theme;
  onToggleTheme: () => void;
}) {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  function startEdit() {
    setName(me?.firstName ?? "");
    setSaveError(null);
    setEditing(true);
  }

  async function saveName() {
    const trimmed = name.trim();
    if (!trimmed) {
      setSaveError("Ism bo'sh bo'lishi mumkin emas");
      return;
    }
    setSaving(true);
    setSaveError(null);
    try {
      await api.updateProfile(trimmed);
      await queryClient.invalidateQueries({ queryKey: ["me"] });
      setEditing(false);
    } catch (e) {
      setSaveError(e instanceof ApiError ? e.message : "Xatolik yuz berdi");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      className="relative overflow-hidden px-4 pb-6 pt-6"
      style={{
        background:
          "radial-gradient(130% 160% at 0% 0%, oklch(0.5 0.15 285) 0%, var(--primary) 45%, oklch(0.36 0.13 272) 100%)",
      }}
    >
      <DotGrid opacity={0.08} />
      <div
        className="pointer-events-none absolute -right-10 -top-14 h-44 w-44 rounded-full opacity-30 blur-2xl"
        style={{ background: "oklch(0.9 0.08 150)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-16 -left-12 h-44 w-44 rounded-full opacity-20 blur-2xl"
        style={{ background: "oklch(0.85 0.1 85)" }}
      />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px"
        style={{
          background: "linear-gradient(90deg, transparent, oklch(1 0 0 / 0.35), transparent)",
        }}
      />

      <div className="relative mx-auto max-w-[560px]">
        <div className="flex items-center justify-between">
          <h1 className="text-[20px] font-bold tracking-tight text-white">Profil</h1>
          <button
            type="button"
            onClick={onToggleTheme}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/15 text-white ring-1 ring-white/25 backdrop-blur-sm transition-all duration-200 hover:bg-white/20 active:scale-90"
            aria-label={theme === "dark" ? "Yorug' mavzuga o'tish" : "Tungi mavzuga o'tish"}
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4" strokeWidth={2} />
            ) : (
              <Moon className="h-4 w-4" strokeWidth={2} />
            )}
          </button>
        </div>

        <div className="mt-5">
          {loading ? (
            <div className="flex items-center gap-4">
              <div className="h-14 w-14 animate-pulse rounded-2xl bg-white/20" />
              <div className="space-y-2">
                <div className="h-4 w-28 animate-pulse rounded bg-white/20" />
                <div className="h-3 w-20 animate-pulse rounded bg-white/15" />
              </div>
            </div>
          ) : error ? (
            <p className="text-sm text-white/80">Profil yuklanmadi.</p>
          ) : me ? (
            <div className="flex items-center gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/15 text-xl font-bold text-white ring-1 ring-white/25 shadow-inner backdrop-blur-sm">
                {me.firstName?.[0]?.toUpperCase() ?? "?"}
              </div>
              <div className="min-w-0 flex-1">
                {editing ? (
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center gap-1.5">
                      <input
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        maxLength={64}
                        autoFocus
                        disabled={saving}
                        placeholder="Ismingiz"
                        className="min-w-0 flex-1 rounded-lg border border-white/30 bg-white/15 px-2.5 py-1.5 text-[15px] font-semibold text-white placeholder:text-white/50 outline-none backdrop-blur-sm focus:border-white/60"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") saveName();
                          if (e.key === "Escape") setEditing(false);
                        }}
                      />
                      <button
                        type="button"
                        onClick={saveName}
                        disabled={saving}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/90 text-primary transition-all duration-200 hover:opacity-90 active:scale-90 disabled:opacity-50"
                        aria-label="Saqlash"
                      >
                        <Check className="h-4 w-4" strokeWidth={2.5} />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditing(false)}
                        disabled={saving}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/15 text-white ring-1 ring-white/25 transition-all duration-200 hover:opacity-90 active:scale-90 disabled:opacity-50"
                        aria-label="Bekor qilish"
                      >
                        <X className="h-4 w-4" strokeWidth={2.5} />
                      </button>
                    </div>
                    {saveError && <p className="text-[12px] text-white/90">{saveError}</p>}
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-1.5">
                      <h2 className="truncate text-[18px] font-bold tracking-tight text-white">
                        {me.firstName}
                      </h2>
                      <button
                        type="button"
                        onClick={startEdit}
                        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/15 text-white ring-1 ring-white/25 backdrop-blur-sm transition-all duration-200 hover:bg-white/20 active:scale-90"
                        aria-label="Ismni o'zgartirish"
                      >
                        <Pencil className="h-3.5 w-3.5" strokeWidth={2} />
                      </button>
                    </div>
                    {me.username && (
                      <p className="truncate text-[13px] text-white/65">@{me.username}</p>
                    )}
                  </>
                )}
              </div>
            </div>
          ) : null}
        </div>

        {me && (
          <div className="mt-5 flex items-stretch overflow-hidden rounded-2xl bg-white/10 ring-1 ring-white/15 backdrop-blur-sm">
            <HeroStat icon={CreditCard} value={formatSum(me.balance)} label="Balans (so'm)" />
            <span className="my-2.5 w-px shrink-0 bg-white/15" aria-hidden />
            <HeroStat icon={Ticket} value={`${me.essayCredits} ta`} label="Esse krediti (30 kun)" />
          </div>
        )}
      </div>
    </div>
  );
}

function HeroStat({
  icon: Icon,
  value,
  label,
}: {
  icon: LucideIcon;
  value: string;
  label: string;
}) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-1 px-3 py-3 text-center">
      <div className="flex items-center gap-1.5 text-[13.5px] font-bold tabular-nums text-white">
        <Icon className="h-3.5 w-3.5 shrink-0 text-white/75" strokeWidth={2} />
        <span className="truncate">{value}</span>
      </div>
      <div className="text-[10.5px] text-white/65">{label}</div>
    </div>
  );
}

/* ========================================================================= */

function OverallStats({ summary, loading }: { summary?: MySummary; loading: boolean }) {
  if (loading) {
    return <Skeleton className="mt-1 h-[150px] rounded-2xl" />;
  }
  if (!summary) return null;

  const best = summary.bestScaledScore;
  const avg = summary.averageScaledScore;

  return (
    <div className="overflow-hidden rounded-2xl bg-card shadow-card ring-1 ring-black/[0.03]">
      <div className="grid grid-cols-2">
        <StatCell label="Jami esse" value={`${summary.totalEssayCount}`} />
        <StatCell label="Baholangan" value={`${summary.checkedEssayCount}`} bordered />
        <StatCell
          label="Eng yaxshi"
          value={best !== null ? `${best}` : "—"}
          unit={best !== null ? "/75" : undefined}
          tone={best !== null ? scaledTone(best) : undefined}
          topBorder
        />
        <StatCell
          label="O'rtacha"
          value={avg !== null ? `${avg}` : "—"}
          unit={avg !== null ? "/75" : undefined}
          tone={avg !== null ? scaledTone(avg) : undefined}
          bordered
          topBorder
        />
      </div>
      <Link
        to="/stats"
        className="group flex items-center justify-between border-t border-border px-4 py-3 transition-colors hover:bg-muted/50"
      >
        <span className="flex items-center gap-2 text-[13px] font-semibold text-foreground">
          <TrendingUp className="h-4 w-4 text-primary" strokeWidth={2} />
          Batafsil statistika
        </span>
        <ChevronRight
          className="h-4 w-4 text-muted-foreground transition-transform duration-200 group-hover:translate-x-0.5"
          strokeWidth={2}
        />
      </Link>
    </div>
  );
}

function StatCell({
  label,
  value,
  unit,
  tone,
  bordered,
  topBorder,
}: {
  label: string;
  value: string;
  unit?: string;
  tone?: "excellent" | "good" | "ok" | "bad";
  bordered?: boolean;
  topBorder?: boolean;
}) {
  return (
    <div
      className="px-4 py-3.5"
      style={{
        borderLeft: bordered ? "1px solid var(--border)" : undefined,
        borderTop: topBorder ? "1px solid var(--border)" : undefined,
      }}
    >
      <p className="text-[11.5px] font-medium text-muted-foreground">{label}</p>
      <p className="mt-1 flex items-baseline gap-0.5">
        <span
          className="text-[24px] font-extrabold leading-none tracking-tight tabular-nums"
          style={{ color: tone ? `var(--tone-${tone})` : "var(--foreground)" }}
        >
          {value}
        </span>
        {unit && <span className="text-[12px] font-medium text-muted-foreground">{unit}</span>}
      </p>
    </div>
  );
}

/* ========================================================================= */

interface Achievement {
  id: string;
  title: string;
  desc: string;
  icon: LucideIcon;
  tone: "primary" | "excellent" | "good" | "ok" | "weak";
  unlocked: boolean;
}

function buildAchievements(summary: MySummary): Achievement[] {
  const total = summary.totalEssayCount;
  const best = summary.bestScaledScore ?? 0;
  const avg = summary.averageScaledScore ?? 0;

  return [
    {
      id: "first",
      title: "Ilk qadam",
      desc: "Birinchi esse yuborildi",
      icon: Sparkles,
      tone: "primary",
      unlocked: total >= 1,
    },
    {
      id: "five",
      title: "Izchillik",
      desc: total >= 5 ? "5 ta esse yozildi" : `${total}/5 esse`,
      icon: FileText,
      tone: "good",
      unlocked: total >= 5,
    },
    {
      id: "ten",
      title: "Marafon",
      desc: total >= 10 ? "10 ta esse yozildi" : `${total}/10 esse`,
      icon: Flame,
      tone: "weak",
      unlocked: total >= 10,
    },
    {
      id: "excellent",
      title: "A'lo baho",
      desc: best >= 59 ? "59+ ball olindi" : "75 ballik shkalada 59+",
      icon: Star,
      tone: "excellent",
      unlocked: best >= 59,
    },
    {
      id: "steady",
      title: "Barqaror",
      desc: avg >= 41 ? "O'rtacha 41+ ball" : "O'rtacha 41+ ball to'plang",
      icon: TrendingUp,
      tone: "ok",
      unlocked: avg >= 41,
    },
    {
      id: "champion",
      title: "Cho'qqi",
      desc: best >= 68 ? "68+ ball olindi" : "75 ballik shkalada 68+",
      icon: Trophy,
      tone: "primary",
      unlocked: best >= 68,
    },
  ];
}

function Achievements({ summary, loading }: { summary?: MySummary; loading: boolean }) {
  if (loading) {
    return (
      <section className="mt-8">
        <SectionTitle>Yutuqlar</SectionTitle>
        <div className="mt-3 grid grid-cols-2 gap-2.5">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-[92px] rounded-2xl" />
          ))}
        </div>
      </section>
    );
  }
  if (!summary) return null;

  const achievements = buildAchievements(summary);
  const unlockedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <section className="mt-8">
      <div className="mb-3 flex items-center justify-between px-1">
        <SectionTitle className="mb-0">Yutuqlar</SectionTitle>
        <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-bold tabular-nums text-muted-foreground ring-1 ring-black/[0.03]">
          {unlockedCount}/{achievements.length}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        {achievements.map((a) => (
          <AchievementTile key={a.id} achievement={a} />
        ))}
      </div>
    </section>
  );
}

function AchievementTile({ achievement: a }: { achievement: Achievement }) {
  const Icon = a.unlocked ? a.icon : Lock;
  return (
    <div
      className="relative overflow-hidden rounded-2xl border p-3.5 transition-transform duration-200"
      style={{
        backgroundColor: a.unlocked ? "var(--card)" : "var(--muted)",
        borderColor: a.unlocked ? `var(--tone-${a.tone}-soft)` : "transparent",
        boxShadow: a.unlocked ? "var(--shadow-card, 0 1px 2px rgba(0,0,0,0.04))" : "none",
        opacity: a.unlocked ? 1 : 0.65,
      }}
    >
      {a.unlocked && (
        <span
          className="pointer-events-none absolute -right-4 -top-4 h-16 w-16 rounded-full opacity-[0.12] blur-xl"
          style={{ background: `var(--tone-${a.tone})` }}
          aria-hidden
        />
      )}
      <span
        className="relative flex h-9 w-9 items-center justify-center rounded-xl ring-1 ring-black/[0.03]"
        style={{
          backgroundColor: a.unlocked ? `var(--tone-${a.tone}-soft)` : "var(--card)",
          color: a.unlocked ? `var(--tone-${a.tone})` : "var(--muted-foreground)",
        }}
      >
        <Icon className="h-[18px] w-[18px]" strokeWidth={2} />
      </span>
      <p className="relative mt-2.5 text-[13.5px] font-bold leading-tight tracking-tight text-foreground">
        {a.title}
      </p>
      <p className="relative mt-0.5 text-[11.5px] leading-tight text-muted-foreground">{a.desc}</p>
    </div>
  );
}

/* ========================================================================= */

function QuizSection() {
  const statusQ = useQuery<QuizStatus, ApiError>({
    queryKey: ["quiz-status"],
    queryFn: api.quizStatus,
    retry: false,
  });

  return (
    <Link
      to="/quiz"
      className="group flex items-center gap-3 rounded-2xl bg-card p-4 shadow-card ring-1 ring-black/[0.03] transition-all duration-200 active:scale-[0.99]"
    >
      <div
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ring-1 ring-black/[0.02] transition-transform duration-200 group-active:scale-90"
        style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
      >
        <Brain className="h-5 w-5" strokeWidth={2} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold tracking-tight text-foreground">AI viktorina</p>
        <p className="mt-0.5 truncate text-xs text-muted-foreground">
          {statusQ.data?.lastQuiz?.completedAt
            ? `So'nggi natija: ${statusQ.data.lastQuiz.score}/${statusQ.data.lastQuiz.questions.length}`
            : "10 ta savol bilan bilimingizni sinang"}
        </p>
      </div>
      <ChevronRight
        className="h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 group-hover:translate-x-0.5"
        strokeWidth={2}
      />
    </Link>
  );
}

function AiAnalysisSection() {
  const statusQ = useQuery<AiAnalysisStatus, ApiError>({
    queryKey: ["ai-analysis-status"],
    queryFn: api.aiAnalysisStatus,
    retry: false,
  });

  return (
    <Link
      to="/analysis"
      className="group flex items-center gap-3 rounded-2xl bg-card p-4 shadow-card ring-1 ring-black/[0.03] transition-all duration-200 active:scale-[0.99]"
    >
      <div
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ring-1 ring-black/[0.02] transition-transform duration-200 group-active:scale-90"
        style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
      >
        <Bot className="h-5 w-5" strokeWidth={2} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold tracking-tight text-foreground">AI xato tahlili</p>
        <p className="mt-0.5 truncate text-xs text-muted-foreground">
          {statusQ.data?.lastAnalysis
            ? `So'nggi tahlil: ${formatDate(statusQ.data.lastAnalysis.createdAt)}`
            : "Takrorlanuvchi xatolar va aniq tavsiyalar"}
        </p>
      </div>
      <ChevronRight
        className="h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 group-hover:translate-x-0.5"
        strokeWidth={2}
      />
    </Link>
  );
}

/* ========================================================================= */

function EmptyState() {
  return (
    <div className="mt-2 rounded-2xl border border-dashed border-border bg-card p-8 text-center">
      <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground ring-1 ring-black/[0.03]">
        <FileText className="h-6 w-6" strokeWidth={2} />
      </div>
      <h3 className="text-sm font-semibold tracking-tight text-foreground">
        Hali esse yubormadingiz
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">Botda "Esse yuborish" tugmasini bosing</p>
    </div>
  );
}

function ErrorState({
  title,
  description,
  onRetry,
}: {
  title: string;
  description: string;
  onRetry?: () => void;
}) {
  return (
    <div
      className="rounded-2xl p-6 text-center ring-1 ring-black/[0.03]"
      style={{ backgroundColor: "var(--tone-bad-soft)" }}
    >
      <h3 className="text-sm font-semibold" style={{ color: "var(--tone-bad)" }}>
        {title}
      </h3>
      <p className="mt-1 text-xs" style={{ color: "var(--tone-bad)", opacity: 0.85 }}>
        {description}
      </p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 rounded-xl px-4 py-2 text-xs font-semibold text-primary-foreground shadow-sm transition-transform duration-200 active:scale-95"
          style={{ backgroundColor: "var(--tone-bad)" }}
        >
          Qayta urinish
        </button>
      )}
    </div>
  );
}
