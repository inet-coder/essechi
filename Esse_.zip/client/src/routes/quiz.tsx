import { useState } from "react";
import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient, type UseQueryResult } from "@tanstack/react-query";
import {
  Brain,
  Check,
  ChevronLeft,
  CreditCard,
  History,
  Layers,
  Lightbulb,
  Minus,
  Plus,
  RotateCcw,
  Shuffle,
  WifiOff,
  X,
} from "lucide-react";
import { api, type QuizAnswer, type QuizRecord, type QuizStatus, ApiError } from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { Skeleton } from "@/components/Skeleton";
import { formatDate, formatSum } from "@/lib/format";

export const Route = createFileRoute("/quiz")({
  head: () => ({
    meta: [{ title: "AI Viktorina" }],
  }),
  component: () => (
    <TelegramGate>
      <QuizPage />
    </TelegramGate>
  ),
});

type Phase = "intro" | "playing" | "result" | "review";

function QuizPage() {
  const router = useRouter();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [phase, setPhase] = useState<Phase>("intro");
  const [activeQuiz, setActiveQuiz] = useState<QuizRecord | null>(null);
  const [reviewQuiz, setReviewQuiz] = useState<QuizRecord | null>(null);
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<QuizAnswer[]>([]);
  const [selected, setSelected] = useState<number | null>(null);

  const statusQ = useQuery<QuizStatus, ApiError>({
    queryKey: ["quiz-status"],
    queryFn: api.quizStatus,
    retry: false,
  });

  const historyQ = useQuery<QuizRecord[], ApiError>({
    queryKey: ["quiz-history"],
    queryFn: api.quizHistory,
    retry: false,
  });

  // Barcha rejimlar (AI, tasodifiy, qayta ishlash, davom ettirish) uchun umumiy
  // boshlash: berilgan viktorinani o'ynash bosqichiga o'tkazadi.
  const beginQuiz = (quiz: QuizRecord) => {
    setActiveQuiz(quiz);
    setIndex(0);
    setAnswers([]);
    setSelected(null);
    setPhase("playing");
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        onBack={() => {
          if (phase === "review") {
            setPhase("intro");
            return;
          }
          router.history.length > 1 ? router.history.back() : navigate({ to: "/stats" });
        }}
        showProgress={phase === "playing"}
        current={index + 1}
        total={activeQuiz?.questions.length ?? 0}
      />

      <div className="mx-auto max-w-[560px] px-4 pb-12 pt-4">
        {phase === "intro" && (
          <IntroScreen
            statusQ={statusQ}
            history={historyQ.data ?? []}
            onReview={(quiz) => {
              setReviewQuiz(quiz);
              setPhase("review");
            }}
            onStart={async () => beginQuiz(await api.generateQuiz())}
            onStartRandom={async (count) => beginQuiz(await api.randomQuiz(count))}
            onRetake={async (quizId) => beginQuiz(await api.retakeQuiz(quizId))}
            onResume={(quiz) => beginQuiz(quiz)}
          />
        )}

        {phase === "playing" && activeQuiz && (
          <QuestionScreen
            quiz={activeQuiz}
            index={index}
            selected={selected}
            onSelect={setSelected}
            onNext={async () => {
              if (selected === null) return;
              const question = activeQuiz.questions[index];
              const nextAnswers = [
                ...answers,
                { questionId: question.id, selectedIndex: selected },
              ];

              if (index + 1 < activeQuiz.questions.length) {
                setAnswers(nextAnswers);
                setIndex(index + 1);
                setSelected(null);
              } else {
                const result = await api.submitQuiz(activeQuiz.id, nextAnswers);
                setActiveQuiz(result);
                queryClient.invalidateQueries({ queryKey: ["quiz-status"] });
                queryClient.invalidateQueries({ queryKey: ["quiz-history"] });
                setPhase("result");
              }
            }}
          />
        )}

        {phase === "result" && activeQuiz && (
          <ResultScreen
            quiz={activeQuiz}
            onRestart={() => {
              setPhase("intro");
              setActiveQuiz(null);
              statusQ.refetch();
            }}
            onFinish={() => navigate({ to: "/stats" })}
          />
        )}

        {phase === "review" && reviewQuiz && (
          <ReviewScreen quiz={reviewQuiz} onBack={() => setPhase("intro")} />
        )}
      </div>
    </div>
  );
}

function Header({
  onBack,
  showProgress,
  current,
  total,
}: {
  onBack: () => void;
  showProgress: boolean;
  current: number;
  total: number;
}) {
  return (
    <div className="sticky top-0 z-10 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-[560px] items-center gap-3 px-4 py-3">
        <button
          type="button"
          onClick={onBack}
          className="-ml-2 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-foreground transition-colors hover:bg-muted"
          aria-label="Orqaga"
        >
          <ChevronLeft className="h-5 w-5" strokeWidth={2} />
        </button>
        <h1 className="flex items-center gap-1.5 text-[15px] font-semibold text-foreground">
          <Brain className="h-4 w-4" strokeWidth={2} />
          AI Viktorina
        </h1>
        {showProgress && total > 0 && (
          <span className="ml-auto text-xs font-medium tabular-nums text-muted-foreground">
            {current}/{total}
          </span>
        )}
      </div>
      {showProgress && total > 0 && (
        <div className="h-1 w-full bg-muted">
          <div
            className="h-full bg-primary transition-[width] duration-300"
            style={{ width: `${(current / total) * 100}%` }}
          />
        </div>
      )}
    </div>
  );
}

function IntroScreen({
  statusQ,
  history,
  onStart,
  onStartRandom,
  onRetake,
  onResume,
  onReview,
}: {
  statusQ: UseQueryResult<QuizStatus, ApiError>;
  history: QuizRecord[];
  onStart: () => Promise<void>;
  onStartRandom: (count: number) => Promise<void>;
  onRetake: (quizId: number) => Promise<void>;
  onResume: (quiz: QuizRecord) => void;
  onReview: (quiz: QuizRecord) => void;
}) {
  const [starting, setStarting] = useState(false);
  const [randomBusy, setRandomBusy] = useState(false);
  const [retakeBusyId, setRetakeBusyId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (statusQ.isLoading) {
    return (
      <div className="space-y-3 pt-2">
        <Skeleton className="h-40 rounded-2xl" />
        <Skeleton className="h-12 rounded-xl" />
      </div>
    );
  }

  if (statusQ.error) {
    return (
      <div className="mt-6 rounded-2xl bg-card p-6 text-center shadow-card">
        <WifiOff className="mx-auto h-8 w-8 text-muted-foreground" strokeWidth={1.5} />
        <h3 className="mt-3 text-base font-semibold text-foreground">Yuklab bo'lmadi</h3>
        <p className="mt-1.5 text-sm text-muted-foreground">
          Internetni tekshirib, qayta urinib ko'ring.
        </p>
        <button
          onClick={() => statusQ.refetch()}
          className="mt-4 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          Qayta urinish
        </button>
      </div>
    );
  }

  const status = statusQ.data;
  if (!status) return null;

  const resumable = status.lastQuiz && !status.lastQuiz.completedAt ? status.lastQuiz : null;

  async function handleStart() {
    setError(null);
    setStarting(true);
    try {
      await onStart();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Xatolik yuz berdi. Qayta urinib ko'ring.");
    } finally {
      setStarting(false);
    }
  }

  async function handleRandom(count: number) {
    setError(null);
    setRandomBusy(true);
    try {
      await onStartRandom(count);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Xatolik yuz berdi. Qayta urinib ko'ring.");
    } finally {
      setRandomBusy(false);
    }
  }

  async function handleRetake(quizId: number) {
    setError(null);
    setRetakeBusyId(quizId);
    try {
      await onRetake(quizId);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Xatolik yuz berdi. Qayta urinib ko'ring.");
    } finally {
      setRetakeBusyId(null);
    }
  }

  return (
    <div className="space-y-4 pt-2">
      <div className="rounded-2xl bg-card p-6 text-center shadow-card">
        <div
          className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl"
          style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
        >
          <Brain className="h-8 w-8" strokeWidth={1.8} />
        </div>
        <h2 className="mt-4 text-lg font-bold text-foreground">
          Zaif tomonlaringizni mustahkamlang
        </h2>
        <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
          AI sizning esselaringizdagi eng past ball olgan mezonlar asosida 10 ta savol tuzadi. Har
          javobdan keyin darhol tushuntirish olasiz.
        </p>

        {resumable && (
          <button
            type="button"
            onClick={() => onResume(resumable)}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            <RotateCcw className="h-4 w-4" strokeWidth={2} />
            Boshlangan viktorinani davom ettirish
          </button>
        )}

        {!resumable && (
          <button
            type="button"
            onClick={handleStart}
            disabled={starting}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
            style={{ backgroundColor: "var(--primary)" }}
          >
            {starting ? (
              "Savollar tuzilmoqda..."
            ) : (
              <>
                <CreditCard className="h-4 w-4" strokeWidth={2} />
                {formatSum(status.price)} evaziga boshlash
              </>
            )}
          </button>
        )}

        {!resumable && (
          <p className="mt-2.5 text-xs text-muted-foreground">
            Narxi {formatSum(status.price)}. Balansingiz:{" "}
            {formatSum(status.balance)}.
            {status.balance < status.price &&
              " Balans yetarli emas — botdagi \"💰 Balansni to'ldirish\" bo'limidan to'ldiring."}
          </p>
        )}
      </div>

      <RandomPracticeCard random={status.random} busy={randomBusy} onStart={handleRandom} />

      {error && (
        <p className="text-center text-xs font-medium" style={{ color: "var(--tone-bad)" }}>
          {error}
        </p>
      )}

      {history.length > 0 && (
        <div>
          <h3 className="flex items-center gap-1.5 px-1 pb-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            <History className="h-4 w-4" strokeWidth={2} />
            Oldingi viktorinalar
          </h3>
          <div className="space-y-2">
            {history.map((quiz) => {
              const pct =
                quiz.questions.length > 0
                  ? Math.round(((quiz.score ?? 0) / quiz.questions.length) * 100)
                  : 0;
              const tone = pct >= 80 ? "excellent" : pct >= 60 ? "good" : pct >= 40 ? "ok" : "weak";
              return (
                <div
                  key={quiz.id}
                  className="flex items-center gap-2 rounded-2xl bg-card p-3 pl-4 shadow-card"
                >
                  <button
                    type="button"
                    onClick={() => onReview(quiz)}
                    className="flex min-w-0 flex-1 items-center gap-3 text-left transition-transform active:scale-[0.99]"
                  >
                    <div
                      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[13px] font-bold tabular-nums"
                      style={{
                        backgroundColor: `var(--tone-${tone}-soft)`,
                        color: `var(--tone-${tone})`,
                      }}
                    >
                      {quiz.score}/{quiz.questions.length}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-foreground">
                        {quiz.score}/{quiz.questions.length} to'g'ri javob
                      </p>
                      <p className="text-xs text-muted-foreground">{formatDate(quiz.createdAt)}</p>
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRetake(quiz.id)}
                    disabled={retakeBusyId === quiz.id}
                    className="flex h-9 shrink-0 items-center gap-1.5 rounded-xl px-3 text-xs font-semibold transition-opacity hover:opacity-90 disabled:opacity-50"
                    style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
                  >
                    <RotateCcw
                      className={`h-3.5 w-3.5 ${retakeBusyId === quiz.id ? "animate-spin" : ""}`}
                      strokeWidth={2.2}
                    />
                    Qayta
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function RandomPracticeCard({
  random,
  busy,
  onStart,
}: {
  random: QuizStatus["random"];
  busy: boolean;
  onStart: (count: number) => void;
}) {
  const { available, poolSize, min, max } = random;
  const [count, setCount] = useState(min);

  // 10 tadan kam savol bo'lsa - yumshoq eslatma (rejim hali ochilmaydi).
  if (!available) {
    return (
      <div className="rounded-2xl bg-card p-5 shadow-card">
        <div className="flex items-center gap-3">
          <div
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
            style={{ backgroundColor: "var(--tone-good-soft)", color: "var(--tone-good)" }}
          >
            <Shuffle className="h-5 w-5" strokeWidth={1.8} />
          </div>
          <div className="min-w-0">
            <h3 className="text-[15px] font-bold text-foreground">Tasodifiy mashq</h3>
            <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
              Kamida {min} ta savol to'planganda ochiladi. Hozircha {poolSize} ta bor — avval AI
              viktorina tuzing.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const clamp = (n: number) => Math.max(min, Math.min(n, max));
  const presets = Array.from(new Set([min, 20, 30, max].filter((p) => p >= min && p <= max))).sort(
    (a, b) => a - b,
  );

  return (
    <div className="rounded-2xl bg-card p-5 shadow-card">
      <div className="flex items-center gap-3">
        <div
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
          style={{ backgroundColor: "var(--tone-good-soft)", color: "var(--tone-good)" }}
        >
          <Shuffle className="h-5 w-5" strokeWidth={1.8} />
        </div>
        <div className="min-w-0">
          <h3 className="text-[15px] font-bold text-foreground">Tasodifiy mashq</h3>
          <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
            Tuzilgan barcha savollardan tasodifiy test. Bepul.
          </p>
        </div>
      </div>

      {/* Son tanlagich: min..max oralig'ida (5 talik qadam) */}
      <div className="mt-4 flex items-center justify-between rounded-xl bg-muted p-2">
        <button
          type="button"
          onClick={() => setCount((c) => clamp(c - 5))}
          disabled={count <= min}
          className="flex h-10 w-10 items-center justify-center rounded-lg bg-card text-foreground shadow-sm transition-opacity hover:opacity-90 disabled:opacity-40"
          aria-label="Kamaytirish"
        >
          <Minus className="h-4 w-4" strokeWidth={2.5} />
        </button>
        <div className="flex flex-col items-center">
          <span className="text-2xl font-bold tabular-nums text-foreground">{count}</span>
          <span className="text-[11px] text-muted-foreground">ta savol</span>
        </div>
        <button
          type="button"
          onClick={() => setCount((c) => clamp(c + 5))}
          disabled={count >= max}
          className="flex h-10 w-10 items-center justify-center rounded-lg bg-card text-foreground shadow-sm transition-opacity hover:opacity-90 disabled:opacity-40"
          aria-label="Ko'paytirish"
        >
          <Plus className="h-4 w-4" strokeWidth={2.5} />
        </button>
      </div>

      {/* Tez tanlash chiplari */}
      <div className="mt-2 flex flex-wrap gap-1.5">
        {presets.map((p) => {
          const activeChip = p === count;
          return (
            <button
              key={p}
              type="button"
              onClick={() => setCount(p)}
              className="rounded-full px-3 py-1 text-xs font-semibold transition-colors"
              style={{
                backgroundColor: activeChip ? "var(--tone-good)" : "var(--muted)",
                color: activeChip ? "white" : "var(--muted-foreground)",
              }}
            >
              {p === max ? `Hammasi (${max})` : p}
            </button>
          );
        })}
      </div>

      <button
        type="button"
        onClick={() => onStart(count)}
        disabled={busy}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
        style={{ backgroundColor: "var(--tone-good)" }}
      >
        {busy ? (
          "Tayyorlanmoqda..."
        ) : (
          <>
            <Shuffle className="h-4 w-4" strokeWidth={2} />
            {count} ta savol bilan boshlash
          </>
        )}
      </button>

      <p className="mt-2 flex items-center justify-center gap-1 text-[11px] text-muted-foreground">
        <Layers className="h-3 w-3" strokeWidth={2} />
        Hovuzda jami {poolSize} ta noyob savol
      </p>
    </div>
  );
}

function QuestionScreen({
  quiz,
  index,
  selected,
  onSelect,
  onNext,
}: {
  quiz: QuizRecord;
  index: number;
  selected: number | null;
  onSelect: (i: number) => void;
  onNext: () => void;
}) {
  const question = quiz.questions[index];
  const isLast = index + 1 === quiz.questions.length;
  const revealed = selected !== null;
  const isCorrect = selected === question.correctIndex;

  return (
    <div className="space-y-4 pt-2">
      <span
        className="inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold"
        style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
      >
        {question.criterionName}
      </span>

      <h2 className="text-[17px] font-bold leading-snug text-foreground">{question.question}</h2>

      <div className="space-y-2">
        {question.options.map((option, i) => {
          const isSelected = selected === i;
          const isRightAnswer = i === question.correctIndex;

          let borderColor = "var(--border)";
          let bg = "var(--card)";
          if (revealed && isRightAnswer) {
            borderColor = "var(--tone-excellent)";
            bg = "var(--tone-excellent-soft)";
          } else if (revealed && isSelected && !isCorrect) {
            borderColor = "var(--tone-bad)";
            bg = "var(--tone-bad-soft)";
          } else if (isSelected) {
            borderColor = "var(--primary)";
          }

          return (
            <button
              key={i}
              type="button"
              disabled={revealed}
              onClick={() => onSelect(i)}
              className="flex w-full items-center gap-2.5 rounded-2xl border-[1.5px] p-3.5 text-left text-sm font-medium text-foreground shadow-card transition-transform active:scale-[0.99] disabled:active:scale-100"
              style={{ borderColor, backgroundColor: bg }}
            >
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold"
                style={{
                  backgroundColor:
                    revealed && isRightAnswer
                      ? "var(--tone-excellent)"
                      : revealed && isSelected && !isCorrect
                        ? "var(--tone-bad)"
                        : "var(--muted)",
                  color:
                    revealed && (isRightAnswer || (isSelected && !isCorrect))
                      ? "white"
                      : "var(--muted-foreground)",
                }}
              >
                {revealed && isRightAnswer ? (
                  <Check className="h-3.5 w-3.5" strokeWidth={2.5} />
                ) : revealed && isSelected && !isCorrect ? (
                  <X className="h-3.5 w-3.5" strokeWidth={2.5} />
                ) : (
                  String.fromCharCode(65 + i)
                )}
              </span>
              {option}
            </button>
          );
        })}
      </div>

      {revealed && (
        <div
          className="flex items-start gap-2.5 rounded-2xl p-4"
          style={{
            backgroundColor: isCorrect ? "var(--tone-excellent-soft)" : "var(--tone-bad-soft)",
          }}
        >
          <Lightbulb
            className="mt-0.5 h-4 w-4 shrink-0"
            style={{ color: isCorrect ? "var(--tone-excellent)" : "var(--tone-bad)" }}
            strokeWidth={2}
          />
          <p
            className="text-[13px] leading-relaxed"
            style={{ color: isCorrect ? "var(--tone-excellent)" : "var(--tone-bad)" }}
          >
            {question.explanation}
          </p>
        </div>
      )}

      {revealed && (
        <button
          type="button"
          onClick={onNext}
          className="flex w-full items-center justify-center rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
        >
          {isLast ? "Yakunlash" : "Keyingi savol"}
        </button>
      )}
    </div>
  );
}

function ResultScreen({
  quiz,
  onRestart,
  onFinish,
}: {
  quiz: QuizRecord;
  onRestart: () => void;
  onFinish: () => void;
}) {
  const total = quiz.questions.length;
  const score = quiz.score ?? 0;
  const pct = total > 0 ? Math.round((score / total) * 100) : 0;

  const tone = pct >= 80 ? "excellent" : pct >= 60 ? "good" : pct >= 40 ? "ok" : "weak";
  const label =
    pct >= 80
      ? "Ajoyib natija!"
      : pct >= 60
        ? "Yaxshi natija!"
        : pct >= 40
          ? "Yomon emas"
          : "Mashq qiling";

  return (
    <div className="space-y-3 pt-2 text-center">
      <div className="rounded-2xl bg-card p-8 shadow-card">
        <div
          className="mx-auto flex h-20 w-20 items-center justify-center rounded-full text-2xl font-bold"
          style={{ backgroundColor: `var(--tone-${tone}-soft)`, color: `var(--tone-${tone})` }}
        >
          {score}/{total}
        </div>
        <h2 className="mt-4 text-lg font-bold text-foreground">{label}</h2>
        <p className="mt-1.5 text-sm text-muted-foreground">
          {total} tadan {score} tasiga to'g'ri javob berdingiz.
        </p>
      </div>

      <button
        type="button"
        onClick={onFinish}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
      >
        Statistikaga qaytish
      </button>
      <button
        type="button"
        onClick={onRestart}
        className="flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted"
      >
        Boshqa savollarni ko'rish
      </button>
    </div>
  );
}

function ReviewScreen({ quiz, onBack }: { quiz: QuizRecord; onBack: () => void }) {
  const answerFor = (questionId: number) =>
    quiz.answers?.find((a) => a.questionId === questionId)?.selectedIndex ?? null;

  return (
    <div className="space-y-4 pt-2">
      <div className="rounded-2xl bg-card p-5 text-center shadow-card">
        <p className="text-sm text-muted-foreground">Natija</p>
        <p className="mt-1 text-2xl font-bold text-foreground">
          {quiz.score}/{quiz.questions.length}
        </p>
        <p className="mt-0.5 text-xs text-muted-foreground">{formatDate(quiz.createdAt)}</p>
      </div>

      {quiz.questions.map((question, qi) => {
        const userIndex = answerFor(question.id);
        const userCorrect = userIndex === question.correctIndex;

        return (
          <div key={question.id} className="space-y-3 rounded-2xl bg-card p-4 shadow-card">
            <div className="flex items-center gap-2">
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold"
                style={{ backgroundColor: "var(--muted)", color: "var(--muted-foreground)" }}
              >
                {qi + 1}
              </span>
              <span
                className="inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold"
                style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
              >
                {question.criterionName}
              </span>
            </div>

            <h3 className="text-[15px] font-bold leading-snug text-foreground">
              {question.question}
            </h3>

            <div className="space-y-2">
              {question.options.map((option, i) => {
                const isRight = i === question.correctIndex;
                const isUser = i === userIndex;

                let borderColor = "var(--border)";
                let bg = "var(--card)";
                if (isRight) {
                  borderColor = "var(--tone-excellent)";
                  bg = "var(--tone-excellent-soft)";
                } else if (isUser && !userCorrect) {
                  borderColor = "var(--tone-bad)";
                  bg = "var(--tone-bad-soft)";
                }

                return (
                  <div
                    key={i}
                    className="flex items-center gap-2.5 rounded-2xl border-[1.5px] p-3 text-sm font-medium text-foreground"
                    style={{ borderColor, backgroundColor: bg }}
                  >
                    <span
                      className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold"
                      style={{
                        backgroundColor: isRight
                          ? "var(--tone-excellent)"
                          : isUser && !userCorrect
                            ? "var(--tone-bad)"
                            : "var(--muted)",
                        color:
                          isRight || (isUser && !userCorrect) ? "white" : "var(--muted-foreground)",
                      }}
                    >
                      {isRight ? (
                        <Check className="h-3.5 w-3.5" strokeWidth={2.5} />
                      ) : isUser ? (
                        <X className="h-3.5 w-3.5" strokeWidth={2.5} />
                      ) : (
                        String.fromCharCode(65 + i)
                      )}
                    </span>
                    {option}
                  </div>
                );
              })}
            </div>

            <div
              className="flex items-start gap-2.5 rounded-2xl p-4"
              style={{ backgroundColor: "var(--tone-excellent-soft)" }}
            >
              <Lightbulb
                className="mt-0.5 h-4 w-4 shrink-0"
                style={{ color: "var(--tone-excellent)" }}
                strokeWidth={2}
              />
              <p className="text-[13px] leading-relaxed" style={{ color: "var(--tone-excellent)" }}>
                {question.explanation}
              </p>
            </div>
          </div>
        );
      })}

      <button
        type="button"
        onClick={onBack}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
      >
        Ro'yxatga qaytish
      </button>
    </div>
  );
}
