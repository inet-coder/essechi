import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart3,
  Dumbbell,
  FileCheck2,
  Lightbulb,
  type LucideIcon,
  Target,
  Trophy,
} from "lucide-react";
import { api, type MyStats, type MySummary, ApiError } from "@/lib/api";
import { TelegramGate } from "@/components/TelegramGate";
import { Skeleton } from "@/components/Skeleton";
import { ProgressRing } from "@/components/ProgressRing";
import { scoreTone, scaledTone } from "@/lib/format";

export const Route = createFileRoute("/stats")({
  head: () => ({
    meta: [
      { title: "Mezon boʻyicha statistika" },
      {
        name: "description",
        content: "Esselaringiz boʻyicha kuchli va zaif tomonlaringiz tahlili.",
      },
    ],
  }),
  component: () => (
    <TelegramGate>
      <StatsPage />
    </TelegramGate>
  ),
});

function StatsPage() {
  const statsQ = useQuery<MyStats, ApiError>({
    queryKey: ["stats"],
    queryFn: api.stats,
    retry: false,
  });
  const summaryQ = useQuery<MySummary, ApiError>({
    queryKey: ["summary"],
    queryFn: api.summary,
    retry: false,
  });

  const isLoading = statsQ.isLoading || summaryQ.isLoading;
  const fatalError = statsQ.error?.status === 0 || summaryQ.error?.status === 0;
  const authError = statsQ.error?.status === 401 || summaryQ.error?.status === 401;

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-[560px] px-4 pb-10">
        <Header />

        {isLoading && (
          <div className="mt-4 space-y-3">
            <Skeleton className="h-[220px] rounded-2xl" />
            <Skeleton className="h-[90px] rounded-2xl" />
            <Skeleton className="h-[72px] rounded-2xl" />
            <Skeleton className="h-[72px] rounded-2xl" />
          </div>
        )}

        {!isLoading && fatalError && (
          <ErrorState
            title="Internetni tekshiring"
            description="Maʼlumotlarni yuklab boʻlmadi."
            onRetry={() => {
              statsQ.refetch();
              summaryQ.refetch();
            }}
          />
        )}

        {!isLoading && !fatalError && authError && (
          <ErrorState title="Sessiya muddati tugagan" description="Iltimos, botni qayta oching." />
        )}

        {!isLoading && !fatalError && !authError && statsQ.data?.essayCount === 0 && <EmptyState />}

        {!isLoading &&
          !fatalError &&
          !authError &&
          statsQ.data &&
          summaryQ.data &&
          statsQ.data.essayCount > 0 && (
            <StatsContent stats={statsQ.data} summary={summaryQ.data} />
          )}
      </div>
    </div>
  );
}

function StatsContent({ stats, summary }: { stats: MyStats; summary: MySummary }) {
  const weakest = stats.bands[0];
  const strongest = stats.bands[stats.bands.length - 1];
  const avg = summary.averageScaledScore ?? 0;

  return (
    <div className="mt-4 space-y-4">
      {/* Hero: overall average ring */}
      <div className="flex flex-col items-center rounded-2xl bg-card p-6 shadow-card">
        <ProgressRing
          value={avg}
          max={75}
          tone={scaledTone(avg)}
          centerLabel={`${avg}`}
          subLabel="/ 75 o'rtacha"
        />
        <p className="mt-3 text-sm text-muted-foreground">
          {stats.essayCount} ta tekshirilgan esse asosida
        </p>
      </div>

      {/* Quick stat chips */}
      <div className="grid grid-cols-2 gap-3">
        <StatChip
          icon={Trophy}
          label="Eng yaxshi natija"
          value={summary.bestScaledScore !== null ? `${summary.bestScaledScore}/75` : "—"}
        />
        <StatChip
          icon={FileCheck2}
          label="Tekshirilgan esselar"
          value={`${summary.checkedEssayCount}/${summary.totalEssayCount}`}
        />
      </div>

      {/* Strongest / weakest skill */}
      {weakest && strongest && (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <SkillHighlightCard
            icon={Target}
            label="Rivojlantirish kerak"
            criterionName={weakest.criterionName}
            score={weakest.averageScore}
            tone={scoreTone(weakest.averageScore)}
          />
          <SkillHighlightCard
            icon={Dumbbell}
            label="Kuchli tomoningiz"
            criterionName={strongest.criterionName}
            score={strongest.averageScore}
            tone={scoreTone(strongest.averageScore)}
          />
        </div>
      )}

      {/* Insight */}
      <InsightCard summary={summary} weakest={weakest} />

      {/* Full skill breakdown */}
      <div>
        <h3 className="px-1 pb-2 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          Barcha mezonlar
        </h3>
        <div className="space-y-2.5">
          {stats.bands.map((band) => (
            <BandBar key={band.band} band={band} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="sticky top-0 z-10 -mx-4 flex items-center gap-3 bg-background/80 px-4 pb-3 pt-4 backdrop-blur-md">
      <Link
        to="/"
        className="flex h-9 w-9 items-center justify-center rounded-full bg-card text-foreground shadow-card transition-opacity hover:opacity-80"
        aria-label="Orqaga"
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className="h-4 w-4"
        >
          <path d="M15 18l-6-6 6-6" />
        </svg>
      </Link>
      <h1 className="flex items-center gap-1.5 text-lg font-semibold text-foreground">
        <BarChart3 className="h-4.5 w-4.5" strokeWidth={2} />
        Statistika
      </h1>
    </div>
  );
}

function StatChip({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <Icon className="h-5 w-5 text-primary" strokeWidth={2} />
      <div className="mt-1.5 text-lg font-bold tabular-nums text-foreground">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}

function SkillHighlightCard({
  icon: Icon,
  label,
  criterionName,
  score,
  tone,
}: {
  icon: LucideIcon;
  label: string;
  criterionName: string;
  score: number;
  tone: "excellent" | "good" | "ok" | "weak" | "bad";
}) {
  return (
    <div className="rounded-2xl p-4" style={{ backgroundColor: `var(--tone-${tone}-soft)` }}>
      <div
        className="flex items-center gap-1.5 text-[12px] font-semibold"
        style={{ color: `var(--tone-${tone})` }}
      >
        <Icon className="h-3.5 w-3.5" strokeWidth={2} aria-hidden />
        {label}
      </div>
      <p className="mt-1.5 text-sm font-semibold leading-snug text-foreground">{criterionName}</p>
      <p className="mt-1 text-xs text-muted-foreground">{score.toFixed(1)}/2 ball</p>
    </div>
  );
}

function InsightCard({
  summary,
  weakest,
}: {
  summary: MySummary;
  weakest: MyStats["bands"][number] | undefined;
}) {
  let text = "Davom eting — muntazam yozish natijalaringizni sezilarli yaxshilaydi.";

  if (summary.bestScaledScore !== null && summary.averageScaledScore !== null) {
    const gap = summary.bestScaledScore - summary.averageScaledScore;
    if (gap >= 8) {
      text = `Eng yaxshi natijangiz (${summary.bestScaledScore}/75) o'rtachadan sezilarli yuqori — demak salohiyatingiz bor, buni barqaror natijaga aylantiring.`;
    } else if (weakest) {
      text = `"${weakest.criterionName}" mezoni ustida ko'proq ishlasangiz, umumiy natijangiz sezilarli oshadi.`;
    }
  }

  return (
    <div className="flex items-start gap-3 rounded-2xl bg-primary-soft p-4">
      <Lightbulb className="h-5 w-5 shrink-0 text-primary" strokeWidth={2} aria-hidden />
      <p className="text-[13px] leading-relaxed text-foreground">{text}</p>
    </div>
  );
}

function BandBar({ band }: { band: MyStats["bands"][number] }) {
  const tone = scoreTone(band.averageScore);
  const widthPct = Math.max(4, Math.round((band.averageScore / 2) * 100));

  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-medium text-foreground">
            {band.band}. {band.criterionName}
          </div>
        </div>
        <span
          className="shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold tabular-nums"
          style={{
            backgroundColor: `var(--tone-${tone}-soft)`,
            color: `var(--tone-${tone})`,
          }}
        >
          {band.averageScore.toFixed(1)}/2
        </span>
      </div>
      <div className="mt-2.5 h-2 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${widthPct}%`,
            backgroundColor: `var(--tone-${tone})`,
          }}
        />
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="mt-6 rounded-2xl bg-card p-8 text-center shadow-card">
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary-soft text-primary">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          className="h-7 w-7"
        >
          <path d="M3 3v18h18" />
          <path d="M7 16l4-5 3 3 5-7" />
        </svg>
      </div>
      <h3 className="text-base font-semibold text-foreground">
        Statistika uchun maʼlumot yetarli emas
      </h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Tekshirilgan esse boʻlmagani uchun mezon statistikasini koʻrsatib boʻlmaydi. Avval botdan
        esse yuboring.
      </p>
    </div>
  );
}

function ErrorState({
  title,
  description,
  onRetry,
}: {
  title: string;
  description: string;
  onRetry?: () => void;
}) {
  return (
    <div className="mt-6 rounded-2xl bg-card p-6 text-center shadow-card">
      <h3 className="text-base font-semibold text-foreground">{title}</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          Qayta urinish
        </button>
      )}
    </div>
  );
}
