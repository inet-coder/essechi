import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Clock, Lightbulb, PenLine, Search, X } from "lucide-react";
import { api, type Topic, ApiError } from "@/lib/api";
import { toneFor } from "@/lib/categoryTone";
import { TelegramGate } from "@/components/TelegramGate";
import { Skeleton } from "@/components/Skeleton";
import { BottomNav } from "@/components/BottomNav";

export const Route = createFileRoute("/topics/")({
  head: () => ({
    meta: [
      { title: "Esse mavzulari" },
      {
        name: "description",
        content:
          "Milliy sertifikat uchun esse mavzulari — kategoriyalar boʻyicha va qidiruv bilan.",
      },
    ],
  }),
  component: () => (
    <TelegramGate>
      <TopicsPage />
    </TelegramGate>
  ),
});

/* -------------------------------------------------------------------------
   Kategoriya ranglari umumiy yordamchida (lib/categoryTone) — Mavzular va
   Esse yozish sahifalari bir xil rang sxemasidan foydalanadi.
   ------------------------------------------------------------------------- */

const UNCATEGORIZED = "none" as const;
type FilterKey = number | typeof UNCATEGORIZED | null; // null = "Barchasi"

interface Group {
  key: number | typeof UNCATEGORIZED;
  name: string;
  categoryId: number | null;
  topics: Topic[];
}

function TopicsPage() {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<FilterKey>(null);

  const topicsQ = useQuery<Topic[], ApiError>({
    queryKey: ["topics"],
    queryFn: api.topics,
    retry: false,
  });

  const topics = useMemo(() => topicsQ.data ?? [], [topicsQ.data]);

  // Mavzulardan kategoriyalarni ajratib olamiz (alohida so'rovsiz). Har bir
  // kategoriya uchun mavzular soni bilan guruh tuzamiz; kategoriyasiz mavzular
  // oxirida "Boshqa mavzular" sifatida ko'rsatiladi.
  const groups = useMemo<Group[]>(() => {
    const byCat = new Map<number, Group>();
    const uncategorized: Topic[] = [];

    for (const t of topics) {
      if (t.category) {
        let g = byCat.get(t.category.id);
        if (!g) {
          g = {
            key: t.category.id,
            name: t.category.name,
            categoryId: t.category.id,
            topics: [],
          };
          byCat.set(t.category.id, g);
        }
        g.topics.push(t);
      } else {
        uncategorized.push(t);
      }
    }

    const result = [...byCat.values()].sort((a, b) => a.name.localeCompare(b.name));
    if (uncategorized.length > 0) {
      result.push({
        key: UNCATEGORIZED,
        name: "Boshqa mavzular",
        categoryId: null,
        topics: uncategorized,
      });
    }
    return result;
  }, [topics]);

  // Qidiruv + kategoriya filtri birga ishlaydi: avval tanlangan kategoriya
  // bo'yicha, keyin qidiruv matni bo'yicha filtrlanadi.
  const q = query.trim().toLowerCase();
  const isFiltering = q.length > 0 || active !== null;

  const filtered = useMemo<Topic[]>(() => {
    let list = topics;
    if (active === UNCATEGORIZED) list = list.filter((t) => !t.category);
    else if (typeof active === "number") list = list.filter((t) => t.category?.id === active);
    if (q) list = list.filter((t) => t.text.toLowerCase().includes(q));
    return list;
  }, [topics, active, q]);

  return (
    <div className="min-h-screen bg-background pb-28">
      <Hero
        count={topics.length}
        query={query}
        onQueryChange={setQuery}
        loading={topicsQ.isLoading}
      />

      <div className="mx-auto max-w-[560px] px-4">
        {/* Kategoriya filtri (chip'lar) */}
        {groups.length > 0 && (
          <div className="scrollbar-hide -mx-4 mt-4 flex gap-2 overflow-x-auto px-4 pb-1">
            <FilterChip
              label="Barchasi"
              count={topics.length}
              activeState={active === null}
              tone={{ fg: "var(--primary)", soft: "var(--primary-soft)" }}
              onClick={() => setActive(null)}
            />
            {groups.map((g) => (
              <FilterChip
                key={g.key}
                label={g.name}
                count={g.topics.length}
                activeState={active === g.key}
                tone={toneFor(g.categoryId)}
                onClick={() => setActive(g.key)}
              />
            ))}
          </div>
        )}

        <div className="pt-4">
          {topicsQ.isLoading && (
            <div className="space-y-3">
              <Skeleton className="h-32 w-full rounded-2xl" />
              <Skeleton className="h-32 w-full rounded-2xl" />
              <Skeleton className="h-32 w-full rounded-2xl" />
            </div>
          )}

          {topicsQ.error && <ErrorState onRetry={() => topicsQ.refetch()} />}

          {topicsQ.data && topics.length === 0 && <EmptyState />}

          {/* Filtrlangan (kategoriya tanlangan yoki qidiruv) — tekis ro'yxat */}
          {topics.length > 0 && isFiltering && (
            <FilteredList
              topics={filtered}
              query={query}
              onClear={() => {
                setQuery("");
                setActive(null);
              }}
            />
          )}

          {/* Filtr yo'q — kategoriyalar bo'yicha guruhlangan */}
          {topics.length > 0 && !isFiltering && (
            <div className="space-y-7">
              {groups.map((g) => (
                <section key={g.key}>
                  <GroupHeader group={g} onSeeAll={() => setActive(g.key)} />
                  <div className="space-y-3">
                    {g.topics.slice(0, 4).map((t, i) => (
                      <div
                        key={t.id}
                        className="animate-fade-slide-up"
                        style={{ animationDelay: `${Math.min(i, 6) * 45}ms` }}
                      >
                        <TopicRow topic={t} />
                      </div>
                    ))}
                  </div>
                  {g.topics.length > 4 && (
                    <button
                      onClick={() => setActive(g.key)}
                      className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl py-2.5 text-[13px] font-semibold transition-all duration-200 hover:opacity-80 active:scale-[0.98]"
                      style={{
                        backgroundColor: toneFor(g.categoryId).soft,
                        color: toneFor(g.categoryId).fg,
                      }}
                    >
                      Yana {g.topics.length - 4} ta mavzu
                      <ArrowRight className="h-3.5 w-3.5" strokeWidth={2.2} />
                    </button>
                  )}
                </section>
              ))}
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}

/**
 * Zich nuqta-panjara naqshi — premium gradient fonlarga chuqurlik va
 * to'qima berish uchun, sof dekorativ qatlam.
 */
function DotGrid({ opacity = 0.14 }: { opacity?: number }) {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden
      style={{ opacity }}
    >
      <defs>
        <pattern id="topics-dot-grid" width="14" height="14" patternUnits="userSpaceOnUse">
          <circle cx="1.2" cy="1.2" r="1.2" fill="white" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#topics-dot-grid)" />
    </svg>
  );
}

function Hero({
  count,
  query,
  onQueryChange,
  loading,
}: {
  count: number;
  query: string;
  onQueryChange: (q: string) => void;
  loading: boolean;
}) {
  return (
    <div
      className="relative overflow-hidden px-4 pb-5 pt-6"
      style={{
        background:
          "radial-gradient(130% 160% at 100% 0%, oklch(0.5 0.15 285) 0%, var(--primary) 45%, oklch(0.36 0.13 272) 100%)",
      }}
    >
      <DotGrid opacity={0.08} />
      <div
        className="pointer-events-none absolute -right-10 -top-14 h-44 w-44 rounded-full opacity-30 blur-2xl"
        style={{ background: "oklch(0.9 0.08 150)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-16 -left-12 h-44 w-44 rounded-full opacity-20 blur-2xl"
        style={{ background: "oklch(0.85 0.1 85)" }}
      />
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px"
        style={{
          background: "linear-gradient(90deg, transparent, oklch(1 0 0 / 0.35), transparent)",
        }}
      />
      <div className="relative mx-auto max-w-[560px]">
        <div className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/25 shadow-inner backdrop-blur-sm">
            <PenLine className="h-5 w-5 text-white" strokeWidth={2} />
          </div>
          <div>
            <h1 className="text-[20px] font-bold tracking-tight text-white">Esse mavzulari</h1>
            <p className="text-[12px] text-white/75">
              Kategoriya tanlang yoki qidiring, so'ng yozishni boshlang
              {!loading && count > 0 && ` · ${count} ta`}
            </p>
          </div>
        </div>

        <div className="relative mt-4">
          <Search
            className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            strokeWidth={2}
          />
          <input
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder="Mavzu qidirish..."
            className="w-full rounded-2xl bg-card py-2.5 pl-10 pr-9 text-sm text-foreground shadow-elevated outline-none ring-1 ring-black/[0.03] transition-shadow placeholder:text-muted-foreground focus:ring-2 focus:ring-white/40"
          />
          {query && (
            <button
              type="button"
              onClick={() => onQueryChange("")}
              className="absolute right-3 top-1/2 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full bg-muted text-muted-foreground transition-all duration-150 hover:opacity-80 active:scale-90"
              aria-label="Qidiruvni tozalash"
            >
              <X className="h-3 w-3" strokeWidth={2.5} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function FilterChip({
  label,
  count,
  activeState,
  tone,
  onClick,
}: {
  label: string;
  count: number;
  activeState: boolean;
  tone: { fg: string; soft: string };
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12.5px] font-semibold transition-all duration-200 active:scale-95"
      style={
        activeState
          ? {
              backgroundColor: tone.fg,
              borderColor: tone.fg,
              color: "var(--primary-foreground)",
              boxShadow: "0 2px 8px -2px color-mix(in oklch, " + tone.fg + " 50%, transparent)",
            }
          : {
              backgroundColor: "var(--card)",
              borderColor: "var(--border)",
              color: "var(--foreground)",
            }
      }
    >
      {label}
      <span
        className="rounded-full px-1.5 text-[10.5px] tabular-nums"
        style={
          activeState
            ? { backgroundColor: "oklch(1 0 0 / 0.22)", color: "var(--primary-foreground)" }
            : { backgroundColor: tone.soft, color: tone.fg }
        }
      >
        {count}
      </span>
    </button>
  );
}

function GroupHeader({ group, onSeeAll }: { group: Group; onSeeAll: () => void }) {
  const tone = toneFor(group.categoryId);
  return (
    <div className="mb-3 flex items-center justify-between px-1">
      <div className="flex items-center gap-2">
        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: tone.fg }} />
        <h2 className="text-[15px] font-bold tracking-tight text-foreground">{group.name}</h2>
        <span
          className="rounded-full px-1.5 py-0.5 text-[11px] font-semibold tabular-nums"
          style={{ backgroundColor: tone.soft, color: tone.fg }}
        >
          {group.topics.length}
        </span>
      </div>
      {group.topics.length > 4 && (
        <button
          onClick={onSeeAll}
          className="shrink-0 text-[12.5px] font-semibold transition-opacity hover:opacity-70"
          style={{ color: tone.fg }}
        >
          Hammasi
        </button>
      )}
    </div>
  );
}

function TopicRow({ topic }: { topic: Topic }) {
  const tone = toneFor(topic.category?.id ?? null);
  return (
    <div className="group relative overflow-hidden rounded-2xl bg-card p-4 pl-5 shadow-card ring-1 ring-black/[0.03] transition-shadow duration-200 hover:shadow-elevated">
      {/* Kategoriya rangidagi chap chiziq — signatura element */}
      <span
        className="absolute inset-y-0 left-0 w-1.5"
        style={{ backgroundColor: tone.fg }}
        aria-hidden
      />
      {topic.category && (
        <span
          className="inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold"
          style={{ backgroundColor: tone.soft, color: tone.fg }}
        >
          {topic.category.name}
        </span>
      )}
      <p className="mt-2 text-[14.5px] font-medium leading-snug text-foreground">{topic.text}</p>

      <div className="mt-3.5 flex items-center justify-between border-t border-border pt-3">
        <span className="flex items-center gap-1 text-[11.5px] text-muted-foreground">
          <Clock className="h-3.5 w-3.5" strokeWidth={2} />
          ~40 daqiqa
        </span>
        <Link
          to="/write"
          search={{ topic: topic.text }}
          className="flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-[12px] font-semibold text-primary-foreground shadow-sm transition-all duration-200 hover:opacity-90 active:scale-95"
        >
          Yozishni boshlash
          <ArrowRight
            className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5"
            strokeWidth={2.2}
          />
        </Link>
      </div>
    </div>
  );
}

function FilteredList({
  topics,
  query,
  onClear,
}: {
  topics: Topic[];
  query: string;
  onClear: () => void;
}) {
  if (topics.length === 0) {
    return (
      <div className="rounded-2xl bg-card p-8 text-center shadow-card ring-1 ring-black/[0.03]">
        <div
          className="mx-auto flex h-14 w-14 items-center justify-center rounded-full"
          style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
        >
          <Search className="h-6 w-6" strokeWidth={1.8} />
        </div>
        <h3 className="mt-3 text-base font-semibold tracking-tight text-foreground">
          Mavzu topilmadi
        </h3>
        <p className="mt-1.5 text-sm text-muted-foreground">
          {query.trim()
            ? `"${query.trim()}" boʻyicha mos mavzu yoʻq. Boshqa soʻz bilan urinib koʻring.`
            : "Bu kategoriyada hozircha mavzu yoʻq."}
        </p>
        <button
          onClick={onClear}
          className="mt-4 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-sm transition-all duration-200 hover:opacity-90 active:scale-95"
        >
          Filtrlarni tozalash
        </button>
      </div>
    );
  }

  return (
    <div>
      <p className="mb-2.5 px-1 text-[12px] font-medium text-muted-foreground">
        {topics.length} ta mavzu
      </p>
      <div className="space-y-3">
        {topics.map((t, i) => (
          <div
            key={t.id}
            className="animate-fade-slide-up"
            style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
          >
            <TopicRow topic={t} />
          </div>
        ))}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="rounded-2xl bg-card p-8 text-center shadow-card ring-1 ring-black/[0.03]">
      <div
        className="mx-auto flex h-14 w-14 items-center justify-center rounded-full"
        style={{ backgroundColor: "var(--tone-ok-soft)", color: "var(--tone-ok)" }}
      >
        <Lightbulb className="h-7 w-7" strokeWidth={1.8} />
      </div>
      <h3 className="mt-3 text-base font-semibold tracking-tight text-foreground">
        Hozircha mavzular yoʻq
      </h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Tez orada esse mavzulari shu yerda paydo boʻladi.
      </p>
    </div>
  );
}

function ErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="rounded-2xl bg-card p-6 text-center shadow-card ring-1 ring-black/[0.03]">
      <h3 className="text-base font-semibold tracking-tight text-foreground">
        Mavzularni yuklab boʻlmadi
      </h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Internetni tekshirib, qayta urinib koʻring.
      </p>
      <button
        onClick={onRetry}
        className="mt-4 inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-sm transition-all duration-200 hover:opacity-90 active:scale-95"
      >
        Qayta urinish
      </button>
    </div>
  );
}
