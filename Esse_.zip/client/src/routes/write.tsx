import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ClipboardList,
  FileText,
  ImagePlus,
  Pencil,
  RefreshCw,
  Search,
  Sparkles,
  Ticket,
  TriangleAlert,
  Upload,
  WifiOff,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";
import { api, type Topic, type EvaluationResult, type Me, ApiError } from "@/lib/api";
import { toneFor } from "@/lib/categoryTone";
import { TelegramGate } from "@/components/TelegramGate";
import { ScoreRing } from "@/components/ScoreRing";
import { ImageOcrPanel } from "@/components/ImageOcrPanel";
import { formatSum, totalLabel, totalTone } from "@/lib/format";

const MIN_WORDS = 100;

export const Route = createFileRoute("/write")({
  validateSearch: (search: Record<string, unknown>) => ({
    topic: typeof search.topic === "string" ? search.topic : undefined,
  }),
  head: () => ({
    meta: [{ title: "Esse yozish" }],
  }),
  component: () => (
    <TelegramGate>
      <WritePage />
    </TelegramGate>
  ),
});

type Phase = "topic" | "compose" | "submitting" | "done";
type Mode = "text" | "image" | "pdf";

function countWords(s: string): number {
  const t = s.trim();
  return t ? t.split(/\s+/).filter(Boolean).length : 0;
}

function apiErrorMessage(error: unknown): { icon: LucideIcon; message: string } {
  if (error instanceof ApiError) {
    if (error.status === 402) {
      return {
        icon: TriangleAlert,
        message: `${error.message}\n\nEsse tekshiruvi paketlar evaziga amalga oshiriladi. Botdagi "💰 Balansni to'ldirish" → "📦 Esse paketlari" bo'limidan paket sotib oling.`,
      };
    }
    if (error.message === "network") {
      return { icon: WifiOff, message: "Internetni tekshirib, qayta urinib ko'ring." };
    }
    return { icon: XCircle, message: `Xatolik: ${error.message}` };
  }
  return { icon: XCircle, message: "Kutilmagan xatolik yuz berdi. Iltimos, qayta urinib ko'ring." };
}

function WritePage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const router = useRouter();
  const queryClient = useQueryClient();

  const topicsQ = useQuery<Topic[], ApiError>({
    queryKey: ["topics"],
    queryFn: api.topics,
    retry: false,
  });

  const meQ = useQuery<Me, ApiError>({
    queryKey: ["me"],
    queryFn: api.me,
    retry: false,
  });

  const [phase, setPhase] = useState<Phase>("topic");
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>("text");
  const [textInput, setTextInput] = useState("");
  const [evalPercent, setEvalPercent] = useState(0);
  const [error, setError] = useState<{ icon: LucideIcon; message: string } | null>(null);
  const [result, setResult] = useState<{ result: EvaluationResult; essayId: number } | null>(null);

  const progressTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const initialized = useRef(false);

  useEffect(() => {
    return () => {
      if (progressTimer.current) clearInterval(progressTimer.current);
    };
  }, []);

  // Boshlang'ich holat: tashqaridan (mavzu kartasidan) mavzu berilgan bo'lsa,
  // to'g'ridan-to'g'ri yozish bosqichiga o'tamiz; aks holda mavzu tanlanadi.
  useEffect(() => {
    if (initialized.current || topicsQ.isLoading) return;
    initialized.current = true;
    if (search.topic) {
      setSelectedTopic(search.topic);
      setPhase("compose");
    }
  }, [topicsQ.isLoading, search.topic]);

  function startEval() {
    setEvalPercent(0);
    let percent = 0;
    progressTimer.current = setInterval(() => {
      percent = Math.min(percent + 7, 92);
      setEvalPercent(percent);
    }, 1100);
  }

  function stopEval() {
    if (progressTimer.current) {
      clearInterval(progressTimer.current);
      progressTimer.current = null;
    }
  }

  async function runSubmission(essayPromise: Promise<{ id: number }>) {
    setError(null);
    setPhase("submitting");
    startEval();
    try {
      const essay = await essayPromise;
      const evaluation = await api.evaluateEssay(essay.id);
      stopEval();
      setResult({ result: evaluation, essayId: essay.id });
      setPhase("done");
      queryClient.invalidateQueries({ queryKey: ["history"] });
      queryClient.invalidateQueries({ queryKey: ["summary"] });
      queryClient.invalidateQueries({ queryKey: ["stats"] });
      queryClient.invalidateQueries({ queryKey: ["me"] });
    } catch (err) {
      stopEval();
      // Xatolik: yozuv bosqichiga qaytamiz va matnni saqlab qolamiz, shunda
      // foydalanuvchi qaytadan yozishga majbur bo'lmaydi.
      setError(apiErrorMessage(err));
      setPhase("compose");
    }
  }

  function chooseTopic(topicText: string) {
    setSelectedTopic(topicText);
    setError(null);
    setPhase("compose");
  }

  function changeTopic() {
    setSelectedTopic(null);
    setTextInput("");
    setError(null);
    setPhase("topic");
  }

  function submitText() {
    if (!selectedTopic) return;
    if (countWords(textInput) < MIN_WORDS) return;
    void runSubmission(api.submitTextEssay(selectedTopic, textInput.trim()));
  }

  // Rasmdan o'qilgan (va tahrirlangan) matnni kvitansiya bilan yuboramiz -
  // esse "prepaidCheck" bo'lib, baholashda qayta pul/kredit olinmaydi (rasm
  // to'lovi OCR bosqichida oldindan olingan).
  function submitImage(text: string, ocrReceipt?: string) {
    if (!selectedTopic) return;
    void runSubmission(api.submitTextEssay(selectedTopic, text.trim(), ocrReceipt));
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !selectedTopic) return;
    void runSubmission(api.submitPdfEssay(selectedTopic, file));
  }

  function writeAnother() {
    setResult(null);
    setTextInput("");
    setError(null);
    setSelectedTopic(null);
    setMode("text");
    setPhase("topic");
  }

  const stepIndex = phase === "topic" ? 0 : phase === "compose" ? 1 : 2;

  return (
    <div className="flex h-[100dvh] flex-col bg-background">
      <Header
        onBack={() => (router.history.length > 1 ? router.history.back() : navigate({ to: "/" }))}
        stepIndex={stepIndex}
      />

      <main className="mx-auto flex w-full max-w-[560px] flex-1 flex-col overflow-hidden px-4">
        {(phase === "topic" || phase === "compose") && meQ.data && (
          <div
            className="mt-3 flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-center text-[12.5px] font-medium"
            style={{
              backgroundColor:
                meQ.data.essayCredits > 0 || meQ.data.freeEssayAvailable
                  ? "var(--primary)"
                  : "var(--tone-weak)",
              color: "#fff",
              opacity: 0.92,
            }}
          >
            <Ticket className="h-3.5 w-3.5 shrink-0" strokeWidth={2} />
            {meQ.data.essayCredits > 0
              ? `Esse tekshiruv krediti: ${meQ.data.essayCredits} ta`
              : meQ.data.freeEssayAvailable
                ? "Birinchi esse tekshiruvingiz bepul"
                : `Paketingiz yo'q — balansdagi mablag'dan ${formatSum(
                    meQ.data.singleCheckPrice,
                  )} so'm evaziga tekshirasiz (balans: ${formatSum(meQ.data.balance)})`}
          </div>
        )}

        {phase === "topic" && (
          <TopicStage
            topics={topicsQ.data ?? []}
            loading={topicsQ.isLoading}
            onChoose={chooseTopic}
          />
        )}

        {phase === "compose" && selectedTopic && (
          <ComposeStage
            topic={selectedTopic}
            mode={mode}
            onModeChange={(m) => {
              setMode(m);
              setError(null);
            }}
            text={textInput}
            onTextChange={(v) => {
              setTextInput(v);
              if (error) setError(null);
            }}
            error={error}
            onSubmitText={submitText}
            onSubmitImage={submitImage}
            onPickFile={() => fileInputRef.current?.click()}
            onChangeTopic={changeTopic}
            imagePagePrice={meQ.data?.imagePagePrice ?? 0}
            imageMaxPages={meQ.data?.imageMaxPages ?? 2}
          />
        )}

        {phase === "submitting" && <EvaluatingStage percent={evalPercent} />}

        {phase === "done" && result && <ResultStage data={result} onWriteAnother={writeAnother} />}
      </main>

      <input
        ref={fileInputRef}
        type="file"
        accept="application/pdf"
        onChange={handleFileChange}
        className="hidden"
      />
    </div>
  );
}

/* ========================================================================= */

function Header({ onBack, stepIndex }: { onBack: () => void; stepIndex: number }) {
  const steps = ["Mavzu", "Yozish", "Natija"];
  return (
    <header className="sticky top-0 z-10 border-b border-border bg-background/90 backdrop-blur-md">
      <div className="mx-auto flex w-full max-w-[560px] items-center gap-2 px-3 py-3">
        <button
          type="button"
          onClick={onBack}
          className="-ml-1 flex h-9 w-9 items-center justify-center rounded-xl text-foreground transition-colors hover:bg-muted"
          aria-label="Orqaga"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={2} />
        </button>
        <div className="flex flex-1 items-center gap-1.5">
          {steps.map((label, i) => (
            <div key={label} className="flex flex-1 items-center gap-1.5">
              <div className="flex items-center gap-1.5">
                <span
                  className="flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold transition-colors"
                  style={
                    i <= stepIndex
                      ? { backgroundColor: "var(--primary)", color: "var(--primary-foreground)" }
                      : { backgroundColor: "var(--muted)", color: "var(--muted-foreground)" }
                  }
                >
                  {i < stepIndex ? <Check className="h-3 w-3" strokeWidth={3} /> : i + 1}
                </span>
                <span
                  className="text-[12px] font-semibold"
                  style={{
                    color: i <= stepIndex ? "var(--foreground)" : "var(--muted-foreground)",
                  }}
                >
                  {label}
                </span>
              </div>
              {i < steps.length - 1 && (
                <span
                  className="h-0.5 flex-1 rounded-full transition-colors"
                  style={{ backgroundColor: i < stepIndex ? "var(--primary)" : "var(--border)" }}
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </header>
  );
}

/* ========================================================================= */

function TopicStage({
  topics,
  loading,
  onChoose,
}: {
  topics: Topic[];
  loading: boolean;
  onChoose: (t: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [custom, setCustom] = useState("");

  const q = query.trim().toLowerCase();
  const filtered = useMemo(
    () => (q ? topics.filter((t) => t.text.toLowerCase().includes(q)) : topics),
    [topics, q],
  );

  return (
    <div className="flex flex-1 flex-col overflow-hidden pt-4">
      <div className="shrink-0">
        <div className="flex items-center gap-2.5">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-2xl"
            style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
          >
            <Sparkles className="h-[18px] w-[18px]" strokeWidth={2} />
          </span>
          <div>
            <h1 className="text-[18px] font-bold leading-tight text-foreground">
              Nima haqida yozasiz?
            </h1>
            <p className="text-[12.5px] text-muted-foreground">
              Tayyor mavzu tanlang yoki o'zingiznikini kiriting
            </p>
          </div>
        </div>

        {/* O'z mavzusi */}
        <div className="mt-4 flex items-center gap-2 rounded-2xl border border-border bg-card p-1.5 shadow-card">
          <Pencil className="ml-2 h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={2} />
          <input
            value={custom}
            onChange={(e) => setCustom(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && custom.trim()) onChoose(custom.trim());
            }}
            placeholder="O'z mavzuingizni yozing..."
            className="min-w-0 flex-1 bg-transparent py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground"
          />
          <button
            type="button"
            onClick={() => custom.trim() && onChoose(custom.trim())}
            disabled={!custom.trim()}
            className="flex h-9 shrink-0 items-center gap-1 whitespace-nowrap rounded-xl bg-primary px-3 text-[13px] font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
          >
            Boshlash
            <ArrowRight className="h-3.5 w-3.5 shrink-0" strokeWidth={2.2} />
          </button>
        </div>

        {/* Qidiruv */}
        {topics.length > 0 && (
          <div className="relative mt-3">
            <Search
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              strokeWidth={2}
            />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Tayyor mavzulardan qidirish..."
              className="w-full rounded-2xl border border-border bg-card py-2.5 pl-10 pr-9 text-sm text-foreground outline-none placeholder:text-muted-foreground"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="absolute right-3 top-1/2 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full bg-muted text-muted-foreground"
                aria-label="Tozalash"
              >
                <X className="h-3 w-3" strokeWidth={2.5} />
              </button>
            )}
          </div>
        )}

        <p className="mb-2 mt-4 px-1 text-[11.5px] font-bold uppercase tracking-wide text-muted-foreground">
          Tayyor mavzular
        </p>
      </div>

      {/* Mavzular ro'yxati (scroll) */}
      <div className="scrollbar-hide -mx-4 flex-1 space-y-2.5 overflow-y-auto px-4 pb-6">
        {loading && (
          <>
            <div className="h-16 animate-pulse rounded-2xl bg-muted" />
            <div className="h-16 animate-pulse rounded-2xl bg-muted" />
            <div className="h-16 animate-pulse rounded-2xl bg-muted" />
          </>
        )}

        {!loading && filtered.length === 0 && (
          <div className="rounded-2xl bg-card p-6 text-center shadow-card">
            <p className="text-sm text-muted-foreground">
              {topics.length === 0
                ? "Hozircha tayyor mavzu yo'q — yuqoridan o'z mavzuingizni yozing."
                : "Mos mavzu topilmadi. Boshqa so'z bilan urinib ko'ring."}
            </p>
          </div>
        )}

        {filtered.map((topic, i) => {
          const tone = toneFor(topic.category?.id ?? null);
          return (
            <button
              key={topic.id}
              onClick={() => onChoose(topic.text)}
              className="animate-fade-slide-up flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-3.5 text-left shadow-card transition-transform active:scale-[0.99]"
              style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
            >
              <span
                className="h-9 w-1.5 shrink-0 rounded-full"
                style={{ backgroundColor: tone.fg }}
              />
              <span className="min-w-0 flex-1">
                {topic.category && (
                  <span
                    className="inline-flex rounded-full px-2 py-0.5 text-[10.5px] font-semibold"
                    style={{ backgroundColor: tone.soft, color: tone.fg }}
                  >
                    {topic.category.name}
                  </span>
                )}
                <span className="mt-1 line-clamp-2 block text-[13.5px] font-medium leading-snug text-foreground">
                  {topic.text}
                </span>
              </span>
              <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={2} />
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ========================================================================= */

function ComposeStage({
  topic,
  mode,
  onModeChange,
  text,
  onTextChange,
  error,
  onSubmitText,
  onSubmitImage,
  onPickFile,
  onChangeTopic,
  imagePagePrice,
  imageMaxPages,
}: {
  topic: string;
  mode: Mode;
  onModeChange: (m: Mode) => void;
  text: string;
  onTextChange: (v: string) => void;
  error: { icon: LucideIcon; message: string } | null;
  onSubmitText: () => void;
  onSubmitImage: (text: string, ocrReceipt?: string) => void;
  onPickFile: () => void;
  onChangeTopic: () => void;
  imagePagePrice: number;
  imageMaxPages: number;
}) {
  const words = countWords(text);
  const enough = words >= MIN_WORDS;

  return (
    <div className="flex flex-1 flex-col overflow-hidden pb-4 pt-4">
      {/* Mavzu (brief) kartasi */}
      <div className="shrink-0 rounded-2xl border border-border bg-card p-3.5 shadow-card">
        <div className="flex items-start justify-between gap-2">
          <span
            className="flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-semibold"
            style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
          >
            <ClipboardList className="h-3 w-3" strokeWidth={2.2} />
            Vaziyat
          </span>
          <button
            type="button"
            onClick={onChangeTopic}
            className="flex shrink-0 items-center gap-1 text-[12px] font-semibold text-primary transition-opacity hover:opacity-70"
          >
            <RefreshCw className="h-3 w-3" strokeWidth={2.2} />
            O'zgartirish
          </button>
        </div>
        <p className="mt-2 text-[13.5px] font-medium leading-snug text-foreground">{topic}</p>
      </div>

      {/* Rejim tanlash */}
      <div className="mt-3 flex shrink-0 gap-1 rounded-2xl bg-muted p-1">
        <ModeTab
          active={mode === "text"}
          onClick={() => onModeChange("text")}
          icon={Pencil}
          label="Matn"
        />
        <ModeTab
          active={mode === "image"}
          onClick={() => onModeChange("image")}
          icon={ImagePlus}
          label="Rasm"
        />
        <ModeTab
          active={mode === "pdf"}
          onClick={() => onModeChange("pdf")}
          icon={FileText}
          label="PDF"
        />
      </div>

      {error && (
        <div
          className="mt-3 flex shrink-0 items-start gap-2 whitespace-pre-wrap rounded-2xl px-3.5 py-3 text-[13px] leading-relaxed"
          style={{ backgroundColor: "var(--tone-bad-soft)", color: "var(--tone-bad)" }}
        >
          <error.icon className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2} aria-hidden />
          <span>{error.message}</span>
        </div>
      )}

      {mode === "text" ? (
        <>
          <textarea
            value={text}
            onChange={(e) => onTextChange(e.target.value)}
            placeholder="Essengizni shu yerga yozing... Fikringizni aniq bandlarga bo'lib, dalillar bilan asoslang."
            className="mt-3 min-h-0 flex-1 resize-none rounded-2xl border border-border bg-card p-4 text-[14px] leading-relaxed text-foreground shadow-card outline-none placeholder:text-muted-foreground focus:border-primary/40"
          />

          {/* Footer: so'z hisoblagich + yuborish */}
          <div className="mt-3 flex shrink-0 items-center gap-2.5">
            <WordRing words={words} />
            <div className="min-w-0 flex-1">
              {enough ? (
                <p
                  className="flex items-center gap-1 truncate text-[12.5px] font-semibold"
                  style={{ color: "var(--tone-good)" }}
                >
                  <Check className="h-3.5 w-3.5 shrink-0" strokeWidth={2.5} />
                  Yuborishga tayyor
                </p>
              ) : (
                <p className="truncate text-[12.5px] font-medium text-muted-foreground">
                  Yana <span className="font-bold text-foreground">{MIN_WORDS - words}</span> so'z
                  kerak
                </p>
              )}
              <p className="truncate text-[11px] text-muted-foreground">Kamida {MIN_WORDS} so'z</p>
            </div>
            <button
              type="button"
              onClick={onSubmitText}
              disabled={!enough}
              className="flex h-11 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-2xl bg-primary px-5 text-[14px] font-semibold text-primary-foreground shadow-card transition-all hover:opacity-90 disabled:opacity-40"
            >
              Tekshirish
              <ArrowRight className="h-4 w-4 shrink-0" strokeWidth={2.2} />
            </button>
          </div>
        </>
      ) : mode === "image" ? (
        <ImageOcrPanel
          extract={(files) => api.extractEssayImageText(files)}
          onConfirm={onSubmitImage}
          confirmLabel="Tekshirish"
          confirming={false}
          minWords={MIN_WORDS}
          maxPages={imageMaxPages}
          pagePrice={imagePagePrice}
        />
      ) : (
        <div className="mt-3 flex flex-1 flex-col">
          <button
            type="button"
            onClick={onPickFile}
            className="flex flex-1 flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border bg-card p-8 text-center transition-colors hover:border-primary/50 hover:bg-primary-soft/30"
          >
            <span
              className="flex h-14 w-14 items-center justify-center rounded-2xl"
              style={{ backgroundColor: "var(--primary-soft)", color: "var(--primary)" }}
            >
              <Upload className="h-6 w-6" strokeWidth={2} />
            </span>
            <span>
              <span className="block text-[15px] font-semibold text-foreground">
                PDF faylni tanlang
              </span>
              <span className="mt-1 block text-[12.5px] text-muted-foreground">
                Essengiz PDF ko'rinishida tayyor bo'lsa, shu yerga yuklang
              </span>
            </span>
            <span className="mt-1 rounded-xl bg-primary px-4 py-2 text-[13px] font-semibold text-primary-foreground">
              Fayl tanlash
            </span>
          </button>
          <p className="mt-3 shrink-0 text-center text-[11.5px] text-muted-foreground">
            Faqat PDF · kamida {MIN_WORDS} so'z
          </p>
        </div>
      )}
    </div>
  );
}

function ModeTab({
  active,
  onClick,
  icon: Icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: LucideIcon;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-[13px] font-semibold transition-all"
      style={
        active
          ? {
              backgroundColor: "var(--card)",
              color: "var(--primary)",
              boxShadow: "var(--shadow-card)",
            }
          : { color: "var(--muted-foreground)" }
      }
    >
      <Icon className="h-4 w-4" strokeWidth={2} />
      {label}
    </button>
  );
}

function WordRing({ words }: { words: number }) {
  const size = 48;
  const stroke = 5;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, words / MIN_WORDS));
  const enough = words >= MIN_WORDS;
  const color = enough ? "var(--tone-good)" : "var(--primary)";
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="var(--muted)"
          strokeWidth={stroke}
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${c * pct} ${c}`}
          style={{ transition: "stroke-dasharray 400ms ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-[13px] font-bold leading-none tabular-nums text-foreground">
          {words}
        </span>
        <span className="text-[8px] leading-none text-muted-foreground">so'z</span>
      </div>
    </div>
  );
}

/* ========================================================================= */

function EvaluatingStage({ percent }: { percent: number }) {
  const message =
    percent < 30
      ? "Matningiz qabul qilindi..."
      : percent < 60
        ? "Mezonlar bo'yicha tahlil qilinmoqda..."
        : percent < 90
          ? "Baholar hisoblanmoqda..."
          : "Natija tayyorlanmoqda...";

  const size = 132;
  const stroke = 11;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;

  return (
    <div className="flex flex-1 flex-col items-center justify-center pb-16 text-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke="var(--primary-soft)"
            strokeWidth={stroke}
            fill="none"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke="var(--primary)"
            strokeWidth={stroke}
            strokeLinecap="round"
            fill="none"
            strokeDasharray={`${c * (percent / 100)} ${c}`}
            style={{ transition: "stroke-dasharray 900ms ease" }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="animate-pulse" style={{ color: "var(--primary)" }}>
            <Sparkles className="h-8 w-8" strokeWidth={1.8} />
          </span>
        </div>
      </div>
      <p className="mt-6 text-[16px] font-bold text-foreground">Esse tekshirilmoqda</p>
      <p className="mt-1 h-5 text-[13px] text-muted-foreground">{message}</p>
      <p className="mt-4 text-[12px] text-muted-foreground">
        Bu bir necha soniya davom etishi mumkin
      </p>
    </div>
  );
}

/* ========================================================================= */

function ResultStage({
  data,
  onWriteAnother,
}: {
  data: { result: EvaluationResult; essayId: number };
  onWriteAnother: () => void;
}) {
  const { result, essayId } = data;
  const completed = result.status === "completed";
  const rejected = result.status === "auto_rejected";

  return (
    <div className="flex flex-1 flex-col overflow-y-auto pb-6 pt-4">
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        {completed ? (
          <>
            <div className="animate-fade-slide-up">
              <ScoreRing
                totalScore={result.totalScore}
                scaledScore={result.scaledScore}
                size={148}
              />
            </div>
            <p
              className="mt-4 rounded-full px-3 py-1 text-[13px] font-bold"
              style={{
                backgroundColor: `var(--tone-${totalTone(result.totalScore)}-soft)`,
                color: `var(--tone-${totalTone(result.totalScore)})`,
              }}
            >
              {totalLabel(result.totalScore)}
            </p>

            <Link
              to="/essay/$id"
              params={{ id: String(essayId) }}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 text-[14px] font-semibold text-primary-foreground shadow-card transition-opacity hover:opacity-90"
            >
              To'liq tahlilni ko'rish
              <ArrowRight className="h-4 w-4" strokeWidth={2.2} />
            </Link>
          </>
        ) : (
          <div
            className="w-full rounded-2xl p-6 text-center"
            style={{
              backgroundColor: rejected ? "var(--tone-weak-soft)" : "var(--tone-bad-soft)",
              color: rejected ? "var(--tone-weak)" : "var(--tone-bad)",
            }}
          >
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-white/50">
              {rejected ? (
                <TriangleAlert className="h-7 w-7" strokeWidth={1.8} />
              ) : (
                <XCircle className="h-7 w-7" strokeWidth={1.8} />
              )}
            </span>
            <p className="mt-3 text-[15px] font-bold">
              {rejected ? "Esse qabul qilinmadi" : "Texnik xatolik yuz berdi"}
            </p>
            {rejected && (
              <p className="mt-1 text-[13px] font-semibold text-foreground">
                Natija: {result.scaledScore}/75 ball
              </p>
            )}
            <p className="mt-2 whitespace-pre-wrap text-[13px] leading-relaxed text-foreground/80">
              {rejected
                ? (result.rejectionReason ?? "Esse qabul qilinmadi.")
                : "Hisobingizdan hech narsa yechilmadi. Iltimos, qayta urinib ko'ring."}
            </p>
          </div>
        )}
      </div>

      <button
        type="button"
        onClick={onWriteAnother}
        className="mt-6 flex w-full shrink-0 items-center justify-center gap-2 rounded-2xl border border-border bg-card py-3.5 text-[14px] font-semibold text-foreground transition-colors hover:bg-muted"
      >
        <Pencil className="h-4 w-4" strokeWidth={2} />
        Yana esse yozish
      </button>
    </div>
  );
}
