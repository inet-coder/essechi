import asyncio

import aiohttp

from bot.config import ADMIN_API_KEY, BACKEND_URL

_session: aiohttp.ClientSession | None = None

# Asinxron baholash natijasini navbat bilan so'rash (poll) sozlamalari.
_EVAL_POLL_INTERVAL = 3  # soniya - har necha soniyada natija so'raladi
_EVAL_POLL_TIMEOUT = 420  # soniya (7 daqiqa) - shundan keyin voz kechiladi


class ApiError(Exception):
    """Backend xato qaytarganda (4xx/5xx) yoki tarmoq darajasida muammo
    (vaqt tugashi, ulanish uzilishi) bo'lganda tashlanadi."""

    def __init__(self, status: int, message: str) -> None:
        self.status = status
        self.message = message
        super().__init__(message)


async def get_session() -> aiohttp.ClientSession:
    """Butun bot bo'ylab bitta umumiy aiohttp session ishlatiladi
    (har bir so'rov uchun yangi session ochish resursni behuda sarflaydi).
    Timeout GPT javobining uzoq cho'zilishi mumkinligini hisobga olib
    (real holatlarda 100+ soniya ham bo'lgan) yetarlicha katta belgilangan -
    aks holda esse tekshiruvi tugamasdan "vaqt tugadi" xatosi chiqib,
    progress osilib qolardi."""
    global _session
    if _session is None or _session.closed:
        timeout = aiohttp.ClientTimeout(total=180, connect=15)
        _session = aiohttp.ClientSession(base_url=BACKEND_URL, timeout=timeout)
    return _session


async def close_session() -> None:
    global _session
    if _session is not None and not _session.closed:
        await _session.close()


async def _parse_response(response: aiohttp.ClientResponse) -> dict:
    try:
        data = await response.json()
    except aiohttp.ContentTypeError:
        # Backend/oraliq server (masalan, tunnel) JSON bo'lmagan javob
        # qaytardi - ko'pincha vaqt tugashi (524) yoki gateway xatosi (502/503)
        # sababli HTML xato sahifasi keladi.
        raise ApiError(
            response.status,
            "Server javob bermadi (vaqt tugadi yoki tarmoq xatosi). "
            "Iltimos, birozdan so'ng qayta urinib ko'ring.",
        )

    if response.status >= 400:
        raise ApiError(response.status, data.get("error", "Noma'lum xatolik"))
    return data


async def _request(method: str, path: str, **kwargs) -> dict:
    """Barcha so'rovlar shu funksiya orqali o'tadi. Tarmoq darajasidagi
    HAR QANDAY xatolik (vaqt tugashi, ulanish uzilishi, DNS muammosi va h.k.)
    shu yerda ushlanib, ApiError'ga aylantiriladi - shunda chaqiruvchi tomon
    (handler'lar) faqat ApiError'ni tutsa kifoya, hech qachon kutilmagan
    xato bilan "jim qolib ketmaydi"."""
    session = await get_session()
    try:
        async with session.request(method, path, **kwargs) as response:
            return await _parse_response(response)
    except ApiError:
        raise
    except asyncio.TimeoutError:
        raise ApiError(
            0,
            "Server javob berishga ulgurmadi (vaqt tugadi). "
            "Iltimos, birozdan so'ng qayta urinib ko'ring.",
        )
    except aiohttp.ClientError as error:
        raise ApiError(0, f"Tarmoq xatosi: {error}")


async def register_user(telegram_id: int, first_name: str | None, username: str | None) -> dict:
    payload = {"telegramId": telegram_id, "firstName": first_name, "username": username}
    return await _request("POST", "/api/users", json=payload)


async def get_user(telegram_id: int) -> dict:
    return await _request("GET", f"/api/users/{telegram_id}")


async def get_user_summary(telegram_id: int) -> dict:
    return await _request("GET", f"/api/users/{telegram_id}/summary")


async def get_user_payments(telegram_id: int) -> list[dict]:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "GET", f"/api/payments/user/{telegram_id}", headers=headers
    )


async def submit_text_essay(
    telegram_id: int, topic: str, text: str, ocr_receipt: str | None = None
) -> dict:
    payload = {"telegramId": telegram_id, "topic": topic, "text": text}
    # ocr_receipt bo'lsa (rasm orqali kelgan, OCR bosqichida oldindan
    # to'langan) - qo'shamiz, shunda esse "prepaidCheck" bo'ladi.
    if ocr_receipt:
        payload["ocrReceipt"] = ocr_receipt
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("POST", "/api/essays/text", json=payload, headers=headers)


async def submit_pdf_essay(
    telegram_id: int, topic: str, file_bytes: bytes, filename: str
) -> dict:
    form = aiohttp.FormData()
    form.add_field("telegramId", str(telegram_id))
    form.add_field("topic", topic)
    form.add_field("file", file_bytes, filename=filename, content_type="application/pdf")
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("POST", "/api/essays/pdf", data=form, headers=headers)


async def extract_image_text(
    telegram_id: int, images: list[tuple[bytes, str]]
) -> dict:
    """`images` - [(rasm_baytlari, content_type), ...] ro'yxati (varoq tartibida).
    RASM orqali tekshiruv to'lovi shu bosqichda OLDINDAN olinadi. Essay yozuvi
    yaratmaydi. Qaytaradi: {text, ocrReceipt, pages, charged}."""
    form = aiohttp.FormData()
    form.add_field("telegramId", str(telegram_id))
    for i, (file_bytes, content_type) in enumerate(images):
        form.add_field(
            "files", file_bytes, filename=f"page-{i + 1}.jpg", content_type=content_type
        )
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "POST", "/api/essays/extract-image-text", data=form, headers=headers
    )


async def evaluate_essay(essay_id: int) -> dict:
    """Baholashni BOSHLAYDI, so'ng natija tayyor bo'lguncha navbat bilan
    (poll) so'raydi. Backend baholashni fon rejimida bajaradi va so'rovni
    darhol yopadi - shu bilan uzoq GPT chaqiruvi tunnelning 100s limitini
    buzib, 524 (HTML) qaytarishi oldini olinadi.
    """
    headers = {"x-admin-key": ADMIN_API_KEY}
    started = await _request(
        "POST", "/api/evaluations", json={"essayId": essay_id}, headers=headers
    )

    # Natija allaqachon tayyor bo'lsa (avval baholangan yoki ikki marta bosilgan),
    # backend to'g'ridan-to'g'ri natijani (status: completed/auto_rejected/failed)
    # qaytaradi - u holda "processing" bo'lmaydi.
    if started.get("status") != "processing":
        return started

    # Aks holda natijani navbat bilan so'raymiz.
    deadline = asyncio.get_event_loop().time() + _EVAL_POLL_TIMEOUT
    while asyncio.get_event_loop().time() < deadline:
        await asyncio.sleep(_EVAL_POLL_INTERVAL)
        result = await _request(
            "GET", f"/api/evaluations/by-essay/{essay_id}", headers=headers
        )
        if result.get("status") != "processing":
            return result

    raise ApiError(
        0,
        "Baholash juda uzoq cho'zildi. Natija tayyor bo'lgach, uni \"Tarixim\" "
        "bo'limidan ko'rishingiz mumkin.",
    )


async def get_user_history(telegram_id: int) -> list[dict]:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "GET", f"/api/evaluations/history/{telegram_id}", headers=headers
    )


async def admin_topup_balance(telegram_id: int, amount: int, note: str) -> dict:
    payload = {"telegramId": telegram_id, "amount": amount, "note": note}
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("POST", "/api/payments/topup", json=payload, headers=headers)


async def create_pending_topup(telegram_id: int, amount: int, provider: str) -> dict:
    """Avtomatik to'lov uchun pending yozuv yaratadi. Backend unikal summa,
    to'lov ID va karta ma'lumotlarini qaytaradi."""
    payload = {"telegramId": telegram_id, "amount": amount, "provider": provider}
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("POST", "/api/payments/pending", json=payload, headers=headers)


async def list_packages() -> list[dict]:
    """Esse tekshiruv paketlari ro'yxati: [{id, credits, price}, ...]."""
    return await _request("GET", "/api/payments/packages")


async def get_payment_status(payment_id: int) -> dict:
    """Bitta to'lovning holati va qolgan vaqti:
    {id, status, kind, amount, essayCredits, expiresAt, secondsLeft}."""
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "GET", f"/api/payments/{payment_id}/status", headers=headers
    )


async def create_package_pending(
    telegram_id: int, package_id: int, provider: str = "any"
) -> dict:
    """Esse paketi uchun pending yozuv yaratadi. Tasdiqlangach balans emas,
    esse tekshiruv krediti qo'shiladi."""
    payload = {
        "telegramId": telegram_id,
        "packageId": package_id,
        "provider": provider,
    }
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "POST", "/api/payments/package-pending", json=payload, headers=headers
    )


async def list_topics() -> list[dict]:
    return await _request("GET", "/api/topics")


async def admin_create_topic(
    text: str,
    category_id: int | None = None,
    new_category_name: str | None = None,
) -> dict:
    payload: dict = {"text": text}
    if category_id is not None:
        payload["categoryId"] = category_id
    if new_category_name:
        payload["newCategoryName"] = new_category_name
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("POST", "/api/topics", json=payload, headers=headers)


async def list_categories() -> list[dict]:
    """Faol mavzu kategoriyalari (ochiq endpoint)."""
    return await _request("GET", "/api/topics/categories")


async def admin_list_categories() -> list[dict]:
    """Admin uchun - faol va nofaol barcha kategoriyalar."""
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("GET", "/api/topics/admin/categories", headers=headers)


async def admin_create_category(name: str) -> dict:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "POST", "/api/topics/categories", json={"name": name}, headers=headers
    )


async def admin_delete_category(category_id: int) -> dict:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "POST", f"/api/topics/categories/{category_id}/deactivate", headers=headers
    )


async def admin_delete_topic(topic_id: int) -> dict:
    headers = {"x-admin-key": ADMIN_API_KEY}
    # DELETE o'rniga POST ishlatiladi - ba'zi tunnel/proxy xizmatlari
    # (masalan cloudflared bepul tunneli) DELETE metodini xavfsizlik
    # siyosati bo'yicha bloklashi yoki boshqacha ishlov berishi mumkin.
    return await _request("POST", f"/api/topics/{topic_id}/deactivate", headers=headers)


async def admin_get_all_telegram_ids() -> list[int]:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("GET", "/api/users/telegram-ids", headers=headers)


# ----- Majburiy obuna kanallari -----


# ----- Qo'llanma (bot ichidagi video + tavsif) -----


async def get_guide() -> dict:
    """Ochiq endpoint: {videoFileId, description}. Video o'rnatilmagan bo'lsa
    videoFileId=None."""
    return await _request("GET", "/api/settings/guide")


async def admin_set_guide_video(file_id: str) -> dict:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "POST",
        "/api/settings/guide/video",
        json={"videoFileId": file_id},
        headers=headers,
    )


async def admin_set_guide_description(description: str) -> dict:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "POST",
        "/api/settings/guide/description",
        json={"description": description},
        headers=headers,
    )


# ----- Savol / Taklif (foydalanuvchi <-> admin yozishmasi) -----


async def log_feedback(telegram_id: int, direction: str, message: str) -> dict:
    """Yozishma xabarini tarix uchun saqlaydi.
    direction: "incoming" (foydalanuvchidan) | "outgoing" (admindan)."""
    headers = {"x-admin-key": ADMIN_API_KEY}
    payload = {
        "telegramId": telegram_id,
        "direction": direction,
        "message": message,
    }
    return await _request("POST", "/api/feedback", json=payload, headers=headers)


# ----- Majburiy obuna kanallari -----


async def list_active_channels() -> list[dict]:
    """Ochiq endpoint - obuna tekshiruvida ishlatiladi (faqat bot allaqachon
    a'zo/admin bo'lgan, faol kanallar)."""
    return await _request("GET", "/api/channels")


async def admin_list_channels() -> list[dict]:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("GET", "/api/channels/admin", headers=headers)


async def admin_add_channel(
    chat_id: int,
    title: str,
    username: str | None = None,
    invite_link: str | None = None,
    status: str = "pending",
) -> dict:
    payload = {
        "chatId": chat_id,
        "title": title,
        "username": username,
        "inviteLink": invite_link,
        "status": status,
    }
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request("POST", "/api/channels", json=payload, headers=headers)


async def admin_update_channel_status(
    channel_id: int,
    status: str | None = None,
    invite_link: str | None = None,
) -> dict:
    payload: dict = {}
    if status is not None:
        payload["status"] = status
    if invite_link is not None:
        payload["inviteLink"] = invite_link
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "POST", f"/api/channels/{channel_id}/status", json=payload, headers=headers
    )


async def admin_delete_channel(channel_id: int) -> dict:
    headers = {"x-admin-key": ADMIN_API_KEY}
    return await _request(
        "POST", f"/api/channels/{channel_id}/deactivate", headers=headers
    )