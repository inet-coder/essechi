import os

from dotenv import load_dotenv

load_dotenv()

REQUIRED_VARS = ["BOT_TOKEN", "ADMIN_API_KEY", "ADMIN_CHAT_ID"]

for var in REQUIRED_VARS:
    if not os.environ.get(var):
        raise RuntimeError(f"Majburiy environment o'zgaruvchi topilmadi: {var}")

BOT_TOKEN = os.environ["BOT_TOKEN"]
BACKEND_URL = os.environ.get("BACKEND_URL", "http://localhost:3000")
WEB_APP_URL = os.environ.get("WEB_APP_URL", "")

# Backenddagi /api/payments/topup endpointini chaqirish uchun (ADMIN_API_KEY
# bilan bir xil bo'lishi shart)
ADMIN_API_KEY = os.environ["ADMIN_API_KEY"]

# Adminning shaxsiy Telegram chat ID raqami - balans to'ldirish so'rovlari
# shu yerga yuboriladi, va faqat shu ID dan kelgan tasdiqlash/tahrirlash
# amallari qabul qilinadi
ADMIN_CHAT_ID = int(os.environ["ADMIN_CHAT_ID"])

PAYMENT_INFO = os.environ.get(
    "PAYMENT_INFO",
    "Balansni to'ldirish uchun administrator bilan bog'laning.",
)

# Minimal to'lov summasi (so'm). Backenddagi MIN_TOPUP_AMOUNT bilan bir xil
# bo'lgani ma'qul - backend baribir mustaqil tekshiradi.
MIN_TOPUP_AMOUNT = int(os.environ.get("MIN_TOPUP_AMOUNT", "2000"))
# Rasm (qo'lyozma) orqali yuborishda HAR BIR varaq uchun OCR narxi (so'm) va
# maksimal varaq soni. Faqat foydalanuvchini OGOHLANTIRISH uchun ishlatiladi -
# haqiqiy to'lov va limitni backend (ESSAY_IMAGE_PAGE_PRICE / ESSAY_IMAGE_MAX_PAGES)
# mustaqil qo'llaydi, shuning uchun bu qiymatlar backend bilan bir xil bo'lsin.
ESSAY_IMAGE_PAGE_PRICE = int(os.environ.get("ESSAY_IMAGE_PAGE_PRICE", "1000"))
ESSAY_IMAGE_MAX_PAGES = int(os.environ.get("ESSAY_IMAGE_MAX_PAGES", "2"))
