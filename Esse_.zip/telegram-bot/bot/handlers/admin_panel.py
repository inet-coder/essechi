import asyncio
import logging

from aiogram import Bot, F, Router, types
from aiogram.exceptions import TelegramBadRequest, TelegramRetryAfter
from aiogram.fsm.context import FSMContext

from bot.config import WEB_APP_URL
from bot.api.client import (
    ApiError,
    admin_add_channel,
    admin_create_category,
    admin_create_topic,
    admin_delete_category,
    admin_delete_channel,
    admin_delete_topic,
    admin_get_all_telegram_ids,
    admin_list_categories,
    admin_list_channels,
    admin_set_guide_description,
    admin_set_guide_video,
    admin_update_channel_status,
    get_guide,
    list_categories,
    list_topics,
)
from bot.keyboards.admin_panel_keyboards import (
    AdminBroadcastCallback,
    AdminCategoryCallback,
    AdminCategoryManageCallback,
    AdminChannelManageCallback,
    AdminGuideCallback,
    AdminPanelCallback,
    AdminTopicManageCallback,
    build_admin_main_keyboard,
    build_broadcast_confirm_keyboard,
    build_categories_manage_keyboard,
    build_category_picker_keyboard,
    build_channel_recheck_keyboard,
    build_channels_manage_keyboard,
    build_guide_manage_keyboard,
    build_topics_manage_keyboard,
)
from bot.keyboards.common import CANCEL_BUTTON_TEXT, build_cancel_reply_keyboard
from bot.keyboards.main_menu import get_main_menu
from bot.middlewares.admin_only import AdminOnlyMiddleware
from bot.states.admin_panel_states import AdminPanelStates

router = Router()
router.message.middleware(AdminOnlyMiddleware())
router.callback_query.middleware(AdminOnlyMiddleware())
logger = logging.getLogger(__name__)


# ----- Admin panelga kirish -----


@router.message(F.text == "🛠 Admin panel")
async def open_admin_panel(message: types.Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "🛠 <b>Admin panel</b>\n\nKerakli bo'limni tanlang:",
        reply_markup=build_admin_main_keyboard(),
    )


# ----- Veb-panelni ochish (brauzerda to'liq boshqaruv) -----


@router.message(F.text == "🌐 Veb-panel")
async def open_web_panel(message: types.Message, state: FSMContext) -> None:
    await state.clear()

    if not WEB_APP_URL:
        await message.answer(
            "🌐 Veb-panel manzili sozlanmagan.\n\n"
            "Uni ishga tushirish uchun botning <code>WEB_APP_URL</code> "
            "environment o'zgaruvchisiga veb-ilova manzilini yozing."
        )
        return

    admin_url = f"{WEB_APP_URL.rstrip('/')}/admin"
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(text="🌐 Veb-panelni ochish", url=admin_url)]
        ]
    )
    await message.answer(
        "🌐 <b>Veb-panel</b>\n\n"
        "Maqolalar, musobaqalar, mavzular, foydalanuvchilar va to'lovlarni "
        "to'liq boshqarish uchun quyidagi tugma orqali veb-panelga o'ting. "
        "Kirishda admin kalitni kiritasiz.",
        reply_markup=keyboard,
    )


@router.callback_query(AdminPanelCallback.filter(F.action == "main"))
async def back_to_admin_main(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text(
        "🛠 <b>Admin panel</b>\n\nKerakli bo'limni tanlang:",
        reply_markup=build_admin_main_keyboard(),
    )
    await callback.answer()


# ----- Qo'llanma (bot ichidagi video + tavsif) -----


@router.callback_query(AdminPanelCallback.filter(F.action == "guide"))
async def open_guide_manage(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()

    try:
        guide = await get_guide()
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    video_status = "✅ o'rnatilgan" if guide.get("videoFileId") else "❌ o'rnatilmagan"
    description = guide.get("description") or "—"

    await callback.message.edit_text(
        "📖 <b>Qo'llanma boshqaruvi</b>\n\n"
        f"🎬 Video: <b>{video_status}</b>\n"
        f"✏️ Tavsif:\n{description}",
        reply_markup=build_guide_manage_keyboard(),
    )
    await callback.answer()


@router.callback_query(AdminGuideCallback.filter(F.action == "set_video"))
async def request_guide_video(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminPanelStates.waiting_for_guide_video)
    await callback.answer()
    await callback.message.answer(
        "🎬 Qo'llanma sifatida ko'rsatiladigan videoni yuboring.\n\n"
        "(Video fayl sifatida yuboring — hujjat/rasm emas.)",
        reply_markup=build_cancel_reply_keyboard(),
    )


@router.callback_query(AdminGuideCallback.filter(F.action == "set_desc"))
async def request_guide_description(
    callback: types.CallbackQuery, state: FSMContext
) -> None:
    await state.set_state(AdminPanelStates.waiting_for_guide_description)
    await callback.answer()
    await callback.message.answer(
        "✏️ Qo'llanma videosi ostida ko'rsatiladigan tavsif matnini yuboring "
        "(video izohi sifatida, 1024 belgigacha):",
        reply_markup=build_cancel_reply_keyboard(),
    )


@router.message(AdminPanelStates.waiting_for_guide_video, F.text == CANCEL_BUTTON_TEXT)
@router.message(
    AdminPanelStates.waiting_for_guide_description, F.text == CANCEL_BUTTON_TEXT
)
async def cancel_guide_edit(message: types.Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "Bekor qilindi. Asosiy menyu:",
        reply_markup=get_main_menu(is_admin=True),
    )


@router.message(AdminPanelStates.waiting_for_guide_video, F.video)
async def receive_guide_video(message: types.Message, state: FSMContext) -> None:
    file_id = message.video.file_id
    try:
        await admin_set_guide_video(file_id)
    except ApiError as error:
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await state.clear()
    await message.answer(
        "✅ Qo'llanma videosi saqlandi. Endi foydalanuvchilar «📖 Qo'llanma» "
        "tugmasi orqali uni ko'radi.",
        reply_markup=get_main_menu(is_admin=True),
    )


@router.message(AdminPanelStates.waiting_for_guide_video)
async def guide_video_wrong_type(message: types.Message) -> None:
    await message.answer(
        "Iltimos, VIDEO yuboring (hujjat, rasm yoki matn emas). Yoki bekor "
        "qiling."
    )


@router.message(AdminPanelStates.waiting_for_guide_description, F.text)
async def receive_guide_description(message: types.Message, state: FSMContext) -> None:
    try:
        await admin_set_guide_description(message.text)
    except ApiError as error:
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await state.clear()
    await message.answer(
        "✅ Qo'llanma tavsifi saqlandi.",
        reply_markup=get_main_menu(is_admin=True),
    )


# ----- Mavzularni boshqarish -----


def _category_name(topic: dict) -> str | None:
    cat = topic.get("category")
    return cat["name"] if cat else None


async def _render_topics_management(message: types.Message, page: int, edit: bool) -> None:
    try:
        topics = await list_topics()
    except ApiError as error:
        text = f"❌ Xatolik: {error.message}"
        if edit:
            await message.edit_text(text)
        else:
            await message.answer(text)
        return

    # Kategoriya bo'yicha guruhlab ko'rsatamiz: avval kategoriyali mavzular
    # (nom bo'yicha), oxirida kategoriyasizlar. Klaviatura ham SHU tartibdagi
    # ro'yxatni ishlatadi - raqamlar tugmalarga mos keladi.
    topics.sort(key=lambda t: (_category_name(t) is None, (_category_name(t) or "").lower()))

    if not topics:
        text = "📋 <b>Mavzularni boshqarish</b>\n\nHozircha hech qanday mavzu yo'q."
    else:
        lines = ["📋 <b>Mavzularni boshqarish</b>\n"]
        start = page * 8
        current_cat = None
        for i, topic in enumerate(topics[start : start + 8], start=start + 1):
            cat = _category_name(topic) or "Kategoriyasiz"
            if cat != current_cat:
                lines.append(f"\n📁 <b>{cat}</b>")
                current_cat = cat
            lines.append(f"<b>{i}.</b> {topic['text']}")
        text = "\n".join(lines)

    keyboard = build_topics_manage_keyboard(topics, page=page)
    if edit:
        await message.edit_text(text, reply_markup=keyboard)
    else:
        await message.answer(text, reply_markup=keyboard)


@router.callback_query(AdminPanelCallback.filter(F.action == "topics"))
async def open_topics_management(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await _render_topics_management(callback.message, page=0, edit=True)
    await callback.answer()


@router.callback_query(AdminTopicManageCallback.filter(F.action == "page"))
async def change_topics_page(
    callback: types.CallbackQuery, callback_data: AdminTopicManageCallback
) -> None:
    await _render_topics_management(callback.message, page=callback_data.page, edit=True)
    await callback.answer()


@router.callback_query(AdminTopicManageCallback.filter(F.action == "delete"))
async def delete_topic(
    callback: types.CallbackQuery, callback_data: AdminTopicManageCallback
) -> None:
    try:
        await admin_delete_topic(callback_data.topic_id)
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    await callback.answer("✅ Mavzu o'chirildi")
    await _render_topics_management(callback.message, page=0, edit=True)


@router.callback_query(AdminTopicManageCallback.filter(F.action == "add"))
async def request_new_topic(callback: types.CallbackQuery, state: FSMContext) -> None:
    # Avval kategoriya tanlanadi (mavjud yoki yangi), keyin mavzu matni so'raladi.
    try:
        categories = await list_categories()
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    await state.set_state(AdminPanelStates.waiting_for_new_topic_category)
    await callback.answer()
    await callback.message.edit_text(
        "Yangi mavzu uchun kategoriyani tanlang:",
        reply_markup=build_category_picker_keyboard(categories),
    )


@router.callback_query(
    AdminPanelStates.waiting_for_new_topic_category, AdminCategoryCallback.filter()
)
async def choose_topic_category(
    callback: types.CallbackQuery,
    callback_data: AdminCategoryCallback,
    state: FSMContext,
) -> None:
    if callback_data.action == "new":
        # Yangi kategoriya nomini so'raymiz.
        await state.set_state(AdminPanelStates.waiting_for_new_category_name)
        await callback.answer()
        await callback.message.edit_text("Yangi kategoriya nomini yuboring:")
        return

    if callback_data.action == "select":
        await state.update_data(category_id=callback_data.category_id, new_category_name=None)
    else:  # "none" - kategoriyasiz
        await state.update_data(category_id=None, new_category_name=None)

    await state.set_state(AdminPanelStates.waiting_for_new_topic_text)
    await callback.answer()
    await callback.message.edit_text("Endi mavzu (vaziyat) matnini yuboring:")


@router.message(AdminPanelStates.waiting_for_new_category_name, F.text)
async def receive_new_category_name(message: types.Message, state: FSMContext) -> None:
    # Kategoriya endi yaratilmaydi - mavzu yaratilganda birga yuboriladi
    # (newCategoryName), shunda bo'sh kategoriya qolib ketmaydi.
    await state.update_data(category_id=None, new_category_name=message.text.strip())
    await state.set_state(AdminPanelStates.waiting_for_new_topic_text)
    await message.answer("Endi mavzu (vaziyat) matnini yuboring:")


@router.message(AdminPanelStates.waiting_for_new_topic_text, F.text)
async def receive_new_topic_text(message: types.Message, state: FSMContext) -> None:
    data = await state.get_data()
    try:
        await admin_create_topic(
            message.text,
            category_id=data.get("category_id"),
            new_category_name=data.get("new_category_name"),
        )
    except ApiError as error:
        logger.exception("Mavzu qo'shishda xatolik")
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await state.clear()
    await message.answer("✅ Yangi mavzu qo'shildi.")
    await _render_topics_management(message, page=0, edit=False)


# ----- Kategoriyalarni boshqarish -----


async def _render_categories_management(message: types.Message, page: int, edit: bool) -> None:
    try:
        categories = await admin_list_categories()
    except ApiError as error:
        text = f"❌ Xatolik: {error.message}"
        if edit:
            await message.edit_text(text)
        else:
            await message.answer(text)
        return

    active = [c for c in categories if c.get("isActive", True)]
    inactive = [c for c in categories if not c.get("isActive", True)]

    if not categories:
        text = "🗂 <b>Kategoriyalarni boshqarish</b>\n\nHozircha hech qanday kategoriya yo'q."
    else:
        lines = ["🗂 <b>Kategoriyalarni boshqarish</b>\n"]
        for i, cat in enumerate(active, start=1):
            lines.append(f"<b>{i}.</b> 📁 {cat['name']}")
        if inactive:
            lines.append("\n<i>O'chirilgan:</i>")
            for cat in inactive:
                lines.append(f"— {cat['name']}")
        text = "\n".join(lines)

    keyboard = build_categories_manage_keyboard(active, page=page)
    if edit:
        await message.edit_text(text, reply_markup=keyboard)
    else:
        await message.answer(text, reply_markup=keyboard)


@router.callback_query(AdminPanelCallback.filter(F.action == "categories"))
async def open_categories_management(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await _render_categories_management(callback.message, page=0, edit=True)
    await callback.answer()


@router.callback_query(AdminCategoryManageCallback.filter(F.action == "page"))
async def change_categories_page(
    callback: types.CallbackQuery, callback_data: AdminCategoryManageCallback
) -> None:
    await _render_categories_management(callback.message, page=callback_data.page, edit=True)
    await callback.answer()


@router.callback_query(AdminCategoryManageCallback.filter(F.action == "delete"))
async def delete_category(
    callback: types.CallbackQuery, callback_data: AdminCategoryManageCallback
) -> None:
    try:
        await admin_delete_category(callback_data.category_id)
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    await callback.answer("✅ Kategoriya o'chirildi")
    await _render_categories_management(callback.message, page=0, edit=True)


@router.callback_query(AdminCategoryManageCallback.filter(F.action == "add"))
async def request_new_category(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminPanelStates.waiting_for_new_standalone_category_name)
    await callback.answer()
    await callback.message.edit_text("Yangi kategoriya nomini yuboring:")


@router.message(AdminPanelStates.waiting_for_new_standalone_category_name, F.text)
async def receive_new_standalone_category_name(
    message: types.Message, state: FSMContext
) -> None:
    await state.clear()
    try:
        await admin_create_category(message.text.strip())
    except ApiError as error:
        logger.exception("Kategoriya qo'shishda xatolik")
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await message.answer("✅ Yangi kategoriya qo'shildi.")
    await _render_categories_management(message, page=0, edit=False)


# ----- Xabar yuborish (broadcast) -----

BROADCAST_DELAY_SECONDS = 0.05  # ~20 xabar/soniya - Telegram limitidan xavfsiz pastda
PROGRESS_UPDATE_EVERY = 50  # har 50 ta yuborilgandan keyin progress xabari yangilanadi


@router.callback_query(AdminPanelCallback.filter(F.action == "broadcast"))
async def request_broadcast_content(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminPanelStates.waiting_for_broadcast_text)
    await callback.answer()
    await callback.message.edit_text(
        "📢 Barcha foydalanuvchilarga yuborilishi kerak bo'lgan xabarni yuboring.\n\n"
        "Istalgan turdagi xabar bo'lishi mumkin: matn, rasm, video, hujjat, "
        "ovozli xabar va h.k."
    )


@router.message(AdminPanelStates.waiting_for_broadcast_text)
async def receive_broadcast_content(message: types.Message, state: FSMContext) -> None:
    # Xabarning o'zini (chat_id + message_id) saqlaymiz - copy_message orqali
    # bu istalgan turdagi kontentni (matn, rasm, video va h.k.) aynan
    # nusxalab, barcha foydalanuvchilarga yuborish imkonini beradi.
    await state.update_data(
        broadcast_chat_id=message.chat.id,
        broadcast_message_id=message.message_id,
    )
    await state.set_state(AdminPanelStates.waiting_for_broadcast_confirmation)

    try:
        telegram_ids = await admin_get_all_telegram_ids()
    except ApiError as error:
        await state.clear()
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await state.update_data(broadcast_recipient_count=len(telegram_ids))
    await message.answer(
        f"Yuqoridagi xabar <b>{len(telegram_ids)}</b> ta foydalanuvchiga "
        "yuboriladi. Tasdiqlaysizmi?",
        reply_markup=build_broadcast_confirm_keyboard(),
    )


@router.callback_query(
    AdminPanelStates.waiting_for_broadcast_confirmation,
    AdminBroadcastCallback.filter(F.action == "cancel"),
)
async def cancel_broadcast(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.answer("Bekor qilindi")
    await callback.message.edit_text(
        "🛠 <b>Admin panel</b>\n\nKerakli bo'limni tanlang:",
        reply_markup=build_admin_main_keyboard(),
    )


@router.callback_query(
    AdminPanelStates.waiting_for_broadcast_confirmation,
    AdminBroadcastCallback.filter(F.action == "confirm"),
)
async def confirm_broadcast(
    callback: types.CallbackQuery, state: FSMContext, bot: Bot
) -> None:
    data = await state.get_data()
    source_chat_id = data.get("broadcast_chat_id")
    source_message_id = data.get("broadcast_message_id")
    await state.clear()

    try:
        telegram_ids = await admin_get_all_telegram_ids()
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    await callback.answer()
    total = len(telegram_ids)
    progress_message = await callback.message.edit_text(
        _format_progress(0, 0, total)
    )

    # Katta hajmdagi (10 000-100 000+) foydalanuvchi ro'yxatida ham
    # ishonchli ishlashi uchun: har bir yuborishda throttling, flood-control
    # (RetryAfter) avtomatik kutish, va boshqa har qanday xatolik (bloklangan
    # foydalanuvchi, o'chirilgan chat va h.k.) yuborishni TO'XTATMAYDI -
    # shunchaki "yetkazilmadi" deb hisoblanadi va davom etiladi.
    sent_count = 0
    failed_count = 0

    for telegram_id in telegram_ids:
        try:
            await bot.copy_message(
                chat_id=telegram_id,
                from_chat_id=source_chat_id,
                message_id=source_message_id,
            )
            sent_count += 1
        except TelegramRetryAfter as flood_error:
            # Telegram flood-control: ko'rsatilgan vaqtni kutib, shu
            # foydalanuvchiga qayta urinib ko'ramiz (urinish behuda
            # ketmasligi uchun)
            await asyncio.sleep(flood_error.retry_after)
            try:
                await bot.copy_message(
                    chat_id=telegram_id,
                    from_chat_id=source_chat_id,
                    message_id=source_message_id,
                )
                sent_count += 1
            except Exception:
                failed_count += 1
        except Exception:
            # Bloklangan bot, o'chirilgan akkaunt va hokazo - bitta
            # foydalanuvchidagi xatolik butun jarayonni to'xtatmaydi
            failed_count += 1

        processed = sent_count + failed_count

        if processed % PROGRESS_UPDATE_EVERY == 0 or processed == total:
            try:
                await progress_message.edit_text(
                    _format_progress(sent_count, failed_count, total)
                )
            except TelegramBadRequest:
                pass  # matn o'zgarmagan bo'lsa - e'tiborsiz qoldiramiz

        await asyncio.sleep(BROADCAST_DELAY_SECONDS)

    await progress_message.edit_text(
        "✅ <b>Xabar yuborish yakunlandi</b>\n\n"
        f"Yuborildi: <b>{sent_count}</b>\n"
        f"Yetkazilmadi: <b>{failed_count}</b>\n"
        f"Jami: {total}"
    )


# ----- Majburiy obuna kanallarini boshqarish -----


def _extract_forwarded_channel(message: types.Message) -> types.Chat | None:
    """Admin kanaldan biror xabarni forward qilganda, o'sha kanalning
    chat obyektini qaytaradi (bot kanalga hali qo'shilmagan bo'lsa ham
    ishlaydi - chat_id'ni olishning eng ishonchli yo'li shu). Bot API
    versiyasiga qarab eski `forward_from_chat` yoki yangi
    `forward_origin` (MessageOriginChannel) maydoni to'ldirilgan bo'lishi
    mumkin - ikkalasi ham tekshiriladi."""
    if message.forward_from_chat is not None:
        return message.forward_from_chat

    origin = message.forward_origin
    if isinstance(origin, types.MessageOriginChannel):
        return origin.chat

    return None


async def _resolve_channel_from_text(bot: Bot, text: str) -> types.Chat:
    """@username, -100... ID yoki oddiy raqamni Chat obyektiga aylantiradi.
    Faqat ochiq (public) kanallar yoki bot allaqachon a'zo bo'lgan
    kanallar uchun ishlaydi - bot.get_chat Telegram tomonidan shunday
    cheklangan."""
    identifier: str | int = text
    if not text.startswith("@"):
        try:
            identifier = int(text)
        except ValueError:
            identifier = text
    return await bot.get_chat(identifier)


async def _render_channels_management(message: types.Message, page: int, edit: bool) -> None:
    try:
        channels = await admin_list_channels()
    except ApiError as error:
        text = f"❌ Xatolik: {error.message}"
        if edit:
            await message.edit_text(text)
        else:
            await message.answer(text)
        return

    active = [c for c in channels if c.get("isActive", True)]

    if not active:
        text = (
            "🔔 <b>Majburiy obuna kanallari</b>\n\n"
            "Hozircha hech qanday kanal qo'shilmagan."
        )
    else:
        lines = ["🔔 <b>Majburiy obuna kanallari</b>\n"]
        for ch in active:
            icon = "✅" if ch.get("status") == "active" else "⏳"
            title = ch.get("title") or ch.get("username") or str(ch.get("chatId"))
            lines.append(f"{icon} {title}")
        lines.append(
            "\n<i>✅ - bot admin, tekshiruv ishlaydi. "
            "⏳ - botni admin qilib qo'shishingiz kerak (kanal nomiga bosing).</i>"
        )
        text = "\n".join(lines)

    keyboard = build_channels_manage_keyboard(active, page=page)
    if edit:
        await message.edit_text(text, reply_markup=keyboard)
    else:
        await message.answer(text, reply_markup=keyboard)


@router.callback_query(AdminPanelCallback.filter(F.action == "channels"))
async def open_channels_management(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await _render_channels_management(callback.message, page=0, edit=True)
    await callback.answer()


@router.callback_query(AdminChannelManageCallback.filter(F.action == "page"))
async def change_channels_page(
    callback: types.CallbackQuery, callback_data: AdminChannelManageCallback
) -> None:
    await _render_channels_management(callback.message, page=callback_data.page, edit=True)
    await callback.answer()


@router.callback_query(AdminChannelManageCallback.filter(F.action == "delete"))
async def delete_channel(
    callback: types.CallbackQuery, callback_data: AdminChannelManageCallback
) -> None:
    try:
        await admin_delete_channel(callback_data.channel_id)
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    await callback.answer("✅ Kanal o'chirildi")
    await _render_channels_management(callback.message, page=0, edit=True)


@router.callback_query(AdminChannelManageCallback.filter(F.action == "recheck"))
async def recheck_channel(
    callback: types.CallbackQuery, callback_data: AdminChannelManageCallback, bot: Bot
) -> None:
    # Kanalning chat_id'sini olish uchun ro'yxatdan qidiramiz (callback'da
    # faqat bizning ichki ID'miz bor, Telegram chat_id emas).
    try:
        channels = await admin_list_channels()
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    channel = next((c for c in channels if c["id"] == callback_data.channel_id), None)
    if channel is None:
        await callback.answer("Kanal topilmadi", show_alert=True)
        return

    try:
        member = await bot.get_chat_member(channel["chatId"], bot.id)
    except Exception:
        await callback.answer(
            "❌ Bot hali bu kanalga admin sifatida qo'shilmagan.", show_alert=True
        )
        return

    if member.status not in ("administrator", "creator"):
        await callback.answer(
            "❌ Bot kanalda a'zo, lekin ADMIN emas. Iltimos, botga admin "
            "huquqini bering.",
            show_alert=True,
        )
        return

    try:
        await admin_update_channel_status(channel["id"], status="active")
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    await callback.answer("✅ Faollashtirildi! Endi obuna tekshiruvi ishlaydi.")
    await _render_channels_management(callback.message, page=0, edit=True)


@router.callback_query(AdminChannelManageCallback.filter(F.action == "add"))
async def request_new_channel(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminPanelStates.waiting_for_channel_input)
    await callback.answer()
    await callback.message.edit_text(
        "➕ <b>Yangi kanal qo'shish</b>\n\n"
        "Kanaldagi istalgan xabarni shu yerga forward qiling "
        "(yopiq kanallar uchun eng ishonchli usul) — "
        "yoki kanal @username'ini yoxud chat ID raqamini yuboring.\n\n"
        "Bekor qilish uchun /cancel yuboring."
    )


@router.message(AdminPanelStates.waiting_for_channel_input, F.text == "/cancel")
async def cancel_channel_input(message: types.Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Bekor qilindi.")
    await _render_channels_management(message, page=0, edit=False)


@router.message(AdminPanelStates.waiting_for_channel_input)
async def receive_channel_input(message: types.Message, state: FSMContext, bot: Bot) -> None:
    chat = _extract_forwarded_channel(message)

    if chat is None:
        text = (message.text or "").strip()
        if not text:
            await message.answer(
                "Kanaldan xabar forward qiling yoki @username/ID yuboring."
            )
            return
        try:
            chat = await _resolve_channel_from_text(bot, text)
        except Exception:
            await message.answer(
                "❌ Kanal topilmadi. Agar kanal yopiq (private) bo'lsa, "
                "@username o'rniga o'sha kanaldan bitta xabarni shu yerga "
                "forward qiling."
            )
            return

    if chat.type != "channel":
        await message.answer("❌ Bu kanal emas. Faqat kanallarni qo'shish mumkin.")
        return

    # Botning shu kanaldagi holatini tekshiramiz - bundan "admin qo'shilish
    # so'rovi" (pending) yoki "oddiy" (active) qo'shilishi kelib chiqadi.
    status = "pending"
    invite_link = None
    try:
        member = await bot.get_chat_member(chat.id, bot.id)
        if member.status in ("administrator", "creator"):
            status = "active"
            if not chat.username:
                try:
                    invite_link = await bot.export_chat_invite_link(chat.id)
                except Exception:
                    invite_link = None
    except Exception:
        status = "pending"

    try:
        channel = await admin_add_channel(
            chat_id=chat.id,
            title=chat.title or chat.username or str(chat.id),
            username=chat.username,
            invite_link=invite_link,
            status=status,
        )
    except ApiError as error:
        logger.exception("Kanal qo'shishda xatolik")
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await state.clear()

    if status == "active":
        await message.answer(
            "✅ Kanal qo'shildi va darhol faollashtirildi — bot allaqachon "
            "u yerda admin, obuna tekshiruvi ishlaydi."
        )
    else:
        await message.answer(
            "⏳ <b>Kanal qo'shildi, lekin hali FAOL emas.</b>\n\n"
            "Botni ushbu kanalga <b>administrator</b> sifatida qo'shing, "
            "so'ng quyidagi tugmani bosing:",
            reply_markup=build_channel_recheck_keyboard(channel["id"]),
        )

    await _render_channels_management(message, page=0, edit=False)


def _format_progress(sent: int, failed: int, total: int) -> str:
    processed = sent + failed
    percent = round((processed / total) * 100) if total else 100
    filled = round(percent / 10)
    bar = "█" * filled + "░" * (10 - filled)

    return (
        "📢 <b>Xabar yuborilmoqda...</b>\n\n"
        f"{bar} {percent}%\n\n"
        f"✅ Yuborildi: {sent}\n"
        f"❌ Yetkazilmadi: {failed}\n"
        f"📊 Jami: {processed}/{total}"
    )