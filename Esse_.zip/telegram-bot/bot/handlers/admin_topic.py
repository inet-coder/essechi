import logging

from aiogram import F, Router, types
from aiogram.fsm.context import FSMContext

from bot.api.client import ApiError, admin_create_topic
from bot.config import ADMIN_CHAT_ID
from bot.states.admin_topic_states import AdminTopicStates

router = Router()
logger = logging.getLogger(__name__)


@router.message(F.text == "➕ Mavzu qo'shish")
async def start_add_topic(message: types.Message, state: FSMContext) -> None:
    if message.from_user.id != ADMIN_CHAT_ID:
        return

    await state.clear()
    await state.set_state(AdminTopicStates.waiting_for_topic_text)
    await message.answer("Yangi mavzu (vaziyat) matnini yuboring:")


@router.message(AdminTopicStates.waiting_for_topic_text, F.text)
async def receive_topic_text(message: types.Message, state: FSMContext) -> None:
    await state.clear()

    try:
        await admin_create_topic(message.text)
    except ApiError as error:
        logger.exception("Mavzu qo'shishda xatolik")
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await message.answer("✅ Yangi mavzu qo'shildi.")