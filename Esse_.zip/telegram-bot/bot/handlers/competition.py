from aiogram import F, Router, types
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardMarkup, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.config import WEB_APP_URL

router = Router()


@router.message(F.text == "🏆 Musobaqa")
async def show_competitions(message: types.Message, state: FSMContext) -> None:
    # Reply tugma bosilganda - mini-app'ning musobaqalar sahifasini ochuvchi
    # inline WebApp tugmasini yuboramiz (stats/natijalar bilan bir xil naqsh).
    await state.clear()
    await message.answer(
        "🏆 <b>Musobaqalar</b>\n\n"
        "Esse musobaqalarida qatnashing, eng zo'rlar qatoriga chiqing va "
        "yutuqlarni qo'lga kiriting. Ochiq musobaqalarni ko'rish, qatnashish "
        "va natijalarni kuzatish uchun pastdagi tugmani bosing:",
        reply_markup=_get_competition_keyboard(),
    )


def _get_competition_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text="🏆 Musobaqalarni ochish",
        web_app=WebAppInfo(url=f"{WEB_APP_URL}/competitions"),
    )
    return builder.as_markup()
