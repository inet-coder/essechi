import asyncio
import logging
from io import BytesIO

from aiogram import Bot, F, Router, types
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext

from bot.api.client import (
    ApiError,
    evaluate_essay,
    extract_image_text,
    list_topics,
    submit_pdf_essay,
    submit_text_essay,
)
from bot.keyboards.common import CancelCallback, build_cancel_keyboard
from bot.keyboards.essay_keyboards import (
    OcrConfirmCallback,
    PageCallback,
    get_add_page_keyboard,
    get_confirm_ocr_keyboard,
    get_result_keyboard,
)
from bot.keyboards.main_menu import get_main_menu
from bot.config import (
    ADMIN_CHAT_ID,
    ESSAY_IMAGE_MAX_PAGES,
    ESSAY_IMAGE_PAGE_PRICE,
)
from bot.keyboards.topic_keyboards import (
    TopicCallback,
    TopicPageCallback,
    build_topic_keyboard,
    format_topics_text,
)
from bot.states.essay_states import EssayStates

router = Router()
logger = logging.getLogger(__name__)

MAX_PAGES = ESSAY_IMAGE_MAX_PAGES
ESSAY_INPUT_HINT = (
    "Endi shu vaziyat yuzasidan essengizni matn, PDF fayl yoki qog'ozga qo'lda "
    "yozib surating ko'rinishida yuboring (kamida 100 so'z)."
)


# ----- Mavzu tanlash bosqichi -----


@router.message(F.text == "📝 Esse yuborish")
async def start_essay_flow(message: types.Message, state: FSMContext) -> None:
    await state.clear()

    try:
        topics = await list_topics()
    except ApiError:
        logger.exception("Mavzular ro'yxatini olishda xatolik")
        topics = []

    # callback orqali keladigan topic_id'ni matnga moslashtirish uchun saqlaymiz
    await state.update_data(topics={t["id"]: t["text"] for t in topics})
    await state.set_state(EssayStates.choosing_topic)

    if topics:
        text = format_topics_text(topics, page=0)
    else:
        text = (
            "Hozircha tayyor mavzu yo'q. O'zingiz mavzu kiritmoqchi bo'lsangiz "
            "pastdagi tugmani bosing:"
        )

    await message.answer(text, reply_markup=build_topic_keyboard(topics))


@router.callback_query(EssayStates.choosing_topic, TopicPageCallback.filter())
async def change_topic_page(
    callback: types.CallbackQuery, callback_data: TopicPageCallback, state: FSMContext
) -> None:
    data = await state.get_data()
    topics_map = data.get("topics", {})
    topics = [{"id": topic_id, "text": text} for topic_id, text in topics_map.items()]

    await callback.message.edit_text(
        format_topics_text(topics, page=callback_data.page),
        reply_markup=build_topic_keyboard(topics, page=callback_data.page),
    )
    await callback.answer()


@router.callback_query(EssayStates.choosing_topic, TopicCallback.filter(F.action == "select"))
async def choose_existing_topic(
    callback: types.CallbackQuery, callback_data: TopicCallback, state: FSMContext
) -> None:
    data = await state.get_data()
    topic_text = data.get("topics", {}).get(callback_data.topic_id)

    if not topic_text:
        await callback.answer("Bu mavzu topilmadi, qaytadan urinib ko'ring.", show_alert=True)
        return

    await state.update_data(topic=topic_text)
    await state.set_state(EssayStates.waiting_for_essay)
    await callback.answer()
    await callback.message.edit_text(
        f"📋 <b>Vaziyat:</b>\n\n{topic_text}\n\n{ESSAY_INPUT_HINT}",
        reply_markup=build_cancel_keyboard(),
    )


@router.callback_query(EssayStates.choosing_topic, TopicCallback.filter(F.action == "custom"))
async def choose_custom_topic(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.set_state(EssayStates.waiting_for_custom_topic)
    await callback.answer()
    await callback.message.edit_text(
        "Mavzuni (vaziyat matnini) yozib yuboring:",
        reply_markup=build_cancel_keyboard(),
    )


@router.message(EssayStates.waiting_for_custom_topic, F.text)
async def receive_custom_topic(message: types.Message, state: FSMContext) -> None:
    await state.update_data(topic=message.text)
    await state.set_state(EssayStates.waiting_for_essay)
    await message.answer(
        f"Mavzu qabul qilindi. {ESSAY_INPUT_HINT}",
        reply_markup=build_cancel_keyboard(),
    )


@router.callback_query(
    StateFilter(
        EssayStates.choosing_topic,
        EssayStates.waiting_for_custom_topic,
        EssayStates.waiting_for_essay,
        EssayStates.editing_ocr_text,
    ),
    CancelCallback.filter(),
)
async def cancel_essay_flow(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.answer("Bekor qilindi")
    is_admin = callback.from_user.id == ADMIN_CHAT_ID
    await callback.message.delete()
    await callback.message.answer(
        "Bekor qilindi. Asosiy menyu:",
        reply_markup=get_main_menu(is_admin=is_admin),
    )


# ----- Esse qabul qilish bosqichi -----


async def _animate_progress(progress_message: types.Message, label: str) -> None:
    """Real progress yo'q (GPT bitta so'rov, oraliq hodisalarsiz), shuning
    uchun foydalanuvchiga kutish jarayoni "his qilinishi" uchun asta-sekin
    to'liqib boruvchi progress-bar simulyatsiya qilinadi. 90%da to'xtaydi -
    real natija kelganda xabar shu bilan almashtiriladi."""
    percent = 0
    try:
        while percent < 90:
            await asyncio.sleep(1.2)
            percent = min(percent + 7, 90)
            try:
                await progress_message.edit_text(_progress_bar_text(percent, label))
            except TelegramBadRequest:
                pass  # matn tasodifan o'zgarmagan bo'lsa - e'tiborsiz qoldiramiz
    except asyncio.CancelledError:
        pass


def _progress_bar_text(percent: int, label: str = "✍️ Esse tekshirilmoqda...") -> str:
    filled = round(percent / 10)
    bar = "█" * filled + "░" * (10 - filled)
    return f"{label}\n{bar} {percent}%"


async def _run_with_progress(
    message: types.Message, work, label: str = "✍️ Esse tekshirilmoqda..."
):
    """`work` - bajarilishi kutilayotgan coroutine. Shu davomida progress-bar
    animatsiya qilinadi. Xato bo'lsa ham progress to'xtatiladi va xato
    chaqiruvchiga uzatiladi (qayta tashlanadi)."""
    progress_message = await message.answer(_progress_bar_text(0, label))
    progress_task = asyncio.create_task(_animate_progress(progress_message, label))

    try:
        result = await work
    finally:
        progress_task.cancel()

    return progress_message, result


@router.message(EssayStates.waiting_for_essay, F.document)
async def handle_pdf_essay(message: types.Message, state: FSMContext, bot: Bot) -> None:
    document = message.document

    if document.mime_type != "application/pdf":
        await message.answer("Iltimos, faqat PDF formatdagi fayl yuboring.")
        return

    data = await state.get_data()
    topic = data.get("topic")
    if not topic:
        await message.answer('Avval mavzuni tanlang: "📝 Esse yuborish" tugmasini bosing.')
        await state.clear()
        return

    async def submit_and_evaluate():
        file_in_memory = BytesIO()
        await bot.download(document, destination=file_in_memory)
        file_bytes = file_in_memory.getvalue()

        essay = await submit_pdf_essay(
            telegram_id=message.from_user.id,
            topic=topic,
            file_bytes=file_bytes,
            filename=document.file_name or "essay.pdf",
        )
        result = await evaluate_essay(essay["id"])
        return essay, result

    try:
        progress_message, (essay, result) = await _run_with_progress(
            message, submit_and_evaluate()
        )
    except ApiError as error:
        logger.exception("PDF esseni tekshirishda xatolik")
        await state.clear()
        await message.answer(_format_api_error(error))
        return
    except Exception:
        # Kutilmagan (dasturiy) xatolik - bu yo'q bo'lsa ham foydalanuvchi
        # progress 90%da "muzlab qolgan" holatda hech qanday javobsiz
        # qoladi. Shuning uchun ApiError'dan tashqari HAR QANDAY xatolikni
        # ham ushlab, albatta javob qaytaramiz.
        logger.exception("PDF esseni tekshirishda kutilmagan xatolik")
        await state.clear()
        await message.answer(
            "❌ Kutilmagan xatolik yuz berdi. Iltimos, qayta urinib ko'ring."
        )
        return

    await state.clear()
    await _send_result(progress_message, essay["id"], result)


@router.message(EssayStates.waiting_for_essay, F.text)
async def handle_text_essay(message: types.Message, state: FSMContext) -> None:
    data = await state.get_data()
    topic = data.get("topic")
    if not topic:
        await message.answer('Avval mavzuni tanlang: "📝 Esse yuborish" tugmasini bosing.')
        await state.clear()
        return

    await _submit_text_and_show_result(
        message, state, telegram_id=message.from_user.id, topic=topic, text=message.text
    )


async def _submit_text_and_show_result(
    message: types.Message,
    state: FSMContext,
    *,
    telegram_id: int,
    topic: str,
    text: str,
    ocr_receipt: str | None = None,
) -> None:
    """Matnni (qo'lda yozilgan, PDF'dan yoki OCR'dan kelgan - farqi yo'q)
    yuborish + baholash + natijani ko'rsatish - barcha manbalar uchun umumiy
    yakuniy bosqich.

    ocr_receipt bo'lsa (rasm orqali kelgan, OCR bosqichida oldindan to'langan)
    - esse "prepaidCheck" bo'ladi, baholashda qayta pul/kredit olinmaydi.

    telegram_id ALOHIDA uzatiladi: OCR tasdiqlashda `message` bot yuborgan
    xabar bo'ladi (callback.message), uning from_user'i esa - bot, foydalanuvchi
    emas. Shuning uchun kimligini message'dan olib bo'lmaydi."""

    async def submit_and_evaluate():
        essay = await submit_text_essay(
            telegram_id=telegram_id,
            topic=topic,
            text=text,
            ocr_receipt=ocr_receipt,
        )
        result = await evaluate_essay(essay["id"])
        return essay, result

    try:
        progress_message, (essay, result) = await _run_with_progress(
            message, submit_and_evaluate()
        )
    except ApiError as error:
        logger.exception("Esseni tekshirishda xatolik")
        await state.clear()
        await message.answer(_format_api_error(error))
        return
    except Exception:
        # Kutilmagan (dasturiy) xatolik - bu yo'q bo'lsa ham foydalanuvchi
        # progress 90%da "muzlab qolgan" holatda hech qanday javobsiz
        # qoladi. Shuning uchun ApiError'dan tashqari HAR QANDAY xatolikni
        # ham ushlab, albatta javob qaytaramiz.
        logger.exception("Esseni tekshirishda kutilmagan xatolik")
        await state.clear()
        await message.answer(
            "❌ Kutilmagan xatolik yuz berdi. Iltimos, qayta urinib ko'ring."
        )
        return

    await state.clear()
    await _send_result(progress_message, essay["id"], result)


async def _send_result(progress_message: types.Message, essay_id: int, result: dict) -> None:
    text = _format_result_summary(result)
    keyboard = get_result_keyboard(essay_id) if result["status"] == "completed" else None
    # Progress-bar xabarining o'zini natija matniga aylantiramiz (yangi xabar
    # yubormaymiz) - bu chatni unday band qilmaydi va o'tish silliq ko'rinadi.
    await progress_message.edit_text(text, reply_markup=keyboard)


# ----- Qo'lyozma rasm orqali yuborish bosqichi -----


async def _download_photo_bytes(message: types.Message, bot: Bot) -> bytes:
    file_in_memory = BytesIO()
    await bot.download(message.photo[-1], destination=file_in_memory)
    return file_in_memory.getvalue()


@router.message(EssayStates.waiting_for_essay, F.photo)
async def handle_first_page_photo(message: types.Message, state: FSMContext, bot: Bot) -> None:
    data = await state.get_data()
    topic = data.get("topic")
    if not topic:
        await message.answer('Avval mavzuni tanlang: "📝 Esse yuborish" tugmasini bosing.')
        await state.clear()
        return

    photo_bytes = await _download_photo_bytes(message, bot)
    await state.update_data(pages=[photo_bytes])
    await state.set_state(EssayStates.collecting_pages)

    await message.answer(
        "1-varoq qabul qilindi ✅\n\n"
        f"⚠️ <b>Diqqat:</b> rasm orqali tekshirishda har bir varaq uchun "
        f"<b>{ESSAY_IMAGE_PAGE_PRICE} so'm</b> balansingizdan OLDINDAN yechiladi "
        f"(qo'lyozmani o'qish xizmati). Bunda paket krediti sarflanmaydi.\n\n"
        f"Agar essangiz davom etsa, keyingi varoq suratini yuboring "
        f"(eng ko'pi {MAX_PAGES} ta). Tugatgan bo'lsangiz, pastdagi tugmani bosing.",
        reply_markup=get_add_page_keyboard(),
    )


@router.message(EssayStates.collecting_pages, F.photo)
async def handle_additional_page_photo(
    message: types.Message, state: FSMContext, bot: Bot
) -> None:
    data = await state.get_data()
    pages: list[bytes] = data.get("pages", [])

    if len(pages) >= MAX_PAGES:
        await message.answer(
            f"Bir martada maksimal {MAX_PAGES} ta varoq yuborish mumkin. "
            "Tugatgan bo'lsangiz, pastdagi tugmani bosing.",
            reply_markup=get_add_page_keyboard(),
        )
        return

    photo_bytes = await _download_photo_bytes(message, bot)
    pages.append(photo_bytes)
    await state.update_data(pages=pages)

    await message.answer(
        f"{len(pages)}-varoq qabul qilindi ✅\n\n"
        "Yana varoq yuborishingiz yoki tugatishingiz mumkin.",
        reply_markup=get_add_page_keyboard(),
    )


@router.callback_query(EssayStates.collecting_pages, PageCallback.filter(F.action == "cancel"))
async def cancel_page_collection(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.answer("Bekor qilindi")
    is_admin = callback.from_user.id == ADMIN_CHAT_ID
    await callback.message.delete()
    await callback.message.answer(
        "Bekor qilindi. Asosiy menyu:",
        reply_markup=get_main_menu(is_admin=is_admin),
    )


@router.callback_query(EssayStates.collecting_pages, PageCallback.filter(F.action == "finish"))
async def finish_page_collection(callback: types.CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    pages: list[bytes] = data.get("pages", [])

    if not pages:
        await callback.answer("Avval kamida bitta rasm yuboring.", show_alert=True)
        return

    await callback.answer()
    await callback.message.edit_reply_markup(reply_markup=None)

    images = [(page_bytes, "image/jpeg") for page_bytes in pages]
    cost = len(pages) * ESSAY_IMAGE_PAGE_PRICE

    try:
        progress_message, ocr_result = await _run_with_progress(
            callback.message,
            extract_image_text(callback.from_user.id, images),
            label=(
                f"💳 {len(pages)} ta varaq × {ESSAY_IMAGE_PAGE_PRICE} = {cost} so'm "
                f"yechilmoqda...\n🔍 Qo'lyozma o'qilmoqda..."
            ),
        )
    except ApiError as error:
        logger.exception("Qo'lyozmani tanishda xatolik")
        await state.clear()
        await callback.message.answer(_format_api_error(error))
        return
    except Exception:
        logger.exception("Qo'lyozmani tanishda kutilmagan xatolik")
        await state.clear()
        await callback.message.answer(
            "❌ Kutilmagan xatolik yuz berdi. Iltimos, qayta urinib ko'ring."
        )
        return

    ocr_text = ocr_result["text"]
    # OCR kvitansiyasi - matn tasdiqlangach /text'ga yuboriladi, esse
    # "prepaidCheck" bo'ladi (baholashda qayta pul olinmaydi).
    await state.update_data(
        ocr_text=ocr_text, ocr_receipt=ocr_result.get("ocrReceipt"), pages=None
    )
    await state.set_state(EssayStates.confirming_ocr_text)

    await progress_message.edit_text(
        f"✅ To'lov qabul qilindi ({cost} so'm).\n\n"
        f"📄 <b>O'qilgan matn:</b>\n\n{ocr_text}\n\nMatn to'g'rimi?",
        reply_markup=get_confirm_ocr_keyboard(),
    )


@router.callback_query(
    EssayStates.confirming_ocr_text, OcrConfirmCallback.filter(F.action == "cancel")
)
async def cancel_ocr_confirmation(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.answer("Bekor qilindi")
    is_admin = callback.from_user.id == ADMIN_CHAT_ID
    await callback.message.delete()
    await callback.message.answer(
        "Bekor qilindi. Asosiy menyu:",
        reply_markup=get_main_menu(is_admin=is_admin),
    )


@router.callback_query(
    EssayStates.confirming_ocr_text, OcrConfirmCallback.filter(F.action == "edit")
)
async def request_ocr_text_edit(callback: types.CallbackQuery, state: FSMContext) -> None:
    await state.set_state(EssayStates.editing_ocr_text)
    await callback.answer()
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(
        "Matnni tuzatib, to'liq holda (boshidan oxirigacha) qayta yuboring:",
        reply_markup=build_cancel_keyboard(),
    )


@router.callback_query(
    EssayStates.confirming_ocr_text, OcrConfirmCallback.filter(F.action == "confirm")
)
async def confirm_ocr_text(callback: types.CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    topic = data.get("topic")
    ocr_text = data.get("ocr_text")
    ocr_receipt = data.get("ocr_receipt")

    if not topic or not ocr_text:
        await callback.answer("Xatolik yuz berdi, qaytadan urinib ko'ring.", show_alert=True)
        await state.clear()
        return

    await callback.answer()
    await callback.message.edit_reply_markup(reply_markup=None)
    await _submit_text_and_show_result(
        callback.message,
        state,
        telegram_id=callback.from_user.id,
        topic=topic,
        text=ocr_text,
        ocr_receipt=ocr_receipt,
    )


@router.message(EssayStates.editing_ocr_text, F.text)
async def handle_edited_ocr_text(message: types.Message, state: FSMContext) -> None:
    data = await state.get_data()
    topic = data.get("topic")
    ocr_receipt = data.get("ocr_receipt")
    if not topic:
        await message.answer('Avval mavzuni tanlang: "📝 Esse yuborish" tugmasini bosing.')
        await state.clear()
        return

    # Matn tahrirlangan bo'lsa ham kvitansiya o'sha (bir foydalanuvchi, 30 daqiqa
    # ichida) - prepaidCheck baribir amal qiladi, qayta pul olinmaydi.
    await _submit_text_and_show_result(
        message,
        state,
        telegram_id=message.from_user.id,
        topic=topic,
        text=message.text,
        ocr_receipt=ocr_receipt,
    )


def _format_api_error(error: ApiError) -> str:
    if error.status == 402:
        return (
            f"⚠️ {error.message}\n\n"
            "Balansni to'ldirish uchun \"💰 Balansni to'ldirish\" tugmasidan foydalaning."
        )
    return f"❌ Xatolik: {error.message}"


def _format_result_summary(result: dict) -> str:
    status = result["status"]

    if status == "failed":
        return (
            "❌ Tekshirishda texnik nosozlik yuz berdi. Hisobingizdan hech "
            "narsa yechilmadi. Iltimos, birozdan so'ng qayta urinib ko'ring."
        )

    if status == "auto_rejected":
        return (
            f"📊 <b>Natija: {result['scaledScore']}/75 ball</b>\n"
            f"(Esse mezoni bo'yicha: {result['totalScore']}/24)\n\n"
            f"Sabab: {result['rejectionReason']}"
        )

    return (
        f"📊 <b>Natija: {result['scaledScore']}/75 ball</b>\n"
        f"(Esse mezoni bo'yicha: {result['totalScore']}/24)\n\n"
        "To'liq tahlil (har bir mezon, xatolar va tavsiyalar) uchun pastdagi "
        "tugmadan foydalaning."
    )