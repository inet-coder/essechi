import logging

from aiogram import Bot, F, Router, types
from aiogram.fsm.context import FSMContext

from bot.api.client import ApiError, log_feedback
from bot.config import ADMIN_CHAT_ID
from bot.keyboards.common import (
    CANCEL_BUTTON_TEXT,
    build_cancel_reply_keyboard,
)
from bot.keyboards.guide_keyboards import (
    FeedbackReplyCallback,
    FeedbackStartCallback,
    build_feedback_reply_keyboard,
)
from bot.keyboards.main_menu import get_main_menu
from bot.states.feedback_states import FeedbackStates

router = Router()
logger = logging.getLogger(__name__)


# ----- Yozishmani boshlash / javob berish -----


@router.callback_query(FeedbackStartCallback.filter())
async def start_feedback(callback: types.CallbackQuery, state: FSMContext) -> None:
    """Foydalanuvchi qo'llanma ostidagi «Savol va takliflar» ni bosdi -
    xabar adminga yuboriladi."""
    await state.set_state(FeedbackStates.writing)
    await state.update_data(to_id=ADMIN_CHAT_ID)
    await callback.answer()
    await callback.message.answer(
        "💬 Savolingiz yoki taklifingizni yozib yuboring. Xabaringiz "
        "administratorga yetkaziladi.",
        reply_markup=build_cancel_reply_keyboard(),
    )


@router.callback_query(FeedbackReplyCallback.filter())
async def reply_feedback(
    callback: types.CallbackQuery,
    callback_data: FeedbackReplyCallback,
    state: FSMContext,
) -> None:
    """Kelgan xabar ostidagi «Javob berish» tugmasi - ikkala tomon ham
    ishlatadi (to_id - javob yuboriladigan tomon)."""
    await state.set_state(FeedbackStates.writing)
    await state.update_data(to_id=callback_data.to_id)
    await callback.answer()
    await callback.message.answer(
        "✍️ Javobingizni yozib yuboring:",
        reply_markup=build_cancel_reply_keyboard(),
    )


# ----- Bekor qilish (writing holatida) -----


@router.message(FeedbackStates.writing, F.text == CANCEL_BUTTON_TEXT)
async def cancel_feedback(message: types.Message, state: FSMContext) -> None:
    await state.clear()
    is_admin = message.from_user.id == ADMIN_CHAT_ID
    await message.answer(
        "Bekor qilindi.",
        reply_markup=get_main_menu(is_admin=is_admin),
    )


# ----- Xabarni yetkazish -----


@router.message(FeedbackStates.writing, F.text)
async def deliver_feedback(
    message: types.Message, state: FSMContext, bot: Bot
) -> None:
    data = await state.get_data()
    to_id = data.get("to_id")
    await state.clear()

    sender = message.from_user
    is_admin_sender = sender.id == ADMIN_CHAT_ID
    text = message.text

    if not to_id:
        await message.answer(
            "Xatolik yuz berdi, qaytadan urinib ko'ring.",
            reply_markup=get_main_menu(is_admin=is_admin_sender),
        )
        return

    if is_admin_sender:
        # Admin -> foydalanuvchi (javob). Yozishmadagi foydalanuvchi - to_id.
        outgoing_text = f"📨 <b>Administrator javobi:</b>\n\n{text}"
        reply_keyboard = build_feedback_reply_keyboard(to_id=ADMIN_CHAT_ID)
        feedback_user_id = to_id
        direction = "outgoing"
        sender_confirmation = "✅ Javob foydalanuvchiga yuborildi."
    else:
        # Foydalanuvchi -> admin (savol/taklif yoki javob).
        name = sender.full_name or sender.username or "Foydalanuvchi"
        outgoing_text = (
            "📨 <b>Yangi savol/taklif</b>\n"
            f"👤 {name} (<code>{sender.id}</code>):\n\n{text}"
        )
        reply_keyboard = build_feedback_reply_keyboard(to_id=sender.id)
        feedback_user_id = sender.id
        direction = "incoming"
        sender_confirmation = (
            "✅ Xabaringiz administratorga yuborildi. Javob shu yerda "
            "keladi."
        )

    # Xabarni yetkazamiz.
    try:
        await bot.send_message(to_id, outgoing_text, reply_markup=reply_keyboard)
    except Exception:
        logger.exception("Yozishma xabarini yetkazishda xatolik (to_id=%s)", to_id)
        await message.answer(
            "❌ Xabarni yetkazib bo'lmadi. Iltimos, birozdan so'ng qayta "
            "urinib ko'ring.",
            reply_markup=get_main_menu(is_admin=is_admin_sender),
        )
        return

    # Tarixга saqlaymiz (best-effort - yetkazishga to'sqinlik qilmaydi).
    try:
        await log_feedback(
            telegram_id=feedback_user_id, direction=direction, message=text
        )
    except ApiError:
        logger.exception("Yozishmani saqlashda xatolik")

    await message.answer(
        sender_confirmation,
        reply_markup=get_main_menu(is_admin=is_admin_sender),
    )
