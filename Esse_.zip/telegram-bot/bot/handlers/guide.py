import logging

from aiogram import F, Router, types
from aiogram.fsm.context import FSMContext

from bot.api.client import ApiError, get_guide
from bot.keyboards.guide_keyboards import GuideCallback, build_guide_keyboard

router = Router()
logger = logging.getLogger(__name__)

_NO_VIDEO_TEXT = (
    "📖 <b>Qo'llanma</b>\n\n"
    "Hozircha qo'llanma videosi qo'shilmagan.\n\n"
    "Savolingiz yoki taklifingiz bo'lsa, quyidagi tugma orqali bizga "
    "yozishingiz mumkin."
)


@router.message(F.text == "📖 Qo'llanma")
async def show_guide(message: types.Message, state: FSMContext) -> None:
    await state.clear()

    try:
        guide = await get_guide()
    except ApiError:
        logger.exception("Qo'llanmani olishda xatolik")
        guide = {"videoFileId": None, "description": None}

    video_file_id = guide.get("videoFileId")
    description = guide.get("description") or (
        "📖 <b>Qo'llanma</b>\n\nBotdan qanday foydalanishni quyidagi videoda "
        "ko'rishingiz mumkin."
    )

    keyboard = build_guide_keyboard()

    if video_file_id:
        try:
            await message.answer_video(
                video=video_file_id,
                caption=description,
                reply_markup=keyboard,
            )
            return
        except Exception:
            # file_id eskirgan/yaroqsiz bo'lsa - matnli variantga o'tamiz.
            logger.exception("Qo'llanma videosini yuborishda xatolik")

    await message.answer(_NO_VIDEO_TEXT, reply_markup=keyboard)


@router.callback_query(GuideCallback.filter(F.action == "back"))
async def guide_back(callback: types.CallbackQuery) -> None:
    await callback.answer()
    try:
        await callback.message.delete()
    except Exception:
        pass
