from datetime import datetime

from aiogram import F, Router, types
from aiogram.filters.callback_data import CallbackData
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.api.client import ApiError, get_user_payments, get_user_summary

router = Router()

DIVIDER = "─────────────────"


class ProfileNavCallback(CallbackData, prefix="profile_nav"):
    action: str  # "payments" | "back"


@router.message(F.text == "👤 Profilim")
async def show_profile(message: types.Message, state: FSMContext) -> None:
    await state.clear()

    try:
        summary = await get_user_summary(message.from_user.id)
    except ApiError as error:
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await message.answer(_format_profile(summary), reply_markup=_get_profile_keyboard())


@router.callback_query(ProfileNavCallback.filter(F.action == "payments"))
async def show_payments(callback: types.CallbackQuery) -> None:
    try:
        payments = await get_user_payments(callback.from_user.id)
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    await callback.message.edit_text(
        _format_payments(payments), reply_markup=_get_back_keyboard()
    )
    await callback.answer()


@router.callback_query(ProfileNavCallback.filter(F.action == "back"))
async def back_to_profile(callback: types.CallbackQuery) -> None:
    try:
        summary = await get_user_summary(callback.from_user.id)
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    await callback.message.edit_text(
        _format_profile(summary), reply_markup=_get_profile_keyboard()
    )
    await callback.answer()


def _format_profile(s: dict) -> str:
    lines = [
        "👤 <b>Profilim</b>",
        DIVIDER,
        f"Ism: <b>{s.get('firstName') or '-'}</b>",
        f"Ro'yxatdan o'tgan: {_format_date(s['createdAt'])}",
        "",
        f"💰 Balans: <b>{s['balance']} so'm</b>",
        f"📦 Esse tekshiruv qoldig'i: <b>{s.get('essayCredits', 0)}</b> ta",
        f"📝 Jami esselar: <b>{s['totalEssayCount']}</b> ta "
        f"({s['checkedEssayCount']} ta tekshirilgan)",
    ]

    if s.get("bestScaledScore") is not None:
        lines.append("")
        lines.append(f"🏆 Eng yaxshi natija: <b>{s['bestScaledScore']}/75</b>")
        lines.append(f"📊 O'rtacha natija: <b>{s['averageScaledScore']}/75</b>")

    weakest = s.get("weakestBand")
    if weakest:
        lines.append("")
        lines.append(
            "⚠️ Eng ko'p e'tibor talab qiladi:\n"
            f"<b>{weakest['criterionName']}</b> (o'rtacha {weakest['averageScore']:.1f}/2)"
        )

    return "\n".join(lines)


def _format_payments(payments: list[dict]) -> str:
    if not payments:
        return "💳 <b>To'lovlarim</b>\n" + DIVIDER + "\n\nSiz hali balans to'ldirmagansiz."

    lines = ["💳 <b>To'lovlarim</b>", DIVIDER, ""]
    total = 0
    for p in payments:
        total += p["amount"]
        date_str = _format_date(p["createdAt"])
        if p.get("kind") == "package":
            note_part = f" — 📦 {p.get('essayCredits', 0)} ta esse paketi"
        elif p.get("note"):
            note_part = f" — {p['note']}"
        else:
            note_part = ""
        lines.append(f"• {date_str}: <b>+{p['amount']} so'm</b>{note_part}")

    lines.append("")
    lines.append(DIVIDER)
    lines.append(f"Jami: <b>{total} so'm</b>")

    return "\n".join(lines)


def _format_date(iso_string: str) -> str:
    dt = datetime.fromisoformat(iso_string.replace("Z", "+00:00"))
    return dt.strftime("%d.%m.%Y")


def _get_profile_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text="💳 To'lovlarim",
        callback_data=ProfileNavCallback(action="payments"),
    )
    return builder.as_markup()


def _get_back_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text="⬅️ Orqaga",
        callback_data=ProfileNavCallback(action="back"),
    )
    return builder.as_markup()