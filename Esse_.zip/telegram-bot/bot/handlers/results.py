from datetime import datetime

from aiogram import F, Router, types
from aiogram.filters.callback_data import CallbackData
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardMarkup, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.api.client import ApiError, get_user_history
from bot.config import WEB_APP_URL

router = Router()

PAGE_SIZE = 5


class ResultsPageCallback(CallbackData, prefix="results_page"):
    page: int


@router.message(F.text == "📋 Natijalarim")
async def show_results(message: types.Message, state: FSMContext) -> None:
    await state.clear()
    await _render_page(message, page=0)


@router.callback_query(ResultsPageCallback.filter())
async def change_results_page(
    callback: types.CallbackQuery, callback_data: ResultsPageCallback
) -> None:
    await _render_page(callback.message, page=callback_data.page, edit=True)
    await callback.answer()


async def _render_page(message: types.Message, page: int, edit: bool = False) -> None:
    try:
        essays = await get_user_history(message.chat.id)
    except ApiError as error:
        text = f"❌ Xatolik: {error.message}"
        if edit:
            await message.edit_text(text)
        else:
            await message.answer(text)
        return

    if not essays:
        text = "Siz hali birorta esse yubormagansiz."
        if edit:
            await message.edit_text(text)
        else:
            await message.answer(text)
        return

    total_pages = (len(essays) + PAGE_SIZE - 1) // PAGE_SIZE
    page = max(0, min(page, total_pages - 1))
    start = page * PAGE_SIZE
    page_essays = essays[start : start + PAGE_SIZE]

    lines = ["📋 <b>Natijalarim</b>\n"]
    for i, essay in enumerate(page_essays, start=start + 1):
        lines.append(_format_essay_line(i, essay))

    keyboard = _build_keyboard(page_essays, start, page, total_pages)
    text = "\n".join(lines)

    if edit:
        await message.edit_text(text, reply_markup=keyboard)
    else:
        await message.answer(text, reply_markup=keyboard)


def _format_essay_line(number: int, essay: dict) -> str:
    date_str = _format_date(essay["createdAt"])
    topic_preview = _truncate(essay["topic"], 40)
    result = essay.get("evaluationResult")

    if result is None:
        status_part = "⏳ tekshirilmagan"
    else:
        status = result["status"]
        score = result["scaledScore"]
        if status == "completed":
            status_part = f"✅ {score}/75 ball"
        elif status == "auto_rejected":
            status_part = f"⚠️ {score}/75 ball"
        else:
            status_part = "❌ xatolik"

    return f"<b>{number}.</b> {date_str} — {topic_preview}\n   {status_part}"


def _truncate(text: str, limit: int) -> str:
    return text[:limit] + "..." if len(text) > limit else text


def _format_date(iso_string: str) -> str:
    dt = datetime.fromisoformat(iso_string.replace("Z", "+00:00"))
    return dt.strftime("%d.%m.%Y")


def _build_keyboard(
    page_essays: list[dict], start: int, page: int, total_pages: int
) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()

    # Har bir esse uchun raqamlangan web_app tugma - bosilganda shu essening
    # tafsilot sahifasiga olib boradi
    for i, essay in enumerate(page_essays, start=start + 1):
        builder.button(
            text=str(i),
            web_app=WebAppInfo(url=f"{WEB_APP_URL}/essay/{essay['id']}"),
        )
    builder.adjust(len(page_essays))

    # Sahifalash tugmalari - faqat kerak bo'lganda ko'rsatiladi
    nav_row = []
    if page > 0:
        nav_row.append(
            types.InlineKeyboardButton(
                text="⬅️ Oldingi",
                callback_data=ResultsPageCallback(page=page - 1).pack(),
            )
        )
    if page < total_pages - 1:
        nav_row.append(
            types.InlineKeyboardButton(
                text="Keyingi ➡️",
                callback_data=ResultsPageCallback(page=page + 1).pack(),
            )
        )
    if nav_row:
        builder.row(*nav_row)

    builder.row(
        types.InlineKeyboardButton(
            text="🌐 Barchasini web panelda ko'rish",
            web_app=WebAppInfo(url=WEB_APP_URL),
        )
    )

    return builder.as_markup()