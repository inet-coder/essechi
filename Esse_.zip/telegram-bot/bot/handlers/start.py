import logging

from aiogram import Bot, F, Router, types
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext

from bot.api.client import ApiError, get_user, register_user
from bot.config import ADMIN_CHAT_ID
from bot.keyboards.main_menu import get_main_menu
from bot.keyboards.subscription_keyboards import build_subscription_keyboard
from bot.states.registration_states import RegistrationStates
from bot.utils.subscription import get_missing_channels

router = Router()
logger = logging.getLogger(__name__)

MAX_NAME_LENGTH = 64


async def _is_registered(telegram_id: int) -> bool:
    """Foydalanuvchi bazada bor (ro'yxatdan o'tgan) yoki yo'qligini tekshiradi."""
    try:
        await get_user(telegram_id)
        return True
    except ApiError as error:
        if error.status == 404:
            return False
        raise


async def _needs_subscription(message: types.Message, bot: Bot, is_admin: bool) -> bool:
    """Majburiy obuna talab qilinsa - gate ko'rsatib True qaytaradi."""
    if is_admin:
        return False
    missing = await get_missing_channels(bot, message.from_user.id)
    if not missing:
        return False
    await message.answer(
        "🔔 <b>Davom etishdan oldin quyidagi kanallarga obuna bo'ling</b>\n\n"
        "Obuna bo'lgach, \"✅ Obuna bo'ldim\" tugmasini bosing.",
        reply_markup=build_subscription_keyboard(missing),
    )
    return True


# Obuna tasdiqlangach (yoki umuman talab qilinmasa) chaqiriladi. Foydalanuvchi
# hali ro'yxatdan o'tmagan bo'lsa - ismini so'raydi, aks holda menyuni ko'rsatadi.
# target - message (start'da) yoki callback.message (obuna tugmasidan keyin).
# telegram_id - HAQIQIY foydalanuvchi id'si (callback.message.from_user emas!).
async def continue_onboarding(
    target: types.Message, telegram_id: int, state: FSMContext, is_admin: bool
) -> None:
    try:
        registered = await _is_registered(telegram_id)
    except ApiError:
        logger.exception("Ro'yxatdan o'tishni tekshirishda xatolik")
        await target.answer("Xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring.")
        return

    if registered:
        await target.answer(
            "Quyidagi menyudan kerakli bo'limni tanlang.",
            reply_markup=get_main_menu(is_admin=is_admin),
        )
        return

    # Ro'yxatdan o'tmagan - ismini so'raymiz.
    await state.set_state(RegistrationStates.waiting_for_name)
    await target.answer(
        "Tanishib olaylik 🙂\n\n"
        "Iltimos, <b>ismingizni</b> kiriting — bu ism reyting va natijalarda "
        "ko'rinadi:"
    )


@router.message(CommandStart())
async def handle_start(message: types.Message, bot: Bot, state: FSMContext) -> None:
    # /start har doim toza boshlaydi (yarim qolgan holatlarni tozalaymiz).
    await state.clear()
    is_admin = message.from_user.id == ADMIN_CHAT_ID

    await message.answer(
        "Assalomu alaykum! Milliy sertifikat esse tekshirish botiga xush kelibsiz."
    )

    # Avval obuna (agar talab qilinsa) - obuna bo'lgach ism so'raladi. Bu tartib
    # ism xabari obuna gate'iga tushib qolmasligi uchun muhim.
    if await _needs_subscription(message, bot, is_admin):
        return

    await continue_onboarding(message, message.from_user.id, state, is_admin)


@router.message(RegistrationStates.waiting_for_name, F.text)
async def handle_registration_name(
    message: types.Message, bot: Bot, state: FSMContext
) -> None:
    name = (message.text or "").strip()

    if name.startswith("/"):
        # Buyruqlarni ism deb qabul qilmaymiz (/start CommandStart'da ushlangan).
        await message.answer("Iltimos, ismingizni oddiy matn ko'rinishida kiriting:")
        return
    if not name:
        await message.answer(
            "Ism bo'sh bo'lishi mumkin emas. Iltimos, ismingizni kiriting:"
        )
        return
    if len(name) > MAX_NAME_LENGTH:
        await message.answer(
            f"Ism juda uzun. Iltimos, {MAX_NAME_LENGTH} belgidan oshmagan ism kiriting:"
        )
        return

    try:
        await register_user(
            telegram_id=message.from_user.id,
            first_name=name,
            username=message.from_user.username,
        )
    except ApiError:
        logger.exception("Foydalanuvchini ro'yxatdan o'tkazishda xatolik")
        await message.answer(
            "Ro'yxatdan o'tishda xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring."
        )
        return

    await state.clear()
    is_admin = message.from_user.id == ADMIN_CHAT_ID
    await message.answer(f"Rahmat, <b>{name}</b>! Ro'yxatdan muvaffaqiyatli o'tdingiz ✅")
    await message.answer(
        "Quyidagi menyudan kerakli bo'limni tanlang.",
        reply_markup=get_main_menu(is_admin=is_admin),
    )
