from aiogram import F, Router, types
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardMarkup, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.config import WEB_APP_URL

router = Router()


@router.message(F.text == "📊 Statistika")
async def show_stats(message: types.Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "📊 Mezon bo'yicha shaxsiy statistikangizni (eng kuchli va zaif "
        "tomonlaringizni) ko'rish uchun pastdagi tugmani bosing:",
        reply_markup=_get_stats_keyboard(),
    )


def _get_stats_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text="📊 Statistikani ko'rish",
        web_app=WebAppInfo(url=f"{WEB_APP_URL}/stats"),
    )
    return builder.as_markup()