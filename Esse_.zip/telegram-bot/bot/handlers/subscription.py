from aiogram import Bot, F, Router, types
from aiogram.fsm.context import FSMContext

from bot.config import ADMIN_CHAT_ID
from bot.handlers.start import continue_onboarding
from bot.keyboards.subscription_keyboards import (
    SubscriptionCheckCallback,
    build_subscription_keyboard,
)
from bot.utils.subscription import get_missing_channels

router = Router()


@router.callback_query(SubscriptionCheckCallback.filter(F.action == "check"))
async def check_subscription(
    callback: types.CallbackQuery, bot: Bot, state: FSMContext
) -> None:
    missing = await get_missing_channels(bot, callback.from_user.id)

    if missing:
        await callback.answer(
            "❌ Hali barcha kanallarga obuna bo'lmadingiz.", show_alert=True
        )
        await callback.message.edit_reply_markup(
            reply_markup=build_subscription_keyboard(missing)
        )
        return

    await callback.answer("✅ Obuna tasdiqlandi!")
    await callback.message.edit_text("✅ Obuna tasdiqlandi! Botdan foydalanishingiz mumkin.")

    # Obuna bo'lgach: ro'yxatdan o'tmagan bo'lsa ism so'raladi, aks holda menyu.
    is_admin = callback.from_user.id == ADMIN_CHAT_ID
    await continue_onboarding(callback.message, callback.from_user.id, state, is_admin)
