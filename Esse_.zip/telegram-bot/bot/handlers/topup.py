import logging

from aiogram import Bot, F, Router, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext

from bot.api.client import (
    ApiError,
    admin_topup_balance,
    create_package_pending,
    create_pending_topup,
    get_payment_status,
    get_user,
    list_packages,
)
from bot.config import ADMIN_CHAT_ID, MIN_TOPUP_AMOUNT
from bot.keyboards.common import CANCEL_BUTTON_TEXT, build_cancel_reply_keyboard
from bot.keyboards.main_menu import get_main_menu
from bot.keyboards.topup_keyboards import (
    PackageCallback,
    PaymentCheckCallback,
    TopupCallback,
    TopupMenuCallback,
    TopupProviderCallback,
    build_admin_topup_keyboard,
    build_packages_keyboard,
    build_payment_card_keyboard,
    build_provider_keyboard,
    build_topup_root_keyboard,
)
from bot.states.topup_states import AdminTopupStates, TopupStates

router = Router()
logger = logging.getLogger(__name__)


def _parse_amount(text: str) -> int | None:
    text = text.strip()
    if not text.isdigit():
        return None
    amount = int(text)
    return amount if amount > 0 else None


def _format_card(raw: str) -> tuple[str, str]:
    """(faqat_raqamlar, 4talab_ajratilgan_ko'rinish) qaytaradi."""
    digits = "".join(ch for ch in raw if ch.isdigit())
    grouped = " ".join(digits[i : i + 4] for i in range(0, len(digits), 4))
    return digits, grouped


# ----- Foydalanuvchi tomoni -----


@router.message(F.text == "💰 Balansni to'ldirish")
async def start_topup(message: types.Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "💳 Nimani to'ldiramiz?",
        reply_markup=build_topup_root_keyboard(),
    )


@router.callback_query(TopupMenuCallback.filter())
async def topup_menu_selected(
    callback: types.CallbackQuery,
    callback_data: TopupMenuCallback,
    state: FSMContext,
) -> None:
    await state.clear()

    if callback_data.section == "balance":
        await callback.message.edit_text(
            "💳 Kerakli to'lov tizimini tanlang:",
            reply_markup=build_provider_keyboard(),
        )
        await callback.answer()
        return

    if callback_data.section == "packages":
        try:
            packages = await list_packages()
        except ApiError as error:
            await callback.answer(f"Xatolik: {error.message}", show_alert=True)
            return

        lines = [
            "📦 <b>Esse tekshiruv paketlari</b>",
            "",
            "Har bir paket esse tekshiruvi uchun ishlatiladi. Balansdan "
            "(so'm) alohida hisoblanadi — paket faqat esse tekshirishga "
            "sarflanadi.",
            "",
            "⏳ Har bir paket sotib olingandan so'ng <b>30 kun</b> amal qiladi.",
            "",
            "Kerakli paketni tanlang:",
        ]
        await callback.message.edit_text(
            "\n".join(lines),
            reply_markup=build_packages_keyboard(packages),
        )
        await callback.answer()
        return

    # section == "root" (orqaga)
    await callback.message.edit_text(
        "💳 Nimani to'ldiramiz?",
        reply_markup=build_topup_root_keyboard(),
    )
    await callback.answer()


@router.callback_query(PackageCallback.filter())
async def package_selected(
    callback: types.CallbackQuery,
    callback_data: PackageCallback,
    state: FSMContext,
) -> None:
    await state.clear()

    try:
        payment = await create_package_pending(
            telegram_id=callback.from_user.id,
            package_id=callback_data.package_id,
        )
    except ApiError as error:
        await callback.answer(f"❌ {error.message}", show_alert=True)
        return

    # Qayta bosilmasligi uchun inline tugmalarni olib tashlaymiz.
    try:
        await callback.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass
    await callback.answer()

    is_admin = callback.from_user.id == ADMIN_CHAT_ID
    card_digits, card_display = _format_card(payment["cardNumber"])

    text = (
        "✅ <b>Paket tanlandi!</b>\n\n"
        f"📦 Paket: <b>{payment['essayCredits']}</b> ta esse tekshiruvi\n"
        f"🆔 To'lov ID: <code>{payment['id']}</code>\n"
        f"💵 To'lov summasi: <b>{payment['amount']}</b> so'm\n"
        f"💳 To'lov uchun: <code>{card_display}</code>\n"
        f"📑 I.F.O : <b>{payment['cardHolder']}</b>\n"
        f"⏰ To'lovni amalga oshirish uchun berilgan vaqt: "
        f"<b>{payment['expiryMinutes']} daqiqa</b>\n\n"
        "⚠️ To'lovda summani AYNAN yuqoridagidek kiriting — u shu paketga "
        "bog'langan.\n"
        "✅ To'lov qilganingizdan so'ng paket avtomatik hisobingizga qo'shiladi."
    )

    await callback.message.answer(
        text, reply_markup=build_payment_card_keyboard(card_digits, payment["id"])
    )
    await callback.message.answer(
        "⬇️ Asosiy menyu", reply_markup=get_main_menu(is_admin=is_admin)
    )


@router.callback_query(TopupProviderCallback.filter())
async def provider_selected(
    callback: types.CallbackQuery,
    callback_data: TopupProviderCallback,
    state: FSMContext,
) -> None:
    if callback_data.provider == "missing":
        await callback.answer(
            "Qidirgan to'lov tizimingiz ro'yxatda bo'lmasa ham, "
            "«Istalgan to'lov tizimi orqali» ni tanlang - to'lov baribir "
            "o'sha kartaga o'tadi.",
            show_alert=True,
        )
        return

    await state.set_state(TopupStates.waiting_for_amount)
    await state.update_data(provider=callback_data.provider)

    # Provayder tanlangach, qayta bosilmasligi uchun inline tugmalarni olib
    # tashlaymiz.
    try:
        await callback.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass

    await callback.answer()
    await callback.message.answer(
        "💵 Hisobingizni necha so'mga to'ldirmoqchisiz?\n\n"
        f"⬇️ Minimal miqdor: {MIN_TOPUP_AMOUNT} so'm",
        reply_markup=build_cancel_reply_keyboard(),
    )


@router.message(TopupStates.waiting_for_amount, F.text == CANCEL_BUTTON_TEXT)
async def cancel_topup_flow(message: types.Message, state: FSMContext) -> None:
    await state.clear()
    is_admin = message.from_user.id == ADMIN_CHAT_ID
    await message.answer(
        "Bekor qilindi. Asosiy menyu:",
        reply_markup=get_main_menu(is_admin=is_admin),
    )


@router.message(TopupStates.waiting_for_amount, F.text)
async def receive_amount(message: types.Message, state: FSMContext) -> None:
    amount = _parse_amount(message.text)

    if amount is None or amount < MIN_TOPUP_AMOUNT:
        await message.answer(
            f"Iltimos, kamida {MIN_TOPUP_AMOUNT} so'm miqdorini raqamda kiriting "
            "(masalan: 5000).",
            reply_markup=build_cancel_reply_keyboard(),
        )
        return

    data = await state.get_data()
    provider = data.get("provider", "any")

    try:
        payment = await create_pending_topup(
            telegram_id=message.from_user.id, amount=amount, provider=provider
        )
    except ApiError as error:
        await state.clear()
        is_admin = message.from_user.id == ADMIN_CHAT_ID
        await message.answer(
            f"❌ Xatolik: {error.message}",
            reply_markup=get_main_menu(is_admin=is_admin),
        )
        return

    await state.clear()
    is_admin = message.from_user.id == ADMIN_CHAT_ID

    card_digits, card_display = _format_card(payment["cardNumber"])

    text = (
        "✅ <b>To'lov miqdori qabul qilindi!</b>\n\n"
        f"🆔 To'lov ID: <code>{payment['id']}</code>\n"
        f"💵 Miqdori: <b>{payment['amount']}</b> so'm\n"
        f"💳 To'lov uchun: <code>{card_display}</code>\n"
        f"📑 I.F.O : <b>{payment['cardHolder']}</b>\n"
        f"⏰ To'lovni amalga oshirish uchun berilgan vaqt: "
        f"<b>{payment['expiryMinutes']} daqiqa</b>\n\n"
        "✅ To'lov qilganingizdan so'ng to'lov avtomatik qabul qilinadi."
    )

    await message.answer(
        text, reply_markup=build_payment_card_keyboard(card_digits, payment["id"])
    )
    await message.answer("⬇️ Asosiy menyu", reply_markup=get_main_menu(is_admin=is_admin))


def _format_remaining(seconds: int) -> str:
    """Soniyani 'M daqiqa S soniya' ko'rinishiga keltiradi."""
    minutes, secs = divmod(max(0, seconds), 60)
    if minutes and secs:
        return f"{minutes} daqiqa {secs} soniya"
    if minutes:
        return f"{minutes} daqiqa"
    return f"{secs} soniya"


@router.callback_query(PaymentCheckCallback.filter())
async def check_payment_remaining(
    callback: types.CallbackQuery, callback_data: PaymentCheckCallback
) -> None:
    """«⏳ Qolgan vaqtni tekshirish» tugmasi: to'lovga qancha vaqt qolganini
    yoki muddati tugagan bo'lsa qayta urinish mumkinligini alert'da ko'rsatadi."""
    try:
        status = await get_payment_status(callback_data.payment_id)
    except ApiError as error:
        await callback.answer(f"❌ {error.message}", show_alert=True)
        return

    state = status.get("status")

    if state == "confirmed":
        await callback.answer(
            "✅ To'lovingiz allaqachon qabul qilingan. Rahmat!",
            show_alert=True,
        )
        return

    if state == "pending":
        remaining = _format_remaining(status.get("secondsLeft", 0))
        await callback.answer(
            f"⏳ To'lov muddati tugashiga {remaining} qoldi.\n\n"
            "Shu vaqt ichida summani AYNAN ko'rsatilgandek yuboring — "
            "to'lov avtomatik qabul qilinadi.",
            show_alert=True,
        )
        return

    # expired yoki boshqa holat
    await callback.answer(
        "⏰ Bu to'lov muddati tugagan. To'lov amalga oshmadi.\n\n"
        "Endi «💰 Balansni to'ldirish» tugmasi orqali yangi to'lov "
        "yaratishingiz mumkin.",
        show_alert=True,
    )


# ----- Admin tomoni (qo'lda tasdiqlash - zaxira variant) -----


# Admin ISTALGAN foydalanuvchiga ISTALGAN summani to'g'ridan-to'g'ri o'tkazadi.
# Foydalanish: /berish <telegram_id> <summa>
@router.message(Command("berish"))
async def admin_give_balance(message: types.Message, bot: Bot) -> None:
    # Admin bo'lmasa buyruq umuman javob bermaydi (mavjudligi ham bilinmaydi).
    if message.from_user.id != ADMIN_CHAT_ID:
        return

    parts = (message.text or "").split()
    if len(parts) != 3:
        await message.answer(
            "Foydalanish: <code>/berish &lt;telegram_id&gt; &lt;summa&gt;</code>\n"
            "Masalan: <code>/berish 123456789 50000</code>"
        )
        return

    try:
        target_id = int(parts[1])
        amount = int(parts[2])
    except ValueError:
        await message.answer("telegram_id va summa faqat butun son bo'lishi kerak.")
        return

    if amount <= 0:
        await message.answer("Summa musbat bo'lishi kerak.")
        return

    try:
        await admin_topup_balance(
            telegram_id=target_id, amount=amount, note="Admin qo'lda o'tkazdi"
        )
        updated_user = await get_user(target_id)
    except ApiError as error:
        await message.answer(f"❌ Xatolik: {error.message}")
        return

    await message.answer(
        f"✅ <code>{target_id}</code> foydalanuvchiga <b>{amount} so'm</b> "
        f"o'tkazildi.\nJoriy balans: <b>{updated_user['balance']} so'm</b>"
    )
    try:
        await bot.send_message(
            target_id,
            f"✅ Balansingiz {amount} so'mga to'ldirildi!\n"
            f"Joriy balans: {updated_user['balance']} so'm",
        )
    except Exception:
        logger.exception("Foydalanuvchiga admin o'tkazma xabarini yuborishda xatolik")


@router.callback_query(TopupCallback.filter(F.action == "confirm"))
async def confirm_topup(
    callback: types.CallbackQuery, callback_data: TopupCallback, bot: Bot
) -> None:
    if callback.from_user.id != ADMIN_CHAT_ID:
        await callback.answer("Bu amal faqat admin uchun.", show_alert=True)
        return

    try:
        await admin_topup_balance(
            telegram_id=callback_data.telegram_id,
            amount=callback_data.amount,
            note="Telegram bot orqali tasdiqlangan",
        )
        updated_user = await get_user(callback_data.telegram_id)
    except ApiError as error:
        await callback.answer(f"Xatolik: {error.message}", show_alert=True)
        return

    confirmation_note = f"✅ <b>Tasdiqlandi:</b> {callback_data.amount} so'm qo'shildi."

    if callback.message.caption is not None:
        await callback.message.edit_caption(
            caption=f"{callback.message.caption}\n\n{confirmation_note}",
            reply_markup=None,
        )
    else:
        await callback.message.edit_text(
            text=f"{callback.message.text}\n\n{confirmation_note}",
            reply_markup=None,
        )
    await callback.answer("Tasdiqlandi ✅")

    try:
        await bot.send_message(
            callback_data.telegram_id,
            f"✅ Balansingiz {callback_data.amount} so'mga to'ldirildi!\n"
            f"Joriy balans: {updated_user['balance']} so'm",
        )
    except Exception:
        logger.exception("Foydalanuvchiga top-up xabarini yuborishda xatolik")


@router.callback_query(TopupCallback.filter(F.action == "edit"))
async def request_edit_amount(
    callback: types.CallbackQuery, callback_data: TopupCallback, state: FSMContext
) -> None:
    if callback.from_user.id != ADMIN_CHAT_ID:
        await callback.answer("Bu amal faqat admin uchun.", show_alert=True)
        return

    await state.set_state(AdminTopupStates.waiting_for_edited_amount)
    await state.update_data(telegram_id=callback_data.telegram_id)

    # Eski tugmalarni olib tashlaymiz - aks holda admin eski summani
    # tasodifan qayta tasdiqlab qo'yishi mumkin
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer()
    await callback.message.reply("Yangi summani kiriting (so'mda, faqat raqam):")


@router.message(AdminTopupStates.waiting_for_edited_amount, F.text)
async def receive_edited_amount(message: types.Message, state: FSMContext) -> None:
    amount = _parse_amount(message.text)

    if amount is None:
        await message.answer("Iltimos, faqat musbat butun son kiriting.")
        return

    data = await state.get_data()
    telegram_id = data["telegram_id"]
    await state.clear()

    await message.answer(
        f"Yangi summa: {amount} so'm. Tasdiqlaysizmi?",
        reply_markup=build_admin_topup_keyboard(telegram_id=telegram_id, amount=amount),
    )