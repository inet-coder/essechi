from aiogram.filters.callback_data import CallbackData
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.config import ADMIN_API_KEY, WEB_APP_URL

TOPICS_MANAGE_PAGE_SIZE = 8
CATEGORIES_MANAGE_PAGE_SIZE = 8


class AdminPanelCallback(CallbackData, prefix="admin_panel"):
    action: str  # "topics" | "categories" | "broadcast" | "channels" | "main"


class AdminTopicManageCallback(CallbackData, prefix="admin_topic_manage"):
    action: str  # "add" | "delete" | "page"
    topic_id: int = 0
    page: int = 0


class AdminCategoryManageCallback(CallbackData, prefix="admin_cat_manage"):
    action: str  # "add" | "delete" | "page"
    category_id: int = 0
    page: int = 0


class AdminBroadcastCallback(CallbackData, prefix="admin_broadcast"):
    action: str  # "confirm" | "cancel"


class AdminCategoryCallback(CallbackData, prefix="admin_topic_cat"):
    action: str  # "select" | "new" | "none"
    category_id: int = 0


class AdminChannelManageCallback(CallbackData, prefix="admin_channel_manage"):
    action: str  # "add" | "delete" | "recheck" | "page"
    channel_id: int = 0
    page: int = 0


class AdminGuideCallback(CallbackData, prefix="admin_guide"):
    action: str  # "set_video" | "set_desc"


def build_guide_manage_keyboard() -> InlineKeyboardMarkup:
    """Qo'llanma boshqaruvi: video va tavsifni o'rnatish/o'zgartirish."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="🎬 Videoni o'rnatish / o'zgartirish",
            callback_data=AdminGuideCallback(action="set_video").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="✏️ Tavsifni o'zgartirish",
            callback_data=AdminGuideCallback(action="set_desc").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="⬅️ Orqaga",
            callback_data=AdminPanelCallback(action="main").pack(),
        )
    )
    return builder.as_markup()


def build_category_picker_keyboard(categories: list[dict]) -> InlineKeyboardMarkup:
    """Yangi mavzu qo'shishda kategoriya tanlash: mavjud kategoriyalar +
    "yangi kategoriya" + "kategoriyasiz"."""
    builder = InlineKeyboardBuilder()

    for cat in categories:
        builder.row(
            InlineKeyboardButton(
                text=f"📁 {cat['name']}",
                callback_data=AdminCategoryCallback(
                    action="select", category_id=cat["id"]
                ).pack(),
            )
        )

    builder.row(
        InlineKeyboardButton(
            text="➕ Yangi kategoriya",
            callback_data=AdminCategoryCallback(action="new").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="Kategoriyasiz",
            callback_data=AdminCategoryCallback(action="none").pack(),
        )
    )
    return builder.as_markup()


def build_admin_main_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(
            text="📝 Maqolalar",
            web_app=WebAppInfo(
                url=f"{WEB_APP_URL}/admin/articles?key={ADMIN_API_KEY}"
            ),
        ),
        InlineKeyboardButton(
            text="📋 Mavzular",
            callback_data=AdminPanelCallback(action="topics").pack(),
        ),
    )

    builder.row(
        InlineKeyboardButton(
            text="🗂 Kategoriyalar",
            callback_data=AdminPanelCallback(action="categories").pack(),
        ),
        InlineKeyboardButton(
            text="🔔 Kanallar",
            callback_data=AdminPanelCallback(action="channels").pack(),
        ),
    )

    builder.row(
        InlineKeyboardButton(
            text="📢 Xabar yuborish",
            callback_data=AdminPanelCallback(action="broadcast").pack(),
        ),
        InlineKeyboardButton(
            text="📖 Qo'llanma",
            callback_data=AdminPanelCallback(action="guide").pack(),
        ),
    )

    builder.row(
        InlineKeyboardButton(
            text="🌐 Veb Admin",
            web_app=WebAppInfo(
                url=f"{WEB_APP_URL}/admin/articles?key={ADMIN_API_KEY}"
            ),
        )
    )

    return builder.as_markup()

def build_categories_manage_keyboard(
    categories: list[dict], page: int = 0
) -> InlineKeyboardMarkup:
    """Har bir kategoriya uchun alohida qator o'chirish tugmasi bilan.
    Nofaol (allaqachon o'chirilgan) kategoriyalar uchun o'chirish tugmasi
    ko'rsatilmaydi."""
    builder = InlineKeyboardBuilder()

    total_pages = max(
        1, (len(categories) + CATEGORIES_MANAGE_PAGE_SIZE - 1) // CATEGORIES_MANAGE_PAGE_SIZE
    )
    page = max(0, min(page, total_pages - 1))
    start = page * CATEGORIES_MANAGE_PAGE_SIZE
    page_categories = categories[start : start + CATEGORIES_MANAGE_PAGE_SIZE]

    for cat in page_categories:
        if not cat.get("isActive", True):
            continue
        builder.row(
            InlineKeyboardButton(
                text=f"🗑 {cat['name']}",
                callback_data=AdminCategoryManageCallback(
                    action="delete", category_id=cat["id"]
                ).pack(),
            )
        )

    nav_row = []
    if page > 0:
        nav_row.append(
            InlineKeyboardButton(
                text="◀️",
                callback_data=AdminCategoryManageCallback(action="page", page=page - 1).pack(),
            )
        )
    if page < total_pages - 1:
        nav_row.append(
            InlineKeyboardButton(
                text="▶️",
                callback_data=AdminCategoryManageCallback(action="page", page=page + 1).pack(),
            )
        )
    if nav_row:
        builder.row(*nav_row)

    builder.row(
        InlineKeyboardButton(
            text="➕ Yangi kategoriya qo'shish",
            callback_data=AdminCategoryManageCallback(action="add").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="⬅️ Admin panelga qaytish",
            callback_data=AdminPanelCallback(action="main").pack(),
        )
    )
    return builder.as_markup()


def build_topics_manage_keyboard(topics: list[dict], page: int = 0) -> InlineKeyboardMarkup:
    """Har bir mavzu uchun alohida qator o'chirish tugmasi bilan. Mavzu
    matnlarining o'zi alohida xabarda (raqamlangan) ko'rsatiladi."""
    builder = InlineKeyboardBuilder()

    total_pages = max(1, (len(topics) + TOPICS_MANAGE_PAGE_SIZE - 1) // TOPICS_MANAGE_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    start = page * TOPICS_MANAGE_PAGE_SIZE
    page_topics = topics[start : start + TOPICS_MANAGE_PAGE_SIZE]

    for i, topic in enumerate(page_topics, start=start + 1):
        builder.row(
            InlineKeyboardButton(
                text=f"🗑 {i}-mavzuni o'chirish",
                callback_data=AdminTopicManageCallback(
                    action="delete", topic_id=topic["id"]
                ).pack(),
            )
        )

    nav_row = []
    if page > 0:
        nav_row.append(
            InlineKeyboardButton(
                text="◀️",
                callback_data=AdminTopicManageCallback(action="page", page=page - 1).pack(),
            )
        )
    if page < total_pages - 1:
        nav_row.append(
            InlineKeyboardButton(
                text="▶️",
                callback_data=AdminTopicManageCallback(action="page", page=page + 1).pack(),
            )
        )
    if nav_row:
        builder.row(*nav_row)

    builder.row(
        InlineKeyboardButton(
            text="➕ Yangi mavzu qo'shish",
            callback_data=AdminTopicManageCallback(action="add").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="⬅️ Admin panelga qaytish",
            callback_data=AdminPanelCallback(action="main").pack(),
        )
    )
    return builder.as_markup()


CHANNELS_MANAGE_PAGE_SIZE = 8


def build_channels_manage_keyboard(
    channels: list[dict], page: int = 0
) -> InlineKeyboardMarkup:
    """Har bir kanal uchun holati bilan: ✅ faol (bot admin, tekshiruv
    ishlaydi) yoki ⏳ kutilmoqda (bot hali admin emas - tugma bosilsa
    qayta tekshiriladi). O'chirish - alohida 🗑 tugma."""
    builder = InlineKeyboardBuilder()

    total_pages = max(
        1, (len(channels) + CHANNELS_MANAGE_PAGE_SIZE - 1) // CHANNELS_MANAGE_PAGE_SIZE
    )
    page = max(0, min(page, total_pages - 1))
    start = page * CHANNELS_MANAGE_PAGE_SIZE
    page_channels = channels[start : start + CHANNELS_MANAGE_PAGE_SIZE]

    for ch in page_channels:
        if not ch.get("isActive", True):
            continue
        is_active = ch.get("status") == "active"
        title = ch.get("title") or ch.get("username") or str(ch.get("chatId"))
        status_icon = "✅" if is_active else "⏳"
        row = []
        if not is_active:
            row.append(
                InlineKeyboardButton(
                    text=f"{status_icon} {title}",
                    callback_data=AdminChannelManageCallback(
                        action="recheck", channel_id=ch["id"]
                    ).pack(),
                )
            )
        else:
            row.append(InlineKeyboardButton(text=f"{status_icon} {title}", callback_data="noop"))
        row.append(
            InlineKeyboardButton(
                text="🗑",
                callback_data=AdminChannelManageCallback(
                    action="delete", channel_id=ch["id"]
                ).pack(),
            )
        )
        builder.row(*row)

    nav_row = []
    if page > 0:
        nav_row.append(
            InlineKeyboardButton(
                text="◀️",
                callback_data=AdminChannelManageCallback(action="page", page=page - 1).pack(),
            )
        )
    if page < total_pages - 1:
        nav_row.append(
            InlineKeyboardButton(
                text="▶️",
                callback_data=AdminChannelManageCallback(action="page", page=page + 1).pack(),
            )
        )
    if nav_row:
        builder.row(*nav_row)

    builder.row(
        InlineKeyboardButton(
            text="➕ Kanal qo'shish",
            callback_data=AdminChannelManageCallback(action="add").pack(),
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="⬅️ Admin panelga qaytish",
            callback_data=AdminPanelCallback(action="main").pack(),
        )
    )
    return builder.as_markup()


def build_channel_recheck_keyboard(channel_id: int) -> InlineKeyboardMarkup:
    """Kanal 'pending' holatda qo'shilganda - botni admin qilib
    qo'shgandan keyin admin shu tugma orqali qayta tekshiradi."""
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="🔄 Tekshirish",
            callback_data=AdminChannelManageCallback(
                action="recheck", channel_id=channel_id
            ).pack(),
        )
    )
    return builder.as_markup()


def build_broadcast_confirm_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Yuborish",
            callback_data=AdminBroadcastCallback(action="confirm").pack(),
        ),
        InlineKeyboardButton(
            text="❌ Bekor qilish",
            callback_data=AdminBroadcastCallback(action="cancel").pack(),
        ),
    )
    return builder.as_markup()