from aiogram.filters.callback_data import CallbackData
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

CANCEL_BUTTON_TEXT = "❌ Bekor qilish"


class CancelCallback(CallbackData, prefix="cancel"):
    pass


def build_cancel_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="❌ Bekor qilish", callback_data=CancelCallback().pack())
    )
    return builder.as_markup()


def build_cancel_reply_keyboard() -> ReplyKeyboardMarkup:
    """Pastdagi asosiy menyu o'rnida ko'rinadigan, faqat "Bekor qilish"
    tugmasidan iborat reply keyboard (FSM jarayonlari davomida ishlatiladi)."""
    builder = ReplyKeyboardBuilder()
    builder.button(text=CANCEL_BUTTON_TEXT)
    return builder.as_markup(resize_keyboard=True)