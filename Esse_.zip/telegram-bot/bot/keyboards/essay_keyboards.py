from aiogram.filters.callback_data import CallbackData
from aiogram.types import InlineKeyboardMarkup, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.config import WEB_APP_URL


def get_result_keyboard(essay_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text="🌐 To'liq natijani ko'rish",
        web_app=WebAppInfo(url=f"{WEB_APP_URL}/essay/{essay_id}"),
    )
    return builder.as_markup()


class PageCallback(CallbackData, prefix="page"):
    action: str  # "finish" | "cancel"


def get_add_page_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Tugatdim", callback_data=PageCallback(action="finish"))
    builder.button(text="❌ Bekor qilish", callback_data=PageCallback(action="cancel"))
    builder.adjust(1)
    return builder.as_markup()


class OcrConfirmCallback(CallbackData, prefix="ocr"):
    action: str  # "confirm" | "edit" | "cancel"


def get_confirm_ocr_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Tasdiqlash", callback_data=OcrConfirmCallback(action="confirm"))
    builder.button(text="✏️ Tahrirlash", callback_data=OcrConfirmCallback(action="edit"))
    builder.button(text="❌ Bekor qilish", callback_data=OcrConfirmCallback(action="cancel"))
    builder.adjust(1)
    return builder.as_markup()