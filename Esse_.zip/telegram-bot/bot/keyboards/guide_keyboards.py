from aiogram.filters.callback_data import CallbackData
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


class GuideCallback(CallbackData, prefix="guide"):
    action: str  # "back"


class FeedbackStartCallback(CallbackData, prefix="fbstart"):
    """Foydalanuvchi qo'llanma ostidagi «Savol va takliflar» ni bosdi -
    yozishma adminga boshlanadi."""


class FeedbackReplyCallback(CallbackData, prefix="fbreply"):
    """Yozishmaga javob yozish. to_id - javob yuboriladigan telegram id
    (foydalanuvchi javob yozsa admin id, admin javob yozsa foydalanuvchi id)."""

    to_id: int


def build_guide_keyboard() -> InlineKeyboardMarkup:
    """Foydalanuvchi qo'llanma ko'rinishi: video ostida savol/taklif + orqaga."""
    builder = InlineKeyboardBuilder()
    builder.button(
        text="💬 Savol va takliflar",
        callback_data=FeedbackStartCallback(),
    )
    # builder.button(
    #     text="⬅️ Orqaga",
    #     callback_data=GuideCallback(action="back"),
    # )
    builder.adjust(1)
    return builder.as_markup()


def build_feedback_reply_keyboard(to_id: int) -> InlineKeyboardMarkup:
    """Kelgan xabar ostidagi «Javob berish» tugmasi."""
    builder = InlineKeyboardBuilder()
    builder.button(
        text="✍️ Javob berish",
        callback_data=FeedbackReplyCallback(to_id=to_id),
    )
    builder.adjust(1)
    return builder.as_markup()
