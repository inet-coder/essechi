from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    WebAppInfo,
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder

from bot.config import WEB_APP_URL


def get_main_menu(is_admin: bool = False) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()

    # Web App tugmasi (1-qator)
    if WEB_APP_URL:
        builder.add(
            KeyboardButton(
                text="🌐 Essechi.uz",
                web_app=WebAppInfo(url=WEB_APP_URL),
            )
        )

    # Asosiy tugmalar
    builder.add(
        KeyboardButton(text="📝 Esse yuborish"),
        KeyboardButton(text="👤 Profilim"),
        KeyboardButton(text="📋 Natijalarim"),
        KeyboardButton(text="📊 Statistika"),
        KeyboardButton(text="🏆 Musobaqa"),
        KeyboardButton(text="💰 Balansni to'ldirish"),
        KeyboardButton(text="📖 Qo'llanma"),
    )

    if is_admin:
        builder.add(
            KeyboardButton(text="🛠 Admin panel"),
        )
        builder.adjust(1, 2, 2, 2, 1, 1)
    else:
        builder.adjust(1, 2, 2, 2, 1)

    return builder.as_markup(
        resize_keyboard=True,
        is_persistent=True,
    )