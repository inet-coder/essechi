from aiogram.filters.callback_data import CallbackData
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


class SubscriptionCheckCallback(CallbackData, prefix="sub_check"):
    action: str = "check"


def _channel_url(channel: dict) -> str:
    username = channel.get("username")
    if username:
        return f"https://t.me/{username.lstrip('@')}"
    invite_link = channel.get("inviteLink")
    if invite_link:
        return invite_link
    # Oxirgi imkoniyat - chatId orqali (faqat username bo'lmagan holatlarda
    # inviteLink har doim to'ldirilgan bo'lishi kerak, lekin xavfsizlik uchun).
    return "https://t.me"


def build_subscription_keyboard(channels: list[dict]) -> InlineKeyboardMarkup:
    """Har bir majburiy kanal uchun 'obuna bo'lish' havolasi + pastda
    'tekshirish' tugmasi."""
    builder = InlineKeyboardBuilder()

    for channel in channels:
        title = channel.get("title") or channel.get("username") or "Kanal"
        builder.row(
            InlineKeyboardButton(text=f"➕ {title}", url=_channel_url(channel))
        )

    builder.row(
        InlineKeyboardButton(
            text="✅ Obuna bo'ldim",
            callback_data=SubscriptionCheckCallback(action="check").pack(),
        )
    )
    return builder.as_markup()
