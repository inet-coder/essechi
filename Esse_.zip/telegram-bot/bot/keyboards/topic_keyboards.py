from aiogram.filters.callback_data import CallbackData
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

TOPICS_PAGE_SIZE = 10
BUTTONS_PER_ROW = 5


class TopicCallback(CallbackData, prefix="topic"):
    action: str  # "select" | "custom"
    topic_id: int = 0


class TopicPageCallback(CallbackData, prefix="topic_page"):
    page: int


def format_topics_text(topics: list[dict], page: int = 0) -> str:
    """Mavzular ro'yxatini TO'LIQ matn bilan, raqamlangan holda qaytaradi."""
    total_pages = max(1, (len(topics) + TOPICS_PAGE_SIZE - 1) // TOPICS_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    start = page * TOPICS_PAGE_SIZE
    page_topics = topics[start : start + TOPICS_PAGE_SIZE]

    lines = ["Tayyor mavzulardan birini tanlang:\n"]
    for i, topic in enumerate(page_topics, start=start + 1):
        lines.append(f"<b>{i}.</b> {topic['text']}\n")

    if total_pages > 1:
        lines.append(f"📄 Sahifa {page + 1}/{total_pages}")

    return "\n".join(lines)


def build_topic_keyboard(topics: list[dict], page: int = 0) -> InlineKeyboardMarkup:
    """Faqat raqamli tugmalar (matn yuqorida, alohida xabar matnida ko'rsatiladi).
    5 tadan 2 qatorda (10 ta mavzu sahifada), 3-qatorda navigatsiya, 4-qatorda
    "o'zim kiritaman" tugmasi."""
    builder = InlineKeyboardBuilder()

    total_pages = max(1, (len(topics) + TOPICS_PAGE_SIZE - 1) // TOPICS_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    start = page * TOPICS_PAGE_SIZE
    page_topics = topics[start : start + TOPICS_PAGE_SIZE]

    for i, topic in enumerate(page_topics, start=start + 1):
        builder.button(
            text=str(i),
            callback_data=TopicCallback(action="select", topic_id=topic["id"]),
        )

    # 5 tadan qatorlarga taqsimlash (10 ta bo'lsa - 2 qator, kamroq bo'lsa
    # ham 5 tadan qatorga joylashadi)
    row_sizes = []
    remaining = len(page_topics)
    while remaining > 0:
        row_sizes.append(min(BUTTONS_PER_ROW, remaining))
        remaining -= row_sizes[-1]
    if row_sizes:
        builder.adjust(*row_sizes)

    nav_row = []
    if page > 0:
        nav_row.append(
            InlineKeyboardButton(
                text="◀️", callback_data=TopicPageCallback(page=page - 1).pack()
            )
        )
    if page < total_pages - 1:
        nav_row.append(
            InlineKeyboardButton(
                text="▶️", callback_data=TopicPageCallback(page=page + 1).pack()
            )
        )
    if nav_row:
        builder.row(*nav_row)

    builder.row(
        InlineKeyboardButton(
            text="✍️ O'zim mavzu kiritaman",
            callback_data=TopicCallback(action="custom").pack(),
        )
    )

    return builder.as_markup()