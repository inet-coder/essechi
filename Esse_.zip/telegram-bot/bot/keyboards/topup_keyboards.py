from aiogram.filters.callback_data import CallbackData
from aiogram.types import CopyTextButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bot.handlers.profile import ProfileNavCallback


class TopupCallback(CallbackData, prefix="topup"):
    action: str  # "confirm" | "edit"
    telegram_id: int
    amount: int


class TopupProviderCallback(CallbackData, prefix="tpprov"):
    provider: str  # provayder kodi, "any", yoki "missing"


class TopupMenuCallback(CallbackData, prefix="tpmenu"):
    section: str  # "balance" | "packages"


class PackageCallback(CallbackData, prefix="pkg"):
    package_id: int


class PaymentCheckCallback(CallbackData, prefix="paychk"):
    payment_id: int


# (kod, ko'rinadigan matn) - matn skrinshotdagi rangli belgilar bilan.
# Barcha provayderlar bir xil kartaga olib boradi (tanlov faqat qulaylik
# uchun); tanlangan provayder to'lov yozuviga saqlanadi.
_PROVIDERS: list[tuple[str, str]] = [
    ("payme", "⚪️ Payme (avto)"),
    ("click", "🔵 Click (avto)"),
    ("xazna", "🟢 Xazna (avto)"),
    ("zoomrad", "🟢 Zoomrad (avto)"),
    ("uzumbank", "🟣 Uzumbank (avto)"),
    ("anorbank", "🔴 Anorbank (avto)"),
    ("paynet", "🟢 Paynet (avto)"),
    ("beepul", "🟠 Beepul (avto)"),
    ("oson", "⚪️ Oson (avto)"),
    ("tenge24", "🟢 Tenge24 (avto)"),
    ("upay", "🔵 UPay (avto)"),
    ("plum", "🔵 Plum (avto)"),
    ("humo", "🟠 Humo (avto)"),
    ("uzcard", "🔴 Uzcard (avto)"),
]


def build_topup_root_keyboard() -> InlineKeyboardMarkup:
    """«Balansni to'ldirish» bosilganda: balans (so'm) yoki esse paketlari."""
    builder = InlineKeyboardBuilder()
    builder.button(
        text="💵 Balansni to'ldirish (so'm)",
        callback_data=TopupMenuCallback(section="balance"),
    )
    builder.button(
        text="📦 Esse tekshiruv paketlari",
        callback_data=TopupMenuCallback(section="packages"),
    )
    builder.button(text="💳 To'lovlarim", callback_data=ProfileNavCallback(action="payments"))
    builder.adjust(1)
    return builder.as_markup()


def build_packages_keyboard(packages: list[dict]) -> InlineKeyboardMarkup:
    """Har bir paket uchun bitta tugma: «📦 N ta — NARX so'm»."""
    builder = InlineKeyboardBuilder()
    for pkg in packages:
        credits = pkg["credits"]
        price = pkg["price"]
        builder.button(
            text=f"📦 {credits} ta tekshiruv — {price:,} so'm".replace(",", " "),
            callback_data=PackageCallback(package_id=pkg["id"]),
        )
    builder.button(text="⬅️ Orqaga", callback_data=TopupMenuCallback(section="root"))
    builder.adjust(1)
    return builder.as_markup()

def build_provider_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()

    builder.button(
        text="🏧 Bankomat (avto)",
        callback_data=TopupProviderCallback(provider="bankomat"),
    )

    for code, label in _PROVIDERS:
        builder.button(
            text=label,
            callback_data=TopupProviderCallback(provider=code),
        )

    builder.button(
        text="💼 Istalgan to'lov tizimi orqali",
        callback_data=TopupProviderCallback(provider="any"),
    )

    # builder.button(
    #     text="🤔 Siz izlagan to'lov tizimi yo'qmi?",
    #     callback_data=TopupProviderCallback(provider="missing"),
    # )

    builder.button(
        text="💳 To'lovlarim",
        callback_data=ProfileNavCallback(action="payments"),
    )

    # YANGI
    builder.button(
        text="⬅️ Orqaga",
        callback_data=TopupMenuCallback(section="root"),
    )

    builder.adjust(
        1,  # Bankomat
        2, 2, 2, 2, 2, 2, 2,  # Provayderlar
        1,  # Istalgan to'lov tizimi
        1,  # Siz izlagan...
        1,  # To'lovlarim
        1,  # Orqaga
    )

    return builder.as_markup()

def build_payment_card_keyboard(
    card_digits: str, payment_id: int | None = None
) -> InlineKeyboardMarkup:
    """Karta raqamini nusxalash tugmasi; ostida (payment_id berilsa) to'lovga
    qancha vaqt qolganini tekshirish tugmasi."""
    builder = InlineKeyboardBuilder()
    builder.button(
        text="💳 Karta raqamdan nusxa olish",
        copy_text=CopyTextButton(text=card_digits),
    )
    if payment_id is not None:
        builder.button(
            text="🔄 Yangilash (qolgan vaqt)",
            callback_data=PaymentCheckCallback(payment_id=payment_id),
        )
    builder.adjust(1)
    return builder.as_markup()


def build_admin_topup_keyboard(telegram_id: int, amount: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(
        text=f"✅ Tasdiqlash ({amount} so'm)",
        callback_data=TopupCallback(action="confirm", telegram_id=telegram_id, amount=amount),
    )
    builder.button(
        text="✏️ Summani tahrirlash",
        callback_data=TopupCallback(action="edit", telegram_id=telegram_id, amount=amount),
    )
    builder.adjust(1)
    return builder.as_markup()