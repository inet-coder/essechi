import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from bot.api.client import close_session
from bot.config import BOT_TOKEN
from bot.handlers import (
    admin_panel,
    competition,
    essay,
    feedback,
    guide,
    profile,
    results,
    start,
    stats,
    subscription,
    topup,
)
from bot.middlewares.subscription_gate import SubscriptionGateMiddleware
from bot.utils.logger import setup_logging


async def main() -> None:
    setup_logging()

    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    # Admin bo'lmagan foydalanuvchilar uchun majburiy obuna tekshiruvi -
    # BARCHA routerlardan OLDIN, dispatcher darajasida ishlaydi (shunda
    # birorta handler ham obuna bo'lmagan foydalanuvchi uchun ishga
    # tushmaydi, "/start" va obunani tekshirish tugmasi bundan mustasno).
    dp.message.outer_middleware(SubscriptionGateMiddleware())
    dp.callback_query.outer_middleware(SubscriptionGateMiddleware())

    dp.include_router(start.router)
    dp.include_router(subscription.router)
    dp.include_router(profile.router)
    dp.include_router(results.router)
    dp.include_router(stats.router)
    dp.include_router(topup.router)
    dp.include_router(admin_panel.router)
    dp.include_router(competition.router)
    dp.include_router(guide.router)
    dp.include_router(feedback.router)
    # essay.router ENG OXIRIDA bo'lishi shart - chunki uning ichida
    # "EssayStates.waiting_for_essay holatida kelgan har qanday matn" filtri
    # bor. Agar bu router avval tursa, boshqa tugma bosilganda ham matn
    # sifatida (esse deb) qabul qilinib qoladi.
    dp.include_router(essay.router)

    try:
        await dp.start_polling(bot)
    finally:
        await close_session()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())