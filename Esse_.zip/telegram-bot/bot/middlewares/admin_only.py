from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from bot.config import ADMIN_CHAT_ID


class AdminOnlyMiddleware(BaseMiddleware):
    """Faqat ADMIN_CHAT_ID'dan kelgan update'larni o'tkazadi. Boshqa
    foydalanuvchilar uchun handler umuman ishga tushmaydi (jim e'tiborsiz
    qoldiriladi - admin panel mavjudligini ham bildirmaslik uchun)."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user_id = None
        if isinstance(event, Message):
            user_id = event.from_user.id if event.from_user else None
        elif isinstance(event, CallbackQuery):
            user_id = event.from_user.id if event.from_user else None

        if user_id != ADMIN_CHAT_ID:
            if isinstance(event, CallbackQuery):
                await event.answer("Sizda bu amalni bajarish huquqi yo'q.", show_alert=True)
            return None

        return await handler(event, data)