from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from bot.config import ADMIN_CHAT_ID
from bot.keyboards.subscription_keyboards import (
    SubscriptionCheckCallback,
    build_subscription_keyboard,
)
from bot.utils.subscription import get_missing_channels

_GATE_TEXT = (
    "🔔 <b>Botdan foydalanish uchun quyidagi kanallarga obuna bo'ling</b>\n\n"
    "Obuna bo'lgach, \"✅ Obuna bo'ldim\" tugmasini bosing."
)


class SubscriptionGateMiddleware(BaseMiddleware):
    """Admin bo'lmagan foydalanuvchi majburiy kanallarning barchasiga obuna
    bo'lmagunicha, boshqa hech qanday amalni bajarishga yo'l qo'ymaydi
    ("/start" va obunani tekshirish tugmasi bundan mustasno - ular har doim
    ishlashi kerak, aks holda foydalanuvchi bloklangan holatdan chiqib
    ketolmay qoladi)."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = None
        if isinstance(event, Message):
            user = event.from_user
        elif isinstance(event, CallbackQuery):
            user = event.from_user

        if user is None or user.id == ADMIN_CHAT_ID:
            return await handler(event, data)

        # "/start" har doim ishlaydi - u o'zi ro'yxatdan o'tkazadi va kerak
        # bo'lsa gate'ni ko'rsatadi.
        if isinstance(event, Message) and event.text and event.text.split()[0] == "/start":
            return await handler(event, data)

        # Obunani tekshirish tugmasi ham har doim ishlashi kerak.
        if isinstance(event, CallbackQuery) and event.data and event.data.startswith(
            SubscriptionCheckCallback.__prefix__
        ):
            return await handler(event, data)

        bot = data.get("bot")
        missing = await get_missing_channels(bot, user.id)
        if not missing:
            return await handler(event, data)

        keyboard = build_subscription_keyboard(missing)
        if isinstance(event, CallbackQuery):
            await event.answer(
                "Avval barcha kanallarga obuna bo'ling.", show_alert=True
            )
            if event.message:
                try:
                    await event.message.answer(_GATE_TEXT, reply_markup=keyboard)
                except Exception:
                    pass
        elif isinstance(event, Message):
            await event.answer(_GATE_TEXT, reply_markup=keyboard)

        return None
