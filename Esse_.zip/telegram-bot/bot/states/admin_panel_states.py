from aiogram.fsm.state import State, StatesGroup


class AdminPanelStates(StatesGroup):
    waiting_for_new_topic_category = State()
    waiting_for_new_category_name = State()
    waiting_for_new_topic_text = State()
    waiting_for_new_standalone_category_name = State()
    waiting_for_broadcast_text = State()
    waiting_for_broadcast_confirmation = State()
    waiting_for_channel_input = State()
    waiting_for_guide_video = State()
    waiting_for_guide_description = State()