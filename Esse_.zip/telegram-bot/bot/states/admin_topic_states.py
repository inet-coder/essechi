from aiogram.fsm.state import State, StatesGroup


class AdminTopicStates(StatesGroup):
    waiting_for_topic_text = State()