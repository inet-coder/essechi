from aiogram.fsm.state import State, StatesGroup


class EssayStates(StatesGroup):
    choosing_topic = State()
    waiting_for_custom_topic = State()
    waiting_for_essay = State()
    collecting_pages = State()
    confirming_ocr_text = State()
    editing_ocr_text = State()