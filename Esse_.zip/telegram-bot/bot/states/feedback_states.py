from aiogram.fsm.state import State, StatesGroup


class FeedbackStates(StatesGroup):
    # Yozishma xabari kutilmoqda. Kimga yuborilishi (to_id) state ma'lumotida
    # saqlanadi - shu bilan bir handler ham foydalanuvchi, ham admin uchun
    # ishlaydi.
    writing = State()
