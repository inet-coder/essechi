from aiogram.fsm.state import State, StatesGroup


class RegistrationStates(StatesGroup):
    # Foydalanuvchi /start bosgach, ro'yxatdan o'tish uchun ismini kiritishini
    # kutish holati.
    waiting_for_name = State()
