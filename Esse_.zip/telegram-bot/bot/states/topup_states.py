from aiogram.fsm.state import State, StatesGroup


class TopupStates(StatesGroup):
    waiting_for_amount = State()


class AdminTopupStates(StatesGroup):
    waiting_for_edited_amount = State()