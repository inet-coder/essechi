import logging

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError

from bot.api.client import ApiError, list_active_channels

logger = logging.getLogger(__name__)

# Foydalanuvchi shu holatlardan birida bo'lsa - kanalga a'zo hisoblanadi.
_SUBSCRIBED_STATUSES = {"creator", "administrator", "member", "restricted"}


async def get_missing_channels(bot: Bot, user_id: int) -> list[dict]:
    """Foydalanuvchi hali obuna bo'lmagan MAJBURIY kanallar ro'yxatini
    qaytaradi. Bo'sh ro'yxat = hammasiga obuna bo'lgan (yoki umuman majburiy
    kanal yo'q).

    Bitta kanalni tekshirishda kutilmagan xatolik (masalan bot kanaldan
    chiqarib yuborilgan bo'lsa-yu, backend hali "active" deb bilsa) BUTUN
    tekshiruvni to'xtatib qo'ymasligi kerak - shunday holatda o'sha kanal
    "obuna bo'linmagan" deb hisoblanadi (xavfsiz tomonga xato).
    """
    try:
        channels = await list_active_channels()
    except ApiError:
        logger.exception("Majburiy kanallar ro'yxatini olishda xatolik")
        # Backend bilan bog'lanib bo'lmasa, foydalanuvchini bloklab
        # qo'ymaymiz - bo'sh ro'yxat qaytaramiz.
        return []

    if not channels:
        return []

    missing = []
    for channel in channels:
        try:
            member = await bot.get_chat_member(channel["chatId"], user_id)
            if member.status not in _SUBSCRIBED_STATUSES:
                missing.append(channel)
        except (TelegramBadRequest, TelegramForbiddenError):
            # Foydalanuvchi kanalda umuman bo'lmagan yoki bot huquqini
            # yo'qotgan - "obuna bo'linmagan" deb hisoblanadi.
            missing.append(channel)
        except Exception:
            logger.exception(
                "Kanal (%s) uchun obunani tekshirishda kutilmagan xatolik",
                channel.get("chatId"),
            )
            missing.append(channel)

    return missing
