import os

from dotenv import load_dotenv

load_dotenv()

REQUIRED_VARS = ["API_ID", "API_HASH", "SESSION_STRING", "ADMIN_API_KEY", "CARD_LAST4"]

for var in REQUIRED_VARS:
    if not os.environ.get(var):
        raise RuntimeError(f"Majburiy environment o'zgaruvchi topilmadi: {var}")

# my.telegram.org dan olinadi
API_ID = int(os.environ["API_ID"])
API_HASH = os.environ["API_HASH"]

# login.py orqali bir marta yaratiladi (foydalanuvchi sessiyasi)
SESSION_STRING = os.environ["SESSION_STRING"]

# Backend confirm endpointini chaqirish uchun (backenddagi ADMIN_API_KEY bilan
# bir xil bo'lishi shart)
BACKEND_URL = os.environ.get("BACKEND_URL", "http://localhost:3000")
ADMIN_API_KEY = os.environ["ADMIN_API_KEY"]

# Xabar keladigan manba: @CardXabarBot (username yoki ID: 915326936).
# ID berilsa ham ishlaydi.
_source = os.environ.get("SOURCE_CHAT", "CardXabarBot").lstrip("@")
SOURCE_CHAT = int(_source) if _source.lstrip("-").isdigit() else _source

# Bizning qabul qiluvchi kartaning oxirgi 4 raqami. Xabardagi ***XXXX shu bilan
# solishtiriladi - boshqa kartaga tushgan pullar e'tiborsiz qoldiriladi.
CARD_LAST4 = os.environ["CARD_LAST4"].strip()