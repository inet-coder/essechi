"""SESSION_STRING yaratish uchun bir martalik interaktiv skript.

Ishga tushirish:
    python login.py

API_ID va API_HASH ni kiritasiz, so'ng Telegram akkauntingizga
(CardXabarBot xabarlari keladigan akkaunt) telefon raqam + kod bilan
kirasiz. Chiqqan SESSION_STRING ni .env fayldagi SESSION_STRING ga yozing.
"""
import asyncio

from telethon import TelegramClient
from telethon.sessions import StringSession


async def main() -> None:
    api_id = int(input("API_ID: ").strip())
    api_hash = input("API_HASH: ").strip()

    async with TelegramClient(StringSession(), api_id, api_hash) as client:
        session_string = client.session.save()
        print("\n===== SESSION_STRING (nusxa oling) =====\n")
        print(session_string)
        print("\n=========================================")
        print("Shu qatorni .env fayldagi SESSION_STRING ga yozing.")


if __name__ == "__main__":
    asyncio.run(main())