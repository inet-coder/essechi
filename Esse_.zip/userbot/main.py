import asyncio
import logging

import aiohttp
from telethon import TelegramClient, events
from telethon.sessions import StringSession

from config import (
    ADMIN_API_KEY,
    API_HASH,
    API_ID,
    BACKEND_URL,
    CARD_LAST4,
    SESSION_STRING,
    SOURCE_CHAT,
)
from parser import parse_transaction

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("userbot")

client = TelegramClient(StringSession(SESSION_STRING), API_ID, API_HASH)


async def _confirm_on_backend(session: aiohttp.ClientSession, amount: int, card_last4):
    url = f"{BACKEND_URL}/api/payments/confirm-by-amount"
    headers = {"x-admin-key": ADMIN_API_KEY}
    payload = {"amount": amount, "cardLast4": card_last4}
    async with session.post(url, json=payload, headers=headers) as response:
        data = await response.json()
        return response.status, data


@client.on(events.NewMessage(chats=SOURCE_CHAT))
async def on_transaction(event) -> None:
    tx = parse_transaction(event.message.message or "")
    if tx is None:
        return  # tranzaksiya emas yoki chiqim - e'tiborsiz

    # Faqat bizning kartaga tushgan pullar (agar xabarda karta ko'rsatilgan bo'lsa)
    if tx["card_last4"] and CARD_LAST4 and tx["card_last4"] != CARD_LAST4:
        logger.info("Boshqa karta ***%s - e'tiborsiz", tx["card_last4"])
        return

    async with aiohttp.ClientSession() as session:
        try:
            status, data = await _confirm_on_backend(
                session, tx["amount"], tx["card_last4"]
            )
        except Exception:
            logger.exception("Backendga ulanishda xatolik (summa: %s)", tx["amount"])
            return

    if data.get("matched"):
        logger.info(
            "✅ Tasdiqlandi: %s so'm  (payment #%s, tg %s, balans %s)",
            data["amount"],
            data["paymentId"],
            data["telegramId"],
            data["balance"],
        )
    else:
        logger.warning(
            "⚠️ Mos pending to'lov topilmadi: %s so'm (karta ***%s, status %s)",
            tx["amount"],
            tx["card_last4"],
            status,
        )


async def main() -> None:
    await client.start()
    me = await client.get_me()
    logger.info("Userbot ishga tushdi: %s (id %s)", me.first_name, me.id)
    logger.info("Manba: %s | Qabul qiluvchi karta oxirgi 4: %s", SOURCE_CHAT, CARD_LAST4)
    await client.run_until_disconnected()


if __name__ == "__main__":
    asyncio.run(main())