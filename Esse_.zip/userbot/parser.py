import re

# CardXabarBot (Uzcard / PLUM TECHNOLOGIES) karta xabarlarini parse qiladi.
# Faqat KIRIM (➕) tranzaksiyalari qabul qilinadi; chiqim (➖) e'tiborsiz.
#
# Xabar namunasi:
#   🟢 Perevod na kartu
#   ➕ 1 000.00 UZS      <- tranzaksiya summasi (bizga kerak)
#   💳 ***5427           <- qabul qiluvchi karta oxirgi 4 raqami
#   📍 CLICK P2P WALLET 2 UZCARD, UZ
#   🕓 08.07.26 12:30
#   💵 96 332.97 UZS     <- karta balansi (BUNI olmaymiz)

_INCOMING = "➕"
_OUTGOING = "➖"


def _parse_amount(raw: str) -> int | None:
    # Barcha bo'sh joylar (oddiy, nbsp, narrow nbsp) - mingliklar ajratgichi
    cleaned = re.sub(r"[\s\u00a0\u202f]", "", raw)
    # Faqat raqam, nuqta, vergul qoldiramiz
    cleaned = re.sub(r"[^\d.,]", "", cleaned)
    if not cleaned:
        return None

    # Kasr ajratgichini normallashtiramiz: agar faqat vergul bo'lsa - u kasr
    # ajratgichi (1000,00), aks holda nuqta kasr, vergullar - mingliklar.
    if "," in cleaned and "." not in cleaned:
        cleaned = cleaned.replace(",", ".")
    else:
        cleaned = cleaned.replace(",", "")

    try:
        value = float(cleaned)
    except ValueError:
        return None

    # To'lovlar butun so'mda; kasr qismi (.00) tashlab yuboriladi.
    return int(round(value))


def _parse_card_last4(text: str) -> str | None:
    match = re.search(r"\*{2,}\s*(\d{4})", text)
    return match.group(1) if match else None


def parse_transaction(text: str) -> dict | None:
    """Kirim tranzaksiyasi bo'lsa {"amount": int, "card_last4": str|None}
    qaytaradi, aks holda None."""
    if not text:
        return None

    # Kirim summasi qatori: ➕ bor va UZS bor (balans qatoridan ajratish uchun
    # aynan ➕ qatorini olamiz)
    amount_line = next(
        (line for line in text.splitlines() if _INCOMING in line and "UZS" in line.upper()),
        None,
    )
    if amount_line is None:
        return None

    amount = _parse_amount(amount_line)
    if amount is None or amount <= 0:
        return None

    return {"amount": amount, "card_last4": _parse_card_last4(text)}