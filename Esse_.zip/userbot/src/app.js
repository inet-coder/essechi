import express from "express";
import cors from "cors";
import helmet from "helmet";
import path from "path";
import { env } from "./core/env.js";
import { sequelize } from "./core/database.js";
import userRoutes from "./modules/user/user.routes.js";
import essayRoutes from "./modules/essay/essay.routes.js";
import evaluationRoutes from "./modules/evaluation/evaluation.routes.js";
import paymentRoutes from "./modules/payment/payment.routes.js";
import meRoutes from "./modules/me/me.routes.js";
import topicRoutes from "./modules/topic/topic.routes.js";
import articleRoutes from "./modules/article/article.routes.js";
import competitionRoutes from "./modules/competition/competition.routes.js";
import { errorHandler } from "./middleware/errorHandler.js";

const app = express();

// Rasm/fayl statik xizmati (maqola muqovalari) helmet CORP siyosatini
// bo'shashtiramiz, aks holda frontend boshqa origindan rasmni yuklay olmaydi
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.use("/api/users", userRoutes);
app.use("/api/essays", essayRoutes);
app.use("/api/evaluations", evaluationRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/me", meRoutes);
app.use("/api/topics", topicRoutes);
app.use("/api/articles", articleRoutes);
app.use("/api/competitions", competitionRoutes);

app.use(errorHandler);

async function start() {
  try {
    await sequelize.authenticate();
    console.log("Database ulanishi muvaffaqiyatli.");

    // Eslatma: bu faqat yangi jadval yaratish uchun.
    // Mavjud jadvalga ustun qo'shish/o'zgartirish kerak bo'lsa,
    // Varaq'dagidek manual SQL migratsiya yoziladi (sync() buni qilmaydi).
    await sequelize.sync();
    console.log("Modellar sinxronlandi.");

    app.listen(env.port, () => {
      console.log(`Server ${env.port}-portda ishga tushdi.`);
    });
  } catch (error) {
    console.error("Serverni ishga tushirishda xatolik:", error);
    process.exit(1);
  }
}

start();
