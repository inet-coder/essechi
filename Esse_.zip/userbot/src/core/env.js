import dotenv from "dotenv";

dotenv.config();

const required = [
  "DATABASE_URL",
  "OPENAI_API_KEY",
  "ADMIN_API_KEY",
  "BOT_TOKEN",
];

for (const key of required) {
  if (!process.env[key]) {
    throw new Error(`Majburiy environment o'zgaruvchi topilmadi: ${key}`);
  }
}

export const env = {
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || "development",
  databaseUrl: process.env.DATABASE_URL,
  openaiApiKey: process.env.OPENAI_API_KEY,
  // Eslatma: OpenAI model nomlari va narxlari tez-tez o'zgaradi.
  // Joriy mavjud modellarni platform.openai.com/docs dan tekshirib, kerakli
  // model nomini .env faylida OPENAI_MODEL orqali belgilang.
  openaiModel: process.env.OPENAI_MODEL || "gpt-4o",
  // Admin endpointlarni himoyalash uchun oddiy kalit (hozircha to'liq
  // admin-auth tizimi yo'q, faqat shu kalitni biluvchi so'rov yuborolishi mumkin).
  adminApiKey: process.env.ADMIN_API_KEY,
  // Har bir bepul limitdan tashqari esse tekshiruvi narxi (so'm).
  essayCheckPrice: parseInt(process.env.ESSAY_CHECK_PRICE || "5000", 10),
  // Haftalik bepul urinishdan tashqari AI xato tahlili narxi (so'm).
  aiAnalysisPrice: parseInt(process.env.AI_ANALYSIS_PRICE || "3000", 10),
  // Haftalik bepul urinishdan tashqari AI viktorina narxi (so'm).
  quizPrice: parseInt(process.env.QUIZ_PRICE || "2000", 10),
  // Telegram WebApp initData'ni HMAC orqali tekshirish uchun kerak
  // (bot.py'dagi BOT_TOKEN bilan bir xil bo'lishi shart)
  botToken: process.env.BOT_TOKEN,
  // --- Avtomatik to'lov (karta orqali) sozlamalari ---
  // To'lov tushadigan karta va uning egasi (foydalanuvchiga ko'rsatiladi).
  paymentCardNumber: process.env.PAYMENT_CARD_NUMBER || "",
  paymentCardHolder: process.env.PAYMENT_CARD_HOLDER || "",
  // Minimal to'lov summasi (so'm).
  minTopupAmount: parseInt(process.env.MIN_TOPUP_AMOUNT || "2000", 10),
  // Pending to'lov necha daqiqadan keyin bekor bo'ladi. Bank SMS'i kechikishi
  // mumkinligini hisobga olib default 30 qo'yildi (.env orqali o'zgartiriladi).
  paymentExpiryMinutes: parseInt(
    process.env.PAYMENT_EXPIRY_MINUTES || "30",
    10,
  ),
  // --- Musobaqa (adolatli baholash) sozlamalari ---
  // Har esse necha marta baholanadi. Median olinadi - LLM shovqinini
  // yo'qotib, adolatli ball beradi. 2 = yaxshi muvozanat, 3 = eng barqaror
  // (lekin qimmatroq).
  competitionScoringPasses: parseInt(
    process.env.COMPETITION_SCORING_PASSES || "2",
    10,
  ),
  // Podium (1-2-3) uchun juftma-juft solishtiriladigan yuqori esselar soni.
  competitionPodiumK: parseInt(process.env.COMPETITION_PODIUM_K || "6", 10),
  // Partiyaviy baholashda bir vaqtda nechta GPT so'rovi ketadi (rate-limitni
  // bosib qo'ymaslik uchun cheklanadi).
  competitionEvalConcurrency: parseInt(
    process.env.COMPETITION_EVAL_CONCURRENCY || "4",
    10,
  ),
};
