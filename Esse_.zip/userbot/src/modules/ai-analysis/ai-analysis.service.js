import { getUserById } from "../user/user.service.js";
import { Essay } from "../essay/essay.model.js";
import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { AiAnalysis } from "./ai-analysis.model.js";
import { generateAiAnalysis } from "./ai-analysis.gpt.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_ESSAYS_FOR_ANALYSIS = 10;

// Bepul urinish faqat "lastAiAnalysisAt" orqali kuzatiladi - pullik
// urinishlar bu vaqtni yangilamaydi. Shu tufayli, hafta ichida necha marta
// pullik tahlil qilingan bo'lishidan qat'i nazar, keyingi hafta baribir
// 1 marta bepul urinish beriladi.
function nextFreeAt(user) {
  if (!user.lastAiAnalysisAt) return null;
  return new Date(new Date(user.lastAiAnalysisAt).getTime() + WEEK_MS);
}

function isFreeEligible(user) {
  const next = nextFreeAt(user);
  return !next || next.getTime() <= Date.now();
}

export async function getAiAnalysisStatus(userId) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const isFree = isFreeEligible(user);
  const next = nextFreeAt(user);

  const lastAnalysis = await AiAnalysis.findOne({
    where: { userId },
    order: [["createdAt", "DESC"]],
  });

  return {
    isFree,
    nextFreeAt: isFree ? null : next.toISOString(),
    price: env.aiAnalysisPrice,
    balance: user.balance,
    lastAnalysis: lastAnalysis
      ? {
          id: lastAnalysis.id,
          content: lastAnalysis.content,
          wasFree: lastAnalysis.wasFree,
          createdAt: lastAnalysis.createdAt,
        }
      : null,
  };
}

export async function generateMyAiAnalysis(userId) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const isFree = isFreeEligible(user);

  if (!isFree && user.balance < env.aiAnalysisPrice) {
    const next = nextFreeAt(user);
    throw httpError(
      402,
      `Haftalik bepul AI tahlil allaqachon ishlatilgan. Keyingi bepul tahlil: ` +
        `${next.toLocaleDateString("uz-UZ")}. Yoki hoziroq ${env.aiAnalysisPrice} so'm ` +
        `evaziga foydalanishingiz mumkin.`,
    );
  }

  const essays = await Essay.findAll({
    where: { userId },
    include: [{ model: EvaluationResult, as: "evaluationResult" }],
    order: [["createdAt", "DESC"]],
    limit: MAX_ESSAYS_FOR_ANALYSIS,
  });

  const completed = essays.filter(
    (e) => e.evaluationResult?.status === "completed",
  );

  if (completed.length === 0) {
    throw httpError(
      400,
      "AI tahlil qilish uchun kamida bitta muvaffaqiyatli tekshirilgan esse kerak.",
    );
  }

  const essaysData = completed.map((e) => ({
    topic: e.topic,
    totalScore: e.evaluationResult.totalScore,
    bandResults: e.evaluationResult.bandResults,
  }));

  const content = await generateAiAnalysis(essaysData);

  if (isFree) {
    user.lastAiAnalysisAt = new Date();
  } else {
    user.balance -= env.aiAnalysisPrice;
  }
  await user.save();

  const analysis = await AiAnalysis.create({
    userId,
    content,
    wasFree: isFree,
  });

  return {
    id: analysis.id,
    content: analysis.content,
    wasFree: analysis.wasFree,
    createdAt: analysis.createdAt,
  };
}

function toPublicAnalysis(a) {
  return {
    id: a.id,
    content: a.content,
    wasFree: a.wasFree,
    createdAt: a.createdAt,
  };
}

export async function listMyAnalyses(userId) {
  const analyses = await AiAnalysis.findAll({
    where: { userId },
    order: [["createdAt", "DESC"]],
  });
  return analyses.map(toPublicAnalysis);
}

export async function getMyAnalysis(userId, id) {
  const analysis = await AiAnalysis.findOne({ where: { id, userId } });
  if (!analysis) throw httpError(404, "Tahlil topilmadi");
  return toPublicAnalysis(analysis);
}
