import {
  createArticle,
  getPublishedArticles,
  getPublishedArticleById,
  getAllArticles,
  getArticleById,
  updateArticle,
  deleteArticle,
  estimateReadingMinutesFromBody,
} from "./article.service.js";

function coverImagePath(file) {
  return file ? `/uploads/articles/${file.filename}` : undefined;
}

// --- Public (foydalanuvchi) ---

export async function listPublishedArticles(req, res, next) {
  try {
    const articles = await getPublishedArticles();
    res.status(200).json(articles);
  } catch (error) {
    next(error);
  }
}

export async function getPublishedArticle(req, res, next) {
  try {
    const { id } = req.params;
    const article = await getPublishedArticleById(id);

    if (!article) {
      return res.status(404).json({ error: "Maqola topilmadi" });
    }

    res.status(200).json({
      ...article.toJSON(),
      readingMinutes: estimateReadingMinutesFromBody(article.body),
    });
  } catch (error) {
    next(error);
  }
}

// --- Admin ---

export async function adminListArticles(req, res, next) {
  try {
    const articles = await getAllArticles();
    res.status(200).json(articles);
  } catch (error) {
    next(error);
  }
}

export async function adminGetArticle(req, res, next) {
  try {
    const { id } = req.params;
    const article = await getArticleById(id);

    if (!article) {
      return res.status(404).json({ error: "Maqola topilmadi" });
    }

    res.status(200).json(article);
  } catch (error) {
    next(error);
  }
}

export async function adminCreateArticle(req, res, next) {
  try {
    const { title, body, isPublished } = req.body;

    if (!title || !title.trim() || !body || !body.trim()) {
      return res.status(400).json({ error: "title va body majburiy" });
    }

    const article = await createArticle({
      title: title.trim(),
      body: body.trim(),
      coverImage: coverImagePath(req.file),
      isPublished:
        isPublished === undefined
          ? true
          : isPublished === "true" || isPublished === true,
    });

    res.status(201).json(article);
  } catch (error) {
    next(error);
  }
}

export async function adminUpdateArticle(req, res, next) {
  try {
    const { id } = req.params;
    const { title, body, isPublished } = req.body;

    const article = await updateArticle(id, {
      title: title !== undefined ? title.trim() : undefined,
      body: body !== undefined ? body.trim() : undefined,
      coverImage: coverImagePath(req.file),
      isPublished:
        isPublished === undefined
          ? undefined
          : isPublished === "true" || isPublished === true,
    });

    if (!article) {
      return res.status(404).json({ error: "Maqola topilmadi" });
    }

    res.status(200).json(article);
  } catch (error) {
    next(error);
  }
}

export async function adminDeleteArticle(req, res, next) {
  try {
    const { id } = req.params;
    const article = await deleteArticle(id);

    if (!article) {
      return res.status(404).json({ error: "Maqola topilmadi" });
    }

    res.status(200).json({ success: true });
  } catch (error) {
    next(error);
  }
}
