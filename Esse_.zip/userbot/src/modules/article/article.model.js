import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

export const Article = sequelize.define(
  "Article",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    coverImage: {
      type: DataTypes.STRING,
      allowNull: true, // "/uploads/articles/<file>" - Multer orqali yuklanadi
    },
    body: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    // Admin qoralama sifatida saqlab, keyin e'lon qilishi mumkin
    isPublished: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    tableName: "articles",
    timestamps: true,
  },
);
