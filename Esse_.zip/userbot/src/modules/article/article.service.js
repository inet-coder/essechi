import { Article } from "./article.model.js";

export async function createArticle({ title, body, coverImage, isPublished }) {
  return Article.create({
    title,
    body,
    coverImage: coverImage ?? null,
    isPublished: isPublished ?? true,
  });
}

const WORDS_PER_MINUTE = 180;
const EXCERPT_LENGTH = 140;

function estimateReadingMinutes(body) {
  const words = body.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / WORDS_PER_MINUTE));
}

function buildExcerpt(body) {
  const flat = body.trim().replace(/\s+/g, " ");
  if (flat.length <= EXCERPT_LENGTH) return flat;
  return `${flat.slice(0, EXCERPT_LENGTH).trimEnd()}…`;
}

// Foydalanuvchilarga faqat e'lon qilingan maqolalar ko'rsatiladi. Ro'yxat
// yengil bo'lishi uchun to'liq matn (body) qaytarilmaydi - faqat undan
// hisoblangan o'qish vaqti (daqiqa) va qisqa parcha (excerpt) beriladi.
export async function getPublishedArticles() {
  const articles = await Article.findAll({
    where: { isPublished: true },
    order: [["createdAt", "DESC"]],
    attributes: ["id", "title", "coverImage", "body", "createdAt"],
  });

  return articles.map((article) => ({
    id: article.id,
    title: article.title,
    coverImage: article.coverImage,
    createdAt: article.createdAt,
    readingMinutes: estimateReadingMinutes(article.body),
    excerpt: buildExcerpt(article.body),
  }));
}

export function estimateReadingMinutesFromBody(body) {
  return estimateReadingMinutes(body);
}

export async function getPublishedArticleById(id) {
  return Article.findOne({ where: { id, isPublished: true } });
}

// Admin panel - qoralamalar ham shu yerda ko'rinadi
export async function getAllArticles() {
  return Article.findAll({ order: [["createdAt", "DESC"]] });
}

export async function getArticleById(id) {
  return Article.findByPk(id);
}

export async function updateArticle(
  id,
  { title, body, coverImage, isPublished },
) {
  const article = await Article.findByPk(id);
  if (!article) return null;

  if (title !== undefined) article.title = title;
  if (body !== undefined) article.body = body;
  if (coverImage !== undefined) article.coverImage = coverImage;
  if (isPublished !== undefined) article.isPublished = isPublished;

  await article.save();
  return article;
}

export async function deleteArticle(id) {
  const article = await Article.findByPk(id);
  if (!article) return null;
  await article.destroy();
  return article;
}
