import OpenAI from "openai";
import { env } from "../../core/env.js";
import { withRetry } from "../../queue/runQueue.js";

const openai = new OpenAI({ apiKey: env.openaiApiKey });

const SYSTEM_PROMPT = `Sen milliy sertifikat imtihoni esse musobaqasining xolis hakamisan.
Senga bitta topshiriq (mavzu) va ikkita esse beriladi: ESSE_A va ESSE_B.
Vazifang - qaysi esse UMUMAN OLGANDA kuchliroq ekanini aniqlash.

Baholash mezonlari (teng muhim): mavzuga mos kelishi va topshiriqni bajarishi,
fikr izchilligi va tuzilishi, dalillar va misollar kuchi, til boyligi va
grammatik aniqlik, xulosaning ishonarliligi.

Qat'iy qoidalar:
- Esse uzunligiga emas, SIFATIGA qara. Uzunroq esse avtomatik yaxshi emas.
- Mualliflarni bilmaysan - faqat matn sifatiga qarab hukm qil.
- Ikkalasi juda yaqin va aniq ustunlik yo'q bo'lsagina "tie" (durang) qaytar.
- Faqat JSON qaytar.`;

const RESPONSE_SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    winner: { type: "string", enum: ["A", "B", "tie"] },
    reason: { type: "string" },
  },
  required: ["winner", "reason"],
};

async function compareOnce({ topic, textA, textB }) {
  const completion = await openai.chat.completions.create({
    model: env.openaiModel,
    temperature: 0,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content:
          `TOPSHIRIQ VAZIYATI:\n${topic}\n\n` +
          `<<<ESSE_A BOSHLANISHI>>>\n${textA}\n<<<ESSE_A TUGASHI>>>\n\n` +
          `<<<ESSE_B BOSHLANISHI>>>\n${textB}\n<<<ESSE_B TUGASHI>>>`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "pairwise_comparison",
        strict: true,
        schema: RESPONSE_SCHEMA,
      },
    },
  });

  const raw = completion.choices[0]?.message?.content;
  if (!raw) throw new Error("GPT bo'sh javob qaytardi (solishtiruv)");
  return JSON.parse(raw);
}

// Ikki esseni solishtiradi. Tartib biasini (LLM birinchi/ikkinchi o'ringa
// moyilligini) yo'qotish uchun IKKI tartibda so'raymiz va natijani birlashtiramiz.
//   a  - { entryId, text }
//   b  - { entryId, text }
// Qaytaradi: { winner: entryId | null (durang), reason }
export async function comparePair({ topic, a, b }) {
  // 1-tartib: a=A, b=B
  const r1 = await withRetry(() =>
    compareOnce({ topic, textA: a.text, textB: b.text }),
  );
  // 2-tartib: b=A, a=B (almashtirilgan)
  const r2 = await withRetry(() =>
    compareOnce({ topic, textA: b.text, textB: a.text }),
  );

  let aWins = 0;
  let bWins = 0;
  if (r1.winner === "A") aWins += 1;
  else if (r1.winner === "B") bWins += 1;
  if (r2.winner === "A") bWins += 1;
  else if (r2.winner === "B") aWins += 1;

  if (aWins > bWins) return { winner: a.entryId, reason: r1.reason };
  if (bWins > aWins) return { winner: b.entryId, reason: r2.reason };
  return { winner: null, reason: r1.reason };
}
