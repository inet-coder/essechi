import { httpError } from "../../core/httpError.js";
import { getUserByTelegramId } from "../user/user.service.js";
import {
  createEssayFromText,
  createEssayFromPdf,
} from "../essay/essay.service.js";
import {
  listPublicCompetitions,
  getCompetitionForUser,
  joinCompetition,
  attachEssayToEntry,
  getResults,
  listAllCompetitions,
  getCompetitionAdmin,
  createCompetition,
  updateCompetition,
  setCompetitionStatus,
  startEvaluation,
} from "./competition.service.js";

// Foydalanuvchi so'rov tanasidan emas, tekshirilgan Telegram initData'dan
// aniqlanadi (me.essay.controller'dagi naqsh).
async function resolveUser(req) {
  const user = await getUserByTelegramId(req.telegramUser.id);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");
  return user;
}

// --- Public ---

export async function listCompetitions(req, res, next) {
  try {
    const competitions = await listPublicCompetitions();
    res.status(200).json(competitions);
  } catch (error) {
    next(error);
  }
}

export async function getCompetition(req, res, next) {
  try {
    const user = await resolveUser(req);
    const data = await getCompetitionForUser(req.params.id, user.id);
    res.status(200).json(data);
  } catch (error) {
    next(error);
  }
}

export async function join(req, res, next) {
  try {
    const user = await resolveUser(req);
    const entry = await joinCompetition(req.params.id, user.id);
    res.status(201).json(entry);
  } catch (error) {
    next(error);
  }
}

export async function submitTextEssay(req, res, next) {
  try {
    const { text } = req.body;
    if (!text || !text.trim()) throw httpError(400, "text majburiy");

    const user = await resolveUser(req);
    const { topic } = await ensureOpenTopic(req.params.id, user.id);

    const essay = await createEssayFromText({ userId: user.id, topic, text });
    await attachEssayToEntry(req.params.id, user.id, essay.id);
    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

export async function submitPdfEssay(req, res, next) {
  try {
    if (!req.file) throw httpError(400, "PDF fayl yuborilmadi");

    const user = await resolveUser(req);
    const { topic } = await ensureOpenTopic(req.params.id, user.id);

    let essay;
    try {
      essay = await createEssayFromPdf({
        userId: user.id,
        topic,
        filePath: req.file.path,
      });
    } catch {
      throw httpError(
        400,
        "PDF faylni o'qib bo'lmadi. Fayl buzilgan, himoyalangan yoki noto'g'ri " +
          "formatda bo'lishi mumkin. Boshqa PDF bilan urinib ko'ring yoki matn " +
          "ko'rinishida yuboring.",
      );
    }

    await attachEssayToEntry(req.params.id, user.id, essay.id);
    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

// Musobaqa mavzusi essega topic sifatida ishlatiladi (foydalanuvchi kiritmaydi)
// va shu bilan birga musobaqa ochiqligi/qatnashuv tekshiriladi.
async function ensureOpenTopic(competitionId, userId) {
  const { competition, joined } = await getCompetitionForUser(
    competitionId,
    userId,
  );
  if (competition.status !== "open") {
    throw httpError(409, "Musobaqa yopilgan, esse qabul qilinmaydi");
  }
  if (!joined) {
    throw httpError(403, "Avval musobaqaga qatnashing (kirish to'lovi)");
  }
  return { topic: competition.topic };
}

export async function results(req, res, next) {
  try {
    const user = await resolveUser(req);
    const data = await getResults(req.params.id, user.id);
    res.status(200).json(data);
  } catch (error) {
    next(error);
  }
}

// --- Admin ---

export async function adminList(req, res, next) {
  try {
    res.status(200).json(await listAllCompetitions());
  } catch (error) {
    next(error);
  }
}

export async function adminGet(req, res, next) {
  try {
    res.status(200).json(await getCompetitionAdmin(req.params.id));
  } catch (error) {
    next(error);
  }
}

export async function adminCreate(req, res, next) {
  try {
    res.status(201).json(await createCompetition(req.body));
  } catch (error) {
    next(error);
  }
}

export async function adminUpdate(req, res, next) {
  try {
    res.status(200).json(await updateCompetition(req.params.id, req.body));
  } catch (error) {
    next(error);
  }
}

export async function adminSetStatus(req, res, next) {
  try {
    const { status } = req.body;
    res
      .status(200)
      .json(await setCompetitionStatus(req.params.id, status));
  } catch (error) {
    next(error);
  }
}

export async function adminFinish(req, res, next) {
  try {
    // Baholash fon rejimida ishga tushadi; 202 - "qabul qilindi, davom etyapti".
    const competition = await startEvaluation(req.params.id);
    res.status(202).json(competition);
  } catch (error) {
    next(error);
  }
}
