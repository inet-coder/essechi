import { env } from "../../core/env.js";
import { Competition, CompetitionEntry } from "./competition.model.js";
import { User } from "../user/user.model.js";
import { Essay } from "../essay/essay.model.js";
import { evaluateEssayCore } from "../evaluation/evaluation.service.js";
import { addBalance } from "../user/user.service.js";
import { sendTelegramMessage } from "../../integrations/telegram.js";
import { processWithConcurrency } from "../../queue/runQueue.js";
import { comparePair } from "./competition.comparator.js";

// --- 2-bosqich: podiumni juftma-juft solishtirib aniq tartiblash ---
// Copeland usuli: har juft solishtiriladi, g'olib +1, durang har biriga +0.5.
// Keyin g'alaba yig'indisi bo'yicha tartiblanadi (teng bo'lsa - absolyut ball,
// so'ng erta yuborgan).
async function rankByPairwise(topic, pool) {
  const wins = new Map(pool.map((s) => [s.entry.id, 0]));
  const audit = [];

  const pairs = [];
  for (let i = 0; i < pool.length; i += 1) {
    for (let j = i + 1; j < pool.length; j += 1) {
      pairs.push([pool[i], pool[j]]);
    }
  }

  const results = await processWithConcurrency(
    pairs,
    async ([sa, sb]) => {
      const res = await comparePair({
        topic,
        a: { entryId: sa.entry.id, text: sa.essay.rawText },
        b: { entryId: sb.entry.id, text: sb.essay.rawText },
      });
      return { sa, sb, res };
    },
    { concurrency: env.competitionEvalConcurrency },
  );

  for (const r of results) {
    // Solishtiruv texnik xato bersa - o'sha juftni durang kabi tashlab
    // yuboramiz (podium ballari absolyut ball tie-break bilan aniqlanadi).
    if (r.error || !r.res) continue;
    const { sa, sb, res } = r;
    if (res.winner === sa.entry.id) {
      wins.set(sa.entry.id, wins.get(sa.entry.id) + 1);
    } else if (res.winner === sb.entry.id) {
      wins.set(sb.entry.id, wins.get(sb.entry.id) + 1);
    } else {
      wins.set(sa.entry.id, wins.get(sa.entry.id) + 0.5);
      wins.set(sb.entry.id, wins.get(sb.entry.id) + 0.5);
    }
    audit.push({
      a: sa.entry.id,
      b: sb.entry.id,
      winner: res.winner,
      reason: res.reason,
    });
  }

  const order = [...pool].sort((x, y) => {
    const winDiff = wins.get(y.entry.id) - wins.get(x.entry.id);
    if (winDiff !== 0) return winDiff;
    if (y.scaledScore !== x.scaledScore) return y.scaledScore - x.scaledScore;
    return new Date(x.entry.createdAt) - new Date(y.entry.createdAt);
  });

  return { order, audit };
}

async function notifyParticipant(entry, competition) {
  const telegramId = entry.user?.telegramId;
  if (!telegramId) return;

  const lines = [
    `🏆 <b>${competition.title}</b> yakunlandi!`,
    "",
    `📊 Sizning o'rningiz: <b>${entry.rank}</b>`,
    `⭐️ Ballingiz: <b>${entry.scaledScore}</b> / 75`,
  ];

  if (entry.awardedPrize) {
    let prizeLine = `🎁 Mukofot: <b>${entry.awardedPrize.title}</b>`;
    if (entry.awardedPrize.rewardAmount > 0) {
      prizeLine += ` (+${entry.awardedPrize.rewardAmount} so'm balansga qo'shildi)`;
    }
    lines.push("", prizeLine);
  }

  lines.push("", "To'liq natijalar va tahlilni ilovadan ko'ring.");

  try {
    await sendTelegramMessage(telegramId, lines.join("\n"));
  } catch (error) {
    console.error(
      `Musobaqa natija xabari yuborilmadi (tg ${telegramId}):`,
      error.message,
    );
  }
}

// Musobaqani to'liq baholaydi va yakunlaydi. finish() tomonidan status
// "evaluating"ga o'tkazilgandan keyin (odatda fon rejimida) chaqiriladi.
// evaluateEssayCore natijani unique constraint bilan saqlagani uchun jarayon
// uzilsa qayta chaqirilganda qoldigidan davom etadi (idempotent).
export async function runCompetitionEvaluation(competitionId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition) throw new Error("Musobaqa topilmadi");

  const entries = await CompetitionEntry.findAll({
    where: { competitionId },
    include: [
      { model: User, as: "user", attributes: ["id", "telegramId"] },
      { model: Essay, as: "essay" },
    ],
  });

  // Faqat esse yuborganlar reytingga kiradi.
  const submitted = entries.filter((e) => e.essayId && e.essay);

  await Competition.update(
    { evalProgress: { done: 0, total: submitted.length } },
    { where: { id: competitionId } },
  );

  // --- 1-bosqich: absolyut rubrik ball (ko'p o'tishli median) ---
  const scored = await processWithConcurrency(
    submitted,
    async (entry) => {
      try {
        const { result } = await evaluateEssayCore(entry.essay, {
          passes: env.competitionScoringPasses,
        });
        return {
          entry,
          essay: entry.essay,
          status: result.status,
          scaledScore:
            result.status === "completed" ? result.scaledScore : 0,
        };
      } catch (error) {
        // Kutilmagan xato (DB va h.) - esse baholanmadi deb belgilaymiz,
        // partiya to'xtamaydi.
        return {
          entry,
          essay: entry.essay,
          status: "failed",
          scaledScore: 0,
        };
      }
    },
    {
      concurrency: env.competitionEvalConcurrency,
      onProgress: (done, total) =>
        Competition.update(
          { evalProgress: { done, total } },
          { where: { id: competitionId } },
        ),
    },
  );

  // --- 2-bosqich: podium (top-K) juftma-juft aniq tartiblash ---
  const completed = scored
    .filter((s) => s.status === "completed")
    .sort(
      (a, b) =>
        b.scaledScore - a.scaledScore ||
        new Date(a.entry.createdAt) - new Date(b.entry.createdAt),
    );

  const podiumPool = completed.slice(0, env.competitionPodiumK);
  let podiumOrder = podiumPool;
  let audit = [];

  if (podiumPool.length >= 2) {
    const ranked = await rankByPairwise(competition.topic, podiumPool);
    podiumOrder = ranked.order;
    audit = ranked.audit;
  }

  // --- Yakuniy tartib: podium -> qolgan baholanganlar -> baholanmaganlar ---
  const podiumIds = new Set(podiumOrder.map((s) => s.entry.id));
  const restCompleted = completed.filter((s) => !podiumIds.has(s.entry.id));
  const nonCompleted = scored
    .filter((s) => s.status !== "completed")
    .sort((a, b) => new Date(a.entry.createdAt) - new Date(b.entry.createdAt));

  const finalOrder = [...podiumOrder, ...restCompleted, ...nonCompleted];

  // --- Reyting, ball va mukofotlarni yozish ---
  const prizesByPlace = new Map(
    (competition.prizes || []).map((p) => [p.place, p]),
  );

  let rank = 1;
  for (const s of finalOrder) {
    const entry = s.entry;
    entry.rank = rank;
    entry.scaledScore = s.scaledScore;

    const prize = prizesByPlace.get(rank);
    if (prize) {
      entry.awardedPrize = prize;
      if (prize.rewardAmount > 0) {
        await addBalance(entry.userId, prize.rewardAmount);
      }
    }

    await entry.save();
    rank += 1;
  }

  competition.status = "finished";
  competition.evalProgress = {
    done: submitted.length,
    total: submitted.length,
  };
  competition.podiumAudit = audit;
  await competition.save();

  // --- Ishtirokchilarga xabar ---
  for (const s of finalOrder) {
    await notifyParticipant(s.entry, competition);
  }

  return competition;
}
