import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";
import { User } from "../user/user.model.js";
import { Essay } from "../essay/essay.model.js";

export const Competition = sequelize.define(
  "Competition",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    // Hamma uchun bitta umumiy mavzu - adolatli solishtirish uchun.
    topic: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    // Kirish to'lovi (so'm). Qatnashishda balansdan yechiladi.
    entryFee: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    // draft   - yaratildi, hali ko'rinmaydi
    // open    - qatnashish va esse yuborish ochiq
    // closed  - admin yopdi, esse qabul qilinmaydi
    // evaluating - AI partiyaviy baholayapti
    // finished   - o'rinlar e'lon qilingan, natijalar ochiq
    // cancelled  - bekor qilindi (kirish to'lovlari qaytarildi)
    status: {
      type: DataTypes.ENUM(
        "draft",
        "open",
        "closed",
        "evaluating",
        "finished",
        "cancelled",
      ),
      allowNull: false,
      defaultValue: "draft",
    },
    // [{ place: 1, title: "1-o'rin", rewardAmount: 50000 }] - rewardAmount > 0
    // bo'lsa yakunda g'olib balansiga avto qo'shiladi; matnli (jismoniy) sovg'a
    // uchun title yetarli.
    prizes: {
      type: DataTypes.JSONB,
      allowNull: false,
      defaultValue: [],
    },
    // Faqat foydalanuvchiga ko'rsatish uchun (asosiy eshik - status).
    startsAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    endsAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    // Partiyaviy baholash jarayoni holati: { done, total }. Admin panelda
    // "312/500 baholandi" ko'rsatish uchun.
    evalProgress: {
      type: DataTypes.JSONB,
      allowNull: true,
    },
    // Podium juftma-juft solishtiruvi izohi (audit/shaffoflik uchun).
    podiumAudit: {
      type: DataTypes.JSONB,
      allowNull: true,
    },
  },
  {
    tableName: "competitions",
    timestamps: true,
  },
);

export const CompetitionEntry = sequelize.define(
  "CompetitionEntry",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    competitionId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    // Yuborilgan esse (deadline'gacha almashtirilishi mumkin). null - qatnashib
    // esse yubormagan.
    essayId: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    // Yakunda to'ladi.
    rank: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    // Yakunda cache qilinadi (tez reyting uchun - VIRTUAL scaledScore'ni har
    // safar qayta hisoblamaslik).
    scaledScore: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },
    // Yutgan mukofot: { place, title, rewardAmount }. null - mukofotsiz.
    awardedPrize: {
      type: DataTypes.JSONB,
      allowNull: true,
    },
  },
  {
    tableName: "competition_entries",
    timestamps: true,
    indexes: [
      // Bir foydalanuvchi bir musobaqada bir marta qatnashadi.
      { unique: true, fields: ["competitionId", "userId"] },
    ],
  },
);

Competition.hasMany(CompetitionEntry, {
  foreignKey: "competitionId",
  as: "entries",
});
CompetitionEntry.belongsTo(Competition, {
  foreignKey: "competitionId",
  as: "competition",
});

CompetitionEntry.belongsTo(User, { foreignKey: "userId", as: "user" });
CompetitionEntry.belongsTo(Essay, { foreignKey: "essayId", as: "essay" });
