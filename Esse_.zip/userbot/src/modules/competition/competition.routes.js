import { Router } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { requireTelegramAuth } from "../../middleware/telegramAuth.js";
import { requireAdmin } from "../../middleware/requireAdmin.js";
import {
  listCompetitions,
  getCompetition,
  join,
  submitTextEssay,
  submitPdfEssay,
  results,
  adminList,
  adminGet,
  adminCreate,
  adminUpdate,
  adminSetStatus,
  adminFinish,
} from "./competition.controller.js";

const uploadsDir = path.join(process.cwd(), "uploads", "essays");
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => cb(null, `${randomUUID()}.pdf`),
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype !== "application/pdf") {
      return cb(new Error("Faqat PDF fayl qabul qilinadi"));
    }
    cb(null, true);
  },
});

const router = Router();

// --- Admin ("/:id" dan oldin bo'lishi shart) ---
router.get("/admin", requireAdmin, adminList);
router.get("/admin/:id", requireAdmin, adminGet);
router.post("/admin", requireAdmin, adminCreate);
router.patch("/admin/:id", requireAdmin, adminUpdate);
router.post("/admin/:id/status", requireAdmin, adminSetStatus);
router.post("/admin/:id/finish", requireAdmin, adminFinish);

// --- Public (Telegram initData bilan) ---
router.use(requireTelegramAuth);
router.get("/", listCompetitions);
router.get("/:id", getCompetition);
router.get("/:id/results", results);
router.post("/:id/join", join);
router.post("/:id/essays/text", submitTextEssay);
router.post("/:id/essays/pdf", upload.single("file"), submitPdfEssay);

export default router;
