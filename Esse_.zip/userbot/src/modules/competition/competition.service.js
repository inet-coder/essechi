import { Op } from "sequelize";
import { sequelize } from "../../core/database.js";
import { httpError } from "../../core/httpError.js";
import { Competition, CompetitionEntry } from "./competition.model.js";
import { User } from "../user/user.model.js";
import { Essay } from "../essay/essay.model.js";
import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { addBalance } from "../user/user.service.js";
import { runCompetitionEvaluation } from "./competition.evaluator.js";

// Foydalanuvchiga ko'rinadigan statuslar (draft yashirin).
const PUBLIC_STATUSES = ["open", "closed", "evaluating", "finished"];

// --- Public ---

export async function listPublicCompetitions() {
  return Competition.findAll({
    where: { status: { [Op.in]: PUBLIC_STATUSES } },
    order: [["createdAt", "DESC"]],
  });
}

// Musobaqa tafsiloti + shu foydalanuvchining holati (qatnashganmi, esse
// yuborganmi).
export async function getCompetitionForUser(competitionId, userId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.status === "draft") {
    throw httpError(404, "Musobaqa topilmadi");
  }

  const entry = await CompetitionEntry.findOne({
    where: { competitionId, userId },
  });

  return {
    competition,
    joined: Boolean(entry),
    hasEssay: Boolean(entry?.essayId),
    entryEssayId: entry?.essayId ?? null,
  };
}

// Qatnashish: kirish to'lovini balansdan yechadi. Butun amal tranzaksiyada,
// qator bloklab (FOR UPDATE) - bir vaqtda ikki so'rov kelsa ham ikki marta
// yechilmaydi. Allaqachon qatnashgan bo'lsa - qayta to'lovsiz mavjud yozuvni
// qaytaradi (idempotent).
export async function joinCompetition(competitionId, userId) {
  return sequelize.transaction(async (t) => {
    const competition = await Competition.findByPk(competitionId, {
      lock: t.LOCK.UPDATE,
      transaction: t,
    });
    if (!competition || competition.status === "draft") {
      throw httpError(404, "Musobaqa topilmadi");
    }
    if (competition.status !== "open") {
      throw httpError(409, "Musobaqa hozir ochiq emas");
    }

    const existing = await CompetitionEntry.findOne({
      where: { competitionId, userId },
      transaction: t,
    });
    if (existing) return existing;

    const user = await User.findByPk(userId, {
      lock: t.LOCK.UPDATE,
      transaction: t,
    });
    if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

    if (user.balance < competition.entryFee) {
      throw httpError(
        402,
        `Balans yetarli emas. Kirish to'lovi: ${competition.entryFee} so'm`,
      );
    }

    user.balance -= competition.entryFee;
    await user.save({ transaction: t });

    return CompetitionEntry.create(
      { competitionId, userId },
      { transaction: t },
    );
  });
}

// Yuborilgan esseni entry'ga bog'laydi (deadline'gacha almashtirilishi mumkin).
// Esse yozuvi chaqiruvchi (controller) tomonidan oldindan yaratiladi.
export async function attachEssayToEntry(competitionId, userId, essayId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.status === "draft") {
    throw httpError(404, "Musobaqa topilmadi");
  }
  if (competition.status !== "open") {
    throw httpError(409, "Musobaqa yopilgan, esse qabul qilinmaydi");
  }

  const entry = await CompetitionEntry.findOne({
    where: { competitionId, userId },
  });
  if (!entry) {
    throw httpError(403, "Avval musobaqaga qatnashing (kirish to'lovi)");
  }

  entry.essayId = essayId;
  await entry.save();
  return entry;
}

// Yakuniy natijalar: to'liq reyting + so'rovchining o'z tahlili. Faqat
// "finished" holatda ochiladi.
export async function getResults(competitionId, userId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.status === "draft") {
    throw httpError(404, "Musobaqa topilmadi");
  }
  if (competition.status !== "finished") {
    throw httpError(409, "Natijalar hali e'lon qilinmagan");
  }

  const entries = await CompetitionEntry.findAll({
    where: { competitionId },
    include: [
      { model: User, as: "user", attributes: ["id", "firstName"] },
      {
        model: Essay,
        as: "essay",
        include: [
          { model: EvaluationResult, as: "evaluationResult" },
        ],
      },
    ],
    order: [["rank", "ASC"]],
  });

  const ranking = entries
    .filter((e) => e.rank != null)
    .map((e) => ({
      rank: e.rank,
      userId: e.userId,
      firstName: e.user?.firstName || "Noma'lum",
      scaledScore: e.scaledScore,
      status: e.essay?.evaluationResult?.status || "failed",
      prize: e.awardedPrize || null,
      isMe: e.userId === userId,
    }));

  // So'rovchining o'z essesi tahlili (band natijalari, tavsiyalar).
  const myEntry = entries.find((e) => e.userId === userId);
  const myResult = myEntry?.essay?.evaluationResult || null;

  return {
    competition: {
      id: competition.id,
      title: competition.title,
      topic: competition.topic,
      prizes: competition.prizes,
    },
    ranking,
    myResult: myResult
      ? {
          rank: myEntry.rank,
          scaledScore: myEntry.scaledScore,
          status: myResult.status,
          bandResults: myResult.bandResults,
          recommendations: myResult.recommendations,
          rejectionReason: myResult.rejectionReason,
          prize: myEntry.awardedPrize || null,
        }
      : null,
  };
}

// --- Admin ---

export async function listAllCompetitions() {
  return Competition.findAll({ order: [["createdAt", "DESC"]] });
}

export async function getCompetitionAdmin(competitionId) {
  const competition = await Competition.findByPk(competitionId, {
    include: [
      {
        model: CompetitionEntry,
        as: "entries",
        include: [{ model: User, as: "user", attributes: ["firstName"] }],
      },
    ],
    order: [[{ model: CompetitionEntry, as: "entries" }, "rank", "ASC"]],
  });
  if (!competition) throw httpError(404, "Musobaqa topilmadi");
  return competition;
}

export async function createCompetition(data) {
  const { title, topic, description, entryFee, prizes, startsAt, endsAt } =
    data;
  if (!title || !title.trim() || !topic || !topic.trim()) {
    throw httpError(400, "title va topic majburiy");
  }
  return Competition.create({
    title: title.trim(),
    topic: topic.trim(),
    description: description || null,
    entryFee: Number.isInteger(entryFee) ? entryFee : 0,
    prizes: Array.isArray(prizes) ? prizes : [],
    startsAt: startsAt || null,
    endsAt: endsAt || null,
    status: "draft",
  });
}

// Tahrirlash faqat draft/open holatda (baholash boshlangach o'zgartirilmaydi).
export async function updateCompetition(competitionId, data) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition) throw httpError(404, "Musobaqa topilmadi");
  if (!["draft", "open"].includes(competition.status)) {
    throw httpError(409, "Bu holatda musobaqani tahrirlab bo'lmaydi");
  }

  const fields = [
    "title",
    "topic",
    "description",
    "entryFee",
    "prizes",
    "startsAt",
    "endsAt",
  ];
  for (const field of fields) {
    if (data[field] !== undefined) competition[field] = data[field];
  }
  await competition.save();
  return competition;
}

// Ruxsat etilgan qo'lda status o'tishlari (admin panel tugmalari).
const ALLOWED_TRANSITIONS = {
  open: ["draft", "closed"], // -> open
  closed: ["open"], // -> closed
  cancelled: ["draft", "open", "closed"], // -> cancelled
};

export async function setCompetitionStatus(competitionId, nextStatus) {
  const allowedFrom = ALLOWED_TRANSITIONS[nextStatus];
  if (!allowedFrom) {
    throw httpError(400, "Noto'g'ri status o'tishi");
  }

  const competition = await Competition.findByPk(competitionId);
  if (!competition) throw httpError(404, "Musobaqa topilmadi");
  if (!allowedFrom.includes(competition.status)) {
    throw httpError(
      409,
      `"${competition.status}" holatidan "${nextStatus}"ga o'tib bo'lmaydi`,
    );
  }

  if (nextStatus === "cancelled") {
    await refundAllEntries(competition.id);
  }

  competition.status = nextStatus;
  await competition.save();
  return competition;
}

// Bekor qilinganda barcha kirish to'lovlarini balansga qaytaramiz.
async function refundAllEntries(competitionId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition || competition.entryFee <= 0) return;

  const entries = await CompetitionEntry.findAll({ where: { competitionId } });
  for (const entry of entries) {
    await addBalance(entry.userId, competition.entryFee);
  }
}

// Yopilgan musobaqani baholab yakunlaydi. Status "evaluating"ga o'tkaziladi va
// og'ir partiya fon rejimida ishga tushadi (HTTP so'rov darhol qaytadi). Xato
// bo'lsa admin qayta urina olishi uchun "closed"ga qaytariladi.
export async function startEvaluation(competitionId) {
  const competition = await Competition.findByPk(competitionId);
  if (!competition) throw httpError(404, "Musobaqa topilmadi");
  if (competition.status !== "closed") {
    throw httpError(409, "Baholash uchun avval musobaqani yoping");
  }

  competition.status = "evaluating";
  competition.evalProgress = { done: 0, total: 0 };
  await competition.save();

  // Fon rejimida (await qilinmaydi).
  runCompetitionEvaluation(competitionId).catch(async (error) => {
    console.error("Musobaqa baholashda xatolik:", error);
    await Competition.update(
      { status: "closed" },
      { where: { id: competitionId } },
    );
  });

  return competition;
}
