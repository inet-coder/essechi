import { getUserByTelegramId } from "../user/user.service.js";
import {
  createEssayFromText,
  createEssayFromPdf,
  getEssayById,
} from "./essay.service.js";
import { extractTextFromImages } from "./essay.imageExtractor.js";
import { httpError } from "../../core/httpError.js";

export async function submitTextEssay(req, res, next) {
  try {
    const { telegramId, topic, text } = req.body;

    if (!telegramId || !topic || !text) {
      return res
        .status(400)
        .json({ error: "telegramId, topic va text majburiy" });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const essay = await createEssayFromText({ userId: user.id, topic, text });
    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

export async function submitPdfEssay(req, res, next) {
  try {
    const { telegramId, topic } = req.body;

    if (!telegramId || !topic) {
      return res.status(400).json({ error: "telegramId va topic majburiy" });
    }
    if (!req.file) {
      return res.status(400).json({ error: "PDF fayl yuborilmadi" });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    let essay;
    try {
      essay = await createEssayFromPdf({
        userId: user.id,
        topic,
        filePath: req.file.path,
      });
    } catch (pdfError) {
      // pdf-parse buzilgan/himoyalangan/noto'g'ri formatdagi PDF fayllarda
      // xato tashlaydi (masalan "bad XRef entry"). Bu foydalanuvchi
      // tushunadigan, aniq xabar bilan qaytariladi - ichki stack trace emas.
      return res.status(400).json({
        error:
          "PDF faylni o'qib bo'lmadi. Fayl buzilgan, himoyalangan yoki " +
          "noto'g'ri formatda bo'lishi mumkin. Boshqa PDF bilan urinib " +
          "ko'ring yoki matn ko'rinishida yuboring.",
      });
    }

    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

export async function getEssay(req, res, next) {
  try {
    const { id } = req.params;
    const essay = await getEssayById(id);

    if (!essay) {
      return res.status(404).json({ error: "Esse topilmadi" });
    }

    res.status(200).json(essay);
  } catch (error) {
    next(error);
  }
}

// Bu endpoint Essay yozuvi YARATMAYDI, balans/limitni tekshirmaydi - u faqat
// rasm(lar)dagi qo'lyozma matnni o'qib beradi. Foydalanuvchi natijani
// tasdiqlagach, oddiy /text endpointi orqali (submitTextEssay) haqiqiy
// urinish sifatida yuboriladi - shu bilan to'lov/limit logikasi
// takrorlanmaydi va bekor qilingan urinishlar DB'da chala qolib ketmaydi.
export async function extractImageText(req, res, next) {
  try {
    if (!req.files || req.files.length === 0) {
      throw httpError(400, "Kamida bitta rasm yuborilishi kerak");
    }

    const imageFiles = req.files.map((f) => ({
      buffer: f.buffer,
      mimeType: f.mimetype,
    }));

    let text;
    try {
      text = await extractTextFromImages(imageFiles);
    } catch (gptError) {
      throw httpError(
        502,
        "Rasmni tahlil qilishda xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring.",
      );
    }

    if (text.startsWith("XATOLIK:")) {
      throw httpError(
        422,
        "Qo'lyozmani tanib bo'lmadi. Iltimos, yorug'roq va aniqroq surat bilan qayta urinib ko'ring.",
      );
    }

    res.status(200).json({ text });
  } catch (error) {
    next(error);
  }
}
