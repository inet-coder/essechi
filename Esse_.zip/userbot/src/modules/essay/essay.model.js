import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";
import { User } from "../user/user.model.js";

export const Essay = sequelize.define(
  "Essay",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    topic: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    sourceType: {
      type: DataTypes.ENUM("text", "pdf"),
      allowNull: false,
    },
    rawText: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    filePath: {
      type: DataTypes.STRING,
      allowNull: true, // faqat sourceType: 'pdf' bo'lganda to'ladi
    },
    wordCount: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    language: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("pending", "checked", "rejected"),
      allowNull: false,
      defaultValue: "pending",
    },
  },
  {
    tableName: "essays",
    timestamps: true,
  },
);

Essay.belongsTo(User, { foreignKey: "userId", as: "user" });
User.hasMany(Essay, { foreignKey: "userId", as: "essays" });
