import { Router } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import {
  submitTextEssay,
  submitPdfEssay,
  extractImageText,
  getEssay,
} from "./essay.controller.js";

const uploadsDir = path.join(process.cwd(), "uploads", "essays");
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => cb(null, `${randomUUID()}.pdf`),
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype !== "application/pdf") {
      return cb(new Error("Faqat PDF fayl qabul qilinadi"));
    }
    cb(null, true);
  },
});

// Qo'lyozma rasmlar diskka saqlanmaydi - faqat bitta GPT so'roviga
// yuborilib, darhol tashlab yuboriladi, shuning uchun xotirada saqlash
// (memoryStorage) yetarli va tezroq.
const MAX_IMAGE_PAGES = 5;
const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: MAX_IMAGE_PAGES }, // 5MB/dona
  fileFilter: (req, file, cb) => {
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.mimetype)) {
      return cb(new Error("Faqat JPEG, PNG yoki WEBP rasm qabul qilinadi"));
    }
    cb(null, true);
  },
});

const router = Router();

router.post("/text", submitTextEssay);
router.post("/pdf", upload.single("file"), submitPdfEssay);
router.post(
  "/extract-image-text",
  imageUpload.array("files", MAX_IMAGE_PAGES),
  extractImageText,
);
router.get("/:id", getEssay);

export default router;
