import fs from "fs/promises";
import { Essay } from "./essay.model.js";
import {
  extractTextFromPdf,
  countWords,
  detectScript,
} from "./essay.extractor.js";

export async function createEssayFromText({ userId, topic, text }) {
  const wordCount = countWords(text);
  const language = detectScript(text);

  return Essay.create({
    userId,
    topic,
    sourceType: "text",
    rawText: text,
    wordCount,
    language,
  });
}

export async function createEssayFromPdf({ userId, topic, filePath }) {
  const fileBuffer = await fs.readFile(filePath);
  const text = await extractTextFromPdf(fileBuffer);
  const wordCount = countWords(text);
  const language = detectScript(text);

  return Essay.create({
    userId,
    topic,
    sourceType: "pdf",
    rawText: text,
    filePath,
    wordCount,
    language,
  });
}

export async function getEssayById(id) {
  return Essay.findByPk(id);
}
