import { evaluateEssay, getUserHistory } from "./evaluation.service.js";
import { EvaluationResult } from "./evaluation.model.js";
import { getUserByTelegramId } from "../user/user.service.js";

export async function submitEvaluation(req, res, next) {
  try {
    const { essayId } = req.body;

    if (!essayId) {
      return res.status(400).json({ error: "essayId majburiy" });
    }

    const result = await evaluateEssay(essayId);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
}

export async function getHistory(req, res, next) {
  try {
    const { telegramId } = req.params;
    const user = await getUserByTelegramId(telegramId);

    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const essays = await getUserHistory(user.id);
    res.status(200).json(essays);
  } catch (error) {
    next(error);
  }
}
export async function getEvaluation(req, res, next) {
  try {
    const { id } = req.params;
    const result = await EvaluationResult.findByPk(id);

    if (!result) {
      return res.status(404).json({ error: "Natija topilmadi" });
    }

    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
}
