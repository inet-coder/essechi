import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";
import { Essay } from "../essay/essay.model.js";
import { convertToStandardScale } from "./evaluation.scoreCalculator.js";

export const EvaluationResult = sequelize.define(
  "EvaluationResult",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    essayId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      unique: true, // bitta essega faqat bitta natija - DB darajasida himoya
    },
    status: {
      type: DataTypes.ENUM("auto_rejected", "completed", "failed"),
      allowNull: false,
    },
    totalScore: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    // Milliy sertifikat tizimidagi rasmiy 75 ballik shkala ekvivalenti.
    // DBda saqlanmaydi - totalScore'dan har safar avtomatik hisoblanadi
    // (VIRTUAL), shuning uchun formula o'zgarsa ham eski yozuvlar ham
    // to'g'ri qiymat qaytaradi.
    scaledScore: {
      type: DataTypes.VIRTUAL,
      get() {
        const raw = this.getDataValue("totalScore");
        if (raw === null || raw === undefined) return null;
        return convertToStandardScale(raw);
      },
    },
    // Har bir banddagi natija: [{ band, score, errors: [{original, suggestion, explanation}] }]
    bandResults: {
      type: DataTypes.JSONB,
      allowNull: true,
    },
    // Band darajasidagi umumiy tavsiyalar: ["Shaxsiy fikrni kengroq yoriting (band 2)"]
    recommendations: {
      type: DataTypes.JSONB,
      allowNull: true,
    },
    // Faqat status = 'auto_rejected' bo'lganda to'ladi
    rejectionReason: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    tableName: "evaluation_results",
    timestamps: true,
  },
);

EvaluationResult.belongsTo(Essay, { foreignKey: "essayId", as: "essay" });
Essay.hasOne(EvaluationResult, {
  foreignKey: "essayId",
  as: "evaluationResult",
});
