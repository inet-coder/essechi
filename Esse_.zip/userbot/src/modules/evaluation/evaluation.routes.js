import { Router } from "express";
import {
  submitEvaluation,
  getEvaluation,
  getHistory,
} from "./evaluation.controller.js";

const router = Router();

router.post("/", submitEvaluation);
router.get("/history/:telegramId", getHistory);
router.get("/:id", getEvaluation);

export default router;
