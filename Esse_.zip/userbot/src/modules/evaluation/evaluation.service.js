import { Essay } from "../essay/essay.model.js";
import { EvaluationResult } from "./evaluation.model.js";
import { runPrecheck } from "./evaluation.precheck.js";
import { evaluateWithGpt } from "./evaluation.gpt.js";
import {
  resolveAutoReject,
  validateBands,
  calculateTotalScore,
} from "./evaluation.scoreCalculator.js";
import { FREE_ATTEMPTS_LIMIT } from "./evaluation.constants.js";
import { getEssayById } from "../essay/essay.service.js";
import {
  getUserById,
  incrementAttemptsUsed,
  deductBalance,
} from "../user/user.service.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

// DB darajasidagi unique constraint orqali himoyalangan saqlash.
// Agar parallel so'rov sababli bu essayId uchun natija allaqachon yozilgan
// bo'lsa (race condition), xato tashlamasdan mavjud natijani qaytaradi va
// buni "yangi yaratilmadi" deb belgilaydi - shu orqali chaqiruvchi tomon
// ikkinchi marta urinish/balansni hisobga olmaydi.
async function saveResult({
  essayId,
  status,
  totalScore,
  bandResults = [],
  recommendations = [],
  rejectionReason = null,
}) {
  try {
    const created = await EvaluationResult.create({
      essayId,
      status,
      totalScore,
      bandResults,
      recommendations,
      rejectionReason,
    });
    return { result: created, isNew: true };
  } catch (error) {
    if (error.name === "SequelizeUniqueConstraintError") {
      const existing = await EvaluationResult.findOne({ where: { essayId } });
      return { result: existing, isNew: false };
    }
    throw error;
  }
}

// Bir nechta GPT o'tishidan "vakil" (median) natijani tanlaydi - Frankenstein
// o'rtacha ball chiqarmasdan, aynan bitta haqiqiy, izchil javobni oladi
// (shuning uchun bandlar validatsiyadan o'tadi va izoh/ballar bir-biriga mos).
//   1) auto-reject ovozi: o'tishlarning ko'pchiligi essени rad etsa - rad.
//      Juft sonli o'tishda durang bo'lsa RAD ETILMAYDI (pullik ishtirokka
//      shubha foydasiga hukm - noto'g'ri rad qilmaslik uchun).
//   2) qolgan (baholangan) o'tishlar orasidan umumiy ball bo'yicha median
//      o'tish tanlanadi.
function aggregatePasses(responses) {
  const rejects = responses
    .map((r) => resolveAutoReject(r.validity))
    .filter(Boolean);

  if (rejects.length > responses.length / 2) {
    return { autoReject: rejects[0] };
  }

  const scored = responses
    .filter((r) => !resolveAutoReject(r.validity))
    .map((r) => ({ response: r, total: calculateTotalScore(r.bands) }))
    .sort((a, b) => a.total - b.total);

  const mid = scored[Math.floor((scored.length - 1) / 2)];
  return { scored: mid.response, totalScore: mid.total };
}

// Baholashning "yadrosi": precheck -> GPT (passes marta, median) -> natijani
// saqlaydi. Balans/urinish hisob-kitobiga TEGMAYDI - shuning uchun ham oddiy
// foydalanuvchi oqimi (evaluateEssay), ham musobaqa partiyasi shuni ishlatadi.
// passes > 1 bo'lsa self-consistency (median) qo'llanadi - musobaqada shovqinni
// yo'qotib, adolatli ball beradi.
export async function evaluateEssayCore(essay, { passes = 1 } = {}) {
  const existing = await EvaluationResult.findOne({
    where: { essayId: essay.id },
  });
  if (existing) return { result: existing, isNew: false };

  // 1-bosqich: lokal precheck (GPTsiz)
  const precheckResult = runPrecheck({
    rawText: essay.rawText,
    wordCount: essay.wordCount,
    language: essay.language,
  });

  if (!precheckResult.passed) {
    return saveResult({
      essayId: essay.id,
      status: "auto_rejected",
      totalScore: precheckResult.totalScore,
      rejectionReason: precheckResult.rejectionReason,
    });
  }

  // 2-bosqich: GPT chaqiruvi passes marta. Struktura talabiga mos kelmagan yoki
  // xato bergan o'tish tashlab yuboriladi; birortasi ham o'tmasa - failed
  // (texnik xatolik, balans/urinish sarflanmaydi).
  const responses = [];
  let lastError = null;
  for (let i = 0; i < passes; i += 1) {
    try {
      const response = await evaluateWithGpt({
        topic: essay.topic,
        essayText: essay.rawText,
      });
      if (!resolveAutoReject(response.validity)) {
        validateBands(response.bands);
      }
      responses.push(response);
    } catch (error) {
      lastError = error;
    }
  }

  if (responses.length === 0) {
    return saveResult({
      essayId: essay.id,
      status: "failed",
      totalScore: 0,
      rejectionReason: `GPT chaqiruvida xatolik: ${lastError?.message}`,
    });
  }

  const agg = aggregatePasses(responses);

  if (agg.autoReject) {
    return saveResult({
      essayId: essay.id,
      status: "auto_rejected",
      totalScore: agg.autoReject.totalScore,
      rejectionReason: agg.autoReject.rejectionReason,
    });
  }

  return saveResult({
    essayId: essay.id,
    status: "completed",
    totalScore: agg.totalScore,
    bandResults: agg.scored.bands,
    recommendations: agg.scored.recommendations,
  });
}

export async function evaluateEssay(essayId) {
  // Tezkor tekshiruv: natija allaqachon mavjud bo'lsa (ikki marta bosildi yoki
  // so'rov qayta yuborildi), GPT chaqirmasdan, urinish sarflamasdan qaytaramiz.
  const existingResult = await EvaluationResult.findOne({ where: { essayId } });
  if (existingResult) {
    return existingResult;
  }

  const essay = await getEssayById(essayId);
  if (!essay) {
    throw httpError(404, "Esse topilmadi");
  }

  const user = await getUserById(essay.userId);
  if (!user) {
    throw httpError(404, "Foydalanuvchi topilmadi");
  }

  const isFreeAttempt = user.totalAttemptsUsed < FREE_ATTEMPTS_LIMIT;

  if (!isFreeAttempt && user.balance < env.essayCheckPrice) {
    throw httpError(
      402,
      `Bepul urinishlar tugagan. Davom etish uchun balansingizda kamida ${env.essayCheckPrice} so'm bo'lishi kerak.`,
    );
  }

  const { result, isNew } = await evaluateEssayCore(essay, { passes: 1 });

  // Hisob-kitob faqat YANGI, texnik xato bo'lmagan natijada: bepul limit ichida
  // bo'lsa sanoq oshadi, tashqarida bo'lsa balansdan yechiladi. "failed"
  // (texnik xato) urinish sarflatmaydi.
  if (isNew && result.status !== "failed") {
    if (!isFreeAttempt) {
      await deductBalance(user.id, env.essayCheckPrice);
    }
    await incrementAttemptsUsed(user.id);
  }

  return result;
}

// Bot/Web app uchun: foydalanuvchining barcha esselarini, har biriga tegishli
// baholash natijasi (mavjud bo'lsa) bilan birga qaytaradi.
export async function getUserHistory(userId) {
  return Essay.findAll({
    where: { userId },
    include: [{ model: EvaluationResult, as: "evaluationResult" }],
    order: [["createdAt", "DESC"]],
  });
}
