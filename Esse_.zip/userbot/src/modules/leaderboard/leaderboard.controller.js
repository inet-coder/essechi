import { getLeaderboard } from "./leaderboard.service.js";

const VALID_PERIODS = new Set(["daily", "weekly", "monthly"]);

export async function getLeaderboardHandler(req, res, next) {
  try {
    const { period } = req.query;

    if (!VALID_PERIODS.has(period)) {
      return res.status(400).json({
        error: "period 'daily', 'weekly' yoki 'monthly' bo'lishi kerak",
      });
    }

    const leaderboard = await getLeaderboard(period);
    res.status(200).json({ period, leaderboard });
  } catch (error) {
    next(error);
  }
}
