import { Op } from "sequelize";
import { EvaluationResult } from "../evaluation/evaluation.model.js";
import { Essay } from "../essay/essay.model.js";
import { User } from "../user/user.model.js";

const PERIOD_DAYS = {
  daily: 1,
  weekly: 7,
  monthly: 30,
};

const TOP_LIMIT = 20;

function getPeriodStartDate(period) {
  const days = PERIOD_DAYS[period];
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date;
}

// Berilgan davr (kunlik/haftalik/oylik) ichida yaratilgan, to'liq tekshirilgan
// (completed) esselar bo'yicha, har bir foydalanuvchining ENG YUQORI
// natijasiga asoslangan reyting. Hozircha barcha mavzular birlashtirilgan
// holda hisoblanadi (mavzu bo'yicha filtrlash keyinroq qo'shiladi).
export async function getLeaderboard(period) {
  const startDate = getPeriodStartDate(period);

  const results = await EvaluationResult.findAll({
    where: {
      status: "completed",
      createdAt: { [Op.gte]: startDate },
    },
    include: [
      {
        model: Essay,
        as: "essay",
        attributes: ["userId"],
        include: [{ model: User, as: "user", attributes: ["firstName"] }],
      },
    ],
    attributes: ["totalScore", "createdAt"],
  });

  // userId -> { firstName, scaledScore, totalScore, achievedAt }
  const bestByUser = new Map();

  for (const result of results) {
    const userId = result.essay.userId;
    const firstName = result.essay.user?.firstName || "Noma'lum";
    const scaledScore = result.scaledScore;

    const existing = bestByUser.get(userId);
    if (!existing || scaledScore > existing.scaledScore) {
      bestByUser.set(userId, {
        userId,
        firstName,
        scaledScore,
        totalScore: result.totalScore,
        achievedAt: result.createdAt,
      });
    }
  }

  const leaderboard = [...bestByUser.values()]
    .sort((a, b) => b.scaledScore - a.scaledScore)
    .slice(0, TOP_LIMIT)
    .map((entry, index) => ({ rank: index + 1, ...entry }));

  return leaderboard;
}
