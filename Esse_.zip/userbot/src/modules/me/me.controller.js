import { getUserByTelegramId } from "../user/user.service.js";
import { getUserHistory } from "../evaluation/evaluation.service.js";
import { getUserBandStats } from "./me.stats.service.js";
import { getUserSummary } from "./me.summary.service.js";
import { httpError } from "../../core/httpError.js";

export async function getMyProfile(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }
    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
}

export async function getMyHistory(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }
    const essays = await getUserHistory(user.id);
    res.status(200).json(essays);
  } catch (error) {
    next(error);
  }
}

export async function getMyStats(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }
    const stats = await getUserBandStats(user.id);
    res.status(200).json(stats);
  } catch (error) {
    next(error);
  }
}

export async function getMySummary(req, res, next) {
  try {
    const user = await getUserByTelegramId(req.telegramUser.id);
    if (!user) {
      throw httpError(404, "Foydalanuvchi topilmadi");
    }
    const summary = await getUserSummary(user.id);
    res.status(200).json(summary);
  } catch (error) {
    next(error);
  }
}
