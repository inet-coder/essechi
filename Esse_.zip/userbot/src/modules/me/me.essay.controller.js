import { getUserByTelegramId } from "../user/user.service.js";
import {
  createEssayFromText,
  createEssayFromPdf,
  getEssayById,
} from "../essay/essay.service.js";
import { evaluateEssay } from "../evaluation/evaluation.service.js";
import { httpError } from "../../core/httpError.js";

// Bot'dagi /api/essays/* endpointlaridan farqli ravishda, bu yerda
// foydalanuvchi so'rov tanasidan (body) emas, balki tekshirilgan Telegram
// initData'dan (req.telegramUser, requireTelegramAuth middleware'i orqali)
// aniqlanadi - shu orqali kimdir boshqa birovning telegramId'sidan
// foydalanib esse yubora olmaydi.
async function resolveUser(req) {
  const user = await getUserByTelegramId(req.telegramUser.id);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");
  return user;
}

export async function submitMyTextEssay(req, res, next) {
  try {
    const { topic, text } = req.body;
    if (!topic || !topic.trim() || !text || !text.trim()) {
      throw httpError(400, "topic va text majburiy");
    }

    const user = await resolveUser(req);
    const essay = await createEssayFromText({
      userId: user.id,
      topic: topic.trim(),
      text,
    });
    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

export async function submitMyPdfEssay(req, res, next) {
  try {
    const { topic } = req.body;
    if (!topic || !topic.trim()) {
      throw httpError(400, "topic majburiy");
    }
    if (!req.file) {
      throw httpError(400, "PDF fayl yuborilmadi");
    }

    const user = await resolveUser(req);

    let essay;
    try {
      essay = await createEssayFromPdf({
        userId: user.id,
        topic: topic.trim(),
        filePath: req.file.path,
      });
    } catch {
      // pdf-parse buzilgan/himoyalangan PDF'larda xato tashlaydi - foydalanuvchiga
      // ichki stack trace o'rniga tushunarli xabar qaytariladi.
      throw httpError(
        400,
        "PDF faylni o'qib bo'lmadi. Fayl buzilgan, himoyalangan yoki noto'g'ri " +
          "formatda bo'lishi mumkin. Boshqa PDF bilan urinib ko'ring yoki matn " +
          "ko'rinishida yuboring.",
      );
    }

    res.status(201).json(essay);
  } catch (error) {
    next(error);
  }
}

export async function evaluateMyEssay(req, res, next) {
  try {
    const { essayId } = req.params;
    const user = await resolveUser(req);
    const essay = await getEssayById(essayId);

    if (!essay) throw httpError(404, "Esse topilmadi");
    // Egalik tekshiruvi - boshqa foydalanuvchining essayId'sini taxmin qilib
    // uning balansi/urinishlarini "yeb qo'yish" imkoniyatini yopadi.
    if (essay.userId !== user.id)
      throw httpError(403, "Bu esse sizga tegishli emas");

    const result = await evaluateEssay(essayId);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
}
