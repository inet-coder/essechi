import { Router } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { requireTelegramAuth } from "../../middleware/telegramAuth.js";
import {
  getMyProfile,
  getMyHistory,
  getMyStats,
  getMySummary,
} from "./me.controller.js";
import {
  submitMyTextEssay,
  submitMyPdfEssay,
  evaluateMyEssay,
} from "./me.essay.controller.js";
import { getLeaderboardHandler } from "../leaderboard/leaderboard.controller.js";
import {
  getStatus as getAiAnalysisStatus,
  generate as generateAiAnalysis,
  history as aiAnalysisHistory,
  getOne as aiAnalysisGetOne,
} from "../ai-analysis/ai-analysis.controller.js";
import {
  getStatus as getQuizStatus,
  generate as generateQuiz,
  submit as submitQuiz,
  history as quizHistory,
  getOne as quizGetOne,
} from "../quiz/quiz.controller.js";

const uploadsDir = path.join(process.cwd(), "uploads", "essays");
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => cb(null, `${randomUUID()}.pdf`),
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype !== "application/pdf") {
      return cb(new Error("Faqat PDF fayl qabul qilinadi"));
    }
    cb(null, true);
  },
});

const router = Router();

router.use(requireTelegramAuth);

router.get("/", getMyProfile);
router.get("/history", getMyHistory);
router.get("/stats", getMyStats);
router.get("/summary", getMySummary);
router.get("/leaderboard", getLeaderboardHandler);

router.post("/essays/text", submitMyTextEssay);
router.post("/essays/pdf", upload.single("file"), submitMyPdfEssay);
router.post("/essays/:essayId/evaluate", evaluateMyEssay);

router.get("/ai-analysis/status", getAiAnalysisStatus);
router.get("/ai-analysis/history", aiAnalysisHistory);
router.post("/ai-analysis", generateAiAnalysis);
router.get("/ai-analysis/:id", aiAnalysisGetOne);

router.get("/quiz/status", getQuizStatus);
router.get("/quiz/history", quizHistory);
router.post("/quiz/generate", generateQuiz);
router.post("/quiz/:quizId/submit", submitQuiz);
router.get("/quiz/:quizId", quizGetOne);

export default router;
