import { env } from "../../core/env.js";
import { getUserByTelegramId } from "../user/user.service.js";
import { sendTelegramMessage } from "../../integrations/telegram.js";
import {
  topUpBalance,
  getUserPayments,
  createPendingPayment,
  confirmPaymentByAmount,
} from "./payment.service.js";

export async function createTopUp(req, res, next) {
  try {
    const { telegramId, amount, note } = req.body;

    if (!telegramId || !amount) {
      return res.status(400).json({ error: "telegramId va amount majburiy" });
    }
    if (typeof amount !== "number" || amount <= 0) {
      return res
        .status(400)
        .json({ error: "amount musbat son bo'lishi kerak" });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const payment = await topUpBalance({ userId: user.id, amount, note });
    res.status(201).json(payment);
  } catch (error) {
    next(error);
  }
}

// Avtomatik to'lov uchun pending yozuv yaratadi va foydalanuvchiga
// ko'rsatiladigan to'lov ma'lumotlarini (ID, unikal summa, karta) qaytaradi.
export async function createPendingTopUp(req, res, next) {
  try {
    const { telegramId, amount, provider } = req.body;

    if (!telegramId || !amount) {
      return res.status(400).json({ error: "telegramId va amount majburiy" });
    }
    if (!Number.isInteger(amount) || amount < env.minTopupAmount) {
      return res.status(400).json({
        error: `Minimal to'lov summasi ${env.minTopupAmount} so'm`,
      });
    }

    if (!env.paymentCardNumber || !env.paymentCardHolder) {
      return res.status(500).json({
        error:
          "To'lov kartasi sozlanmagan (PAYMENT_CARD_NUMBER / PAYMENT_CARD_HOLDER)",
      });
    }

    const user = await getUserByTelegramId(telegramId);
    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const payment = await createPendingPayment({
      userId: user.id,
      requestedAmount: amount,
      provider: provider || null,
      cardNumber: env.paymentCardNumber,
      expiryMinutes: env.paymentExpiryMinutes,
    });

    res.status(201).json({
      id: payment.id,
      amount: payment.amount,
      requestedAmount: payment.requestedAmount,
      cardNumber: env.paymentCardNumber,
      cardHolder: env.paymentCardHolder,
      provider: payment.provider,
      expiresAt: payment.expiresAt,
      expiryMinutes: env.paymentExpiryMinutes,
    });
  } catch (error) {
    next(error);
  }
}

// Userbot bank/karta xabaridan olingan summani yuboradi; mos pending to'lov
// topilsa - tasdiqlanadi, balans qo'shiladi va foydalanuvchiga xabar beriladi.
export async function confirmByAmount(req, res, next) {
  try {
    const { amount } = req.body;

    if (!Number.isInteger(amount) || amount <= 0) {
      return res
        .status(400)
        .json({ error: "amount butun musbat son bo'lishi kerak" });
    }

    const result = await confirmPaymentByAmount(amount);
    if (!result) {
      // Mos pending to'lov yo'q - userbot buni "unmatched" deb log qiladi
      // (masalan begona o'tkazma yoki summa mos kelmadi).
      return res.status(200).json({ matched: false });
    }

    const { payment, user } = result;

    // Balans allaqachon qo'shildi; xabar yuborish xatosi tasdiqlashni
    // bekor qilmasligi kerak.
    try {
      await sendTelegramMessage(
        user.telegramId,
        "✅ <b>To'lovingiz qabul qilindi!</b>\n\n" +
          `💵 <b>${payment.amount}</b> so'm balansingizga qo'shildi.\n` +
          `💰 Joriy balans: <b>${user.balance}</b> so'm`,
      );
    } catch (error) {
      console.error(
        "To'lov tasdiqlash xabarini yuborishda xatolik:",
        error.message,
      );
    }

    res.status(200).json({
      matched: true,
      paymentId: payment.id,
      telegramId: user.telegramId,
      amount: payment.amount,
      balance: user.balance,
    });
  } catch (error) {
    next(error);
  }
}

export async function listPaymentsByTelegramId(req, res, next) {
  try {
    const { telegramId } = req.params;
    const user = await getUserByTelegramId(telegramId);

    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const payments = await getUserPayments(user.id);
    res.status(200).json(payments);
  } catch (error) {
    next(error);
  }
}
