import { Router } from "express";
import {
  createTopUp,
  createPendingTopUp,
  confirmByAmount,
  listPaymentsByTelegramId,
} from "./payment.controller.js";
import { requireAdmin } from "../../middleware/requireAdmin.js";

const router = Router();

router.post("/topup", requireAdmin, createTopUp);
router.post("/pending", requireAdmin, createPendingTopUp);
router.post("/confirm-by-amount", requireAdmin, confirmByAmount);
router.get("/user/:telegramId", listPaymentsByTelegramId);

export default router;
