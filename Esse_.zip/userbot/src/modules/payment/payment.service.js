import { Op } from "sequelize";

import { httpError } from "../../core/httpError.js";
import { sequelize } from "../../core/database.js";
import { Payment } from "./payment.model.js";
import { User } from "../user/user.model.js";
import { addBalance } from "../user/user.service.js";

// Foydalanuvchi kiritgan summaga qo'shiladigan qoldiq oralig'i (0..99).
// Bir vaqtda ko'p pending to'lov bo'lganda ham summalar unikal bo'lib turadi.
const UNIQUE_OFFSET_RANGE = 100;

export async function topUpBalance({ userId, amount, note }) {
  await addBalance(userId, amount);
  return Payment.create({ userId, amount, note, status: "confirmed" });
}

// "To'lovlarim" ro'yxatiga faqat haqiqatan amalga oshgan to'lovlar tushishi
// kerak - pending/expired yozuvlar bu yerga chiqmaydi.
export async function getUserPayments(userId) {
  return Payment.findAll({
    where: { userId, status: "confirmed" },
    order: [["createdAt", "DESC"]],
  });
}

// Muddati o'tgan pending to'lovlarni "expired"ga o'tkazamiz - shunda ular
// band qilib turgan unikal summalar boshqa foydalanuvchilarga bo'shaydi.
async function expireStalePayments() {
  await Payment.update(
    { status: "expired" },
    { where: { status: "pending", expiresAt: { [Op.lt]: new Date() } } },
  );
}

// Yangi pending to'lov yaratadi. Balans HALI qo'shilmaydi - u userbot
// bank SMS'ini solishtirib tasdiqlagandan keyin (keyingi bosqich) qo'shiladi.
export async function createPendingPayment({
  userId,
  requestedAmount,
  provider,
  cardNumber,
  expiryMinutes,
}) {
  await expireStalePayments();

  const expiresAt = new Date(Date.now() + expiryMinutes * 60 * 1000);

  // requestedAmount dan boshlab band bo'lmagan birinchi unikal summani
  // topamiz. DB'dagi partial unique index (status='pending') poyga holatidan
  // himoya qiladi - agar create shu sababdan xato bersa, keyingi offsetni
  // sinaymiz.
  for (let offset = 0; offset < UNIQUE_OFFSET_RANGE; offset++) {
    const amount = requestedAmount + offset;

    const busy = await Payment.findOne({
      where: { amount, status: "pending" },
    });
    if (busy) continue;

    try {
      return await Payment.create({
        userId,
        amount,
        requestedAmount,
        provider,
        cardNumber,
        status: "pending",
        expiresAt,
      });
    } catch (error) {
      if (error.name === "SequelizeUniqueConstraintError") continue;
      throw error;
    }
  }

  throw httpError(
    409,
    "Ayni damda bo'sh to'lov summasi topilmadi. Birozdan so'ng qayta urinib ko'ring.",
  );
}

// Bank/karta xabaridan kelgan summa bo'yicha mos pending to'lovni topib
// tasdiqlaydi va balansni qo'shadi. Butun amal bitta tranzaksiyada, qator
// bloklab (FOR UPDATE) bajariladi - shunda bir vaqtda ikki xabar kelsa ham
// balans ikki marta qo'shilib ketmaydi. Mos to'lov bo'lmasa null qaytaradi.
export async function confirmPaymentByAmount(amount) {
  await expireStalePayments();

  return sequelize.transaction(async (t) => {
    const payment = await Payment.findOne({
      where: { amount, status: "pending" },
      order: [["createdAt", "ASC"]],
      lock: t.LOCK.UPDATE,
      transaction: t,
    });
    if (!payment) return null;

    const user = await User.findByPk(payment.userId, {
      lock: t.LOCK.UPDATE,
      transaction: t,
    });
    if (!user) return null;

    user.balance += payment.amount;
    await user.save({ transaction: t });

    payment.status = "confirmed";
    await payment.save({ transaction: t });

    return { payment, user };
  });
}
