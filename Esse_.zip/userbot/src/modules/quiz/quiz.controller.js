import {
  getQuizStatus,
  generateMyQuiz,
  submitMyQuizAnswers,
  listMyQuizzes,
  getMyQuiz,
} from "./quiz.service.js";
import { getUserByTelegramId } from "../user/user.service.js";
import { httpError } from "../../core/httpError.js";

async function resolveUserId(req) {
  const user = await getUserByTelegramId(req.telegramUser.id);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");
  return user.id;
}

export async function getStatus(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const status = await getQuizStatus(userId);
    res.status(200).json(status);
  } catch (error) {
    next(error);
  }
}

export async function generate(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const result = await generateMyQuiz(userId);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
}

export async function submit(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const quizId = Number(req.params.quizId);
    const result = await submitMyQuizAnswers(userId, quizId, req.body.answers);
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
}

export async function history(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const quizzes = await listMyQuizzes(userId);
    res.status(200).json(quizzes);
  } catch (error) {
    next(error);
  }
}

export async function getOne(req, res, next) {
  try {
    const userId = await resolveUserId(req);
    const quiz = await getMyQuiz(userId, Number(req.params.quizId));
    res.status(200).json(quiz);
  } catch (error) {
    next(error);
  }
}
