import { Op } from "sequelize";

import { getUserById } from "../user/user.service.js";
import { getUserBandStats } from "../me/me.stats.service.js";
import { Quiz } from "./quiz.model.js";
import { generateQuizQuestions } from "./quiz.gpt.js";
import { httpError } from "../../core/httpError.js";
import { env } from "../../core/env.js";

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
// Savollarni juda ko'p mezonga sochib yubormaslik uchun faqat eng zaif
// bir nechta mezon asosida savol tuziladi (10 ta savol shular orasida
// mutanosib taqsimlanadi).
const MAX_WEAK_CRITERIA = 4;

// ai-analysis'dagi bilan bir xil hisoblash mantig'i - bepul urinish faqat
// "lastQuizAt" orqali kuzatiladi, pullik urinishlar bu vaqtni yangilamaydi.
function nextFreeAt(user) {
  if (!user.lastQuizAt) return null;
  return new Date(new Date(user.lastQuizAt).getTime() + WEEK_MS);
}

function isFreeEligible(user) {
  const next = nextFreeAt(user);
  return !next || next.getTime() <= Date.now();
}

function toPublicQuiz(quiz) {
  return {
    id: quiz.id,
    questions: quiz.questions,
    answers: quiz.answers,
    score: quiz.score,
    wasFree: quiz.wasFree,
    completedAt: quiz.completedAt,
    createdAt: quiz.createdAt,
  };
}

export async function getQuizStatus(userId) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const isFree = isFreeEligible(user);
  const next = nextFreeAt(user);

  const lastQuiz = await Quiz.findOne({
    where: { userId },
    order: [["createdAt", "DESC"]],
  });

  return {
    isFree,
    nextFreeAt: isFree ? null : next.toISOString(),
    price: env.quizPrice,
    balance: user.balance,
    lastQuiz: lastQuiz ? toPublicQuiz(lastQuiz) : null,
  };
}

export async function generateMyQuiz(userId) {
  const user = await getUserById(userId);
  if (!user) throw httpError(404, "Foydalanuvchi topilmadi");

  const isFree = isFreeEligible(user);

  if (!isFree && user.balance < env.quizPrice) {
    const next = nextFreeAt(user);
    throw httpError(
      402,
      `Haftalik bepul AI viktorina allaqachon ishlatilgan. Keyingi bepul ` +
        `urinish: ${next.toLocaleDateString("uz-UZ")}. Yoki hoziroq ` +
        `${env.quizPrice} so'm evaziga foydalanishingiz mumkin.`,
    );
  }

  const { essayCount, bands } = await getUserBandStats(userId);

  if (essayCount === 0) {
    throw httpError(
      400,
      "Viktorina tuzish uchun kamida bitta muvaffaqiyatli tekshirilgan esse kerak.",
    );
  }

  const weakBands = bands.slice(0, MAX_WEAK_CRITERIA).map((b) => ({
    criterionName: b.criterionName,
    averageScore: b.averageScore,
  }));

  const generated = await generateQuizQuestions(weakBands);

  const questions = generated.map((q, i) => ({ id: i + 1, ...q }));

  if (isFree) {
    user.lastQuizAt = new Date();
  } else {
    user.balance -= env.quizPrice;
  }
  await user.save();

  const quiz = await Quiz.create({
    userId,
    questions,
    wasFree: isFree,
  });

  return toPublicQuiz(quiz);
}

export async function submitMyQuizAnswers(userId, quizId, answers) {
  const quiz = await Quiz.findOne({ where: { id: quizId, userId } });
  if (!quiz) throw httpError(404, "Viktorina topilmadi");
  if (quiz.completedAt)
    throw httpError(400, "Bu viktorina allaqachon topshirilgan");

  if (!Array.isArray(answers) || answers.length !== quiz.questions.length) {
    throw httpError(400, "Barcha savollarga javob berilishi kerak");
  }

  const correctByQuestionId = new Map(
    quiz.questions.map((q) => [q.id, q.correctIndex]),
  );

  let score = 0;
  for (const answer of answers) {
    const correctIndex = correctByQuestionId.get(answer.questionId);
    if (correctIndex !== undefined && correctIndex === answer.selectedIndex) {
      score += 1;
    }
  }

  quiz.answers = answers;
  quiz.score = score;
  quiz.completedAt = new Date();
  await quiz.save();

  return toPublicQuiz(quiz);
}

export async function listMyQuizzes(userId) {
  const quizzes = await Quiz.findAll({
    where: { userId, completedAt: { [Op.ne]: null } },
    order: [["createdAt", "DESC"]],
  });
  return quizzes.map(toPublicQuiz);
}

export async function getMyQuiz(userId, quizId) {
  const quiz = await Quiz.findOne({ where: { id: quizId, userId } });
  if (!quiz) throw httpError(404, "Viktorina topilmadi");
  return toPublicQuiz(quiz);
}
