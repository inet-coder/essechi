import {
  createTopic,
  getActiveTopics,
  deactivateTopic,
} from "./topic.service.js";

export async function addTopic(req, res, next) {
  try {
    const { text } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ error: "text majburiy" });
    }

    const topic = await createTopic(text.trim());
    res.status(201).json(topic);
  } catch (error) {
    next(error);
  }
}

export async function listTopics(req, res, next) {
  try {
    const topics = await getActiveTopics();
    res.status(200).json(topics);
  } catch (error) {
    next(error);
  }
}

export async function removeTopic(req, res, next) {
  try {
    const { id } = req.params;
    const topic = await deactivateTopic(id);

    if (!topic) {
      return res.status(404).json({ error: "Mavzu topilmadi" });
    }

    res.status(200).json(topic);
  } catch (error) {
    next(error);
  }
}
