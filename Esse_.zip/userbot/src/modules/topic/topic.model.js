import { DataTypes } from "sequelize";
import { sequelize } from "../../core/database.js";

export const Topic = sequelize.define(
  "Topic",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    text: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    // Admin mavzuni o'chirib tashlamasdan, faollikdan chiqarishi mumkin
    // (eski/foydalanilmaydigan mavzularni ro'yxatdan olib tashlash uchun)
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    tableName: "topics",
    timestamps: true,
  },
);
