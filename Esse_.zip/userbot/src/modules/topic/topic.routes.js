import { Router } from "express";
import { requireAdmin } from "../../middleware/requireAdmin.js";
import { addTopic, listTopics, removeTopic } from "./topic.controller.js";

const router = Router();

router.get("/", listTopics);
router.post("/", requireAdmin, addTopic);
router.post("/:id/deactivate", requireAdmin, removeTopic);

export default router;
