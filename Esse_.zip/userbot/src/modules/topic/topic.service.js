import { Topic } from "./topic.model.js";

export async function createTopic(text) {
  return Topic.create({ text });
}

export async function getActiveTopics() {
  return Topic.findAll({
    where: { isActive: true },
    order: [["createdAt", "DESC"]],
  });
}

// "O'chirish" aslida soft-delete - hard delete qilinmaydi, chunki essalar
// topicId orqali bog'langan bo'lishi mumkin (reyting/tarix uchun kerak).
// Faollikdan chiqarilgan mavzu endi yangi esselarda ko'rsatilmaydi.
export async function deactivateTopic(id) {
  const topic = await Topic.findByPk(id);
  if (!topic) return null;
  topic.isActive = false;
  await topic.save();
  return topic;
}
