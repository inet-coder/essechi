import {
  findOrCreateUser,
  getUserByTelegramId,
  getAllTelegramIds,
} from "./user.service.js";
import { getUserSummary } from "../me/me.summary.service.js";

export async function registerUser(req, res, next) {
  try {
    const { telegramId, firstName, username } = req.body;

    if (!telegramId) {
      return res.status(400).json({ error: "telegramId majburiy" });
    }

    const user = await findOrCreateUser({ telegramId, firstName, username });
    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
}

export async function getUser(req, res, next) {
  try {
    const { telegramId } = req.params;
    const user = await getUserByTelegramId(telegramId);

    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
}

export async function getUserSummaryByTelegramId(req, res, next) {
  try {
    const { telegramId } = req.params;
    const user = await getUserByTelegramId(telegramId);

    if (!user) {
      return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    }

    const summary = await getUserSummary(user.id);
    res.status(200).json({ ...user.toJSON(), ...summary });
  } catch (error) {
    next(error);
  }
}

export async function listAllTelegramIds(req, res, next) {
  try {
    const telegramIds = await getAllTelegramIds();
    res.status(200).json(telegramIds);
  } catch (error) {
    next(error);
  }
}
