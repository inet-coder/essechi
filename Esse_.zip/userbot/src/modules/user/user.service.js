import { User } from "./user.model.js";

export async function findOrCreateUser({ telegramId, firstName, username }) {
  const [user] = await User.findOrCreate({
    where: { telegramId },
    defaults: { firstName, username },
  });
  return user;
}

export async function getUserByTelegramId(telegramId) {
  return User.findOne({ where: { telegramId } });
}

export async function getUserById(id) {
  return User.findByPk(id);
}

// Faqat broadcast (admin xabar yuborishi) uchun - minimal ma'lumot, butun
// User obyektini emas, faqat telegramId ro'yxatini qaytaradi.
export async function getAllTelegramIds() {
  const users = await User.findAll({ attributes: ["telegramId"] });
  return users.map((u) => u.telegramId);
}

export async function incrementAttemptsUsed(userId) {
  const user = await User.findByPk(userId);
  user.totalAttemptsUsed += 1;
  await user.save();
  return user;
}

export async function addBalance(userId, amount) {
  const user = await User.findByPk(userId);
  user.balance += amount;
  await user.save();
  return user;
}

export async function deductBalance(userId, amount) {
  const user = await User.findByPk(userId);
  user.balance -= amount;
  await user.save();
  return user;
}
